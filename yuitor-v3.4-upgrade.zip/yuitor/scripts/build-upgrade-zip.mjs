import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(__dirname, "..");
const OUT_ZIP = path.join(APP_ROOT, "dist-shared", "yuitor-v3.4-upgrade.zip");

const INCLUDE_TOP = [
  "server.js",
  "app.cjs",
  "package.json",
  "tsconfig.json",
  "vite.config.ts",
  "index.html",
  "metadata.json",
  ".env.example",
  ".gitignore",
  "htaccess.example",
  "README.md",
  "CHANGELOG.md",
  "DEPLOY.md",
  "DEPLOY-SHARED-HOSTING.md",
  "SECURITY_REPORT.md",
  "database",
  "server",
  "scripts",
  "src",
  "public"
];

const FORBIDDEN_RE = /(?:^|\/)(?:\.env(?:\.[^/]+)?$)|(?:\.(?:db|db-shm|db-wal|sqlite|sqlite3|log|zip)$)|(?:^|\/)\.DS_Store$/i;

const entries = [];
function collect(absPath, relPath) {
  const st = fs.lstatSync(absPath);
  if (st.isSymbolicLink()) return;
  if (st.isDirectory()) {
    for (const name of fs.readdirSync(absPath).sort()) {
      collect(path.join(absPath, name), `${relPath}/${name}`);
    }
    return;
  }
  const cleanRel = relPath.replace(/^yuitor\//, "");
  const base = path.posix.basename(cleanRel);
  if (base !== ".env.example" && FORBIDDEN_RE.test(cleanRel)) return;
  const raw = fs.readFileSync(absPath);
  const comp = zlib.deflateRawSync(raw, { level: 6 });
  const useDeflate = comp.length < raw.length;
  entries.push({
    name: relPath,
    data: useDeflate ? comp : raw,
    method: useDeflate ? 8 : 0,
    crc: zlib.crc32(raw) >>> 0,
    uncompressedSize: raw.length >>> 0
  });
}

for (const item of INCLUDE_TOP) {
  const abs = path.join(APP_ROOT, item);
  if (fs.existsSync(abs)) {
    collect(abs, `yuitor/${item}`);
  }
}

const chunks = [];
const central = [];
let offset = 0;
const UNIX_FILE_ATTR = ((0o100644 << 16) >>> 0);

for (const e of entries) {
  const nameBuf = Buffer.from(e.name, "utf8");
  const lfh = Buffer.alloc(30);
  lfh.writeUInt32LE(0x04034b50, 0);
  lfh.writeUInt16LE(20, 4);
  lfh.writeUInt16LE(0x0800, 6);
  lfh.writeUInt16LE(e.method, 8);
  lfh.writeUInt16LE(0, 10);
  lfh.writeUInt16LE(0x5421, 12);
  lfh.writeUInt32LE(e.crc, 14);
  lfh.writeUInt32LE(e.data.length >>> 0, 18);
  lfh.writeUInt32LE(e.uncompressedSize, 22);
  lfh.writeUInt16LE(nameBuf.length, 26);
  lfh.writeUInt16LE(0, 28);
  chunks.push(lfh, nameBuf, e.data);

  const cdh = Buffer.alloc(46);
  cdh.writeUInt32LE(0x02014b50, 0);
  cdh.writeUInt16LE(0x031e, 4);
  cdh.writeUInt16LE(20, 6);
  cdh.writeUInt16LE(0x0800, 8);
  cdh.writeUInt16LE(e.method, 10);
  cdh.writeUInt16LE(0, 12);
  cdh.writeUInt16LE(0x5421, 14);
  cdh.writeUInt32LE(e.crc, 16);
  cdh.writeUInt32LE(e.data.length >>> 0, 20);
  cdh.writeUInt32LE(e.uncompressedSize, 24);
  cdh.writeUInt16LE(nameBuf.length, 28);
  cdh.writeUInt16LE(0, 30);
  cdh.writeUInt16LE(0, 32);
  cdh.writeUInt16LE(0, 34);
  cdh.writeUInt16LE(0, 36);
  cdh.writeUInt32LE(UNIX_FILE_ATTR, 38);
  cdh.writeUInt32LE(offset >>> 0, 42);
  central.push(cdh, nameBuf);

  offset += lfh.length + nameBuf.length + e.data.length;
}

const cdBuf = Buffer.concat(central);
const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054b50, 0);
eocd.writeUInt16LE(0, 4);
eocd.writeUInt16LE(0, 6);
eocd.writeUInt16LE(entries.length, 8);
eocd.writeUInt16LE(entries.length, 10);
eocd.writeUInt32LE(cdBuf.length >>> 0, 12);
eocd.writeUInt32LE(offset >>> 0, 16);
eocd.writeUInt16LE(0, 20);

fs.mkdirSync(path.dirname(OUT_ZIP), { recursive: true });
const finalZip = Buffer.concat([...chunks, cdBuf, eocd]);
fs.writeFileSync(OUT_ZIP, finalZip);
console.log(`Built ${OUT_ZIP} (${entries.length} entries, ${(finalZip.length / (1024 * 1024)).toFixed(2)} MB)`);
