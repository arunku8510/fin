-- Yuitor Smart Classes — Add-on Schema: Referrals, Wallets, Withdrawals, Campaigns, Cart & Admin Search
-- Migration 002: Strictly additive tables (never drops or alters existing core tables destructively)

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS referral_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  referrals_enabled INTEGER NOT NULL DEFAULT 1,
  allow_student_referrals INTEGER NOT NULL DEFAULT 1,
  allow_teacher_referrals INTEGER NOT NULL DEFAULT 1,
  allow_self_referral INTEGER NOT NULL DEFAULT 0,
  required_fee_months INTEGER NOT NULL DEFAULT 3,
  yearly_plan_months_credit INTEGER NOT NULL DEFAULT 12,
  min_withdrawal_amount INTEGER NOT NULL DEFAULT 200,
  max_withdrawal_amount INTEGER NOT NULL DEFAULT 50000,
  require_admin_approval INTEGER NOT NULL DEFAULT 1,
  prevent_duplicate_withdrawals INTEGER NOT NULL DEFAULT 1,
  notify_in_app INTEGER NOT NULL DEFAULT 1,
  notify_email INTEGER NOT NULL DEFAULT 1,
  notify_sms INTEGER NOT NULL DEFAULT 0,
  notify_whatsapp INTEGER NOT NULL DEFAULT 0,
  terms_and_conditions TEXT NOT NULL DEFAULT '1. Share your unique Yuitor referral code or link with new Students.\n2. The referred Student must enter your code during registration and verify their account.\n3. Self-referrals, duplicate accounts, or fake registrations are disqualified automatically.\n4. A referral qualifies ONLY after the referred student successfully pays verified tuition fees for 3 complete months.\n5. Only verified and settled fee payments count (pending, failed, or refunded payments are excluded).\n6. Rewards follow cumulative milestones configured by Admin — only the additional difference is credited when unlocking a higher milestone.\n7. Refunds or fee reversals trigger automatic reward/progress recalculation and reversal entries.\n8. Withdrawals from Available Balance can be requested via UPI or Bank Transfer (subject to minimum limit and Admin approval). Pending Rewards cannot be withdrawn.',
  updated_at TEXT NOT NULL,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS referral_milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  qualified_count INTEGER NOT NULL UNIQUE CHECK (qualified_count >= 1),
  cumulative_reward INTEGER NOT NULL CHECK (cumulative_reward >= 0),
  title TEXT NOT NULL DEFAULT '',
  badge_label TEXT NOT NULL DEFAULT '',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS referral_campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  target_role TEXT NOT NULL DEFAULT 'all' CHECK (target_role IN ('all', 'student', 'teacher')),
  bonus_amount INTEGER NOT NULL DEFAULT 0 CHECK (bonus_amount >= 0),
  min_qualified_referrals INTEGER NOT NULL DEFAULT 1 CHECK (min_qualified_referrals >= 1),
  banner_cta TEXT NOT NULL DEFAULT 'Invite Now',
  starts_at TEXT,
  ends_at TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS referral_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('student', 'teacher')),
  referral_code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  total_referrals INTEGER NOT NULL DEFAULT 0,
  qualified_referrals INTEGER NOT NULL DEFAULT 0,
  pending_referrals INTEGER NOT NULL DEFAULT 0,
  total_rewards_credited INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_referral_profiles_code ON referral_profiles(referral_code);

CREATE TABLE IF NOT EXISTS referrals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referrer_role TEXT NOT NULL CHECK (referrer_role IN ('student', 'teacher')),
  referred_user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  referral_code_used TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'registered'
    CHECK (status IN ('registered', 'in_progress', 'qualified', 'rewarded', 'reversed', 'disqualified')),
  paid_months_count INTEGER NOT NULL DEFAULT 0,
  required_months INTEGER NOT NULL DEFAULT 3,
  verified_fees_total INTEGER NOT NULL DEFAULT 0,
  month1_paid INTEGER NOT NULL DEFAULT 0,
  month2_paid INTEGER NOT NULL DEFAULT 0,
  month3_paid INTEGER NOT NULL DEFAULT 0,
  month1_paid_at TEXT,
  month2_paid_at TEXT,
  month3_paid_at TEXT,
  qualified_at TEXT,
  reward_amount_credited INTEGER NOT NULL DEFAULT 0,
  pending_estimated_reward INTEGER NOT NULL DEFAULT 0,
  milestone_reached INTEGER NOT NULL DEFAULT 0,
  disqualification_reason TEXT NOT NULL DEFAULT '',
  signup_ip TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_user_id, status);
CREATE INDEX IF NOT EXISTS idx_referrals_referred ON referrals(referred_user_id);

CREATE TABLE IF NOT EXISTS referral_fee_progress_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referral_id INTEGER NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  payment_id INTEGER REFERENCES payments(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('payment_verified', 'payment_refunded', 'manual_recompute')),
  months_before INTEGER NOT NULL DEFAULT 0,
  months_after INTEGER NOT NULL DEFAULT 0,
  amount_delta INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS wallets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  wallet_type TEXT NOT NULL CHECK (wallet_type IN ('student', 'teacher')),
  available_balance INTEGER NOT NULL DEFAULT 0 CHECK (available_balance >= 0),
  pending_rewards INTEGER NOT NULL DEFAULT 0 CHECK (pending_rewards >= 0),
  pending_withdrawal_hold INTEGER NOT NULL DEFAULT 0 CHECK (pending_withdrawal_hold >= 0),
  total_earnings INTEGER NOT NULL DEFAULT 0 CHECK (total_earnings >= 0),
  withdrawn_amount INTEGER NOT NULL DEFAULT 0 CHECK (withdrawn_amount >= 0),
  referral_rewards_total INTEGER NOT NULL DEFAULT 0,
  is_frozen INTEGER NOT NULL DEFAULT 0,
  freeze_reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_wallets_type ON wallets(wallet_type, is_frozen);

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tx_code TEXT NOT NULL UNIQUE,
  wallet_id INTEGER NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tx_type TEXT NOT NULL CHECK (tx_type IN ('credit', 'debit')),
  category TEXT NOT NULL DEFAULT 'referral_reward'
    CHECK (category IN ('referral_reward', 'campaign_bonus', 'reward_reversal', 'withdrawal_hold', 'withdrawal_refund', 'withdrawal_paid', 'admin_credit', 'admin_debit')),
  amount INTEGER NOT NULL CHECK (amount >= 0),
  credit_amount INTEGER NOT NULL DEFAULT 0,
  debit_amount INTEGER NOT NULL DEFAULT 0,
  remaining_balance INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'reversed', 'cancelled')),
  reference_type TEXT NOT NULL DEFAULT '',
  reference_id TEXT NOT NULL DEFAULT '',
  idempotency_key TEXT UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_wtx_user_created ON wallet_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wtx_wallet ON wallet_transactions(wallet_id, id DESC);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_code TEXT NOT NULL UNIQUE,
  wallet_id INTEGER NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_role TEXT NOT NULL CHECK (user_role IN ('student', 'teacher')),
  amount INTEGER NOT NULL CHECK (amount > 0),
  payout_method TEXT NOT NULL CHECK (payout_method IN ('upi', 'bank')),
  upi_id TEXT NOT NULL DEFAULT '',
  account_holder_name TEXT NOT NULL DEFAULT '',
  bank_name TEXT NOT NULL DEFAULT '',
  account_number TEXT NOT NULL DEFAULT '',
  ifsc_code TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'under_review', 'approved', 'processing', 'paid', 'rejected')),
  admin_note TEXT NOT NULL DEFAULT '',
  payout_reference TEXT NOT NULL DEFAULT '',
  reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TEXT,
  paid_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_user_status ON withdrawal_requests(user_id, status);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawal_requests(status, created_at DESC);

CREATE TABLE IF NOT EXISTS cart_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  guest_token TEXT NOT NULL DEFAULT '',
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  plan TEXT NOT NULL DEFAULT '1m' CHECK (plan IN ('monthly', '1m', '3m', '6m', '9m', 'yearly')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_cart_guest ON cart_items(guest_token);

CREATE TABLE IF NOT EXISTS cart_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_code TEXT NOT NULL UNIQUE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  items_json TEXT NOT NULL DEFAULT '[]',
  subtotal_amount INTEGER NOT NULL DEFAULT 0,
  discount_amount INTEGER NOT NULL DEFAULT 0,
  total_amount INTEGER NOT NULL DEFAULT 0,
  coupon_code TEXT NOT NULL DEFAULT '',
  payment_method TEXT NOT NULL DEFAULT 'upi' CHECK (payment_method IN ('upi', 'cash', 'gateway')),
  utr_reference TEXT NOT NULL DEFAULT '',
  gateway_order_id TEXT NOT NULL DEFAULT '',
  gateway_payment_id TEXT NOT NULL DEFAULT '',
  verification_status TEXT NOT NULL DEFAULT 'pending_verification'
    CHECK (verification_status IN ('pending_verification', 'verified', 'failed', 'refunded')),
  invoice_number TEXT NOT NULL DEFAULT '',
  receipt_number TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cart_orders_student ON cart_orders(student_id, id DESC);

CREATE TABLE IF NOT EXISTS admin_search_preferences (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  recent_searches_json TEXT NOT NULL DEFAULT '[]',
  recent_pages_json TEXT NOT NULL DEFAULT '[]',
  pinned_pages_json TEXT NOT NULL DEFAULT '[]',
  frequent_settings_json TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL
);
