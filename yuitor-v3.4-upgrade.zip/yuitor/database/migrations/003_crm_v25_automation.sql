-- Yuitor Smart Institute CRM v2.5.0 — Automation, Hybrid Coaching & Operations Upgrade
-- Safe additive migration: preserves all existing tables and data.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS crm_automation_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  global_kill_switch INTEGER NOT NULL DEFAULT 0,
  quiet_hours_enabled INTEGER NOT NULL DEFAULT 1,
  quiet_start_hour INTEGER NOT NULL DEFAULT 21,
  quiet_end_hour INTEGER NOT NULL DEFAULT 8,
  max_auto_messages_per_day INTEGER NOT NULL DEFAULT 3,
  fee_reminders_enabled INTEGER NOT NULL DEFAULT 1,
  fee_reminder_schedule_json TEXT NOT NULL DEFAULT '[-7,-3,0,1,3,7,15]',
  absent_alerts_enabled INTEGER NOT NULL DEFAULT 1,
  low_attendance_threshold INTEGER NOT NULL DEFAULT 75,
  consecutive_absent_task_days INTEGER NOT NULL DEFAULT 3,
  defaulter_soft_lock_enabled INTEGER NOT NULL DEFAULT 0,
  defaulter_soft_lock_days INTEGER NOT NULL DEFAULT 15,
  doubt_sla_hours INTEGER NOT NULL DEFAULT 12,
  monthly_fee_auto_generate INTEGER NOT NULL DEFAULT 1,
  monthly_fee_due_day INTEGER NOT NULL DEFAULT 10,
  payroll_draft_day INTEGER NOT NULL DEFAULT 25,
  renewal_campaign_days_before INTEGER NOT NULL DEFAULT 45,
  whatsapp_api_enabled INTEGER NOT NULL DEFAULT 0,
  sms_dlt_enabled INTEGER NOT NULL DEFAULT 0,
  email_channel_enabled INTEGER NOT NULL DEFAULT 1,
  founder_report_email TEXT NOT NULL DEFAULT '',
  founder_report_phone TEXT NOT NULL DEFAULT '',
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crm_automation_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  event_name TEXT NOT NULL,
  conditions_json TEXT NOT NULL DEFAULT '{}',
  actions_json TEXT NOT NULL DEFAULT '[]',
  priority INTEGER NOT NULL DEFAULT 100,
  version INTEGER NOT NULL DEFAULT 1,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  execution_count INTEGER NOT NULL DEFAULT 0,
  last_executed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_rules_event ON crm_automation_rules(event_name, is_enabled, priority);

CREATE TABLE IF NOT EXISTS crm_automation_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_name TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  entity_type TEXT NOT NULL DEFAULT '',
  entity_id TEXT NOT NULL DEFAULT '',
  payload_json TEXT NOT NULL DEFAULT '{}',
  matched_rules INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'processed',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_events_created ON crm_automation_events(created_at DESC);

CREATE TABLE IF NOT EXISTS crm_job_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_type TEXT NOT NULL,
  rule_key TEXT NOT NULL DEFAULT '',
  idempotency_key TEXT NOT NULL UNIQUE,
  payload_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'running', 'completed', 'failed', 'dead_letter', 'cancelled')),
  attempts INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 3,
  next_run_at TEXT NOT NULL,
  locked_at TEXT,
  completed_at TEXT,
  last_error TEXT NOT NULL DEFAULT '',
  result_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_jobs_status_next ON crm_job_queue(status, next_run_at);

CREATE TABLE IF NOT EXISTS crm_scheduler_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_name TEXT NOT NULL,
  run_key TEXT NOT NULL UNIQUE,
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed', 'skipped')),
  started_at TEXT NOT NULL,
  finished_at TEXT,
  duration_ms INTEGER NOT NULL DEFAULT 0,
  summary_json TEXT NOT NULL DEFAULT '{}',
  error_message TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_crm_sched_job ON crm_scheduler_runs(job_name, started_at DESC);

CREATE TABLE IF NOT EXISTS crm_exception_inbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL DEFAULT 'failed_job',
  severity TEXT NOT NULL DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  entity_type TEXT NOT NULL DEFAULT '',
  entity_id TEXT NOT NULL DEFAULT '',
  details_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'approved', 'retried', 'resolved', 'ignored')),
  escalation_level TEXT NOT NULL DEFAULT 'staff' CHECK (escalation_level IN ('system', 'staff', 'team_lead', 'owner')),
  assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
  resolved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  resolution_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_exceptions_status ON crm_exception_inbox(status, severity, created_at DESC);

CREATE TABLE IF NOT EXISTS crm_message_consent (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  whatsapp_opt_in INTEGER NOT NULL DEFAULT 1,
  sms_opt_in INTEGER NOT NULL DEFAULT 1,
  email_opt_in INTEGER NOT NULL DEFAULT 1,
  marketing_opt_in INTEGER NOT NULL DEFAULT 1,
  parent_consent_under18 INTEGER NOT NULL DEFAULT 0,
  opted_out_all INTEGER NOT NULL DEFAULT 0,
  opt_out_reason TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_consent_phone ON crm_message_consent(phone) WHERE phone != '';
CREATE INDEX IF NOT EXISTS idx_crm_consent_user ON crm_message_consent(user_id);

CREATE TABLE IF NOT EXISTS crm_lead_activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inquiry_id INTEGER NOT NULL REFERENCES inquiries(id) ON DELETE CASCADE,
  actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_name TEXT NOT NULL DEFAULT 'System',
  activity_type TEXT NOT NULL DEFAULT 'note',
  summary TEXT NOT NULL,
  next_followup_at TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_lead_act_inq ON crm_lead_activities(inquiry_id, created_at DESC);

CREATE TABLE IF NOT EXISTS crm_counsellor_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_type TEXT NOT NULL DEFAULT 'followup',
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  inquiry_id INTEGER REFERENCES inquiries(id) ON DELETE CASCADE,
  assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  due_date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'dismissed')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_tasks_status ON crm_counsellor_tasks(status, due_date);

CREATE TABLE IF NOT EXISTS crm_financial_approvals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_type TEXT NOT NULL CHECK (request_type IN ('discount', 'waiver', 'refund', 'fee_adjustment')),
  student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  fee_record_id INTEGER REFERENCES fee_records(id) ON DELETE SET NULL,
  payment_id INTEGER REFERENCES payments(id) ON DELETE SET NULL,
  amount INTEGER NOT NULL DEFAULT 0,
  reason TEXT NOT NULL DEFAULT '',
  requested_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  review_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  reviewed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_crm_fin_appr_status ON crm_financial_approvals(status, created_at DESC);

CREATE TABLE IF NOT EXISTS crm_payment_reconciliations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_at TEXT NOT NULL,
  checked_count INTEGER NOT NULL DEFAULT 0,
  verified_count INTEGER NOT NULL DEFAULT 0,
  pending_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  duplicate_count INTEGER NOT NULL DEFAULT 0,
  summary_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS crm_study_materials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  subject_name TEXT NOT NULL DEFAULT 'General',
  chapter_name TEXT NOT NULL DEFAULT 'Chapter 1',
  material_type TEXT NOT NULL DEFAULT 'notes'
    CHECK (material_type IN ('notes', 'dpp', 'pyq', 'assignment', 'homework', 'practice_set')),
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  file_url TEXT NOT NULL DEFAULT '',
  file_name TEXT NOT NULL DEFAULT '',
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_materials_course_batch ON crm_study_materials(course_id, batch_id, material_type);

CREATE TABLE IF NOT EXISTS crm_doubts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  subject_name TEXT NOT NULL DEFAULT 'Mathematics',
  chapter_name TEXT NOT NULL DEFAULT '',
  question_text TEXT NOT NULL DEFAULT '',
  question_image_url TEXT NOT NULL DEFAULT '',
  assigned_teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'answered', 'resolved', 'escalated')),
  sla_due_at TEXT NOT NULL,
  sla_breached INTEGER NOT NULL DEFAULT 0,
  reply_text TEXT NOT NULL DEFAULT '',
  reply_attachment_url TEXT NOT NULL DEFAULT '',
  replied_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  replied_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crm_doubts_teacher_status ON crm_doubts(assigned_teacher_id, status, sla_due_at);
CREATE INDEX IF NOT EXISTS idx_crm_doubts_student ON crm_doubts(student_id, created_at DESC);

CREATE TABLE IF NOT EXISTS crm_live_class_joins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timetable_slot_id INTEGER NOT NULL REFERENCES timetable_slots(id) ON DELETE CASCADE,
  session_date TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_role TEXT NOT NULL DEFAULT 'student',
  joined_at TEXT NOT NULL,
  last_heartbeat_at TEXT NOT NULL,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  platform_verified INTEGER NOT NULL DEFAULT 0,
  attendance_marked INTEGER NOT NULL DEFAULT 0,
  UNIQUE(timetable_slot_id, session_date, user_id)
);

CREATE TABLE IF NOT EXISTS crm_student_risk_scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  calculated_date TEXT NOT NULL,
  risk_score INTEGER NOT NULL DEFAULT 0,
  risk_level TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  attendance_percent REAL NOT NULL DEFAULT 100,
  overdue_days INTEGER NOT NULL DEFAULT 0,
  avg_test_percent REAL NOT NULL DEFAULT 0,
  weak_topics_json TEXT NOT NULL DEFAULT '[]',
  recommended_action TEXT NOT NULL DEFAULT '',
  retest_scheduled_date TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  UNIQUE(student_id, calculated_date)
);

CREATE TABLE IF NOT EXISTS crm_daily_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_date TEXT NOT NULL,
  report_type TEXT NOT NULL DEFAULT 'founder_8pm' CHECK (report_type IN ('founder_8pm', 'owner_930pm', 'weekly_monday')),
  metrics_json TEXT NOT NULL DEFAULT '{}',
  summary_text TEXT NOT NULL DEFAULT '',
  dispatched_channels TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  UNIQUE(report_date, report_type)
);

CREATE TABLE IF NOT EXISTS crm_marketing_campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  utm_source TEXT NOT NULL DEFAULT 'website',
  utm_medium TEXT NOT NULL DEFAULT 'organic',
  utm_campaign TEXT NOT NULL DEFAULT '',
  budget_amount INTEGER NOT NULL DEFAULT 0,
  spend_amount INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  target_cpa INTEGER NOT NULL DEFAULT 1500,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crm_batch_waitlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  inquiry_id INTEGER REFERENCES inquiries(id) ON DELETE SET NULL,
  student_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  student_name TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'promoted', 'cancelled')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crm_document_checklists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  photo_submitted INTEGER NOT NULL DEFAULT 0,
  id_proof_submitted INTEGER NOT NULL DEFAULT 0,
  marksheet_submitted INTEGER NOT NULL DEFAULT 0,
  parent_consent_submitted INTEGER NOT NULL DEFAULT 0,
  id_card_issued INTEGER NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crm_counsellor_incentives (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  salary_month TEXT NOT NULL,
  admissions_count INTEGER NOT NULL DEFAULT 0,
  rate_per_admission INTEGER NOT NULL DEFAULT 250,
  total_incentive INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'approved', 'paid')),
  updated_at TEXT NOT NULL,
  UNIQUE(staff_user_id, salary_month)
);

-- Student / Teacher / Staff Exit Settlement, Alumni Archive & 1-Click Rejoin
CREATE TABLE IF NOT EXISTS crm_member_exits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('student', 'teacher', 'staff')),
  exit_category TEXT NOT NULL DEFAULT 'dropped_out',
  exit_date TEXT NOT NULL,
  exit_reason TEXT NOT NULL DEFAULT '',
  dues_action TEXT NOT NULL DEFAULT 'keep_due',
  dues_amount_snapshot INTEGER NOT NULL DEFAULT 0,
  settlement_note TEXT NOT NULL DEFAULT '',
  previous_enrollments_json TEXT NOT NULL DEFAULT '[]',
  handover_teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reminders_stopped INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'left' CHECK (status IN ('left', 'rejoined')),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  rejoined_at TEXT NOT NULL DEFAULT '',
  rejoined_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  rejoin_note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_crm_member_exits_role_status ON crm_member_exits(role, status, id DESC);
CREATE INDEX IF NOT EXISTS idx_crm_member_exits_user ON crm_member_exits(user_id, status);

-- Teacher Leave -> Auto Substitute Assignment & Batch Student Notification
CREATE TABLE IF NOT EXISTS crm_leave_substitutions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  leave_request_id INTEGER NOT NULL,
  absent_teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  substitute_teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  timetable_slot_id INTEGER REFERENCES timetable_slots(id) ON DELETE SET NULL,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  from_date TEXT NOT NULL DEFAULT '',
  to_date TEXT NOT NULL DEFAULT '',
  students_notified INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned', 'completed', 'cancelled')),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crm_leave_subs_leave ON crm_leave_substitutions(leave_request_id);
CREATE INDEX IF NOT EXISTS idx_crm_leave_subs_sub ON crm_leave_substitutions(substitute_teacher_id, status);

-- Anonymous / Private Student Feedback & Teacher Rating
CREATE TABLE IF NOT EXISTS crm_student_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  subject_name TEXT NOT NULL DEFAULT '',
  topic_unclear TEXT NOT NULL DEFAULT '',
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  clarity_rating INTEGER NOT NULL DEFAULT 5 CHECK (clarity_rating BETWEEN 1 AND 5),
  pace_tag TEXT NOT NULL DEFAULT 'just_right' CHECK (pace_tag IN ('too_fast', 'just_right', 'too_slow')),
  feedback_text TEXT NOT NULL DEFAULT '',
  is_anonymous INTEGER NOT NULL DEFAULT 1,
  admin_reviewed INTEGER NOT NULL DEFAULT 0,
  admin_action_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crm_feedback_teacher ON crm_student_feedback(teacher_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_crm_feedback_student ON crm_student_feedback(student_id, id DESC);

-- Birthday Wishing & Role-Wise New Joining Welcome Mail Audit Logs
CREATE TABLE IF NOT EXISTS crm_celebration_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'student',
  event_type TEXT NOT NULL CHECK (event_type IN ('birthday', 'welcome_joining')),
  year_key TEXT NOT NULL DEFAULT '',
  channel TEXT NOT NULL DEFAULT 'email_and_portal',
  recipient_email TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'sent',
  sent_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_celeb_bday_once
  ON crm_celebration_logs(user_id, event_type, year_key) WHERE event_type = 'birthday';
CREATE INDEX IF NOT EXISTS idx_crm_celeb_created ON crm_celebration_logs(created_at DESC);


