// Yuitor Smart Classes v3.3 — Dynamic Pricing, Advanced Invoicing, Smart Upgrades,
// Cross-Selling/Upselling, Add-Ons, Automated Follow-Ups, Renewal & Revenue Analytics Engine.
// Strictly additive & backward-compatible with existing v3.0 / v3.1 / v3.2 tables and workflows.

import crypto from "node:crypto";
import { nowIso } from "./addons-db.mjs";
import { escapeHtml, getIstDateKey, logV31Audit } from "./v31-engine.mjs";

export const V33_VERSION = "3.3.0";

export const DEFAULT_SCHOOL_SUBJECT_FEES = {
  "6": 600,
  "7": 650,
  "8": 700,
  "9": 750,
  "10": 800,
  "11": 850,
  "12": 900,
};

export const CLASS_SUBJECT_CATALOG = {
  "6": ["Mathematics", "Science", "English", "SST", "Hindi", "Computer", "Sanskrit"],
  "7": ["Mathematics", "Science", "English", "SST", "Hindi", "Computer", "Sanskrit"],
  "8": ["Mathematics", "Science", "English", "SST", "Hindi", "Computer", "Sanskrit"],
  "9": ["Mathematics", "Science", "English", "SST", "Hindi", "Computer"],
  "10": ["Mathematics", "Science", "English", "SST", "Hindi", "Computer"],
  "11": ["Physics", "Chemistry", "Mathematics", "Biology", "English", "Accountancy", "Business Studies", "Economics", "Computer"],
  "12": ["Physics", "Chemistry", "Mathematics", "Biology", "English", "Accountancy", "Business Studies", "Economics", "Computer"],
};

export const DEFAULT_DURATION_DISCOUNTS = {
  "1": 0,
  "3": 5,
  "6": 10,
  "9": 15,
  "12": 20,
};

export const DEFAULT_MULTI_SUBJECT_SLABS = [
  { minSubjects: 2, discountPercent: 5, label: "2 Subjects Combo (5% OFF)", active: true },
  { minSubjects: 3, discountPercent: 10, label: "3 Subjects Combo (10% OFF)", active: true },
  { minSubjects: 4, discountPercent: 15, label: "4 Subjects Combo (15% OFF)", active: true },
  { minSubjects: 5, discountPercent: 20, label: "5+ Subjects Combo (20% OFF)", active: true },
];

export const DEFAULT_RENEWAL_OFFSETS = [30, 15, 7, 3, 1];

export const DEFAULT_DISCOUNT_PRIORITY = [
  "bundle",
  "duration",
  "multi_subject",
  "promo_offer",
  "scholarship",
  "coupon",
];

const SEED_BRANCHES = [
  { name: "Muradnagar Branch", code: "MRD-01", city: "Muradnagar", address: "Main Market, Muradnagar, Ghaziabad", phone: "+91 7827289292" },
  { name: "Modinagar Branch", code: "MDN-02", city: "Modinagar", address: "GT Road, Modinagar, Ghaziabad", phone: "+91 7827289292" },
  { name: "Ghaziabad Branch", code: "GZB-03", city: "Ghaziabad", address: "Raj Nagar District Centre, Ghaziabad", phone: "+91 7827289292" },
  { name: "Online Branch", code: "ONL-04", city: "Online", address: "Live Online Smart Classes (Pan-India)", phone: "+91 7827289292" },
];

const SEED_COURSES_V33 = [
  // Competitive Exams
  { title: "JEE Foundation", slug: "jee-foundation", category: "Competitive Exams", class_range: "Class 9th-12th", board: "CBSE / NCERT", monthly_fee: 1200, description: "Strong JEE Main & Advanced foundation in Physics, Chemistry & Mathematics." },
  { title: "NEET Foundation", slug: "neet-foundation", category: "Competitive Exams", class_range: "Class 9th-12th", board: "CBSE / NCERT", monthly_fee: 1200, description: "NCERT-first NEET Medical foundation in Biology, Physics & Chemistry." },
  { title: "CUET Preparation", slug: "cuet-preparation", category: "Competitive Exams", class_range: "Class 12th", board: "NTA CUET", monthly_fee: 900, description: "Complete CUET Domain + General Test + Language preparation with mock tests." },
  { title: "NDA Preparation", slug: "nda-preparation", category: "Competitive Exams", class_range: "Class 11th-12th", board: "UPSC NDA", monthly_fee: 900, description: "UPSC NDA Mathematics + GAT coaching with weekly SSB & mock drills." },
  { title: "SSC Exam Batch", slug: "ssc-exam-batch", category: "Competitive Exams", class_range: "12th / Graduate", board: "SSC CGL/CHSL/GD", monthly_fee: 700, description: "Quant, Reasoning, English & General Studies batch for Muradnagar & NCR aspirants." },
  { title: "Banking Exam Batch", slug: "banking-exam-batch", category: "Competitive Exams", class_range: "Graduate", board: "IBPS / SBI / RRB", monthly_fee: 700, description: "Quantitative Aptitude, Reasoning, English & Current Affairs with speed tests." },
  { title: "Railways Exam Batch", slug: "railways-exam-batch", category: "Competitive Exams", class_range: "10th / 12th+", board: "RRB NTPC / Group D", monthly_fee: 700, description: "Complete RRB NTPC, ALP & Group D syllabus coverage with PYQ series." },
  { title: "CDS Preparation", slug: "cds-preparation", category: "Competitive Exams", class_range: "Graduate", board: "UPSC CDS", monthly_fee: 900, description: "Officer-level CDS English, General Knowledge & Elementary Mathematics." },
  { title: "AFCAT Preparation", slug: "afcat-preparation", category: "Competitive Exams", class_range: "Graduate", board: "IAF AFCAT", monthly_fee: 900, description: "Targeted AFCAT Verbal, Numerical Ability, Reasoning & Military Aptitude." },
  { title: "Olympiad Foundation", slug: "olympiad-foundation", category: "Competitive Exams", class_range: "Class 6th-10th", board: "SOF / NTSE", monthly_fee: 600, description: "Maths & Science Olympiad problem-solving and logical reasoning mastery." },
  { title: "Foundation Batch", slug: "foundation-batch", category: "Foundation Courses", class_range: "Class 6th-10th", board: "CBSE / ICSE / UP", monthly_fee: 800, description: "Integrated School + Competitive Foundation program with regular assessments." },
  // Technology Courses
  { title: "Coding Classes", slug: "coding-classes", category: "Technology Courses", class_range: "Class 6th-12th", board: "Practical Tech", monthly_fee: 800, description: "Hands-on coding logic, Scratch, HTML/CSS/JS & real mini-projects for students." },
  { title: "AI Classes", slug: "ai-classes", category: "Technology Courses", class_range: "Class 8th-12th+", board: "Practical Tech", monthly_fee: 1200, description: "Practical Artificial Intelligence, Prompt Engineering, ML basics & AI tools." },
  { title: "Python Programming", slug: "python-programming", category: "Technology Courses", class_range: "Class 8th-12th+", board: "CBSE CS / Tech", monthly_fee: 1000, description: "Zero-to-pro Python programming aligned with CBSE CS & real automation projects." },
  { title: "Web Development", slug: "web-development", category: "Technology Courses", class_range: "Class 9th-12th+", board: "Full-Stack", monthly_fee: 1200, description: "Build responsive modern websites with HTML5, CSS, JavaScript & React." },
  { title: "App Development", slug: "app-development", category: "Technology Courses", class_range: "Class 9th-12th+", board: "Mobile Tech", monthly_fee: 1200, description: "Design and build practical Android & cross-platform mobile apps." },
  { title: "Data Science Basics", slug: "data-science-basics", category: "Technology Courses", class_range: "Class 11th-12th+", board: "Analytics", monthly_fee: 1200, description: "Data analysis with Python, spreadsheets, charts & introductory ML models." },
  // Communication & Language Courses
  { title: "English Speaking", slug: "english-speaking", category: "Communication & Language", class_range: "All Ages", board: "Fluency", monthly_fee: 700, description: "Daily speaking practice, pronunciation, vocabulary & confidence building." },
  { title: "Spoken English", slug: "spoken-english", category: "Communication & Language", class_range: "Class 6th-12th+", board: "Fluency", monthly_fee: 700, description: "Structured grammar + conversational Spoken English for school & college learners." },
  { title: "Communication Skills", slug: "communication-skills", category: "Communication & Language", class_range: "Class 8th-12th+", board: "Soft Skills", monthly_fee: 800, description: "Public speaking, stage confidence, active listening & group discussions." },
  { title: "Personality Development", slug: "personality-development", category: "Communication & Language", class_range: "Class 9th-12th+", board: "Soft Skills", monthly_fee: 800, description: "Body language, leadership etiquette, presentation skills & goal setting." },
  { title: "Interview Preparation", slug: "interview-preparation", category: "Communication & Language", class_range: "12th / College", board: "Career Prep", monthly_fee: 1000, description: "Mock interviews, resume polishing, HR & technical Q&A confidence training." },
];

const SEED_BUNDLES = [
  { code: "JEE-PKG", name: "JEE Package", category: "Competitive Exams", class_level: "Class 11th-12th", subjects: ["Physics", "Chemistry", "Mathematics"], base_monthly_price: 2550, discount_percent: 15, description: "Physics + Chemistry + Mathematics integrated JEE bundle." },
  { code: "NEET-PKG", name: "NEET Package", category: "Competitive Exams", class_level: "Class 11th-12th", subjects: ["Physics", "Chemistry", "Biology"], base_monthly_price: 2550, discount_percent: 15, description: "Physics + Chemistry + Biology integrated NEET Medical bundle." },
  { code: "SSC-PKG", name: "SSC Package", category: "Competitive Exams", class_level: "Competitive", subjects: ["Quant", "Reasoning", "English", "General Studies"], base_monthly_price: 2400, discount_percent: 20, description: "Quant + Reasoning + English + General Studies complete SSC bundle." },
  { code: "BANK-PKG", name: "Banking Package", category: "Competitive Exams", class_level: "Competitive", subjects: ["Quantitative Aptitude", "English", "Reasoning", "Current Affairs"], base_monthly_price: 2400, discount_percent: 20, description: "Quantitative Aptitude + English + Reasoning + Current Affairs Banking bundle." },
  { code: "COMPLETE-SCHOOL", name: "Complete School Package", category: "School", class_level: "All Classes (6th-12th)", subjects: ["Mathematics", "Science", "English", "SST", "Hindi", "Computer"], base_monthly_price: 4200, discount_percent: 25, description: "All available subjects of the selected class with 25% Complete Package savings." },
  { code: "C10-MS", name: "Class 10 Maths + Science", category: "School", class_level: "Class 10th", subjects: ["Mathematics", "Science"], base_monthly_price: 1600, discount_percent: 10, description: "Core Board Exam combo for Class 10th Mathematics & Science." },
  { code: "C10-MSE", name: "Class 10 Maths + Science + English", category: "School", class_level: "Class 10th", subjects: ["Mathematics", "Science", "English"], base_monthly_price: 2400, discount_percent: 15, description: "High-scoring Class 10th triple-subject board combo." },
  { code: "C10-ALL", name: "Complete Class 10", category: "School", class_level: "Class 10th", subjects: ["Mathematics", "Science", "English", "SST", "Hindi", "Computer"], base_monthly_price: 4800, discount_percent: 25, description: "Complete Class 10th all-subject Board Mastery package." },
];

const SEED_SCHOLARSHIPS = [
  { code: "MERIT20", name: "Merit Scholarship", scholarship_type: "merit", discount_type: "percent", discount_value: 20, eligibility: "90%+ in previous exam or Yuitor scholarship test", priority: 10, max_uses: 500 },
  { code: "GIRLCHILD15", name: "Girl Child Scholarship", scholarship_type: "girl_child", discount_type: "percent", discount_value: 15, eligibility: "Empowering girl students across Classes 6th–12th & Competitive batches", priority: 20, max_uses: 1000 },
  { code: "REFERRAL10", name: "Referral Discount", scholarship_type: "referral", discount_type: "percent", discount_value: 10, eligibility: "Referred by an active Yuitor Student or Teacher", priority: 30, max_uses: 2000 },
  { code: "FESTIVAL15", name: "Festival Discount", scholarship_type: "festival", discount_type: "percent", discount_value: 15, eligibility: "Limited-period festival enrollment offer", priority: 40, max_uses: 1000 },
  { code: "EARLYBIRD10", name: "Early Bird Discount", scholarship_type: "early_bird", discount_type: "percent", discount_value: 10, eligibility: "Admissions confirmed before new batch start date", priority: 50, max_uses: 500 },
  { code: "FINAID25", name: "Financial Assistance Discount", scholarship_type: "financial_aid", discount_type: "percent", discount_value: 25, eligibility: "Need-based support approved by Branch Director", priority: 5, max_uses: 200 },
];

const SEED_ADDONS = [
  { code: "ADD-TESTSERIES", title: "Weekly & Board Test Series", category: "Test Series", price: 499, description: "Chapter-wise + Full Syllabus OMR & CBT mock test series with rank analysis." },
  { code: "ADD-NOTES", title: "Handwritten Topper Notes Pack", category: "Handwritten Notes", price: 399, description: "Structured chapter-wise handwritten revision notes & formula sheets." },
  { code: "ADD-EBOOK", title: "NCERT & Exemplar E-Books Bundle", category: "E-Books", price: 299, description: "Curated digital reference books & solved question bank PDFs." },
  { code: "ADD-RECORDED", title: "Recorded Revision Classes Access", category: "Recorded Classes", price: 699, description: "Unlimited HD recorded concept lectures for anytime revision." },
  { code: "ADD-ASSIGN", title: "Chapter Assignment & DPP Pack", category: "Assignment Packs", price: 249, description: "Daily Practice Problems (DPPs) with detailed step-by-step solutions." },
  { code: "ADD-PYQ", title: "10-Year PYQ & Sample Paper Pack", category: "PYQ Packs", price: 349, description: "Last 10 years board/exam PYQs with marking scheme solutions." },
  { code: "ADD-DOUBT", title: "1-on-1 Priority Doubt-Solving Pack", category: "Doubt-Solving Packs", price: 599, description: "Dedicated faculty doubt resolution within 4 hours via portal & WhatsApp." },
  { code: "ADD-CRASH", title: "30-Day Exam Crash Course", category: "Crash Courses", price: 999, description: "Fast-track revision + high-weightage question marathon before exams." },
];

const SEED_CROSS_SELL_RULES = [
  // Subject-based
  { rule_type: "subject", trigger_value: "Mathematics", recommended_items: ["Science", "English", "SST", "Hindi", "Computer"], category: "School Subjects", priority: 10 },
  { rule_type: "subject", trigger_value: "Science", recommended_items: ["Mathematics", "English", "SST", "Hindi"], category: "School Subjects", priority: 11 },
  { rule_type: "subject", trigger_value: "English", recommended_items: ["Spoken English", "Grammar Mastery", "Communication Skills"], category: "Communication & Language", priority: 12 },
  { rule_type: "subject", trigger_value: "Computer", recommended_items: ["Coding Classes", "AI Classes", "Python Programming", "Web Development"], category: "Technology Courses", priority: 13 },
  // Board-based
  { rule_type: "board", trigger_value: "CBSE", recommended_items: ["NCERT Solutions Pack", "CBSE Sample Papers", "Board Exam Batch"], category: "Add-On Learning Products", priority: 20 },
  { rule_type: "board", trigger_value: "ICSE", recommended_items: ["ICSE Special Series", "Subject Booster Packs"], category: "Add-On Learning Products", priority: 21 },
  { rule_type: "board", trigger_value: "UP Board", recommended_items: ["UP Board Preparation Courses", "UP Board Practice Papers"], category: "Add-On Learning Products", priority: 22 },
  { rule_type: "board", trigger_value: "State Board", recommended_items: ["Board Preparation Courses", "State Board Practice Papers"], category: "Add-On Learning Products", priority: 23 },
  // Class-based
  { rule_type: "class_range", trigger_value: "6-8", recommended_items: ["Olympiad Foundation", "Foundation Batch", "Coding Classes"], category: "Foundation Courses", priority: 30 },
  { rule_type: "class_range", trigger_value: "9-10", recommended_items: ["Olympiad Foundation", "NTSE Prep", "JEE Foundation", "NEET Foundation"], category: "Competitive Exams", priority: 31 },
  { rule_type: "class_range", trigger_value: "11-12", recommended_items: ["JEE Foundation", "NEET Foundation", "CUET Preparation", "NDA Preparation"], category: "Competitive Exams", priority: 32 },
];

const SEED_MESSAGE_TEMPLATES = [
  { key: "v33_welcome_message", name: "Welcome Message", category: "onboarding", subject: "Welcome to Yuitor Smart Classes, {{student_name}}!", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Welcome to <strong>Yuitor Smart Classes ({{branch}})</strong>! Your enrollment for <strong>{{course}}</strong> is now initiated. Complete your profile in the Student Portal to unlock classes, notes, and schedules.</p><p>Warm regards,<br>Yuitor Smart Classes</p>" },
  { key: "v33_fee_reminder", name: "Fee Reminder", category: "finance", subject: "Fee Reminder — {{course}} | Pending ₹{{pending_amount}}", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>This is a friendly reminder regarding your fee for <strong>{{course}}</strong> ({{branch}}). Total Fee: ₹{{fee_amount}} | Pending Balance: <strong>₹{{pending_amount}}</strong> | Due Date: <strong>{{due_date}}</strong>.</p><p>Please pay securely via your Student Panel.</p>" },
  { key: "v33_due_payment_reminder", name: "Due Payment Reminder", category: "finance", subject: "Action Needed: Fee Payment Due ({{due_date}}) — ₹{{pending_amount}}", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Your fee balance of <strong>₹{{pending_amount}}</strong> for <strong>{{course}}</strong> is due on <strong>{{due_date}}</strong>. Timely payment keeps your classes, tests, and study notes uninterrupted.</p>" },
  { key: "v33_verification_pending", name: "Verification Pending", category: "finance", subject: "Payment Received — Verification Pending ({{course}})", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>We received your payment submission for <strong>{{course}}</strong>. Our accounts team at <strong>{{branch}}</strong> is verifying the transaction. Your invoice &amp; receipt will update automatically once verified.</p>" },
  { key: "v33_reactivation_notice", name: "Reactivation Notice", category: "account", subject: "Your Yuitor Student Account is Reactivated!", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Your Yuitor Smart Classes account for <strong>{{course}}</strong> has been reactivated. You can now sign in and resume classes immediately.</p>" },
  { key: "v33_course_upgrade_offer", name: "Course Upgrade Offer", category: "upsell", subject: "Smart Upgrade Offer for {{student_name}} — Pay Only the Difference!", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Upgrade your current <strong>{{course}}</strong> enrollment to our Complete Bundle! Your previously paid fee is automatically adjusted so you only pay the remaining difference.</p>" },
  { key: "v33_cross_sell_offer", name: "Cross-Sell Offer", category: "cross_sell", subject: "Recommended Next Subject for {{student_name}} (Multi-Subject Discount)", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Boost your preparation in <strong>{{course}}</strong> by adding complementary subjects or Add-On Test Series with automatic Multi-Subject savings!</p>" },
  { key: "v33_renewal_reminder", name: "Renewal Reminder", category: "renewal", subject: "Course Renewal Reminder — {{course}} Expiring Soon", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Your enrollment in <strong>{{course}}</strong> ({{branch}}) is approaching expiry on <strong>{{due_date}}</strong>. Renew early to enjoy duration savings up to 20% OFF!</p>" },
  { key: "v33_festival_greetings", name: "Festival Greetings", category: "campaign", subject: "Warm Festival Wishes from Yuitor Smart Classes!", body: "<p>Dear <strong>{{student_name}}</strong> &amp; Family,</p><p>Wishing you joy, success, and bright results this festive season! Explore our limited-time Festival Offers in your Student Portal.</p>" },
  { key: "v33_birthday_wishes", name: "Birthday Wishes", category: "celebration", subject: "Happy Birthday, {{student_name}}! — Yuitor Smart Classes", body: "<p>Happy Birthday <strong>{{student_name}}</strong>!</p><p>May this year bring top ranks, strong learning, and happiness. Best wishes from all faculty at Yuitor Smart Classes ({{branch}}).</p>" },
  { key: "v33_exam_prep_campaign", name: "Exam Preparation Campaign", category: "campaign", subject: "Exam Sprint: PYQs, Mock Tests & Booster Batches for {{student_name}}", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Board &amp; Competitive exams are approaching! Practice with Yuitor PYQ Packs, Handwritten Notes, and Weekly Rank Tests to maximize your score.</p>" },
  { key: "v33_custom_message", name: "Custom Message", category: "custom", subject: "Important Update from Yuitor Smart Classes", body: "<p>Dear <strong>{{student_name}}</strong>,</p><p>Greetings from Yuitor Smart Classes ({{branch}}). Regarding <strong>{{course}}</strong> — please check your Student Portal for the latest update.</p>" },
];

function safeAddColumn(db, table, columnDef) {
  const colName = columnDef.trim().split(/\s+/)[0];
  try {
    const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
    if (!cols.includes(colName)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`);
    }
  } catch {
    // ignore if table absent in minimal unit tests
  }
}

export function ensureV33Schema(db) {
  // 1. Additive columns on existing tables (zero destructive changes!)
  safeAddColumn(db, "courses", "show_on_frontend INTEGER DEFAULT 1");
  safeAddColumn(db, "courses", "promo_enabled INTEGER DEFAULT 0");
  safeAddColumn(db, "courses", "promo_price INTEGER DEFAULT 0");
  safeAddColumn(db, "courses", "promo_valid_until TEXT DEFAULT ''");
  safeAddColumn(db, "courses", "pricing_priority INTEGER DEFAULT 100");
  safeAddColumn(db, "courses", "availability_status TEXT DEFAULT 'available'");
  safeAddColumn(db, "courses", "subjects_pricing_json TEXT DEFAULT '{}'");

  safeAddColumn(db, "notifications", "status TEXT DEFAULT 'new'");
  safeAddColumn(db, "notifications", "deep_link TEXT DEFAULT ''");
  safeAddColumn(db, "notifications", "entity_type TEXT DEFAULT ''");
  safeAddColumn(db, "notifications", "entity_id TEXT DEFAULT ''");

  safeAddColumn(db, "inquiries", "interested_subjects_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "inquiries", "counselor_notes TEXT DEFAULT ''");
  safeAddColumn(db, "inquiries", "last_contacted_at TEXT DEFAULT ''");

  safeAddColumn(db, "student_profiles", "subjects_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "student_profiles", "enrolled_subjects_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "student_profiles", "profile_completion_pct INTEGER DEFAULT 0");
  safeAddColumn(db, "student_profiles", "profile_completed_at TEXT DEFAULT ''");

  safeAddColumn(db, "fee_records", "invoice_number TEXT DEFAULT ''");
  safeAddColumn(db, "fee_records", "course_duration_months INTEGER DEFAULT 12");
  safeAddColumn(db, "fee_records", "course_expiry_date TEXT DEFAULT ''");
  safeAddColumn(db, "fee_records", "fee_plan_label TEXT DEFAULT ''");
  safeAddColumn(db, "fee_records", "next_followup_date TEXT DEFAULT ''");
  safeAddColumn(db, "fee_records", "pricing_snapshot_json TEXT DEFAULT '{}'");

  // 2. New v3.3 tables (only genuinely missing entities)
  db.exec(`
    CREATE TABLE IF NOT EXISTS v33_pricing_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      school_subject_fees_json TEXT NOT NULL,
      duration_discounts_json TEXT NOT NULL,
      multi_subject_slabs_json TEXT NOT NULL,
      discount_priority_json TEXT NOT NULL,
      allow_discount_stacking INTEGER DEFAULT 0,
      renewal_offsets_json TEXT NOT NULL,
      renewal_discount_percent INTEGER DEFAULT 10,
      abandoned_checkout_enabled INTEGER DEFAULT 1,
      abandoned_intervals_json TEXT NOT NULL,
      referral_rewards_json TEXT NOT NULL,
      updated_by INTEGER,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_branch_pricing (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER NOT NULL UNIQUE,
      school_subject_fees_json TEXT DEFAULT '{}',
      course_overrides_json TEXT DEFAULT '{}',
      bundle_overrides_json TEXT DEFAULT '{}',
      duration_discounts_json TEXT DEFAULT '{}',
      disabled_course_ids_json TEXT DEFAULT '[]',
      promo_note TEXT DEFAULT '',
      updated_by INTEGER,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_bundles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT DEFAULT 'School',
      class_level TEXT DEFAULT '',
      subjects_json TEXT DEFAULT '[]',
      base_monthly_price INTEGER DEFAULT 0,
      custom_price INTEGER DEFAULT 0,
      discount_percent REAL DEFAULT 15,
      promo_enabled INTEGER DEFAULT 0,
      promo_price INTEGER DEFAULT 0,
      branch_ids_json TEXT DEFAULT '[]',
      description TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      show_on_frontend INTEGER DEFAULT 1,
      priority INTEGER DEFAULT 100,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_scholarships (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      scholarship_type TEXT DEFAULT 'merit',
      discount_type TEXT DEFAULT 'percent',
      discount_value REAL DEFAULT 10,
      eligibility TEXT DEFAULT '',
      valid_from TEXT DEFAULT '',
      valid_until TEXT DEFAULT '',
      branch_ids_json TEXT DEFAULT '[]',
      course_ids_json TEXT DEFAULT '[]',
      max_uses INTEGER DEFAULT 500,
      used_count INTEGER DEFAULT 0,
      priority INTEGER DEFAULT 50,
      is_active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_promo_offers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      offer_type TEXT DEFAULT 'flash_sale',
      discount_type TEXT DEFAULT 'percent',
      discount_value REAL DEFAULT 10,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      branch_ids_json TEXT DEFAULT '[]',
      course_ids_json TEXT DEFAULT '[]',
      max_uses INTEGER DEFAULT 500,
      used_count INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      banner_text TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_addons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      category TEXT DEFAULT 'Test Series',
      price INTEGER DEFAULT 299,
      promo_price INTEGER DEFAULT 0,
      description TEXT DEFAULT '',
      class_range TEXT DEFAULT 'All',
      is_active INTEGER DEFAULT 1,
      show_on_frontend INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_cross_sell_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rule_type TEXT NOT NULL,
      trigger_value TEXT NOT NULL,
      recommended_items_json TEXT NOT NULL,
      category TEXT DEFAULT 'School Subjects',
      branch_id INTEGER,
      priority INTEGER DEFAULT 50,
      is_active INTEGER DEFAULT 1,
      impressions INTEGER DEFAULT 0,
      conversions INTEGER DEFAULT 0,
      revenue_generated INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_invoice_followups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      fee_record_id INTEGER,
      follow_up_date TEXT NOT NULL,
      follow_up_time TEXT NOT NULL DEFAULT '10:00',
      scheduled_at TEXT NOT NULL,
      reminder_type TEXT NOT NULL DEFAULT 'due_payment',
      channels_json TEXT NOT NULL DEFAULT '["email","whatsapp","in_app"]',
      custom_message TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'scheduled',
      sent_at TEXT DEFAULT '',
      delivery_log_json TEXT DEFAULT '{}',
      idempotency_key TEXT UNIQUE,
      created_by INTEGER,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_upgrade_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      from_summary TEXT NOT NULL,
      to_target_type TEXT NOT NULL DEFAULT 'bundle',
      to_target_id INTEGER,
      to_target_name TEXT NOT NULL,
      gross_new_price INTEGER NOT NULL,
      previous_paid_credit INTEGER NOT NULL DEFAULT 0,
      remaining_payable INTEGER NOT NULL DEFAULT 0,
      fee_record_id INTEGER,
      payment_id INTEGER,
      created_by INTEGER,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_pricing_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER,
      actor_name TEXT DEFAULT 'Admin',
      entity_type TEXT NOT NULL,
      entity_id TEXT DEFAULT '',
      action TEXT NOT NULL,
      before_json TEXT DEFAULT '{}',
      after_json TEXT DEFAULT '{}',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS v33_scheduled_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      channel TEXT NOT NULL DEFAULT 'email',
      template_key TEXT DEFAULT 'v33_custom_message',
      subject TEXT DEFAULT '',
      body_html TEXT NOT NULL,
      scheduled_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'scheduled',
      sent_at TEXT DEFAULT '',
      error_message TEXT DEFAULT '',
      created_by INTEGER,
      created_at TEXT NOT NULL
    );
  `);

  const now = nowIso();

  // Seed default pricing config once
  const existingCfg = db.prepare("SELECT id FROM v33_pricing_config WHERE id = 1").get();
  if (!existingCfg) {
    db.prepare(`
      INSERT INTO v33_pricing_config (
        id, school_subject_fees_json, duration_discounts_json, multi_subject_slabs_json,
        discount_priority_json, allow_discount_stacking, renewal_offsets_json, renewal_discount_percent,
        abandoned_checkout_enabled, abandoned_intervals_json, referral_rewards_json, updated_at
      ) VALUES (1, ?, ?, ?, ?, 0, ?, 10, 1, ?, ?, ?)
    `).run(
      JSON.stringify(DEFAULT_SCHOOL_SUBJECT_FEES),
      JSON.stringify(DEFAULT_DURATION_DISCOUNTS),
      JSON.stringify(DEFAULT_MULTI_SUBJECT_SLABS),
      JSON.stringify(DEFAULT_DISCOUNT_PRIORITY),
      JSON.stringify(DEFAULT_RENEWAL_OFFSETS),
      JSON.stringify([1, 24, 72]),
      JSON.stringify({ walletReward: 200, refereeDiscountPercent: 5, bonusClasses: 2, premiumNotesUnlock: true, maxReferralsPerMonth: 25 }),
      now
    );
  }

  // Seed official branches idempotently (preserving existing Muradnagar branch if present)
  try {
    const existingBranches = db.prepare("SELECT name, code FROM branches").all();
    const hasName = (kw) => existingBranches.some((b) => String(b.name || "").toLowerCase().includes(kw.toLowerCase()));
    const insBranch = db.prepare(`
      INSERT OR IGNORE INTO branches (name, code, address, city, phone, email, timing_note, is_active, created_at)
      VALUES (?, ?, ?, ?, ?, 'info@yuitor.com', 'Mon–Sat · 08:00 AM – 08:00 PM', 1, ?)
    `);
    for (const br of SEED_BRANCHES) {
      const kw = br.city.toLowerCase();
      if (!hasName(kw)) {
        insBranch.run(br.name, br.code, br.address, br.city, br.phone, now);
      }
    }
  } catch {
    // ignore in isolated unit test DBs without branches table
  }

  // Seed Competitive, Technology & Communication courses idempotently
  try {
    const insCourse = db.prepare(`
      INSERT OR IGNORE INTO courses (
        title, slug, category, class_range, board, description, duration_months,
        monthly_fee, yearly_fee, is_active, show_on_frontend, availability_status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 12, ?, ?, 1, 1, 'available', ?)
    `);
    for (const c of SEED_COURSES_V33) {
      const yearlyFee = Math.round(c.monthly_fee * 12 * 0.8);
      insCourse.run(c.title, c.slug, c.category, c.class_range, c.board, c.description, c.monthly_fee, yearlyFee, now);
    }
  } catch {
    // ignore in minimal test DBs
  }

  // Seed default bundles
  const insBundle = db.prepare(`
    INSERT OR IGNORE INTO v33_bundles (
      code, name, category, class_level, subjects_json, base_monthly_price,
      discount_percent, description, is_active, show_on_frontend, priority, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 50, ?, ?)
  `);
  for (const b of SEED_BUNDLES) {
    insBundle.run(b.code, b.name, b.category, b.class_level, JSON.stringify(b.subjects), b.base_monthly_price, b.discount_percent, b.description, now, now);
  }

  // Seed default scholarships
  const insSch = db.prepare(`
    INSERT OR IGNORE INTO v33_scholarships (
      code, name, scholarship_type, discount_type, discount_value, eligibility,
      priority, max_uses, is_active, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
  `);
  for (const s of SEED_SCHOLARSHIPS) {
    insSch.run(s.code, s.name, s.scholarship_type, s.discount_type, s.discount_value, s.eligibility, s.priority, s.max_uses, now, now);
  }

  // Seed default add-ons
  const insAddon = db.prepare(`
    INSERT OR IGNORE INTO v33_addons (
      code, title, category, price, description, is_active, show_on_frontend, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, 1, 1, ?, ?)
  `);
  for (const a of SEED_ADDONS) {
    insAddon.run(a.code, a.title, a.category, a.price, a.description, now, now);
  }

  // Seed default cross-sell rules if empty
  const ruleCount = Number(db.prepare("SELECT COUNT(*) AS c FROM v33_cross_sell_rules").get()?.c || 0);
  if (ruleCount === 0) {
    const insRule = db.prepare(`
      INSERT INTO v33_cross_sell_rules (
        rule_type, trigger_value, recommended_items_json, category, priority, is_active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 1, ?, ?)
    `);
    for (const r of SEED_CROSS_SELL_RULES) {
      insRule.run(r.rule_type, r.trigger_value, JSON.stringify(r.recommended_items), r.category, r.priority, now, now);
    }
  }

  // Seed 12 Message Templates into existing v31_mail_templates without overwriting existing templates
  try {
    const insTpl = db.prepare(`
      INSERT OR IGNORE INTO v31_mail_templates (
        template_key, name, audience, category, theme_key, subject, body_html, is_active, created_at, updated_at
      ) VALUES (?, ?, 'student', ?, 'burgundy_gold', ?, ?, 1, ?, ?)
    `);
    for (const t of SEED_MESSAGE_TEMPLATES) {
      insTpl.run(t.key, t.name, t.category, t.subject, t.body, now, now);
    }
  } catch {
    // ignore if v31_mail_templates not yet initialized
  }
}

function safeJsonParse(raw, fallback) {
  try {
    const parsed = JSON.parse(raw);
    return parsed !== null && parsed !== undefined ? parsed : fallback;
  } catch {
    return fallback;
  }
}

export function getV33PricingConfig(db) {
  ensureV33Schema(db);
  const row = db.prepare("SELECT * FROM v33_pricing_config WHERE id = 1").get();
  return {
    schoolSubjectFees: { ...DEFAULT_SCHOOL_SUBJECT_FEES, ...safeJsonParse(row?.school_subject_fees_json, {}) },
    durationDiscounts: { ...DEFAULT_DURATION_DISCOUNTS, ...safeJsonParse(row?.duration_discounts_json, {}) },
    multiSubjectSlabs: safeJsonParse(row?.multi_subject_slabs_json, DEFAULT_MULTI_SUBJECT_SLABS),
    discountPriority: safeJsonParse(row?.discount_priority_json, DEFAULT_DISCOUNT_PRIORITY),
    allowDiscountStacking: Boolean(Number(row?.allow_discount_stacking || 0)),
    renewalOffsets: safeJsonParse(row?.renewal_offsets_json, DEFAULT_RENEWAL_OFFSETS),
    renewalDiscountPercent: Number(row?.renewal_discount_percent ?? 10),
    abandonedCheckoutEnabled: Boolean(Number(row?.abandoned_checkout_enabled ?? 1)),
    abandonedIntervalsHours: safeJsonParse(row?.abandoned_intervals_json, [1, 24, 72]),
    referralRewards: safeJsonParse(row?.referral_rewards_json, {
      walletReward: 200,
      refereeDiscountPercent: 5,
      bonusClasses: 2,
      premiumNotesUnlock: true,
      maxReferralsPerMonth: 25,
    }),
    updatedAt: row?.updated_at || nowIso(),
  };
}

export function logPricingAudit(db, { actorId = null, actorName = "Admin", entityType, entityId = "", action, before = {}, after = {} }) {
  ensureV33Schema(db);
  db.prepare(`
    INSERT INTO v33_pricing_audit (actor_id, actor_name, entity_type, entity_id, action, before_json, after_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    actorId,
    String(actorName || "Admin").slice(0, 120),
    String(entityType || "pricing").slice(0, 60),
    String(entityId || "").slice(0, 60),
    String(action || "update").slice(0, 60),
    JSON.stringify(before || {}),
    JSON.stringify(after || {}),
    nowIso()
  );
}

export function updateV33PricingConfig(db, patch = {}, actor = {}) {
  const current = getV33PricingConfig(db);
  const next = {
    schoolSubjectFees: patch.schoolSubjectFees
      ? Object.fromEntries(
          Object.entries({ ...current.schoolSubjectFees, ...patch.schoolSubjectFees }).map(([k, v]) => [
            String(k),
            Math.max(100, Math.round(Number(v) || 0)),
          ])
        )
      : current.schoolSubjectFees,
    durationDiscounts: patch.durationDiscounts
      ? Object.fromEntries(
          Object.entries({ ...current.durationDiscounts, ...patch.durationDiscounts }).map(([k, v]) => [
            String(k),
            Math.min(75, Math.max(0, Number(v) || 0)),
          ])
        )
      : current.durationDiscounts,
    multiSubjectSlabs: Array.isArray(patch.multiSubjectSlabs)
      ? patch.multiSubjectSlabs
          .map((s) => ({
            minSubjects: Math.max(2, Math.round(Number(s.minSubjects) || 2)),
            discountPercent: Math.min(60, Math.max(0, Number(s.discountPercent) || 0)),
            label: String(s.label || `${s.minSubjects} Subjects Combo`).slice(0, 80),
            active: s.active !== false,
          }))
          .sort((a, b) => a.minSubjects - b.minSubjects)
      : current.multiSubjectSlabs,
    discountPriority: Array.isArray(patch.discountPriority) && patch.discountPriority.length
      ? patch.discountPriority.map((x) => String(x))
      : current.discountPriority,
    allowDiscountStacking:
      patch.allowDiscountStacking !== undefined ? Boolean(patch.allowDiscountStacking) : current.allowDiscountStacking,
    renewalOffsets: Array.isArray(patch.renewalOffsets)
      ? patch.renewalOffsets.map((n) => Math.max(1, Math.round(Number(n) || 1))).filter((v, i, arr) => arr.indexOf(v) === i).sort((a, b) => b - a)
      : current.renewalOffsets,
    renewalDiscountPercent:
      patch.renewalDiscountPercent !== undefined
        ? Math.min(50, Math.max(0, Number(patch.renewalDiscountPercent) || 0))
        : current.renewalDiscountPercent,
    abandonedCheckoutEnabled:
      patch.abandonedCheckoutEnabled !== undefined ? Boolean(patch.abandonedCheckoutEnabled) : current.abandonedCheckoutEnabled,
    abandonedIntervalsHours: Array.isArray(patch.abandonedIntervalsHours)
      ? patch.abandonedIntervalsHours.map((n) => Math.max(1, Math.round(Number(n) || 1)))
      : current.abandonedIntervalsHours,
    referralRewards: patch.referralRewards
      ? { ...current.referralRewards, ...patch.referralRewards }
      : current.referralRewards,
  };

  db.prepare(`
    UPDATE v33_pricing_config SET
      school_subject_fees_json = ?,
      duration_discounts_json = ?,
      multi_subject_slabs_json = ?,
      discount_priority_json = ?,
      allow_discount_stacking = ?,
      renewal_offsets_json = ?,
      renewal_discount_percent = ?,
      abandoned_checkout_enabled = ?,
      abandoned_intervals_json = ?,
      referral_rewards_json = ?,
      updated_by = ?,
      updated_at = ?
    WHERE id = 1
  `).run(
    JSON.stringify(next.schoolSubjectFees),
    JSON.stringify(next.durationDiscounts),
    JSON.stringify(next.multiSubjectSlabs),
    JSON.stringify(next.discountPriority),
    next.allowDiscountStacking ? 1 : 0,
    JSON.stringify(next.renewalOffsets),
    next.renewalDiscountPercent,
    next.abandonedCheckoutEnabled ? 1 : 0,
    JSON.stringify(next.abandonedIntervalsHours),
    JSON.stringify(next.referralRewards),
    actor.id || null,
    nowIso()
  );

  logPricingAudit(db, {
    actorId: actor.id || null,
    actorName: actor.full_name || "Admin",
    entityType: "pricing_config",
    entityId: "1",
    action: "update_config",
    before: current,
    after: next,
  });

  return getV33PricingConfig(db);
}

export function getBranchPricingOverlay(db, branchId) {
  ensureV33Schema(db);
  if (!branchId) {
    return {
      branchId: null,
      schoolSubjectFees: {},
      courseOverrides: {},
      bundleOverrides: {},
      durationDiscounts: {},
      disabledCourseIds: [],
      promoNote: "",
    };
  }
  const row = db.prepare("SELECT * FROM v33_branch_pricing WHERE branch_id = ?").get(Number(branchId));
  return {
    branchId: Number(branchId),
    schoolSubjectFees: safeJsonParse(row?.school_subject_fees_json, {}),
    courseOverrides: safeJsonParse(row?.course_overrides_json, {}),
    bundleOverrides: safeJsonParse(row?.bundle_overrides_json, {}),
    durationDiscounts: safeJsonParse(row?.duration_discounts_json, {}),
    disabledCourseIds: safeJsonParse(row?.disabled_course_ids_json, []).map(Number),
    promoNote: row?.promo_note || "",
  };
}

/**
 * PURE FORMULA: Final Price = Base Price × Duration × (1 - Discount%)
 */
export function computeDurationPrice(baseMonthlyPrice, durationMonths, durationDiscounts = DEFAULT_DURATION_DISCOUNTS) {
  const base = Math.max(0, Number(baseMonthlyPrice || 0));
  const months = [1, 3, 6, 9, 12].includes(Number(durationMonths)) ? Number(durationMonths) : 1;
  const discountPercent = Math.min(75, Math.max(0, Number(durationDiscounts[String(months)] ?? 0)));
  const gross = Math.round(base * months);
  const finalPrice = Math.round(gross * (1 - discountPercent / 100));
  const discountAmount = Math.max(0, gross - finalPrice);
  return {
    baseMonthlyPrice: base,
    durationMonths: months,
    grossAmount: gross,
    discountPercent,
    discountAmount,
    finalPrice,
  };
}

/**
 * PURE FORMULA: Multi-Subject Discount Slab Lookup
 */
export function computeMultiSubjectDiscount(subtotal, subjectCount, slabs = DEFAULT_MULTI_SUBJECT_SLABS) {
  const cleanSub = Math.max(0, Number(subtotal || 0));
  const count = Math.max(0, Math.round(Number(subjectCount || 0)));
  if (cleanSub <= 0 || count < 2) {
    return { applied: false, subjectCount: count, discountPercent: 0, discountAmount: 0, label: "" };
  }
  const activeSlabs = (Array.isArray(slabs) ? slabs : DEFAULT_MULTI_SUBJECT_SLABS)
    .filter((s) => s.active !== false && count >= Number(s.minSubjects || 2))
    .sort((a, b) => Number(b.minSubjects) - Number(a.minSubjects));
  if (!activeSlabs.length) {
    return { applied: false, subjectCount: count, discountPercent: 0, discountAmount: 0, label: "" };
  }
  const best = activeSlabs[0];
  const pct = Math.min(60, Math.max(0, Number(best.discountPercent || 0)));
  const discountAmount = Math.round((cleanSub * pct) / 100);
  return {
    applied: discountAmount > 0,
    subjectCount: count,
    discountPercent: pct,
    discountAmount,
    label: best.label || `${count} Subjects (${pct}% OFF)`,
  };
}

/**
 * PURE FORMULA: Smart Upgrade Deduction (prevents double-charging already paid components)
 */
export function computeSmartUpgradePricing({ newPackagePrice, previousPaidAmount }) {
  const newPrice = Math.max(0, Math.round(Number(newPackagePrice || 0)));
  const prevPaid = Math.max(0, Math.round(Number(previousPaidAmount || 0)));
  const creditApplied = Math.min(newPrice, prevPaid);
  const remainingPayable = Math.max(0, newPrice - creditApplied);
  return {
    newPackagePrice: newPrice,
    previousPaidAmount: prevPaid,
    creditApplied,
    remainingPayable,
  };
}

/**
 * SERVER-SIDE DYNAMIC CHECKOUT & INVOICE CALCULATOR
 * Never trusts client-side price amounts. Resolves every price from DB + Branch Overlay + Admin Config.
 */
export function calculateDynamicCheckoutQuote(db, payload = {}) {
  ensureV33Schema(db);
  const cfg = getV33PricingConfig(db);
  const branchId = payload.branchId ? Number(payload.branchId) : null;
  const branchOverlay = getBranchPricingOverlay(db, branchId);
  const durationMonths = [1, 3, 6, 9, 12].includes(Number(payload.durationMonths)) ? Number(payload.durationMonths) : 1;

  const effectiveSchoolFees = { ...cfg.schoolSubjectFees, ...(branchOverlay.schoolSubjectFees || {}) };
  const effectiveDurationDiscounts = { ...cfg.durationDiscounts, ...(branchOverlay.durationDiscounts || {}) };

  const lineItems = [];
  let rawMonthlyBaseTotal = 0;
  let subjectItemsBaseAfterDuration = 0;
  let subjectCount = 0;
  let bundleSavings = 0;
  let durationSavings = 0;
  let baseGrossTotal = 0;

  // 1. Selected School Subjects (Class 6th–12th)
  const classNum = String(payload.classNumber || payload.classLevel || "").replace(/[^0-9]/g, "");
  const selectedSubjects = Array.isArray(payload.subjects)
    ? [...new Set(payload.subjects.map((s) => String(s || "").trim()).filter(Boolean))]
    : [];
  if (classNum && selectedSubjects.length && effectiveSchoolFees[classNum]) {
    const perSubjectMonthly = Number(effectiveSchoolFees[classNum]);
    for (const subj of selectedSubjects) {
      const calc = computeDurationPrice(perSubjectMonthly, durationMonths, effectiveDurationDiscounts);
      lineItems.push({
        type: "school_subject",
        code: `CLS${classNum}-${subj.toUpperCase().slice(0, 6)}`,
        title: `Class ${classNum}th — ${subj}`,
        monthlyRate: perSubjectMonthly,
        durationMonths,
        grossAmount: calc.grossAmount,
        durationDiscountPercent: calc.discountPercent,
        durationDiscountAmount: calc.discountAmount,
        netAmount: calc.finalPrice,
      });
      rawMonthlyBaseTotal += perSubjectMonthly;
      baseGrossTotal += calc.grossAmount;
      durationSavings += calc.discountAmount;
      subjectItemsBaseAfterDuration += calc.finalPrice;
      subjectCount += 1;
    }
  }

  // 2. Selected Courses (Competitive / Tech / Communication / School Courses)
  const courseIds = Array.isArray(payload.courseIds) ? payload.courseIds.map(Number).filter((n) => n > 0) : [];
  const today = nowIso().slice(0, 10);
  for (const cid of courseIds) {
    if (branchOverlay.disabledCourseIds.includes(cid)) continue;
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(cid);
    if (!course) continue;
    let monthly = Number(branchOverlay.courseOverrides?.[String(cid)] ?? course.monthly_fee ?? 0);
    if (
      Number(course.promo_enabled) === 1 &&
      Number(course.promo_price) > 0 &&
      (!course.promo_valid_until || course.promo_valid_until >= today)
    ) {
      monthly = Math.min(monthly, Number(course.promo_price));
    }
    const calc = computeDurationPrice(monthly, durationMonths, effectiveDurationDiscounts);
    lineItems.push({
      type: "course",
      courseId: Number(course.id),
      title: course.title,
      category: course.category,
      monthlyRate: monthly,
      durationMonths,
      grossAmount: calc.grossAmount,
      durationDiscountPercent: calc.discountPercent,
      durationDiscountAmount: calc.discountAmount,
      netAmount: calc.finalPrice,
    });
    rawMonthlyBaseTotal += monthly;
    baseGrossTotal += calc.grossAmount;
    durationSavings += calc.discountAmount;
  }

  // 3. Selected Bundle (if any)
  let selectedBundle = null;
  if (payload.bundleId) {
    const b = db.prepare("SELECT * FROM v33_bundles WHERE id = ? AND is_active = 1").get(Number(payload.bundleId));
    if (b) {
      selectedBundle = b;
      const subjects = safeJsonParse(b.subjects_json, []);
      let monthlyBase = Number(branchOverlay.bundleOverrides?.[String(b.id)] ?? b.base_monthly_price ?? 0);
      // If Complete School Package & classNum selected, dynamically compute from class subject fee
      if (b.code === "COMPLETE-SCHOOL" && classNum && effectiveSchoolFees[classNum]) {
        const avail = CLASS_SUBJECT_CATALOG[classNum] || subjects;
        monthlyBase = Number(effectiveSchoolFees[classNum]) * avail.length;
      }
      const bundlePct = Math.min(60, Math.max(0, Number(b.discount_percent || 0)));
      const grossForDuration = Math.round(monthlyBase * durationMonths);
      let discountedMonthly = b.custom_price > 0 ? Number(b.custom_price) : Math.round(monthlyBase * (1 - bundlePct / 100));
      if (Number(b.promo_enabled) === 1 && Number(b.promo_price) > 0) {
        discountedMonthly = Math.min(discountedMonthly, Number(b.promo_price));
      }
      const durCalc = computeDurationPrice(discountedMonthly, durationMonths, effectiveDurationDiscounts);
      const thisBundleSaving = Math.max(0, grossForDuration - durCalc.grossAmount);
      bundleSavings += thisBundleSaving;
      durationSavings += durCalc.discountAmount;
      baseGrossTotal += grossForDuration;
      lineItems.push({
        type: "bundle",
        bundleId: Number(b.id),
        code: b.code,
        title: b.name,
        subjects,
        monthlyBase,
        bundleDiscountPercent: bundlePct,
        bundleSavings: thisBundleSaving,
        durationMonths,
        grossAmount: grossForDuration,
        durationDiscountAmount: durCalc.discountAmount,
        netAmount: durCalc.finalPrice,
      });
    }
  }

  // 4. Add-On Products (one-time purchases integrated with invoice)
  const addonIds = Array.isArray(payload.addonIds) ? payload.addonIds.map(Number).filter((n) => n > 0) : [];
  let addonsTotal = 0;
  for (const aid of addonIds) {
    const a = db.prepare("SELECT * FROM v33_addons WHERE id = ? AND is_active = 1").get(aid);
    if (!a) continue;
    const price = Number(a.promo_price) > 0 && Number(a.promo_price) < Number(a.price) ? Number(a.promo_price) : Number(a.price);
    addonsTotal += price;
    baseGrossTotal += price;
    lineItems.push({
      type: "addon",
      addonId: Number(a.id),
      code: a.code,
      title: a.title,
      category: a.category,
      grossAmount: Number(a.price),
      netAmount: price,
    });
  }

  // 5. Multi-Subject Discount (applies to eligible school subjects purchased together)
  const multiSubject = computeMultiSubjectDiscount(subjectItemsBaseAfterDuration, subjectCount, cfg.multiSubjectSlabs);
  const afterCoreDiscounts = Math.max(
    0,
    lineItems.reduce((acc, it) => acc + Number(it.netAmount || 0), 0) - multiSubject.discountAmount
  );

  // 6. Promo Offer / Scholarship / Coupon with Anti-Stacking Priority Control
  let promoDiscount = { applied: false, code: "", title: "", discountAmount: 0 };
  let scholarshipDiscount = { applied: false, code: "", name: "", discountAmount: 0 };
  let couponDiscount = { applied: false, code: "", discountAmount: 0 };
  const warnings = [];
  const nowStr = nowIso();

  // Check active limited-time promo offer (explicit code or auto-best active offer)
  const promoCode = String(payload.promoCode || "").trim().toUpperCase();
  if (promoCode) {
    const offer = db.prepare("SELECT * FROM v33_promo_offers WHERE UPPER(code) = ? AND is_active = 1").get(promoCode);
    if (offer) {
      const offerBranches = safeJsonParse(offer.branch_ids_json, []).map(Number);
      const branchOk = !offerBranches.length || (branchId && offerBranches.includes(branchId));
      const dateOk = offer.start_at <= nowStr && offer.end_at >= nowStr;
      const usageOk = Number(offer.used_count || 0) < Number(offer.max_uses || 1);
      if (branchOk && dateOk && usageOk) {
        const amt =
          offer.discount_type === "fixed"
            ? Math.min(afterCoreDiscounts, Math.round(Number(offer.discount_value || 0)))
            : Math.round((afterCoreDiscounts * Number(offer.discount_value || 0)) / 100);
        promoDiscount = { applied: amt > 0, id: offer.id, code: offer.code, title: offer.title, discountAmount: amt };
      } else {
        warnings.push("Promotional offer is expired, branch-restricted, or reached usage limit.");
      }
    }
  }

  // Check scholarship code
  const scholarshipCode = String(payload.scholarshipCode || "").trim().toUpperCase();
  if (scholarshipCode) {
    const sch = db.prepare("SELECT * FROM v33_scholarships WHERE UPPER(code) = ? AND is_active = 1").get(scholarshipCode);
    if (sch) {
      const schBranches = safeJsonParse(sch.branch_ids_json, []).map(Number);
      const branchOk = !schBranches.length || (branchId && schBranches.includes(branchId));
      const dateOk = (!sch.valid_from || sch.valid_from <= today) && (!sch.valid_until || sch.valid_until >= today);
      const usageOk = Number(sch.used_count || 0) < Number(sch.max_uses || 1);
      if (branchOk && dateOk && usageOk) {
        const amt =
          sch.discount_type === "fixed"
            ? Math.min(afterCoreDiscounts, Math.round(Number(sch.discount_value || 0)))
            : Math.round((afterCoreDiscounts * Number(sch.discount_value || 0)) / 100);
        scholarshipDiscount = { applied: amt > 0, id: sch.id, code: sch.code, name: sch.name, discountAmount: amt };
      } else {
        warnings.push("Scholarship code is inactive, expired, branch-restricted, or exhausted.");
      }
    } else {
      warnings.push("Invalid scholarship code.");
    }
  }

  // Check standard coupon code from existing coupons table
  const couponCode = String(payload.couponCode || "").trim().toUpperCase();
  if (couponCode) {
    try {
      const cpn = db.prepare("SELECT * FROM coupons WHERE UPPER(code) = ? AND is_active = 1").get(couponCode);
      if (cpn) {
        if (Number(cpn.used_count || 0) >= Number(cpn.max_uses || 1) || (cpn.expires_at && cpn.expires_at < today)) {
          warnings.push("Coupon expired or usage limit reached.");
        } else {
          const amt =
            cpn.discount_type === "percent"
              ? Math.round((afterCoreDiscounts * Number(cpn.discount_value || 0)) / 100)
              : Math.min(afterCoreDiscounts, Math.round(Number(cpn.discount_value || 0)));
          couponDiscount = { applied: amt > 0, code: cpn.code, discountAmount: amt };
        }
      } else if (!(promoDiscount.applied && promoCode === couponCode)) {
        warnings.push("Invalid coupon code.");
      }
    } catch {
      // ignore if coupons table absent
    }
  }

  // Anti-Stacking Rule: unless Admin enables allowDiscountStacking, only ONE of Promo/Scholarship/Coupon applies (highest priority / best value)
  let extraDiscountApplied = 0;
  if (cfg.allowDiscountStacking) {
    extraDiscountApplied = Math.min(
      afterCoreDiscounts,
      promoDiscount.discountAmount + scholarshipDiscount.discountAmount + couponDiscount.discountAmount
    );
  } else {
    const candidates = [
      { key: "promo_offer", obj: promoDiscount },
      { key: "scholarship", obj: scholarshipDiscount },
      { key: "coupon", obj: couponDiscount },
    ].filter((c) => c.obj.applied && c.obj.discountAmount > 0);
    if (candidates.length > 1) {
      candidates.sort((a, b) => {
        const pa = cfg.discountPriority.indexOf(a.key);
        const pb = cfg.discountPriority.indexOf(b.key);
        return (pa === -1 ? 99 : pa) - (pb === -1 ? 99 : pb);
      });
      const winner = candidates[0];
      for (const loser of candidates.slice(1)) {
        loser.obj.applied = false;
        loser.obj.discountAmount = 0;
      }
      warnings.push(`Discount stacking disabled: applied highest-priority discount (${winner.key}).`);
    }
    extraDiscountApplied = Math.min(
      afterCoreDiscounts,
      promoDiscount.discountAmount + scholarshipDiscount.discountAmount + couponDiscount.discountAmount
    );
  }

  const netBeforeUpgradeCredit = Math.max(0, afterCoreDiscounts - extraDiscountApplied);

  // 7. Smart Upgrade Credit Deduction (if studentId + isUpgrade)
  let upgradeCredit = { applied: false, previousPaidAmount: 0, creditApplied: 0 };
  if (payload.isUpgrade && payload.studentId) {
    const prevPaidRow = db
      .prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE student_id = ? AND verification_status = 'verified'")
      .get(Number(payload.studentId));
    const prevPaid = Number(payload.explicitPreviousPaid ?? prevPaidRow?.total ?? 0);
    const upg = computeSmartUpgradePricing({ newPackagePrice: netBeforeUpgradeCredit, previousPaidAmount: prevPaid });
    upgradeCredit = { applied: upg.creditApplied > 0, previousPaidAmount: prevPaid, creditApplied: upg.creditApplied };
  }

  const finalPayableAmount = Math.max(0, netBeforeUpgradeCredit - upgradeCredit.creditApplied);
  const totalDiscountAmount = Math.max(
    0,
    durationSavings + bundleSavings + multiSubject.discountAmount + extraDiscountApplied
  );

  return {
    branchId,
    durationMonths,
    lineItems,
    baseAmount: baseGrossTotal,
    addonsTotal,
    breakdown: {
      durationDiscount: durationSavings,
      bundleSavings,
      multiSubjectDiscount: multiSubject.discountAmount,
      multiSubjectLabel: multiSubject.label,
      promoDiscount: promoDiscount.discountAmount,
      promoCode: promoDiscount.applied ? promoDiscount.code : "",
      scholarshipDiscount: scholarshipDiscount.discountAmount,
      scholarshipCode: scholarshipDiscount.applied ? scholarshipDiscount.code : "",
      couponDiscount: couponDiscount.discountAmount,
      couponCode: couponDiscount.applied ? couponDiscount.code : "",
      upgradeCredit: upgradeCredit.creditApplied,
      totalDiscountAmount,
    },
    finalPayableAmount,
    warnings,
    selectedBundle: selectedBundle ? { id: selectedBundle.id, name: selectedBundle.name, code: selectedBundle.code } : null,
  };
}

/**
 * PROFILE COMPLETION WIZARD (0%–100%)
 * Mandatory fields: Full Address, School Name, Board, Class, Selected Subjects (>=1), Branch, Profile Photo.
 * Parent Name & Parent Mobile are OPTIONAL and NEVER block 100% completion or service access!
 */
export function calculateProfileCompletion(profile = {}, user = {}) {
  const subjects = safeJsonParse(profile?.subjects_json || profile?.enrolled_subjects_json || "[]", []);
  const checks = [
    { key: "address", label: "Full Address", done: String(profile?.address || "").trim().length >= 5, required: true },
    { key: "schoolName", label: "School Name", done: String(profile?.school_name || "").trim().length >= 2, required: true },
    { key: "board", label: "Board (CBSE / ICSE / UP / State)", done: Boolean(String(profile?.board || "").trim()), required: true },
    { key: "classLevel", label: "Class (6th–12th)", done: Boolean(String(profile?.class_level || "").trim()), required: true },
    { key: "subjects", label: "Subjects Selected", done: Array.isArray(subjects) && subjects.length > 0, required: true },
    { key: "branchId", label: "Branch Selected", done: Number(profile?.branch_id || user?.branch_id || 0) > 0, required: true },
    { key: "avatarUrl", label: "Profile Photo", done: Boolean(String(user?.avatar_url || "").trim()), required: true },
  ];
  const completedCount = checks.filter((c) => c.done).length;
  const percent = Math.round((completedCount / checks.length) * 100);
  const optional = {
    parentName: String(profile?.parent_name || "").trim(),
    parentPhone: String(profile?.parent_phone || "").trim(),
  };
  return {
    percent,
    isComplete: percent === 100,
    completedCount,
    totalRequired: checks.length,
    checks,
    optional,
    subjects,
  };
}

/**
 * STUDENT FINANCIAL SUMMARY (Used by both Student Panel & Admin/Staff Invoice Management)
 */
export function buildStudentFinancialSummary(db, studentId) {
  ensureV33Schema(db);
  const sid = Number(studentId);
  const user = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.verification_status, u.is_active, u.branch_id,
              b.name AS branch_name,
              sp.class_level, sp.board, sp.roll_number, sp.course_duration_months, sp.billing_cycle,
              sp.admission_date, sp.enrollment_status, sp.subjects_json, sp.total_fee, sp.paid_fee, sp.remaining_fee
       FROM users u
       LEFT JOIN branches b ON b.id = u.branch_id
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       WHERE u.id = ?`
    )
    .get(sid);

  if (!user) return null;

  const invoices = db
    .prepare(
      `SELECT fr.*, COALESCE(c.title, fr.title) AS course_title
       FROM fee_records fr
       LEFT JOIN courses c ON c.id = fr.course_id
       WHERE fr.student_id = ?
       ORDER BY fr.id DESC`
    )
    .all(sid);

  const payments = db
    .prepare(
      `SELECT p.*, COALESCE(c.title, 'Course / Package') AS course_title
       FROM payments p
       LEFT JOIN courses c ON c.id = p.course_id
       WHERE p.student_id = ?
       ORDER BY p.id DESC`
    )
    .all(sid);

  const enrollments = db
    .prepare(
      `SELECT e.*, c.title AS course_title, c.category
       FROM enrollments e
       LEFT JOIN courses c ON c.id = e.course_id
       WHERE e.student_id = ?
       ORDER BY e.id DESC`
    )
    .all(sid);

  const followups = db
    .prepare("SELECT * FROM v33_invoice_followups WHERE student_id = ? ORDER BY scheduled_at DESC LIMIT 30")
    .all(sid);

  const upgrades = db
    .prepare("SELECT * FROM v33_upgrade_history WHERE student_id = ? ORDER BY id DESC LIMIT 20")
    .all(sid);

  const today = getIstDateKey();
  let totalCourseFees = 0;
  let totalDiscount = 0;
  let amountPaidFromInvoices = 0;
  let overdueFees = 0;
  let earliestOpenDueDate = "";

  for (const inv of invoices) {
    const net = Math.max(0, Number(inv.total_amount || 0) - Number(inv.discount_amount || 0));
    const paid = Math.max(0, Number(inv.paid_amount || 0));
    const bal = Math.max(0, net - paid);
    totalCourseFees += net;
    totalDiscount += Number(inv.discount_amount || 0);
    amountPaidFromInvoices += paid;
    if (bal > 0 && inv.due_date) {
      if (!earliestOpenDueDate || inv.due_date < earliestOpenDueDate) earliestOpenDueDate = inv.due_date;
      if (inv.due_date < today) overdueFees += bal;
    }
  }

  const verifiedPaidTotal = payments
    .filter((p) => p.verification_status === "verified" && p.refund_status !== "refunded")
    .reduce((acc, p) => acc + Number(p.amount || 0), 0);

  const unverifiedPendingTotal = payments
    .filter((p) => p.verification_status === "pending_verification")
    .reduce((acc, p) => acc + Number(p.amount || 0), 0);

  // Use invoice-tracked total or fallback to profile fee if no fee_record exists yet
  const effectiveTotalFees = totalCourseFees > 0 ? totalCourseFees : Number(user.total_fee || 0);
  const amountReceived = Math.max(amountPaidFromInvoices, verifiedPaidTotal);
  const pendingAmount = Math.max(0, effectiveTotalFees - amountReceived);

  let paymentStatus = "Unpaid";
  if (effectiveTotalFees > 0 && pendingAmount === 0) paymentStatus = "Paid";
  else if (unverifiedPendingTotal > 0 && amountReceived === 0) paymentStatus = "Pending Verification";
  else if (amountReceived > 0 && pendingAmount > 0) paymentStatus = overdueFees > 0 ? "Partially Paid (Overdue)" : "Partially Paid";
  else if (overdueFees > 0) paymentStatus = "Overdue";

  const verifiedPaymentRows = payments.filter((p) => p.verification_status === "verified");
  const lastPaymentDate = verifiedPaymentRows[0]?.paid_at || verifiedPaymentRows[0]?.created_at || "";
  const nextFollowUp = followups.find((f) => f.status === "scheduled");
  const activeEnrollment = enrollments.find((e) => e.status === "active") || enrollments[0];
  const courseExpiryDate = activeEnrollment?.expires_at || invoices[0]?.course_expiry_date || "";

  return {
    student: {
      id: user.id,
      fullName: user.full_name,
      email: user.email,
      phone: user.phone,
      rollNumber: user.roll_number || "",
      classLevel: user.class_level || "",
      board: user.board || "",
      branchId: user.branch_id || null,
      branchName: user.branch_name || "Muradnagar Branch",
      verificationStatus: user.verification_status || "pending_approval",
      isActive: Boolean(user.is_active),
    },
    summary: {
      totalCourseFees: effectiveTotalFees,
      totalDiscount,
      amountPaid: amountReceived,
      amountReceived,
      pendingAmount,
      outstandingBalance: pendingAmount,
      unverifiedSubmittedAmount: unverifiedPendingTotal,
      overdueFees,
      verificationStatus: unverifiedPendingTotal > 0 ? "Pending Verification" : user.verification_status || "approved",
      paymentStatus,
      courseDuration: `${Number(invoices[0]?.course_duration_months || user.course_duration_months || 12)} Months`,
      feePlan: invoices[0]?.billing_cycle || user.billing_cycle || "monthly",
      courseExpiryDate: courseExpiryDate ? String(courseExpiryDate).slice(0, 10) : "Active Plan",
      dueDate: earliestOpenDueDate || invoices[0]?.due_date || "-",
      lastPaymentDate: lastPaymentDate ? String(lastPaymentDate).slice(0, 10) : "-",
      nextFollowUpDate: nextFollowUp ? `${nextFollowUp.follow_up_date} ${nextFollowUp.follow_up_time}` : "-",
    },
    invoices: invoices.map((inv) => {
      const net = Math.max(0, Number(inv.total_amount || 0) - Number(inv.discount_amount || 0));
      const bal = Math.max(0, net - Number(inv.paid_amount || 0));
      return {
        ...inv,
        invoice_number: inv.invoice_number || `YTR-INV-${String(inv.id).padStart(5, "0")}`,
        net_amount: net,
        pending_amount: bal,
      };
    }),
    payments: payments.map((p) => ({
      ...p,
      payment_status:
        p.verification_status === "verified"
          ? "Verified & Paid"
          : p.verification_status === "rejected"
            ? "Rejected"
            : "Pending Verification",
      transaction_id: p.gateway_payment_id || p.utr_reference || `TXN-${p.id}`,
    })),
    followups,
    upgrades,
    enrollments,
  };
}

/**
 * Recomputes fee_records.paid_amount, fee_records.status & student_profiles fee totals
 * strictly from verified payments (never counts unverified payments!).
 */
export function recalculateStudentInvoiceBalances(db, studentId) {
  const sid = Number(studentId);
  const invoices = db.prepare("SELECT * FROM fee_records WHERE student_id = ? ORDER BY id ASC").all(sid);
  const verifiedTotal = Number(
    db
      .prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE student_id = ? AND verification_status = 'verified' AND refund_status != 'refunded'")
      .get(sid)?.total || 0
  );

  let remainingToAllocate = verifiedTotal;
  const today = getIstDateKey();
  let totalNet = 0;

  for (const inv of invoices) {
    const net = Math.max(0, Number(inv.total_amount || 0) - Number(inv.discount_amount || 0));
    totalNet += net;
    const allocated = Math.min(net, remainingToAllocate);
    remainingToAllocate = Math.max(0, remainingToAllocate - allocated);
    let status = "pending";
    if (net > 0 && allocated >= net) status = "paid";
    else if (allocated > 0) status = "partial";
    else if (inv.due_date && inv.due_date < today) status = "overdue";

    db.prepare("UPDATE fee_records SET paid_amount = ?, status = ? WHERE id = ?").run(allocated, status, inv.id);
  }

  try {
    db.prepare("UPDATE student_profiles SET total_fee = ?, paid_fee = ?, remaining_fee = ? WHERE user_id = ?").run(
      totalNet,
      verifiedTotal,
      Math.max(0, totalNet - verifiedTotal),
      sid
    );
  } catch {
    // ignore if columns missing
  }
  return { totalNet, verifiedTotal, remaining: Math.max(0, totalNet - verifiedTotal) };
}

/**
 * SMART CROSS-SELLING, PERFORMANCE-BASED RECOMMENDATIONS, "STUDENTS ALSO BOUGHT" & GAMIFIED PATH
 * Zero fake statistics: all co-purchase & performance recommendations come strictly from real SQLite data.
 */
export function buildSmartRecommendations(db, studentId) {
  ensureV33Schema(db);
  const sid = Number(studentId);
  const profile = db
    .prepare(
      `SELECT u.id, u.full_name, u.branch_id, sp.class_level, sp.board, sp.subjects_json, sp.enrolled_subjects_json
       FROM users u LEFT JOIN student_profiles sp ON sp.user_id = u.id WHERE u.id = ?`
    )
    .get(sid);

  const purchasedSubjects = [
    ...new Set([
      ...safeJsonParse(profile?.subjects_json || "[]", []),
      ...safeJsonParse(profile?.enrolled_subjects_json || "[]", []),
    ].map((s) => String(s || "").trim()).filter(Boolean)),
  ];
  const classNum = Number(String(profile?.class_level || "").replace(/[^0-9]/g, "")) || 10;
  const board = String(profile?.board || "CBSE").trim();
  const branchId = profile?.branch_id ? Number(profile.branch_id) : null;

  const rules = db
    .prepare("SELECT * FROM v33_cross_sell_rules WHERE is_active = 1 AND (branch_id IS NULL OR branch_id = ?) ORDER BY priority ASC, id ASC")
    .all(branchId || -1);

  const recommendedMap = new Map();
  const addRec = (title, reason, category, ruleId = null) => {
    const key = String(title || "").trim().toLowerCase();
    if (!key) return;
    if (purchasedSubjects.some((s) => s.toLowerCase() === key)) return;
    if (!recommendedMap.has(key)) {
      recommendedMap.set(key, { title, reason, category, ruleId });
    }
  };

  for (const r of rules) {
    const items = safeJsonParse(r.recommended_items_json, []);
    if (r.rule_type === "subject") {
      const matched = purchasedSubjects.some((s) => s.toLowerCase().includes(String(r.trigger_value).toLowerCase()));
      if (matched) {
        for (const it of items) addRec(it, `Pairs great with ${r.trigger_value}`, r.category, r.id);
      }
    } else if (r.rule_type === "board") {
      if (board.toLowerCase().includes(String(r.trigger_value).toLowerCase())) {
        for (const it of items) addRec(it, `Recommended for ${board}`, r.category, r.id);
      }
    } else if (r.rule_type === "class_range") {
      const [lo, hi] = String(r.trigger_value).split("-").map(Number);
      if (classNum >= (lo || 6) && classNum <= (hi || 12)) {
        for (const it of items) addRec(it, `Popular for Class ${classNum}th`, r.category, r.id);
      }
    }
  }

  // Real Performance-Based Recommendations (from actual offline_test_marks & attendance)
  const weakSubjects = [];
  try {
    const markRows = db
      .prepare(
        `SELECT t.subject_name, AVG(CASE WHEN t.max_marks > 0 THEN (m.marks_obtained * 100.0 / t.max_marks) ELSE NULL END) AS avg_pct,
                COUNT(*) AS attempts
         FROM offline_test_marks m
         JOIN offline_tests t ON t.id = m.test_id
         WHERE m.student_id = ? AND m.is_absent = 0
         GROUP BY t.subject_name
         HAVING avg_pct < 65
         ORDER BY avg_pct ASC`
      )
      .all(sid);
    for (const m of markRows) {
      weakSubjects.push({
        subject: m.subject_name,
        avgPercent: Math.round(Number(m.avg_pct || 0)),
        attempts: Number(m.attempts || 0),
        suggestion: `${m.subject_name} Booster & Doubt-Solving Pack`,
      });
      addRec(`${m.subject_name} Improvement Booster`, `Based on your ${Math.round(m.avg_pct)}% test average`, "Performance Booster");
    }
  } catch {
    // ignore if offline_test_marks empty
  }

  // Real "Students Also Bought" co-purchase query (ZERO fake data!)
  const alsoBought = [];
  try {
    const myCourseIds = db
      .prepare("SELECT DISTINCT course_id FROM enrollments WHERE student_id = ? AND course_id IS NOT NULL")
      .all(sid)
      .map((r) => Number(r.course_id));
    if (myCourseIds.length > 0) {
      const ph = myCourseIds.map(() => "?").join(",");
      const rows = db
        .prepare(
          `SELECT c.id, c.title, c.category, c.monthly_fee, COUNT(DISTINCT e2.student_id) AS peer_count
           FROM enrollments e1
           JOIN enrollments e2 ON e1.student_id = e2.student_id AND e2.course_id != e1.course_id
           JOIN courses c ON c.id = e2.course_id AND c.is_active = 1
           WHERE e1.course_id IN (${ph}) AND e2.course_id NOT IN (${ph})
           GROUP BY c.id
           ORDER BY peer_count DESC
           LIMIT 5`
        )
        .all(...myCourseIds, ...myCourseIds);
      for (const r of rows) {
        alsoBought.push({
          courseId: Number(r.id),
          title: r.title,
          category: r.category,
          monthlyFee: Number(r.monthly_fee || 0),
          peerCount: Number(r.peer_count || 0),
        });
      }
    }
  } catch {
    // ignore
  }

  // Available Bundles with Smart Upgrade Preview
  const prevPaid = Number(
    db
      .prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE student_id = ? AND verification_status = 'verified'")
      .get(sid)?.total || 0
  );
  const bundles = db
    .prepare("SELECT * FROM v33_bundles WHERE is_active = 1 ORDER BY priority ASC, id ASC")
    .all()
    .map((b) => {
      const subjects = safeJsonParse(b.subjects_json, []);
      const monthlyNet = b.custom_price > 0 ? Number(b.custom_price) : Math.round(Number(b.base_monthly_price || 0) * (1 - Number(b.discount_percent || 0) / 100));
      const yearlyPrice = Math.round(monthlyNet * 12 * 0.8);
      const upgradeCalc = computeSmartUpgradePricing({ newPackagePrice: yearlyPrice, previousPaidAmount: prevPaid });
      return {
        id: Number(b.id),
        code: b.code,
        name: b.name,
        category: b.category,
        classLevel: b.class_level,
        subjects,
        discountPercent: Number(b.discount_percent || 0),
        monthlyNet,
        yearlyPrice,
        upgradeRemainingPayable: upgradeCalc.remainingPayable,
        previousPaidCredit: upgradeCalc.creditApplied,
        badge: `Save ${Number(b.discount_percent || 0)}% with Bundle`,
        description: b.description,
      };
    });

  // Active Add-On Products
  const addons = db
    .prepare("SELECT * FROM v33_addons WHERE is_active = 1 ORDER BY id ASC")
    .all()
    .map((a) => ({
      id: Number(a.id),
      code: a.code,
      title: a.title,
      category: a.category,
      price: Number(a.price || 0),
      promoPrice: Number(a.promo_price || 0),
      effectivePrice: Number(a.promo_price) > 0 && Number(a.promo_price) < Number(a.price) ? Number(a.promo_price) : Number(a.price),
      description: a.description,
    }));

  // Active Limited-Time Offers (for live countdown timer)
  const nowStr = nowIso();
  const activeOffers = db
    .prepare("SELECT * FROM v33_promo_offers WHERE is_active = 1 AND start_at <= ? AND end_at >= ? ORDER BY end_at ASC")
    .all(nowStr, nowStr)
    .map((o) => ({
      id: Number(o.id),
      code: o.code,
      title: o.title,
      offerType: o.offer_type,
      discountType: o.discount_type,
      discountValue: Number(o.discount_value || 0),
      startAt: o.start_at,
      endAt: o.end_at,
      bannerText: o.banner_text || `${o.title} — ${o.discount_type === "fixed" ? `₹${o.discount_value}` : `${o.discount_value}%`} OFF`,
    }));

  // Gamified Learning Path (based on actual lesson progress + subject coverage)
  let lessonsTotal = 0;
  let lessonsCompleted = 0;
  try {
    const lp = db
      .prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS done FROM lesson_progress WHERE student_id = ?")
      .get(sid);
    lessonsTotal = Number(lp?.total || 0);
    lessonsCompleted = Number(lp?.done || 0);
  } catch {
    // ignore
  }
  const availableForClass = CLASS_SUBJECT_CATALOG[String(classNum)] || CLASS_SUBJECT_CATALOG["10"];
  const subjectCoveragePct = availableForClass.length ? Math.round((purchasedSubjects.length / availableForClass.length) * 100) : 0;
  const lessonPct = lessonsTotal > 0 ? Math.round((lessonsCompleted / lessonsTotal) * 100) : subjectCoveragePct;
  const remainingSubjectsNeeded = Math.max(0, Math.min(2, availableForClass.length - purchasedSubjects.length));
  const gamifiedPrompt =
    remainingSubjectsNeeded > 0
      ? `You have completed ${lessonPct}% of your recommended learning path (${purchasedSubjects.length}/${availableForClass.length} subjects active). Add ${remainingSubjectsNeeded} more subject${remainingSubjectsNeeded > 1 ? "s" : ""} and unlock Complete Package Benefits.`
      : `Awesome progress! You have completed ${lessonPct}% of your learning path with full class subject coverage.`;

  return {
    studentClass: `Class ${classNum}th`,
    board,
    purchasedSubjects,
    recommendations: Array.from(recommendedMap.values()).slice(0, 12),
    weakSubjects,
    alsoBought,
    bundles,
    addons,
    activeOffers,
    gamifiedPath: {
      progressPercent: lessonPct,
      lessonsCompleted,
      lessonsTotal,
      activeSubjectsCount: purchasedSubjects.length,
      totalClassSubjects: availableForClass.length,
      message: gamifiedPrompt,
    },
  };
}

/**
 * LIVE MESSAGE TEMPLATE PREVIEW WITH PLACEHOLDER INTERPOLATION
 */
export function renderMessagePreview({ subject = "", bodyHtml = "", context = {} }) {
  const vars = {
    student_name: String(context.studentName || "Student"),
    course: String(context.course || "Selected Course"),
    branch: String(context.branch || "Muradnagar Branch"),
    fee_amount: String(context.feeAmount ?? 0),
    pending_amount: String(context.pendingAmount ?? 0),
    due_date: String(context.dueDate || "-"),
    roll_number: String(context.rollNumber || "-"),
    phone: String(context.phone || ""),
  };
  const interpolate = (str, escapeValues = false) =>
    String(str || "").replace(/\{\{\s*([a-z0-9_]+)\s*\}\}/gi, (_, key) => {
      const k = String(key).toLowerCase();
      const val = vars[k] !== undefined ? vars[k] : "";
      return escapeValues ? escapeHtml(val) : val;
    });

  const renderedSubject = interpolate(subject, false);
  const renderedHtml = interpolate(bodyHtml, true);
  const plainText = renderedHtml
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return {
    subject: renderedSubject,
    html: renderedHtml,
    plainText,
    whatsappUrl: vars.phone
      ? `https://wa.me/91${vars.phone.replace(/\D/g, "").slice(-10)}?text=${encodeURIComponent(plainText)}`
      : "",
    placeholdersUsed: vars,
  };
}

/**
 * AUTOMATED INVOICE FOLLOW-UP SWEEP (Runs in Central Scheduler every minute)
 * Sends Email + WhatsApp log + In-App Notification at scheduled date/time, prevents duplicates, stores delivery logs.
 */
export async function runInvoiceFollowupSweep(db, deps = {}, { now = new Date() } = {}) {
  ensureV33Schema(db);
  const nowStr = now.toISOString();
  const dueRows = db
    .prepare(
      `SELECT f.*, u.full_name, u.email, u.phone, b.name AS branch_name
       FROM v33_invoice_followups f
       JOIN users u ON u.id = f.student_id
       LEFT JOIN branches b ON b.id = u.branch_id
       WHERE f.status = 'scheduled' AND f.scheduled_at <= ?
       ORDER BY f.scheduled_at ASC
       LIMIT 30`
    )
    .all(nowStr);

  let dispatched = 0;
  for (const row of dueRows) {
    const fin = buildStudentFinancialSummary(db, row.student_id);
    const channels = safeJsonParse(row.channels_json, ["email", "whatsapp", "in_app"]);
    const msgText =
      row.custom_message ||
      `Hello ${row.full_name}, reminder for your pending Yuitor fee balance of ₹${fin?.summary?.pendingAmount || 0} (Due: ${fin?.summary?.dueDate || "-"}). Please complete payment via your Student Panel.`;

    const deliveryLog = { channels: {}, executedAt: nowStr };

    if (channels.includes("in_app")) {
      db.prepare(
        `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
         VALUES (?, 'student', ?, ?, 0, 'new', '#fees', 'invoice', ?, ?)`
      ).run(
        row.student_id,
        `Fee Follow-Up (${row.reminder_type.replace(/_/g, " ")})`,
        msgText,
        String(row.fee_record_id || row.id),
        nowStr
      );
      deliveryLog.channels.in_app = { ok: true, status: "delivered" };
    }

    if (channels.includes("email") && row.email) {
      let emailOk = false;
      let emailNote = "queued";
      if (typeof deps.sendTransactionalEmail === "function") {
        try {
          await deps.sendTransactionalEmail({
            to: row.email,
            subject: `Fee Follow-Up Reminder — Yuitor Smart Classes`,
            html: `<p>${escapeHtml(msgText)}</p>`,
          });
          emailOk = true;
          emailNote = "sent";
        } catch (err) {
          emailNote = String(err?.message || "smtp_error").slice(0, 120);
        }
      }
      deliveryLog.channels.email = { ok: emailOk, to: row.email, status: emailNote };
    }

    if (channels.includes("whatsapp") && row.phone) {
      const cleanPhone = String(row.phone).replace(/\D/g, "").slice(-10);
      const waLink = `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(msgText)}`;
      try {
        db.prepare(
          `INSERT INTO alert_dispatch_logs (channel, recipient_user_id, recipient_name, recipient_contact, category, message, status, provider_response, created_at)
           VALUES ('whatsapp', ?, ?, ?, 'invoice_followup', ?, 'logged', ?, ?)`
        ).run(row.student_id, row.full_name, cleanPhone, msgText, waLink, nowStr);
      } catch {
        // ignore if alert_dispatch_logs absent
      }
      deliveryLog.channels.whatsapp = { ok: true, phone: cleanPhone, status: "logged", waLink };
    }

    db.prepare(
      `UPDATE v33_invoice_followups SET status = 'sent', sent_at = ?, delivery_log_json = ? WHERE id = ?`
    ).run(nowStr, JSON.stringify(deliveryLog), row.id);
    dispatched += 1;
  }

  return { scanned: dueRows.length, dispatched };
}

/**
 * COURSE RENEWAL AUTOMATION (v3.3 Configurable Offsets: 30, 15, 7, 3, 1 Days Before Expiry)
 * Prevents duplicate reminders via v32_reminder_logs and stops automatically once renewed.
 */
export async function runCourseRenewalV33Sweep(db, deps = {}, { now = new Date() } = {}) {
  ensureV33Schema(db);
  const cfg = getV33PricingConfig(db);
  const offsets = Array.isArray(cfg.renewalOffsets) && cfg.renewalOffsets.length ? cfg.renewalOffsets : DEFAULT_RENEWAL_OFFSETS;
  const todayStr = getIstDateKey(now);
  const todayMs = Date.parse(todayStr);

  const enrollments = db
    .prepare(
      `SELECT e.id, e.student_id, e.course_id, e.expires_at, u.full_name, u.email, u.phone, c.title AS course_title
       FROM enrollments e
       JOIN users u ON u.id = e.student_id
       LEFT JOIN courses c ON c.id = e.course_id
       WHERE e.status = 'active' AND u.is_active = 1 AND e.expires_at IS NOT NULL AND e.expires_at != ''`
    )
    .all();

  let triggered = 0;
  let skippedDuplicate = 0;
  for (const e of enrollments) {
    const expDateStr = String(e.expires_at).slice(0, 10);
    const expMs = Date.parse(expDateStr);
    if (!Number.isFinite(expMs)) continue;
    const daysLeft = Math.round((expMs - todayMs) / 86400000);
    if (!offsets.includes(daysLeft)) continue;

    const rKey = `v33_renewal:${e.id}:${expDateStr}:d${daysLeft}`;
    try {
      const exists = db.prepare("SELECT id FROM v32_reminder_logs WHERE reminder_key = ?").get(rKey);
      if (exists) {
        skippedDuplicate += 1;
        continue;
      }
    } catch {
      // ignore if table absent
    }

    const msg = `Hi ${e.full_name}, your course "${e.course_title || "Yuitor Course"}" expires in ${daysLeft} day(s) on ${expDateStr}. Renew now and get ${cfg.renewalDiscountPercent}% early renewal savings!`;

    db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
       VALUES (?, 'student', ?, ?, 0, 'new', '#fees', 'course_renewal', ?, ?)`
    ).run(e.student_id, `Renewal Reminder (${daysLeft}d left)`, msg, String(e.id), now.toISOString());

    try {
      db.prepare(
        `INSERT OR IGNORE INTO v32_reminder_logs (reminder_key, reminder_type, user_id, email, meta_json, sent_at)
         VALUES (?, 'v33_course_renewal', ?, ?, ?, ?)`
      ).run(rKey, e.student_id, e.email || "", JSON.stringify({ enrollmentId: e.id, daysLeft, expDateStr }), now.toISOString());
    } catch {
      // ignore
    }

    if (typeof deps.sendTransactionalEmail === "function" && e.email) {
      try {
        await deps.sendTransactionalEmail({
          to: e.email,
          subject: `Course Renewal Reminder (${daysLeft} Days Left) — ${e.course_title || "Yuitor"}`,
          html: `<p>${escapeHtml(msg)}</p>`,
        });
      } catch {
        // non-fatal
      }
    }
    triggered += 1;
  }
  return { scanned: enrollments.length, triggered, skippedDuplicate, offsets };
}

/**
 * COMPREHENSIVE REVENUE & SALES ANALYTICS ENGINE (Strictly from verified payments & real DB records)
 */
export function buildRevenueAndSalesAnalytics(db, filters = {}) {
  ensureV33Schema(db);
  const { fromDate = "", toDate = "", branchId = "", courseId = "", subject = "" } = filters;

  const wherePay = ["p.verification_status = 'verified'", "COALESCE(p.refund_status, 'none') != 'refunded'"];
  const params = [];
  if (fromDate) {
    wherePay.push("substr(COALESCE(p.paid_at, p.created_at), 1, 10) >= ?");
    params.push(String(fromDate).slice(0, 10));
  }
  if (toDate) {
    wherePay.push("substr(COALESCE(p.paid_at, p.created_at), 1, 10) <= ?");
    params.push(String(toDate).slice(0, 10));
  }
  if (branchId) {
    wherePay.push("u.branch_id = ?");
    params.push(Number(branchId));
  }
  if (courseId) {
    wherePay.push("p.course_id = ?");
    params.push(Number(courseId));
  }

  const verifiedRows = db
    .prepare(
      `SELECT p.id, p.student_id, p.course_id, p.amount, p.discount_amount, p.base_amount, p.plan, p.notes,
              p.payment_method, p.coupon_code, COALESCE(p.paid_at, p.created_at) AS tx_date,
              u.full_name AS student_name, u.branch_id, COALESCE(b.name, 'Muradnagar Branch') AS branch_name,
              COALESCE(c.title, 'General / Package') AS course_title, COALESCE(c.category, 'General') AS course_category,
              sp.subjects_json
       FROM payments p
       JOIN users u ON u.id = p.student_id
       LEFT JOIN branches b ON b.id = u.branch_id
       LEFT JOIN courses c ON c.id = p.course_id
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       WHERE ${wherePay.join(" AND ")}
       ORDER BY tx_date DESC`
    )
    .all(...params);

  const today = getIstDateKey();
  const thisMonth = today.slice(0, 7);
  const thisYear = today.slice(0, 4);

  let dailyRevenue = 0;
  let monthlyRevenue = 0;
  let yearlyRevenue = 0;
  let totalCollected = 0;
  let totalDiscounts = 0;
  let crossSellRevenue = 0;
  let upsellRevenue = 0;
  let renewalRevenue = 0;
  let addonRevenue = 0;

  const byBranch = new Map();
  const byCourse = new Map();
  const bySubject = new Map();
  const byMonth = new Map();

  for (const r of verifiedRows) {
    const subjList = safeJsonParse(r.subjects_json || "[]", []);
    if (subject && !subjList.some((s) => String(s).toLowerCase().includes(String(subject).toLowerCase()))) {
      continue;
    }
    const amt = Number(r.amount || 0);
    const disc = Number(r.discount_amount || 0);
    const dStr = String(r.tx_date || "").slice(0, 10);
    const mStr = dStr.slice(0, 7);
    const yStr = dStr.slice(0, 4);

    totalCollected += amt;
    totalDiscounts += disc;
    if (dStr === today) dailyRevenue += amt;
    if (mStr === thisMonth) monthlyRevenue += amt;
    if (yStr === thisYear) yearlyRevenue += amt;

    const noteLow = `${r.notes || ""} ${r.plan || ""}`.toLowerCase();
    if (noteLow.includes("cross")) crossSellRevenue += amt;
    if (noteLow.includes("upgrade") || noteLow.includes("upsell")) upsellRevenue += amt;
    if (noteLow.includes("renew")) renewalRevenue += amt;
    if (noteLow.includes("addon") || noteLow.includes("add-on")) addonRevenue += amt;

    byBranch.set(r.branch_name, (byBranch.get(r.branch_name) || 0) + amt);
    const cEntry = byCourse.get(r.course_title) || { title: r.course_title, revenue: 0, sales: 0 };
    cEntry.revenue += amt;
    cEntry.sales += 1;
    byCourse.set(r.course_title, cEntry);

    if (mStr) byMonth.set(mStr, (byMonth.get(mStr) || 0) + amt);

    const perSubjShare = subjList.length > 0 ? Math.round(amt / subjList.length) : 0;
    for (const sName of subjList) {
      const sEntry = bySubject.get(sName) || { subject: sName, revenue: 0, sales: 0 };
      sEntry.revenue += perSubjShare;
      sEntry.sales += 1;
      bySubject.set(sName, sEntry);
    }
  }

  // Pending Revenue & Refunds (distinctly tracked!)
  const pendingRow = db
    .prepare(
      `SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) AS pending
       FROM fee_records WHERE status IN ('pending', 'partial', 'overdue')`
    )
    .get();
  const pendingRevenue = Number(pendingRow?.pending || 0);

  const refundRow = db
    .prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE refund_status = 'refunded'")
    .get();
  const totalRefunds = Number(refundRow?.total || 0);

  const grossBilled = totalCollected + pendingRevenue;
  const collectionRate = grossBilled > 0 ? Math.round((totalCollected / grossBilled) * 100) : 0;

  // Upgrade & Bundle performance from v33_upgrade_history
  const bundlePerf = db
    .prepare(
      `SELECT to_target_name AS name, COUNT(*) AS sales, COALESCE(SUM(remaining_payable), 0) AS revenue
       FROM v33_upgrade_history GROUP BY to_target_name ORDER BY sales DESC, revenue DESC LIMIT 5`
    )
    .all();

  const ruleStats = db
    .prepare("SELECT COALESCE(SUM(impressions), 0) AS imp, COALESCE(SUM(conversions), 0) AS conv, COALESCE(SUM(revenue_generated), 0) AS rev FROM v33_cross_sell_rules")
    .get();
  const recConversionRate =
    Number(ruleStats?.imp || 0) > 0 ? Math.round((Number(ruleStats.conv || 0) / Number(ruleStats.imp)) * 100) : 0;

  const leadStats = db
    .prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'admitted' OR converted_student_id IS NOT NULL THEN 1 ELSE 0 END) AS conv FROM inquiries")
    .get();
  const campaignConversionRate =
    Number(leadStats?.total || 0) > 0 ? Math.round((Number(leadStats.conv || 0) / Number(leadStats.total)) * 100) : 0;

  const mostSoldCourses = Array.from(byCourse.values()).sort((a, b) => b.sales - a.sales || b.revenue - a.revenue);
  const mostSoldSubjects = Array.from(bySubject.values()).sort((a, b) => b.sales - a.sales || b.revenue - a.revenue);
  const highestRevenueSubject = [...mostSoldSubjects].sort((a, b) => b.revenue - a.revenue)[0] || null;
  const monthlyTrends = Array.from(byMonth.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, revenue]) => ({ month, revenue }));

  return {
    kpis: {
      dailyRevenue,
      monthlyRevenue,
      yearlyRevenue,
      totalCollected,
      pendingRevenue,
      totalRefunds,
      totalDiscounts,
      collectionRate,
      crossSellRevenue,
      upsellRevenue,
      renewalRevenue,
      addonRevenue,
      campaignConversionRate,
      recommendationConversionRate: recConversionRate,
    },
    branchWiseRevenue: Array.from(byBranch.entries()).map(([branch, revenue]) => ({ branch, revenue })),
    mostSoldCourses: mostSoldCourses.slice(0, 10),
    mostSoldSubjects: mostSoldSubjects.slice(0, 10),
    highestRevenueSubject,
    bestPerformingBundle: bundlePerf[0] || null,
    bundlePerformance: bundlePerf,
    monthlyTrends,
    studentPurchaseHistory: verifiedRows.slice(0, 50).map((r) => ({
      paymentId: r.id,
      studentId: r.student_id,
      studentName: r.student_name,
      branch: r.branch_name,
      course: r.course_title,
      amount: Number(r.amount || 0),
      discount: Number(r.discount_amount || 0),
      method: r.payment_method,
      date: String(r.tx_date || "").slice(0, 10),
    })),
  };
}

export function csvCellSafe(v) {
  let s = String(v ?? "").replace(/\r?\n/g, " ");
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
}

export function buildRevenueCsv(analytics) {
  const lines = [
    ["Payment ID", "Date", "Student", "Branch", "Course / Package", "Amount (INR)", "Discount (INR)", "Method"].map(csvCellSafe).join(","),
    ...(analytics.studentPurchaseHistory || []).map((row) =>
      [row.paymentId, row.date, row.studentName, row.branch, row.course, row.amount, row.discount, row.method].map(csvCellSafe).join(",")
    ),
  ];
  return lines.join("\n");
}

export function generateOtpCode() {
  return String(crypto.randomInt(100000, 1000000));
}
