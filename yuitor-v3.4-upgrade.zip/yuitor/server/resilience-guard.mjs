// Yuitor Smart Classes v3.4 — Zero-Downtime Fault Isolation, Circuit Breakers & Error Vault
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { Router } from "express";
import { redactSecretsForLog } from "./security-hardening.mjs";

const OPTIONAL_MODULES = [
  {
    name: "chatbot",
    label: "Shreya AI Assistant",
    category: "widget",
    description: "Floating AI assistant widget and Gemini chat endpoint"
  },
  {
    name: "festival_engine",
    label: "Festival Themes & Promos",
    category: "widget",
    description: "Automatic Indian festival themes and seasonal promo banners"
  },
  {
    name: "custom_scripts",
    label: "CMS Site Customizations",
    category: "widget",
    description: "Admin custom CSS/branding overrides on public pages"
  },
  {
    name: "mail_sync",
    label: "IMAP/SMTP Mail Hub Sync",
    category: "background",
    description: "Background mailbox inbox synchronization and campaign queue"
  },
  {
    name: "scheduler",
    label: "CRM Automation Scheduler",
    category: "background",
    description: "Automated fee reminders, reports, and risk scoring jobs"
  },
  {
    name: "addons_cart_wallet",
    label: "Cart, Wallet & Referrals",
    category: "addon",
    description: "Multi-course cart checkout, student/teacher wallet, and referral engine"
  },
  {
    name: "crm_automation",
    label: "Smart CRM & Exception Inbox",
    category: "addon",
    description: "CRM lead automation rules, CBT exams, and doubt SLA workflows"
  },
  {
    name: "v31_campaigns",
    label: "v3.1 Campaigns & Cross-Sell",
    category: "addon",
    description: "Email campaigns, templates, and course cross-sell engine"
  },
  {
    name: "v32_public",
    label: "v3.2 Quick Register & Media",
    category: "addon",
    description: "Quick registration modal, media gallery, and renewal sweeps"
  },
  {
    name: "v33_hub",
    label: "v3.3 Dynamic Pricing & Hub",
    category: "addon",
    description: "v3.3 dynamic checkout pricing, follow-ups, and analytics"
  }
];

const OPTIONAL_MODULE_SET = new Set(OPTIONAL_MODULES.map((m) => m.name));
const CIRCUIT_THRESHOLD = 5;
const CIRCUIT_WINDOW_MS = 60 * 1000;
const CIRCUIT_COOLDOWN_MS = 120 * 1000;
const MEMORY_RING_LIMIT = 150;
const memoryErrorRing = [];
const inMemoryRollingHits = new Map();
const clientErrorRateWindow = new Map();
const GLOBAL_GUARD_KEY = Symbol.for("yuitor.globalProcessGuardsInstalled");
const WRAPPED_HANDLER_KEY = Symbol.for("yuitor.wrappedRouteHandler");

export function safeJsonParse(raw, fallback = null) {
  if (raw === null || raw === undefined || raw === "") return fallback;
  if (typeof raw !== "string") return raw;
  try {
    const parsed = JSON.parse(raw);
    return parsed === undefined ? fallback : parsed;
  } catch {
    return fallback;
  }
}

function nowIso() {
  return new Date().toISOString();
}

export function ensureResilienceSchema(db) {
  if (!db) return;
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_module_states (
      module_name TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'addon',
      description TEXT NOT NULL DEFAULT '',
      enabled INTEGER NOT NULL DEFAULT 1,
      circuit_open_until TEXT DEFAULT NULL,
      consecutive_errors INTEGER NOT NULL DEFAULT 0,
      total_errors INTEGER NOT NULL DEFAULT 0,
      last_error_at TEXT DEFAULT NULL,
      last_error_message TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      updated_by INTEGER DEFAULT NULL
    );

    CREATE TABLE IF NOT EXISTS system_error_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      source TEXT NOT NULL DEFAULT 'backend',
      module_name TEXT NOT NULL DEFAULT 'core',
      severity TEXT NOT NULL DEFAULT 'error',
      route TEXT NOT NULL DEFAULT '',
      message TEXT NOT NULL,
      stack_excerpt TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_system_error_logs_created ON system_error_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_system_error_logs_module ON system_error_logs(module_name);
  `);

  const upsert = db.prepare(`
    INSERT INTO system_module_states (module_name, label, category, description, enabled, updated_at)
    VALUES (?, ?, ?, ?, 1, ?)
    ON CONFLICT(module_name) DO UPDATE SET
      label = excluded.label,
      category = excluded.category,
      description = excluded.description
  `);
  const ts = nowIso();
  for (const mod of OPTIONAL_MODULES) {
    upsert.run(mod.name, mod.label, mod.category, mod.description, ts);
  }
}

export function recordSystemError(db, info = {}) {
  const source = String(info.source || "backend").slice(0, 32);
  const moduleName = String(info.moduleName || "core").slice(0, 64);
  const severity = ["info", "warn", "error", "critical"].includes(String(info.severity))
    ? String(info.severity)
    : "error";
  const route = redactSecretsForLog(String(info.route || "").slice(0, 220));
  const rawMessage = info.error?.message || info.message || String(info.error || "Unexpected error");
  const message = redactSecretsForLog(String(rawMessage)).slice(0, 800) || "Unexpected error";
  const rawStack = info.error?.stack || info.stack || "";
  const stackExcerpt = redactSecretsForLog(String(rawStack)).slice(0, 1400);
  const createdAt = nowIso();

  const entry = {
    source,
    module_name: moduleName,
    severity,
    route,
    message,
    stack_excerpt: stackExcerpt,
    created_at: createdAt
  };

  memoryErrorRing.unshift(entry);
  if (memoryErrorRing.length > MEMORY_RING_LIMIT) {
    memoryErrorRing.length = MEMORY_RING_LIMIT;
  }

  if (!db) return entry;

  try {
    db.prepare(
      `INSERT INTO system_error_logs (source, module_name, severity, route, message, stack_excerpt, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(source, moduleName, severity, route, message, stackExcerpt, createdAt);

    db.prepare(
      `DELETE FROM system_error_logs
       WHERE id NOT IN (SELECT id FROM system_error_logs ORDER BY id DESC LIMIT 500)`
    ).run();

    if (OPTIONAL_MODULE_SET.has(moduleName) && severity !== "info" && severity !== "warn") {
      const nowMs = Date.now();
      const hits = (inMemoryRollingHits.get(moduleName) || []).filter((t) => nowMs - t <= CIRCUIT_WINDOW_MS);
      hits.push(nowMs);
      inMemoryRollingHits.set(moduleName, hits);

      const tripUntil =
        hits.length >= CIRCUIT_THRESHOLD ? new Date(nowMs + CIRCUIT_COOLDOWN_MS).toISOString() : null;

      if (tripUntil) {
        db.prepare(
          `UPDATE system_module_states
           SET consecutive_errors = ?,
               total_errors = total_errors + 1,
               last_error_at = ?,
               last_error_message = ?,
               circuit_open_until = ?,
               updated_at = ?
           WHERE module_name = ?`
        ).run(hits.length, createdAt, message.slice(0, 300), tripUntil, createdAt, moduleName);
      } else {
        db.prepare(
          `UPDATE system_module_states
           SET consecutive_errors = ?,
               total_errors = total_errors + 1,
               last_error_at = ?,
               last_error_message = ?,
               updated_at = ?
           WHERE module_name = ?`
        ).run(hits.length, createdAt, message.slice(0, 300), createdAt, moduleName);
      }
    }
  } catch {
    // Never let error logging crash the application
  }

  return entry;
}

export function isModuleEnabled(db, moduleName) {
  if (!OPTIONAL_MODULE_SET.has(moduleName)) return true;
  if (!db) return true;
  try {
    const row = db
      .prepare("SELECT enabled, circuit_open_until FROM system_module_states WHERE module_name = ?")
      .get(moduleName);
    if (!row) return true;
    if (Number(row.enabled) !== 1) return false;
    if (row.circuit_open_until) {
      const openUntilMs = Date.parse(row.circuit_open_until);
      if (Number.isFinite(openUntilMs) && openUntilMs > Date.now()) {
        return false;
      }
      // Cooldown expired — reset circuit half-open back to active
      db.prepare(
        "UPDATE system_module_states SET circuit_open_until = NULL, consecutive_errors = 0, updated_at = ? WHERE module_name = ?"
      ).run(nowIso(), moduleName);
      inMemoryRollingHits.delete(moduleName);
    }
    return true;
  } catch {
    return true;
  }
}

export function getPublicModulesStatus(db) {
  const status = {};
  for (const mod of OPTIONAL_MODULES) {
    status[mod.name] = isModuleEnabled(db, mod.name);
  }
  return status;
}

export function setModuleState(db, moduleName, opts = {}) {
  if (!OPTIONAL_MODULE_SET.has(moduleName)) {
    return { ok: false, error: "Unknown module name." };
  }
  const now = nowIso();
  const row = db.prepare("SELECT * FROM system_module_states WHERE module_name = ?").get(moduleName);
  const nextEnabled = opts.enabled === undefined ? Number(row?.enabled ?? 1) : opts.enabled ? 1 : 0;
  const resetCircuit = Boolean(opts.resetCircuit || nextEnabled === 1);
  if (resetCircuit) {
    inMemoryRollingHits.delete(moduleName);
  }
  db.prepare(
    `UPDATE system_module_states
     SET enabled = ?,
         circuit_open_until = CASE WHEN ? = 1 THEN NULL ELSE circuit_open_until END,
         consecutive_errors = CASE WHEN ? = 1 THEN 0 ELSE consecutive_errors END,
         updated_at = ?,
         updated_by = ?
     WHERE module_name = ?`
  ).run(nextEnabled, resetCircuit ? 1 : 0, resetCircuit ? 1 : 0, now, opts.updatedBy ?? null, moduleName);

  return {
    ok: true,
    module: db.prepare("SELECT * FROM system_module_states WHERE module_name = ?").get(moduleName)
  };
}

function wrapRouteCallback(fn, moduleName, db, opts = {}) {
  if (typeof fn !== "function") return fn;
  // Sub-router (Express Router has .stack and .handle)
  if (typeof fn.handle === "function" && Array.isArray(fn.stack)) {
    return protectRouter(fn, moduleName, db, opts);
  }
  // Error middleware (err, req, res, next)
  if (fn.length === 4) {
    return fn;
  }
  if (fn[WRAPPED_HANDLER_KEY]) {
    return fn;
  }
  const wrapped = function yuitorSafeHandler(req, res, next) {
    if (opts.optionalModule && OPTIONAL_MODULE_SET.has(moduleName) && !isModuleEnabled(db, moduleName)) {
      if (!res.headersSent) {
        return res.status(503).json({
          error: `The '${moduleName}' module is temporarily isolated to keep the website & admin online.`,
          moduleDisabled: true,
          module: moduleName
        });
      }
      return;
    }

    try {
      const result = fn.call(this, req, res, next);
      if (result && typeof result.then === "function") {
        result.catch((err) => {
          recordSystemError(db, {
            source: "backend-route",
            moduleName,
            severity: "error",
            route: `${req.method} ${req.originalUrl || req.path || ""}`,
            error: err
          });
          if (!res.headersSent) {
            const status = Number(err?.status) >= 400 && Number(err?.status) < 500 ? Number(err.status) : 500;
            const safeMsg =
              status >= 500
                ? "An isolated error occurred in this feature. The rest of the website remains unaffected."
                : redactSecretsForLog(err?.message || "Request could not be completed.");
            res.status(status).json({ error: safeMsg, isolatedModule: moduleName });
          }
        });
      }
    } catch (err) {
      recordSystemError(db, {
        source: "backend-route",
        moduleName,
        severity: "error",
        route: `${req.method} ${req.originalUrl || req.path || ""}`,
        error: err
      });
      if (!res.headersSent) {
        const status = Number(err?.status) >= 400 && Number(err?.status) < 500 ? Number(err.status) : 500;
        const safeMsg =
          status >= 500
            ? "An isolated error occurred in this feature. The rest of the website remains unaffected."
            : redactSecretsForLog(err?.message || "Request could not be completed.");
        res.status(status).json({ error: safeMsg, isolatedModule: moduleName });
      }
    }
  };
  wrapped[WRAPPED_HANDLER_KEY] = true;
  return wrapped;
}

export function protectRouter(router, moduleName = "core", db = null, opts = {}) {
  if (!router || typeof router !== "function") return router;

  // Wrap already-registered stack layers (e.g. routers returned by createXRouter())
  if (Array.isArray(router.stack)) {
    for (const layer of router.stack) {
      if (layer.route && Array.isArray(layer.route.stack)) {
        for (const routeLayer of layer.route.stack) {
          routeLayer.handle = wrapRouteCallback(routeLayer.handle, moduleName, db, opts);
        }
      } else if (typeof layer.handle === "function") {
        if (typeof layer.handle.handle === "function" && Array.isArray(layer.handle.stack)) {
          protectRouter(layer.handle, moduleName, db, opts);
        } else {
          layer.handle = wrapRouteCallback(layer.handle, moduleName, db, opts);
        }
      }
    }
  }

  return router;
}

export function installGlobalProcessGuards(getDbFn) {
  if (globalThis[GLOBAL_GUARD_KEY]) return;
  globalThis[GLOBAL_GUARD_KEY] = true;

  process.on("unhandledRejection", (reason) => {
    const db = typeof getDbFn === "function" ? (() => { try { return getDbFn(); } catch { return null; } })() : null;
    const errObj = reason instanceof Error ? reason : new Error(String(reason ?? "Unhandled promise rejection"));
    console.error("[Yuitor Resilience Guard] Caught unhandledRejection:", redactSecretsForLog(errObj.message));
    recordSystemError(db, {
      source: "process-rejection",
      moduleName: "background",
      severity: "critical",
      route: "process:unhandledRejection",
      error: errObj
    });
  });

  process.on("uncaughtException", (err) => {
    const db = typeof getDbFn === "function" ? (() => { try { return getDbFn(); } catch { return null; } })() : null;
    console.error("[Yuitor Resilience Guard] Caught uncaughtException:", redactSecretsForLog(err?.message || String(err)));
    recordSystemError(db, {
      source: "process-exception",
      moduleName: "background",
      severity: "critical",
      route: "process:uncaughtException",
      error: err instanceof Error ? err : new Error(String(err))
    });
  });
}

export function createResiliencePublicRouter(db, deps = {}) {
  const router = Router();
  const clientIp = deps.clientIp || ((req) => req.ip || "0.0.0.0");

  router.get("/public/modules-status", (_req, res) => {
    res.json({
      ok: true,
      modules: getPublicModulesStatus(db),
      timestamp: nowIso()
    });
  });

  router.post("/public/client-error", (req, res) => {
    const ip = String(clientIp(req) || "0.0.0.0");
    const now = Date.now();
    const bucket = (clientErrorRateWindow.get(ip) || []).filter((ts) => now - ts < 60_000);
    if (bucket.length >= 15) {
      res.status(429).json({ ok: false, throttled: true });
      return;
    }
    bucket.push(now);
    clientErrorRateWindow.set(ip, bucket);

    const moduleName = String(req.body?.moduleName || "frontend_widget").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64) || "frontend_widget";
    const route = String(req.body?.route || "/").slice(0, 200);
    const message = String(req.body?.message || "Client runtime error").slice(0, 600);
    const stack = String(req.body?.stack || "").slice(0, 1200);

    recordSystemError(db, {
      source: "frontend",
      moduleName,
      severity: "error",
      route,
      message,
      stack
    });
    res.json({ ok: true, recorded: true });
  });

  return router;
}

export function createResilienceAdminRouter(db, deps = {}) {
  const router = Router();
  const requireAdmin = deps.requireAdmin;
  const writeAuditLog = deps.writeAuditLog;
  const clientIp = deps.clientIp || ((req) => req.ip || "0.0.0.0");
  const backupsDir = deps.backupsDir;

  router.get("/resilience/overview", requireAdmin, (_req, res) => {
    const modules = db.prepare("SELECT * FROM system_module_states ORDER BY category ASC, label ASC").all();
    const errors = db.prepare("SELECT * FROM system_error_logs ORDER BY id DESC LIMIT 100").all();
    let dbCheck = "ok";
    try {
      const row = db.prepare("PRAGMA quick_check").get();
      dbCheck = Object.values(row || {})[0] || "ok";
    } catch (err) {
      dbCheck = `error: ${err?.message || "unknown"}`;
    }
    const mem = process.memoryUsage();
    let backupFiles = [];
    try {
      if (backupsDir && fs.existsSync(backupsDir)) {
        backupFiles = fs
          .readdirSync(backupsDir)
          .filter((f) => f.endsWith(".db"))
          .sort()
          .reverse()
          .slice(0, 12);
      }
    } catch {
      backupFiles = [];
    }

    res.json({
      ok: true,
      uptimeSeconds: Math.round(process.uptime()),
      nodeVersion: process.version,
      memoryMb: {
        rss: Math.round(mem.rss / (1024 * 1024)),
        heapUsed: Math.round(mem.heapUsed / (1024 * 1024))
      },
      dbQuickCheck: dbCheck,
      modules,
      errors,
      recentMemoryErrors: memoryErrorRing.slice(0, 20),
      backups: backupFiles
    });
  });

  router.post("/resilience/modules/:moduleName/toggle", requireAdmin, (req, res) => {
    const moduleName = String(req.params.moduleName || "").trim();
    const enabled = req.body?.enabled !== undefined ? Boolean(req.body.enabled) : undefined;
    const resetCircuit = Boolean(req.body?.resetCircuit);
    const result = setModuleState(db, moduleName, {
      enabled,
      resetCircuit,
      updatedBy: req.ctx?.user?.id || null
    });
    if (!result.ok) {
      res.status(404).json({ error: result.error });
      return;
    }
    try {
      writeAuditLog?.(db, {
        actorId: req.ctx?.user?.id,
        actorName: req.ctx?.user?.full_name || "Admin",
        action: "resilience_module_toggled",
        details: `${moduleName} -> enabled=${result.module.enabled} resetCircuit=${resetCircuit}`,
        ipAddress: clientIp(req)
      });
    } catch {
    }
    res.json({ ok: true, module: result.module });
  });

  router.post("/resilience/errors/clear", requireAdmin, (req, res) => {
    db.prepare("DELETE FROM system_error_logs").run();
    memoryErrorRing.length = 0;
    try {
      writeAuditLog?.(db, {
        actorId: req.ctx?.user?.id,
        actorName: req.ctx?.user?.full_name || "Admin",
        action: "resilience_errors_cleared",
        details: "Cleared system error vault",
        ipAddress: clientIp(req)
      });
    } catch {
    }
    res.json({ ok: true, cleared: true });
  });

  router.post("/resilience/db-check", requireAdmin, (_req, res) => {
    try {
      db.exec("PRAGMA wal_checkpoint(PASSIVE);");
    } catch {
    }
    const row = db.prepare("PRAGMA quick_check").get();
    const status = Object.values(row || {})[0] || "ok";
    res.json({ ok: status === "ok", status });
  });

  router.post("/resilience/backup-now", requireAdmin, (req, res) => {
    if (!backupsDir) {
      res.status(503).json({ error: "Backup directory is not configured." });
      return;
    }
    fs.mkdirSync(backupsDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const filename = `yuitor-resilience-${stamp}-${crypto.randomBytes(2).toString("hex")}.db`;
    const dest = path.resolve(backupsDir, filename);
    if (!dest.startsWith(path.resolve(backupsDir) + path.sep)) {
      res.status(400).json({ error: "Invalid backup path." });
      return;
    }
    const escapedDest = dest.replace(/'/g, "''");
    db.exec(`VACUUM INTO '${escapedDest}';`);
    try {
      writeAuditLog?.(db, {
        actorId: req.ctx?.user?.id,
        actorName: req.ctx?.user?.full_name || "Admin",
        action: "resilience_backup_created",
        details: `Created instant snapshot ${filename}`,
        ipAddress: clientIp(req)
      });
    } catch {
    }
    res.json({ ok: true, filename });
  });

  return router;
}
