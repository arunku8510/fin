import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { Router } from "express";
import {
  BILLING_CYCLES,
  CLASS_FEE_PLANS,
  calculateClassFeePlan,
  parseClassNumberFromLabel,
} from "./fee-plans.mjs";
import { getCartDetails, mergeGuestCartToUser } from "./cart-service.mjs";
import { buildSimplePdfBuffer } from "./crm-pdf.mjs";
import {
  escapeHtml,
  getAppBaseUrl,
  getCrossSellSettings,
  getIstDateKey,
  logV31Audit,
} from "./v31-engine.mjs";
import {
  QUICK_QUIZ_BANK,
  buildClassWiseFinanceReport,
  buildTeacherMonthlyPayoutLog,
  buildWhatsAppTemplates,
  createV32Certificate,
  exportClassFinanceReport,
  generateSampleNotesPdfBuffer,
  getV32Settings,
  gradeQuickQuiz,
  renderQrCertificateHtml,
  runAbandonedCartReminderSweep,
  runPlanExpiryRenewalSweep,
  updateV32Settings,
} from "./v32-engine.mjs";

const GUEST_CART_COOKIE = "ytr_cart_id";

export function createV32UserRouter(db, deps = {}) {
  const router = Router();
  const { getSessionContext, createSession, setSessionCookie, writeAuditLog, clientIp } = deps;

  /**
   * 1. Public Individual Classes 6th–12th Catalog (Single Source of Truth Fees, Live Vacant Seats, Synced Cross-Sell)
   */
  router.get("/public/classes-catalog", (req, res) => {
    const csSettings = getCrossSellSettings(db);
    const v32Settings = getV32Settings(db);

    const classes = CLASS_FEE_PLANS.map((plan) => {
      const slug = `class-${plan.classNumber}-coaching`;
      const course = db
        .prepare("SELECT * FROM courses WHERE (slug = ? OR slug = ?) AND is_active = 1 LIMIT 1")
        .get(slug, `class-${plan.classNumber}`);

      let batches = [];
      if (course) {
        batches = db
          .prepare(
            `SELECT b.id, b.name, b.code, b.room_name, b.schedule_days, b.start_time, b.end_time,
                    COALESCE(b.seat_limit, b.total_seats, 30) AS seat_limit,
                    u.full_name AS teacher_name,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) AS filled_seats
             FROM batches b
             LEFT JOIN users u ON u.id = b.teacher_id
             WHERE b.course_id = ? AND b.is_active = 1
             ORDER BY b.id ASC`
          )
          .all(course.id)
          .map((b) => {
            const seatLimit = Math.max(1, Number(b.seat_limit || 30));
            const filled = Number(b.filled_seats || 0);
            const seatsRemaining = Math.max(0, seatLimit - filled);
            return {
              id: Number(b.id),
              name: b.name,
              code: b.code || "",
              roomName: b.room_name || "Muradnagar Campus",
              scheduleDays: b.schedule_days || "Mon-Sat",
              timing: b.start_time ? `${b.start_time}–${b.end_time || ""}` : "Evening Batch",
              teacherName: b.teacher_name || "Yuitor Senior Faculty",
              seatLimit,
              filledSeats: filled,
              seatsRemaining,
            };
          });
      }

      const totalVacantSeats = batches.reduce((acc, b) => acc + b.seatsRemaining, 0);
      const pricingByCycle = {};
      for (const c of BILLING_CYCLES) {
        pricingByCycle[c.id] = calculateClassFeePlan(plan.classNumber, c.id);
      }

      return {
        classNumber: plan.classNumber,
        classLabel: plan.classLabel,
        courseId: course ? Number(course.id) : null,
        slug: course?.slug || slug,
        title: course?.title || `${plan.classLabel} Coaching`,
        description: course?.description || `${plan.classLabel} complete coaching with weekly tests & notes.`,
        thumbnailUrl: course?.thumbnail_url || "/assets/images/teacher-led-class.webp",
        monthlyFee: plan.monthly,
        yearlyGross: plan.yearlyGross,
        yearlyDiscountPercent: 10,
        yearlySavings: plan.yearlySavings,
        yearlyTotal: plan.yearlyTotal,
        pricingByCycle,
        batches,
        vacantSeats: batches.length > 0 ? totalVacantSeats : 25,
      };
    });

    res.json({
      classes,
      billingCycles: BILLING_CYCLES.map((c) => ({ ...c, key: c.id })),
      comboDiscount: {
        enabled: v32Settings.comboDiscountEnabled,
        percent: v32Settings.comboDiscountPercent,
      },
      crossSell: csSettings.masterSwitch
        ? {
            enabled: true,
            headline: "Special Cross-Sell Offer Active: Add an extra subject/course in Cart & unlock automatic server-verified discount!",
            discountPercent: 10,
          }
        : { enabled: false },
    });
  });

  /**
   * 2. Quick Register / Quick Login directly from Cart Drawer (Auto-merges guest cart!)
   *    Account starts as `pending_approval` until verified payment auto-activates it.
   */
  router.post("/public/quick-register", async (req, res) => {
    const mode = String(req.body?.mode || "register").toLowerCase();
    const email = String(req.body?.email || "").trim().toLowerCase();
    const phone = String(req.body?.phone || "").replace(/\D/g, "").slice(-10);
    const fullName = String(req.body?.fullName || "").trim().slice(0, 80);
    const password = String(req.body?.password || "");
    const classLevel = String(req.body?.classLevel || "Class 10th").trim().slice(0, 30);
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");

    if (!email || !email.includes("@")) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters." });
      return;
    }

    const existing = db.prepare("SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1").get(email);

    let user = existing;
    let isNewAccount = false;

    if (mode === "login" || existing) {
      if (!existing) {
        res.status(404).json({ error: "Account not found. Switch to Quick Register to create one." });
        return;
      }
      const blocked = new Set(["suspended", "terminated", "deleted", "rejected"]);
      if (blocked.has(String(existing.verification_status || "").toLowerCase())) {
        res.status(403).json({ error: "This account is currently restricted. Contact Yuitor Admin." });
        return;
      }
      const okPwd = await bcrypt.compare(password, existing.password_hash || "");
      if (!okPwd) {
        res.status(401).json({ error: "Incorrect password for this registered email." });
        return;
      }
      user = existing;
    } else {
      if (fullName.length < 2) {
        res.status(400).json({ error: "Please enter the student's full name." });
        return;
      }
      if (phone.length !== 10) {
        res.status(400).json({ error: "Please enter a valid 10-digit mobile number." });
        return;
      }
      const phoneDup = db.prepare("SELECT id FROM users WHERE phone = ? LIMIT 1").get(phone);
      if (phoneDup) {
        res.status(409).json({ error: "This mobile number is already registered. Please sign in with your email & password." });
        return;
      }
      const now = new Date().toISOString();
      const hash = await bcrypt.hash(password, 10);
      const roll = `YTR-STU-${String(Math.floor(1000 + Math.random() * 9000))}`;
      const ins = db
        .prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, is_active, verification_status, mobile_verified, created_at, updated_at)
           VALUES ('student', ?, ?, ?, ?, 1, 'pending_approval', 1, ?, ?)`
        )
        .run(fullName, email, phone, hash, now, now);
      const newId = Number(ins.lastInsertRowid);
      try {
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, roll_number, class_level, board, created_at)
           VALUES (?, ?, ?, 'CBSE', ?)`
        ).run(newId, roll, classLevel, now);
      } catch {
        // optional columns
      }
      user = db.prepare("SELECT * FROM users WHERE id = ?").get(newId);
      isNewAccount = true;
    }

    // Merge guest cart immediately
    if (guestToken) {
      mergeGuestCartToUser(db, user.id, guestToken);
    }

    if (typeof createSession === "function" && typeof setSessionCookie === "function") {
      const token = createSession(db, user.id, user.role);
      setSessionCookie(res, token, req);
    }

    if (typeof writeAuditLog === "function") {
      writeAuditLog(db, {
        actorId: user.id,
        actorName: user.full_name,
        targetId: user.id,
        targetName: user.email,
        action: isNewAccount ? "quick_cart_register" : "quick_cart_login",
        details: `Cart quick admission (${user.verification_status})`,
        ipAddress: typeof clientIp === "function" ? clientIp(req) : "",
      });
    }

    const cart = getCartDetails(db, { userId: user.id, guestToken });
    res.status(isNewAccount ? 201 : 200).json({
      ok: true,
      isNewAccount,
      user: {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        verification_status: user.verification_status,
      },
      cart,
      message: isNewAccount
        ? "Quick account created & cart saved! Complete payment to auto-activate your portal instantly."
        : "Signed in & guest cart merged! Proceed to checkout.",
    });
  });

  /**
   * 3. Free 5-Question Quick Quiz (Class 6th–12th) — No login required
   */
  router.get("/public/quick-quiz/:classNumber", (req, res) => {
    const cls = Math.min(12, Math.max(6, Number(req.params.classNumber || 10)));
    const bank = QUICK_QUIZ_BANK[cls] || QUICK_QUIZ_BANK[10];
    const plan = calculateClassFeePlan(cls, "1m");
    const course = db
      .prepare("SELECT id, title FROM courses WHERE slug = ? AND is_active = 1 LIMIT 1")
      .get(`class-${cls}-coaching`);
    res.json({
      classNumber: cls,
      classLabel: plan.classLabel,
      durationSeconds: 60,
      courseId: course ? Number(course.id) : null,
      monthlyFee: plan.monthlyRate,
      questions: bank.map((item, idx) => ({
        index: idx,
        question: item.q,
        options: item.options,
      })),
    });
  });

  router.post("/public/quick-quiz/:classNumber/submit", (req, res) => {
    const cls = Math.min(12, Math.max(6, Number(req.params.classNumber || 10)));
    const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];
    const graded = gradeQuickQuiz(cls, answers);
    const course = db
      .prepare("SELECT id, title FROM courses WHERE slug = ? AND is_active = 1 LIMIT 1")
      .get(`class-${cls}-coaching`);
    res.json({
      ...graded,
      courseId: course ? Number(course.id) : null,
      courseTitle: course?.title || `${graded.classLabel} Coaching`,
      ctaLabel: `Join ${graded.classLabel} (₹${graded.monthlyFee}/mo) — Add to Cart`,
    });
  });

  /**
   * 4. Freemium Class-Wise Notes & PYQ Library (1–2 public sample PDFs, full chapter notes unlocked only for active enrolled students)
   */
  router.get("/public/study-library", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    const classFilter = req.query?.classNumber ? Number(req.query.classNumber) : null;

    let enrolledCourseIds = new Set();
    let isPrivileged = false;
    if (ctx?.user) {
      if (["admin", "super_admin", "teacher"].includes(ctx.user.role)) {
        isPrivileged = true;
      } else if (ctx.user.role === "student" && Number(ctx.user.is_active) === 1 && ctx.user.verification_status === "approved") {
        const rows = db
          .prepare("SELECT course_id FROM enrollments WHERE student_id = ? AND status IN ('active', 'completed')")
          .all(ctx.user.id);
        enrolledCourseIds = new Set(rows.map((r) => Number(r.course_id)));
      }
    }

    let materials = [];
    try {
      materials = db
        .prepare(
          `SELECT m.*, c.title AS course_title, c.class_range
           FROM crm_study_materials m
           LEFT JOIN courses c ON c.id = m.course_id
           WHERE m.is_active = 1
           ORDER BY COALESCE(m.class_number, 10) ASC, m.is_free_sample DESC, m.id DESC`
        )
        .all();
    } catch {
      materials = [];
    }

    const items = materials
      .map((m) => {
        const cls = Number(m.class_number || parseClassNumberFromLabel(m.class_range || m.course_title) || 10);
        const isFreeSample = Number(m.is_free_sample || 0) === 1;
        const unlocked = isFreeSample || isPrivileged || enrolledCourseIds.has(Number(m.course_id));
        return {
          id: Number(m.id),
          courseId: m.course_id ? Number(m.course_id) : null,
          classNumber: cls,
          classLabel: `Class ${cls}th`,
          subjectName: m.subject_name || "General",
          chapterName: m.chapter_name || "",
          materialType: m.material_type || "notes",
          title: m.title,
          description: m.description || "",
          isFreeSample,
          unlocked,
          downloadUrl: unlocked ? m.file_url || `/api/public/study-library/sample-pdf/${cls}` : "",
        };
      })
      .filter((it) => (!classFilter ? true : it.classNumber === classFilter));

    res.json({ items, isEnrolledStudent: enrolledCourseIds.size > 0 || isPrivileged });
  });

  router.get("/public/study-library/sample-pdf/:classNumber", (req, res) => {
    const cls = Math.min(12, Math.max(6, Number(req.params.classNumber || 10)));
    const pdf = generateSampleNotesPdfBuffer(cls);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="yuitor-class-${cls}-free-sample-notes.pdf"`);
    res.send(pdf);
  });

  router.get("/student/study-library/pdf/:classNumber", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx?.user) {
      res.status(401).json({ error: "Sign in as an active enrolled student to unlock full chapter notes." });
      return;
    }
    const cls = Math.min(12, Math.max(6, Number(req.params.classNumber || 10)));
    const isStaff = ["admin", "super_admin", "teacher"].includes(ctx.user.role);
    if (!isStaff) {
      const course = db.prepare("SELECT id FROM courses WHERE slug = ? LIMIT 1").get(`class-${cls}-coaching`);
      const hasEnr = course
        ? db
            .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed') LIMIT 1")
            .get(ctx.user.id, course.id)
        : db
            .prepare("SELECT id FROM enrollments WHERE student_id = ? AND status IN ('active', 'completed') LIMIT 1")
            .get(ctx.user.id);
      if (!hasEnr) {
        res.status(403).json({ error: `Full notes for Class ${cls}th are unlocked exclusively for active enrolled students.` });
        return;
      }
    }
    const plan = calculateClassFeePlan(cls, "1m");
    const pdf = buildSimplePdfBuffer({
      title: `${plan.classLabel} Complete Chapter-Wise Notes & 5-Year PYQ Bank`,
      subtitle: `Issued to ${ctx.user.full_name} · Yuitor Smart Classes Muradnagar (Verified Enrolled Copy)`,
      rows: [
        { section: "Chapter 1–4 Summary & Board Formulas" },
        { label: "Mathematics", value: "Complete Theorems, Step-Marking Solutions, NCERT Exemplar & Case-Study Qs" },
        { label: "Science", value: "All Diagrams, Numericals, Chemical Equations & Expected 5-Mark Board Questions" },
        { section: "5-Year Solved PYQ Highlights" },
        { label: "Board Weightage", value: "High-frequency chapters highlighted with common marking-scheme pitfalls" },
        { label: "Doubt Support", value: "Upload any question photo in Hybrid Doubt Box for Shreya AI + Teacher review" },
      ],
    });
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="yuitor-class-${cls}-full-notes.pdf"`);
    res.send(pdf);
  });

  /**
   * 5. Live Class-Wise Notice Board (All or Class 6th–12th)
   */
  router.get("/public/live-notices", (req, res) => {
    const classFilter = String(req.query?.class || "").trim();
    const clsNum = parseClassNumberFromLabel(classFilter);
    let rows = [];
    try {
      rows = db
        .prepare(
          `SELECT id, title, body, badge_text, link_url, COALESCE(target_class, 'all') AS target_class, created_at
           FROM announcements
           WHERE is_active = 1
           ORDER BY id DESC LIMIT 20`
        )
        .all();
    } catch {
      rows = [];
    }
    const notices = rows.filter((n) => {
      const tc = String(n.target_class || "all").toLowerCase();
      if (!classFilter || tc === "all" || tc === "") return true;
      if (clsNum && parseClassNumberFromLabel(tc) === clsNum) return true;
      return tc === classFilter.toLowerCase();
    });
    res.json({ notices });
  });

  /**
   * 6. Instant Official Fee Receipt + Assigned Batch Timing & Teacher Slip (Student Portal)
   */
  router.get("/student/receipt-slip/:paymentId", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx?.user) {
      res.status(401).json({ error: "Authentication required." });
      return;
    }
    const pid = Number(req.params.paymentId);
    const pay = db
      .prepare(
        `SELECT p.*, u.full_name, u.email, u.phone, c.title AS course_title, c.class_range,
                e.batch_id, e.expires_at,
                b.name AS batch_name, b.schedule_days, b.start_time, b.end_time, b.room_name,
                t.full_name AS teacher_name
         FROM payments p
         JOIN users u ON u.id = p.student_id
         LEFT JOIN courses c ON c.id = p.course_id
         LEFT JOIN enrollments e ON e.id = p.enrollment_id
         LEFT JOIN batches b ON b.id = e.batch_id
         LEFT JOIN users t ON t.id = b.teacher_id
         WHERE p.id = ? LIMIT 1`
      )
      .get(pid);

    if (!pay) {
      res.status(404).json({ error: "Receipt not found." });
      return;
    }
    const isAdmin = ["admin", "super_admin"].includes(ctx.user.role);
    if (!isAdmin && Number(pay.student_id) !== Number(ctx.user.id)) {
      res.status(403).json({ error: "Access denied." });
      return;
    }

    if (String(req.query?.format || "") === "json") {
      res.json({ receipt: pay });
      return;
    }

    const timing = pay.start_time ? `${pay.schedule_days || "Mon-Sat"} · ${pay.start_time}–${pay.end_time || ""}` : "Mon–Sat Regular Batch";
    const html = `<!doctype html>
<html lang="en">
<head><meta charset="utf-8" /><title>Fee Receipt & Batch Slip — ${escapeHtml(pay.receipt_number || pay.invoice_number)}</title>
<style>
  body{font-family:system-ui,sans-serif;background:#f8fafc;padding:24px;color:#0f172a}
  .slip{max-width:740px;margin:0 auto;background:#fff;border:2px solid #7A0F28;border-radius:14px;padding:28px;box-shadow:0 16px 36px rgba(15,23,42,.08)}
  .hdr{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #e2e8f0;padding-bottom:14px;margin-bottom:18px}
  .brand h1{margin:0;color:#7A0F28;font-size:20px}
  .brand p{margin:3px 0 0;font-size:12px;color:#64748b}
  .badge{background:#dcfce7;color:#166534;padding:5px 12px;border-radius:999px;font-size:12px;font-weight:700}
  table{width:100%;border-collapse:collapse;margin:14px 0}
  td{padding:10px 12px;border-bottom:1px solid #e2e8f0;font-size:14px}
  td:first-child{font-weight:700;color:#475569;width:38%}
  .batch-box{background:#fff8eb;border:1px solid #f59e0b;border-radius:10px;padding:14px 16px;margin-top:16px}
  .btn{background:#7A0F28;color:#fff;border:0;padding:10px 16px;border-radius:8px;font-weight:700;cursor:pointer}
  @media print{.no-print{display:none}body{background:#fff;padding:0}}
</style></head>
<body>
  <div class="slip">
    <div class="hdr">
      <div class="brand">
        <h1>YUITOR SMART CLASSES</h1>
        <p>Official Fee Receipt &amp; Assigned Batch Slip · Trimurti Vihar, Muradnagar</p>
      </div>
      <div>
        <span class="badge">${escapeHtml(String(pay.verification_status || "verified").toUpperCase())}</span>
        <div style="font-size:12px;color:#475569;margin-top:6px;">Receipt: <strong>${escapeHtml(pay.receipt_number || pay.invoice_number)}</strong></div>
      </div>
    </div>
    <table>
      <tr><td>Student Name</td><td>${escapeHtml(pay.full_name)} (${escapeHtml(pay.email || "")})</td></tr>
      <tr><td>Course &amp; Plan</td><td>${escapeHtml(pay.course_title || "Yuitor Course")} (${escapeHtml(pay.plan || "1m")})</td></tr>
      <tr><td>Base Fee / Discount</td><td>₹${Number(pay.base_amount || pay.amount || 0).toLocaleString("en-IN")} / −₹${Number(pay.discount_amount || 0).toLocaleString("en-IN")}</td></tr>
      <tr><td>Amount Paid</td><td><strong>₹${Number(pay.amount || 0).toLocaleString("en-IN")}</strong> (${escapeHtml(String(pay.payment_method || "online").toUpperCase())})</td></tr>
      <tr><td>Valid Until</td><td>${escapeHtml(pay.expires_at || "Active Term")}</td></tr>
    </table>
    <div class="batch-box">
      <div style="font-weight:800;color:#92400e;margin-bottom:6px;">Assigned Batch &amp; Class Slip</div>
      <div style="font-size:14px;line-height:1.6;">
        <strong>Batch:</strong> ${escapeHtml(pay.batch_name || "Regular Batch")} &nbsp;|&nbsp;
        <strong>Timing:</strong> ${escapeHtml(timing)}<br/>
        <strong>Teacher:</strong> ${escapeHtml(pay.teacher_name || "Yuitor Senior Faculty")} &nbsp;|&nbsp;
        <strong>Room:</strong> ${escapeHtml(pay.room_name || "Muradnagar Campus")}
      </div>
    </div>
    <div class="no-print" style="margin-top:18px;text-align:right;">
      <button class="btn" onclick="window.print()">Print / Save PDF</button>
    </div>
  </div>
</body></html>`;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(html);
  });

  /**
   * 7. 1-Click Ready WhatsApp Templates (Teacher & Admin)
   */
  router.get("/v32/whatsapp-templates", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx?.user || !["admin", "super_admin", "teacher", "staff"].includes(ctx.user.role)) {
      res.status(403).json({ error: "Admin, Staff, or Teacher login required." });
      return;
    }
    const templates = buildWhatsAppTemplates({
      studentName: String(req.query?.studentName || "Student"),
      className: String(req.query?.className || "Class 10th"),
      amountDue: Number(req.query?.amountDue || 0),
      date: String(req.query?.date || getIstDateKey()),
      examName: String(req.query?.examName || "Weekly Test"),
      score: String(req.query?.score || ""),
    });
    res.json({ templates });
  });

  /**
   * 8. Teacher Monthly Payout & Class Log (Self View for Teacher)
   */
  router.get("/v32/teacher/payout-log", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx?.user || !["teacher", "admin", "super_admin"].includes(ctx.user.role)) {
      res.status(403).json({ error: "Teacher authentication required." });
      return;
    }
    const month = String(req.query?.month || getIstDateKey().slice(0, 7)).slice(0, 7);
    const all = buildTeacherMonthlyPayoutLog(db, month);
    const rows = ctx.user.role === "teacher" ? all.filter((t) => t.teacherId === Number(ctx.user.id)) : all;
    res.json({ salaryMonth: month, rows });
  });

  /**
   * 9. QR-Verified Certificate Public Verification & Printable View (v3.2 + Legacy Enrollment Fallback)
   */
  function findAnyCertificate(code) {
    const clean = String(code || "").trim().toUpperCase();
    if (!clean) return null;
    const cert = db.prepare("SELECT * FROM v32_certificates WHERE UPPER(certificate_code) = ? LIMIT 1").get(clean);
    if (cert) return cert;
    try {
      const legacy = db.prepare("SELECT * FROM certificates WHERE UPPER(certificate_code) = ? LIMIT 1").get(clean);
      if (legacy) return legacy;
    } catch {
      // ignore
    }
    try {
      const enr = db
        .prepare(
          `SELECT e.certificate_code, e.created_at, u.full_name AS student_name, c.title AS course_title, c.class_range AS class_label
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           LEFT JOIN courses c ON c.id = e.course_id
           WHERE UPPER(COALESCE(e.certificate_code, '')) = ? LIMIT 1`
        )
        .get(clean);
      if (enr) {
        return {
          certificate_code: enr.certificate_code,
          student_name: enr.student_name,
          class_label: enr.class_label || "Yuitor Program",
          course_title: enr.course_title || "Course Completion",
          cert_type: "completion",
          rank_or_score: "Verified Course Completion",
          issued_date_ist: String(enr.created_at || getIstDateKey()).slice(0, 10),
          is_valid: 1,
        };
      }
    } catch {
      // ignore
    }
    return null;
  }

  router.get("/student/v32/certificates", (req, res) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx?.user) {
      res.status(401).json({ error: "Authentication required." });
      return;
    }
    const v32Certs = db
      .prepare("SELECT * FROM v32_certificates WHERE student_id = ? OR LOWER(student_name) = LOWER(?) ORDER BY id DESC")
      .all(ctx.user.id, ctx.user.full_name || "");
    let enrCerts = [];
    try {
      enrCerts = db
        .prepare(
          `SELECT e.certificate_code, e.created_at, c.title AS course_title, c.class_range AS class_label
           FROM enrollments e
           LEFT JOIN courses c ON c.id = e.course_id
           WHERE e.student_id = ? AND COALESCE(e.certificate_code, '') <> ''
           ORDER BY e.id DESC`
        )
        .all(ctx.user.id)
        .map((r) => ({
          certificate_code: r.certificate_code,
          student_name: ctx.user.full_name,
          class_label: r.class_label || "Yuitor Program",
          course_title: r.course_title || "Course Completion",
          cert_type: "completion",
          rank_or_score: "Verified Course Completion",
          issued_date_ist: String(r.created_at || "").slice(0, 10),
        }));
    } catch {
      enrCerts = [];
    }
    const seen = new Set();
    const combined = [];
    for (const c of [...v32Certs, ...enrCerts]) {
      const k = String(c.certificate_code || "").toUpperCase();
      if (!k || seen.has(k)) continue;
      seen.add(k);
      combined.push(c);
    }
    res.json({ certificates: combined });
  });

  router.get("/certificates/verify/:code", (req, res) => {
    const cert = findAnyCertificate(req.params.code);
    if (!cert) {
      res.status(404).json({ valid: false, error: "Certificate code not found." });
      return;
    }
    res.json({ valid: cert.is_valid === undefined ? true : Number(cert.is_valid) === 1, certificate: cert });
  });

  router.get("/certificates/:code/print", (req, res) => {
    const cert = findAnyCertificate(req.params.code);
    if (!cert) {
      res.status(404).send("<h1>Certificate not found</h1>");
      return;
    }
    const baseUrl = getAppBaseUrl(deps);
    const html = renderQrCertificateHtml(cert, {
      baseUrl,
      pdfUrl: `/api/certificates/${encodeURIComponent(cert.certificate_code)}/pdf`,
    });
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(html);
  });

  router.get("/certificates/:code/pdf", (req, res) => {
    const cert = findAnyCertificate(req.params.code);
    if (!cert) {
      res.status(404).json({ error: "Certificate not found." });
      return;
    }
    const pdf = buildSimplePdfBuffer({
      title: cert.cert_type === "topper" ? "CERTIFICATE OF TOPPER EXCELLENCE" : "CERTIFICATE OF COURSE COMPLETION",
      subtitle: `Yuitor Smart Classes · QR Verified ID: ${cert.certificate_code}`,
      rows: [
        { section: "Recipient Details" },
        { label: "Student Name", value: cert.student_name },
        { label: "Class / Program", value: cert.class_label || cert.course_title || "Yuitor Program" },
        { label: "Achievement / Rank", value: cert.rank_or_score || "Successfully Completed" },
        { label: "Issued Date (IST)", value: cert.issued_date_ist },
        { label: "Verify Online", value: `${getAppBaseUrl(deps)}/api/certificates/verify/${cert.certificate_code}` },
      ],
    });
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="${cert.certificate_code}.pdf"`);
    res.send(pdf);
  });

  return router;
}

export function createV32AdminRouter(db, deps = {}) {
  const router = Router();
  const { getSessionContext } = deps;

  router.use((req, res, next) => {
    const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
    if (!ctx || !["admin", "super_admin"].includes(ctx.user.role)) {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.adminCtx = ctx;
    next();
  });

  // Admin v3.2 Settings (Multi-Subject Combo/Sibling Discount ON/OFF + %, AI Daily Rate Limits)
  router.get("/v32/settings", (_req, res) => {
    res.json({
      settings: getV32Settings(db),
      crossSell: getCrossSellSettings(db),
      feePlans: CLASS_FEE_PLANS,
    });
  });

  router.patch("/v32/settings", (req, res) => {
    const updated = updateV32Settings(db, req.body || {}, req.adminCtx.user.id);
    logV31Audit(db, {
      actorId: req.adminCtx.user.id,
      actorName: req.adminCtx.user.full_name,
      action: "v32_settings_updated",
      entityType: "v32_settings",
      entityId: "1",
      summary: `Combo=${updated.comboDiscountEnabled ? `${updated.comboDiscountPercent}%` : "OFF"}, GuestAI=${updated.guestDailyAiQuestions}q/${updated.guestDailyAiUploads}u, StudentAI=${updated.studentDailyAiQuestions}q/${updated.studentDailyAiUploads}u`,
      after: updated,
    });
    res.json({ ok: true, settings: updated });
  });

  // Class 6th–12th Revenue, Admissions, Pending Dues & Vacant Seats Report
  router.get("/v32/finance/class-report", (_req, res) => {
    res.json(buildClassWiseFinanceReport(db));
  });

  router.get("/v32/finance/class-report/export", (req, res) => {
    const format = String(req.query?.format || "csv").toLowerCase();
    const out = exportClassFinanceReport(db, format);
    res.setHeader("Content-Type", out.contentType);
    res.setHeader("Content-Disposition", `attachment; filename="${out.filename}"`);
    res.send(out.body);
  });

  // Teacher Monthly Payout & Class Log Summary
  router.get("/v32/teachers/payout-log", (req, res) => {
    const month = String(req.query?.month || getIstDateKey().slice(0, 7)).slice(0, 7);
    res.json({ salaryMonth: month, rows: buildTeacherMonthlyPayoutLog(db, month) });
  });

  // Topper / Course Completion QR-Verified Certificate Generator
  router.get("/v32/certificates", (_req, res) => {
    const certificates = db.prepare("SELECT * FROM v32_certificates ORDER BY id DESC LIMIT 100").all();
    res.json({ certificates });
  });

  router.post("/v32/certificates", (req, res) => {
    const studentId = req.body?.studentId ? Number(req.body.studentId) : null;
    let studentName = String(req.body?.studentName || "").trim();
    let classLabel = String(req.body?.classLabel || "").trim();
    if (studentId && !studentName) {
      const stu = db
        .prepare("SELECT u.full_name, sp.class_level FROM users u LEFT JOIN student_profiles sp ON sp.user_id = u.id WHERE u.id = ?")
        .get(studentId);
      if (stu) {
        studentName = stu.full_name;
        if (!classLabel) classLabel = stu.class_level || "";
      }
    }
    if (!studentName) {
      res.status(400).json({ error: "Student name is required to issue a certificate." });
      return;
    }
    const cert = createV32Certificate(db, {
      studentId,
      studentName,
      classLabel,
      courseTitle: String(req.body?.courseTitle || `${classLabel || "Yuitor"} Coaching`),
      certType: req.body?.certType === "topper" ? "topper" : "completion",
      rankOrScore: String(req.body?.rankOrScore || ""),
      issuedBy: req.adminCtx.user.id,
    });
    res.status(201).json({
      ok: true,
      certificate: cert,
      printUrl: `/api/certificates/${encodeURIComponent(cert.certificate_code)}/print`,
      pdfUrl: `/api/certificates/${encodeURIComponent(cert.certificate_code)}/pdf`,
      verifyUrl: `/api/certificates/verify/${encodeURIComponent(cert.certificate_code)}`,
    });
  });

  // Manual trigger for Abandoned Cart & Plan Expiry Renewal sweeps (ops/testing)
  router.post("/v32/reminders/run", async (_req, res) => {
    const settings = getV32Settings(db);
    const abandoned = await runAbandonedCartReminderSweep(db, deps, {
      minAgeMinutes: Math.max(60, Number(settings.abandonedCartHours || 1) * 60),
    });
    const renewals = await runPlanExpiryRenewalSweep(db, deps);
    res.json({ ok: true, abandoned, renewals });
  });

  return router;
}
