import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { ensureAddonsSchema } from "./addons-db.mjs";
import { ensureCrmV25Schema, getAutomationConfig, updateAutomationConfig } from "./crm-db.mjs";
import {
  assignSubstituteOnTeacherLeave,
  buildBirthdayEmailTemplate,
  buildRoleWelcomeEmailTemplate,
  buildWhatsAppClickToChatUrl,
  calculateCbtResult,
  calculateStudentRiskScore,
  calculateTeacherPayroll,
  checkMessageSafetyGate,
  computeCostPerAdmission,
  computeLeadScore,
  computeRankAndPercentile,
  detectTimetableClash,
  emitSystemEvent,
  enqueueAutomationJob,
  executeMemberExit,
  generateMonthlyFeeInvoices,
  getStudentDefaulterLockState,
  getUpcomingBirthdays,
  isBirthdayTodayIst,
  isTeacherPhoneMaskingEnabled,
  isWithinQuietHoursIst,
  maskPhoneForTeacher,
  parseCsvRows,
  pickBestSubstituteTeacher,
  processJobQueueBatch,
  redactFeedbackForTeacher,
  rejoinExitedMember,
  sendBirthdayWishesForToday,
  sendRoleWelcomeKit
} from "./crm-engine.mjs";
import { buildSimplePdfBuffer, generateQrSvg } from "./crm-pdf.mjs";
import { computeFounderDailyMetrics, generateTeacherPayrollDrafts, runCentralSchedulerTick } from "./crm-scheduler.mjs";

function createTestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec("PRAGMA foreign_keys = ON;");
  const m1 = fs.readFileSync(path.resolve("database/migrations/001_unified_portal.sql"), "utf8");
  db.exec(m1);
  // Add runtime upgrade columns that server.js normally adds before addons/crm
  db.exec(`
    CREATE TABLE IF NOT EXISTS branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS batches (id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL, branch_id INTEGER, teacher_id INTEGER, name TEXT NOT NULL, code TEXT NOT NULL UNIQUE, room_name TEXT DEFAULT 'Room 101', seat_limit INTEGER DEFAULT 40, schedule_days TEXT DEFAULT 'Mon-Sat', start_time TEXT DEFAULT '16:00', end_time TEXT DEFAULT '17:30', start_date TEXT DEFAULT '', is_active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS timetable_slots (id INTEGER PRIMARY KEY AUTOINCREMENT, branch_id INTEGER, course_id INTEGER, batch_id INTEGER, teacher_id INTEGER, day_of_week TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, subject_name TEXT DEFAULT '', room_name TEXT DEFAULT 'Room 101', mode TEXT DEFAULT 'offline', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS fee_installments (id INTEGER PRIMARY KEY AUTOINCREMENT, fee_record_id INTEGER NOT NULL, student_id INTEGER NOT NULL, installment_no INTEGER DEFAULT 1, title TEXT NOT NULL, amount INTEGER DEFAULT 0, paid_amount INTEGER DEFAULT 0, due_date TEXT NOT NULL, payment_id INTEGER, status TEXT DEFAULT 'pending', reminder_sent_at TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS teacher_leave_requests (id INTEGER PRIMARY KEY AUTOINCREMENT, teacher_id INTEGER NOT NULL, branch_id INTEGER, from_date TEXT NOT NULL, to_date TEXT NOT NULL, reason TEXT NOT NULL, status TEXT DEFAULT 'pending', admin_note TEXT DEFAULT '', reviewed_by INTEGER, created_at TEXT NOT NULL, reviewed_at TEXT);
    CREATE TABLE IF NOT EXISTS teacher_payouts (id INTEGER PRIMARY KEY AUTOINCREMENT, teacher_id INTEGER NOT NULL, branch_id INTEGER, salary_month TEXT NOT NULL, base_amount INTEGER DEFAULT 0, bonus_amount INTEGER DEFAULT 0, deduction_amount INTEGER DEFAULT 0, net_amount INTEGER DEFAULT 0, payment_method TEXT DEFAULT 'upi', reference_no TEXT DEFAULT '', status TEXT DEFAULT 'pending', paid_at TEXT, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS offline_tests (id INTEGER PRIMARY KEY AUTOINCREMENT, branch_id INTEGER, course_id INTEGER NOT NULL, batch_id INTEGER, teacher_id INTEGER, title TEXT NOT NULL, subject_name TEXT DEFAULT 'Maths', test_date TEXT NOT NULL, max_marks INTEGER DEFAULT 100, passing_marks INTEGER DEFAULT 33, room_name TEXT DEFAULT 'Hall 1', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS offline_test_marks (id INTEGER PRIMARY KEY AUTOINCREMENT, test_id INTEGER NOT NULL, student_id INTEGER NOT NULL, marks_obtained REAL DEFAULT 0, is_absent INTEGER DEFAULT 0, remarks TEXT DEFAULT '', rank_position INTEGER, graded_by INTEGER, updated_at TEXT NOT NULL, UNIQUE(test_id, student_id));
    CREATE TABLE IF NOT EXISTS alert_dispatch_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT DEFAULT 'sms', recipient_user_id INTEGER, recipient_name TEXT DEFAULT '', recipient_contact TEXT DEFAULT '', category TEXT DEFAULT 'automation', message TEXT NOT NULL, status TEXT DEFAULT 'logged', provider_response TEXT DEFAULT '', created_by INTEGER, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, branch_id INTEGER, title TEXT NOT NULL, category TEXT DEFAULT 'Ops', amount INTEGER DEFAULT 0, expense_date TEXT NOT NULL, payment_method TEXT DEFAULT 'upi', notes TEXT DEFAULT '', created_by INTEGER, created_at TEXT NOT NULL);
  `);
  for (const [tbl, col, ddl] of [
    ["student_profiles", "roll_number", "roll_number TEXT NOT NULL DEFAULT ''"],
    ["student_profiles", "branch_id", "branch_id INTEGER"],
    ["student_profiles", "batch_id", "batch_id INTEGER"],
    ["enrollments", "batch_id", "batch_id INTEGER"],
    ["attendance", "batch_id", "batch_id INTEGER"],
    ["attendance", "marked_via", "marked_via TEXT NOT NULL DEFAULT 'manual'"],
    ["fee_records", "branch_id", "branch_id INTEGER"],
    ["inquiries", "branch_id", "branch_id INTEGER"],
    ["inquiries", "follow_up_date", "follow_up_date TEXT NOT NULL DEFAULT ''"],
    ["inquiries", "follow_up_notes", "follow_up_notes TEXT NOT NULL DEFAULT ''"],
    ["inquiries", "assigned_staff", "assigned_staff TEXT NOT NULL DEFAULT ''"],
    ["inquiries", "demo_date", "demo_date TEXT NOT NULL DEFAULT ''"],
    ["inquiries", "demo_time_slot", "demo_time_slot TEXT NOT NULL DEFAULT ''"]
  ]) {
    const cols = db.prepare(`PRAGMA table_info(${tbl})`).all();
    if (!cols.some((c) => c.name === col)) db.exec(`ALTER TABLE ${tbl} ADD COLUMN ${ddl}`);
  }
  ensureAddonsSchema(db);
  ensureCrmV25Schema(db);
  return db;
}

test("IST Quiet Hours blocks 9 PM to 8 AM IST and allows daytime", () => {
  // 22:30 IST = 17:00 UTC
  assert.equal(isWithinQuietHoursIst(new Date("2026-11-20T17:00:00Z"), 21, 8), true);
  // 06:30 IST = 01:00 UTC
  assert.equal(isWithinQuietHoursIst(new Date("2026-11-20T01:00:00Z"), 21, 8), true);
  // 14:00 IST = 08:30 UTC
  assert.equal(isWithinQuietHoursIst(new Date("2026-11-20T08:30:00Z"), 21, 8), false);
});

test("WhatsApp click-to-chat URL normalizes Indian numbers cleanly", () => {
  const url = buildWhatsAppClickToChatUrl("+91 98765-43210", "Fee due ₹2,500");
  assert.ok(url.startsWith("https://wa.me/919876543210?text="));
  assert.ok(url.includes(encodeURIComponent("Fee due ₹2,500")));
});

test("Lead scoring weights high-intent walk-in/JEE leads higher", () => {
  const hot = computeLeadScore({ phone: "9876543210", email: "a@b.com", source: "walk_in_qr", class_or_course: "JEE Main Batch", demo_date: "2026-11-22", message: "Want admission this week" });
  const cold = computeLeadScore({ phone: "123", source: "website", class_or_course: "" });
  assert.ok(hot >= 85);
  assert.ok(cold < 45);
});

test("Competitive CBT scoring computes +4/-1 marks, weak topics <40%, rank & percentile", () => {
  const questions = [
    { id: 1, correctAnswer: "Newton", topic: "Mechanics" },
    { id: 2, correctAnswer: "9.8", topic: "Gravitation" },
    { id: 3, correctAnswer: "Ohm", topic: "Electricity" },
    { id: 4, correctAnswer: "Volt", topic: "Electricity" }
  ];
  const res = calculateCbtResult(questions, { 1: "Newton", 2: "8.9", 3: "Ampere" }, { positiveMarks: 4, negativeMarks: 1 });
  assert.equal(res.correct, 1);
  assert.equal(res.wrong, 2);
  assert.equal(res.unanswered, 1);
  assert.equal(res.score, 2);
  assert.equal(res.maxMarks, 16);
  assert.equal(res.needsRemediation, true);
  assert.ok(res.weakTopics.includes("Electricity"));

  const rp = computeRankAndPercentile([16, 12, 8, 2], 12);
  assert.equal(rp.rank, 2);
  assert.equal(rp.percentile, 75);
});

test("Teacher payroll calculator combines fixed, per-class, incentives and unpaid leave deductions", () => {
  const out = calculateTeacherPayroll({
    salaryType: "hybrid",
    fixedMonthly: 15000,
    perClassRate: 400,
    classesConducted: 20,
    unpaidLeaveDays: 2,
    incentives: 1000,
    deductions: 500
  });
  assert.equal(out.baseAmount, 23000);
  assert.equal(out.deductionAmount, 1500); // 1000 leave + 500 extra
  assert.equal(out.netAmount, 22500);
});

test("Timetable clash detection catches teacher, batch, and room overlaps", () => {
  const existing = [{ id: 1, day_of_week: "Monday", start_time: "16:00", end_time: "17:00", teacher_id: 5, batch_id: 2, room_name: "Room 101" }];
  assert.equal(detectTimetableClash(existing, { day_of_week: "Monday", start_time: "16:30", end_time: "17:30", teacher_id: 5 }).clash, true);
  assert.equal(detectTimetableClash(existing, { day_of_week: "Monday", start_time: "16:30", end_time: "17:30", room_name: "Room 101", mode: "offline" }).clash, true);
  assert.equal(detectTimetableClash(existing, { day_of_week: "Monday", start_time: "17:00", end_time: "18:00", teacher_id: 5, room_name: "Room 101" }).clash, false);
});

test("CSV parser handles quoted values and headers cleanly", () => {
  const parsed = parseCsvRows('Full Name,Phone,Notes\n"Sharma, Aarav",9876543210,"Needs JEE, Physics"');
  assert.deepEqual(parsed.headers, ["full_name", "phone", "notes"]);
  assert.equal(parsed.rows.length, 1);
  assert.equal(parsed.rows[0].full_name, "Sharma, Aarav");
  assert.equal(parsed.rows[0].notes, "Needs JEE, Physics");
});

test("Student risk scoring and CPA calculation produce accurate thresholds", () => {
  const high = calculateStudentRiskScore({ attendancePercent: 45, overdueDays: 20, avgTestPercent: 30 });
  assert.equal(high.riskLevel, "critical");
  assert.equal(computeCostPerAdmission(9000, 3), 3000);
});

test("PDF generator produces valid %PDF-1.4 binary buffer and QR SVG markup", () => {
  const buf = buildSimplePdfBuffer({ title: "TEST RECEIPT", rows: [{ label: "Student", value: "Aarav" }] });
  assert.ok(buf.toString("utf8").startsWith("%PDF-1.4"));
  assert.ok(buf.toString("utf8").includes("%%EOF"));
  const svg = generateQrSvg("YUITOR:STU:1:YSC01", 120);
  assert.ok(svg.startsWith("<svg"));
  assert.ok(svg.includes("</svg>"));
});

test("DB Integration: Kill switch, Event Bus idempotency, 3-retry dead-letter -> Exception Inbox, Monthly Fees & Soft Lock", async () => {
  const db = createTestDb();
  const now = new Date().toISOString();

  // Seed 1 course, 1 student, 1 teacher
  db.prepare(`INSERT INTO courses (title, slug, monthly_fee, yearly_fee, created_at) VALUES ('Class 10 Maths', 'c10-math', 1500, 15000, ?)`).run(now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('student', 'Riya Verma', 'riya@test.local', '9876543210', 'hash', 1, 'approved', 1, 'tok1', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('teacher', 'Anil Sir', 'anil@test.local', '9876543299', 'hash', 1, 'approved', 1, 'tok2', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO student_profiles (user_id, roll_number, parent_phone) VALUES (1, 'YSC-001', '9876543211')`).run();
  db.prepare(`INSERT INTO enrollments (student_id, course_id, plan, status, enrolled_at) VALUES (1, 1, 'monthly', 'active', ?)`).run(now);

  // 1. Idempotent Monthly Fee Generation (double run must skip duplicates)
  const gen1 = generateMonthlyFeeInvoices(db, { billingMonth: "2026-10", dueDay: 5 });
  assert.equal(gen1.created, 1);
  const gen2 = generateMonthlyFeeInvoices(db, { billingMonth: "2026-10", dueDay: 5 });
  assert.equal(gen2.created, 0);
  assert.equal(gen2.skipped, 1);

  // 2. Fee Defaulter Soft Lock toggle
  assert.equal(getStudentDefaulterLockState(db, 1).locked, false);
  updateAutomationConfig(db, { defaulter_soft_lock_enabled: 1, defaulter_soft_lock_days: 15 });
  const lockOn = getStudentDefaulterLockState(db, 1);
  assert.equal(lockOn.locked, true);
  assert.equal(lockOn.overdueAmount, 1500);

  // 3. Global Kill Switch blocks events and safety gate
  updateAutomationConfig(db, { global_kill_switch: 1 });
  const blocked = emitSystemEvent(db, "payment.received", { studentId: 1, amount: 1500 }, { idempotencyKey: "k-block" });
  assert.equal(blocked.blockedByKillSwitch, true);
  assert.equal(checkMessageSafetyGate(db, { userId: 1, phone: "9876543210", channel: "email", now: new Date("2026-11-20T08:30:00Z") }).allowed, false);
  updateAutomationConfig(db, { global_kill_switch: 0, quiet_hours_enabled: 0 });

  // 4. Event Bus idempotency & dry-run
  const dry = emitSystemEvent(db, "payment.received", { studentId: 1, amount: 1500 }, { dryRun: true });
  assert.ok(dry.matchedRules.length >= 1);
  const ev1 = emitSystemEvent(db, "payment.received", { studentId: 1, amount: 1500 }, { idempotencyKey: "ev-dup-test" });
  assert.equal(ev1.duplicate, false);
  const ev2 = emitSystemEvent(db, "payment.received", { studentId: 1, amount: 1500 }, { idempotencyKey: "ev-dup-test" });
  assert.equal(ev2.duplicate, true);

  // 5. Job Queue 3-retry dead-letter -> Exception Inbox escalation
  const q = enqueueAutomationJob(db, { jobType: "simulate_failure_test", idempotencyKey: "fail-3x", maxAttempts: 3, payload: { errorMessage: "Provider timeout" } });
  assert.equal(q.queued, true);
  for (let i = 0; i < 3; i += 1) {
    db.prepare(`UPDATE crm_job_queue SET next_run_at = ? WHERE id = ?`).run(new Date(Date.now() - 1000).toISOString(), q.jobId);
    await processJobQueueBatch(db, {}, { limit: 10 });
  }
  const jobRow = db.prepare(`SELECT status, attempts FROM crm_job_queue WHERE id = ?`).get(q.jobId);
  assert.equal(jobRow.status, "dead_letter");
  assert.equal(jobRow.attempts, 3);
  const ex = db.prepare(`SELECT * FROM crm_exception_inbox WHERE entity_type = 'crm_job_queue' AND entity_id = ?`).get(String(q.jobId));
  assert.ok(ex, "Dead-letter job must appear in Exception Inbox");

  // 6. Teacher Payroll Draft & Central Scheduler Tick
  const pr = generateTeacherPayrollDrafts(db, "2026-11");
  assert.equal(pr.created, 1);
  const tick = await runCentralSchedulerTick(db, {}, { forceJob: "founder_8pm" });
  assert.equal(tick.timezone, "Asia/Kolkata");
  assert.equal(tick.results.founder_8pm.ok, true);

  const metrics = computeFounderDailyMetrics(db);
  assert.equal(metrics.totalPendingFees, 1500);
  assert.ok(getAutomationConfig(db).id === 1);
  db.close();
});

test("Anti-poaching phone masking masks 10-digit and +91 mobile numbers cleanly", () => {
  assert.equal(maskPhoneForTeacher("+91 98765 43210"), "+91 ••••••3210");
  assert.equal(maskPhoneForTeacher("9876543210"), "••••••3210");
  assert.equal(maskPhoneForTeacher("1234"), "••••");
  assert.equal(maskPhoneForTeacher(""), "");
});

test("Substitute teacher picker skips absent/on-leave/clashing teachers and prefers subject match", () => {
  const affectedSlots = [{ id: 1, day_of_week: "Monday", start_time: "16:00", end_time: "17:00", subject_name: "Physics", teacher_id: 10 }];
  const activeTeachers = [
    { id: 10, full_name: "Absent Sir", is_active: 1, subjects_json: '["Physics"]' },
    { id: 11, full_name: "OnLeave Ma'am", is_active: 1, subjects_json: '["Physics"]' },
    { id: 12, full_name: "Clashing Sir", is_active: 1, subjects_json: '["Physics"]' },
    { id: 13, full_name: "Maths Sir", is_active: 1, subjects_json: '["Maths"]' },
    { id: 14, full_name: "Physics Backup Ma'am", is_active: 1, subjects_json: '["Physics", "Science"]' }
  ];
  const allSlots = [
    ...affectedSlots,
    { id: 2, day_of_week: "Monday", start_time: "16:15", end_time: "17:15", subject_name: "Physics", teacher_id: 12 }
  ];
  const pick = pickBestSubstituteTeacher(10, affectedSlots, activeTeachers, allSlots, [11]);
  assert.equal(pick.reason, "matched_clash_free");
  assert.equal(pick.substitute.id, 14);
});

test("Feedback redaction strictly hides student identity on anonymous rows", () => {
  const rows = [
    { id: 1, teacher_id: 2, student_id: 99, student_name: "Aarav Sharma", is_anonymous: 1, rating: 4, clarity_rating: 4, topic_unclear: "Optics", pace_tag: "too_fast", feedback_text: "Go slower" },
    { id: 2, teacher_id: 2, student_id: 100, student_name: "Riya Verma", is_anonymous: 0, rating: 5, clarity_rating: 5, topic_unclear: "", pace_tag: "just_right", feedback_text: "Great!" }
  ];
  const redacted = redactFeedbackForTeacher(rows);
  assert.equal(redacted[0].student_display, "Anonymous Student");
  assert.equal(redacted[0].student_id, undefined);
  assert.equal(redacted[0].student_name, undefined);
  assert.equal(redacted[1].student_display, "Riya Verma");
});

test("DB Integration: Role-separated Student/Teacher/Staff Exits, 1-Click Rejoin & Teacher Leave Auto-Substitute", () => {
  const db = createTestDb();
  const now = new Date().toISOString();

  // Seed course, batch, student, 2 teachers, 1 staff
  db.prepare(`INSERT INTO courses (title, slug, monthly_fee, yearly_fee, created_at) VALUES ('CBSE Class 10', 'cbse-10', 800, 8000, ?)`).run(now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('student', 'Kabir Singh', 'kabir@test.local', '9876500001', 'h', 1, 'approved', 1, 'u1', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('teacher', 'Rajesh Sir', 'rajesh@test.local', '9876500002', 'h', 1, 'approved', 1, 'u2', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('teacher', 'Neha Maam', 'neha@test.local', '9876500003', 'h', 1, 'approved', 1, 'u3', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at) VALUES ('staff', 'Suresh Office', 'suresh@test.local', '9876500004', 'h', 1, 'approved', 1, 'u4', ?, ?)`).run(now, now);

  db.prepare(`INSERT INTO teacher_profiles (user_id, subjects_json) VALUES (2, '["Maths","Physics"]')`).run();
  db.prepare(`INSERT INTO teacher_profiles (user_id, subjects_json) VALUES (3, '["Maths","Science"]')`).run();
  db.prepare(`INSERT INTO batches (course_id, teacher_id, name, code, seat_limit, created_at) VALUES (1, 2, 'CBSE-10 Morning', 'CBSE10-M', 30, ?)`).run(now);
  db.prepare(`INSERT INTO timetable_slots (course_id, batch_id, teacher_id, day_of_week, start_time, end_time, subject_name, created_at) VALUES (1, 1, 2, 'Monday', '16:00', '17:00', 'Maths', ?)`).run(now);
  db.prepare(`INSERT INTO student_profiles (user_id, roll_number, batch_id, parent_phone) VALUES (1, 'YSC-101', 1, '9876511111')`).run();
  db.prepare(`INSERT INTO enrollments (student_id, course_id, batch_id, plan, status, enrolled_at) VALUES (1, 1, 1, 'monthly', 'active', ?)`).run(now);
  db.prepare(`INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, billing_month, created_at) VALUES (1, 1, 'Nov Fee', 800, 0, 200, '2026-11-10', 'partial', '2026-11', ?)`).run(now);
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES ('tok-teacher-2', 2, 4102444800000, 1700000000000, 1700000000000)`).run();
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES ('tok-staff-4', 4, 4102444800000, 1700000000000, 1700000000000)`).run();
  enqueueAutomationJob(db, { jobType: "send_notification", idempotencyKey: "fee-rem-stu-1", payload: { studentId: 1, message: "Pay fee" } });

  // Phone masking is ON by default
  assert.equal(isTeacherPhoneMaskingEnabled(db), true);

  // 1. Teacher Leave -> Auto Substitute Assignment + Batch Student Notification
  const lvRes = db.prepare(`INSERT INTO teacher_leave_requests (teacher_id, from_date, to_date, reason, status, created_at) VALUES (2, '2026-11-25', '2026-11-26', 'Family function', 'approved', ?)`).run(now);
  const sub = assignSubstituteOnTeacherLeave(db, { leaveRequestId: Number(lvRes.lastInsertRowid), actorId: 2 });
  assert.equal(sub.assigned, true);
  assert.equal(sub.substituteTeacherId, 3);
  assert.equal(sub.slotsCovered, 1);
  assert.equal(sub.studentsNotified, 1);
  const slotRow = db.prepare(`SELECT substitute_teacher_id FROM timetable_slots WHERE id = 1`).get();
  assert.equal(slotRow.substitute_teacher_id, 3);
  const stuNotif = db.prepare(`SELECT title FROM notifications WHERE user_id = 1`).get();
  assert.ok(stuNotif && stuNotif.title.includes("Substitute"));

  // 2. Role mismatch guard: cannot exit a teacher through student endpoint
  assert.throws(() => executeMemberExit(db, { userId: 2, role: "student" }), /Role mismatch/);

  // 3. Student 1-Click Exit (waive_off dues, frees seat, cancels pending reminders) + 1-Click Rejoin
  const stuExit = executeMemberExit(db, {
    userId: 1,
    role: "student",
    exitCategory: "dropped_out",
    exitDate: "2026-11-20",
    exitReason: "Shifted to another city",
    duesAction: "waive_off",
    settlementNote: "Waived ₹600 on exit"
  });
  assert.equal(stuExit.ok, true);
  assert.equal(stuExit.seatsFreed, 1);
  assert.equal(stuExit.duesAmountSnapshot, 600);
  assert.equal(stuExit.remindersCancelled, 1);
  assert.equal(db.prepare(`SELECT is_active FROM users WHERE id = 1`).get().is_active, 0);
  assert.equal(db.prepare(`SELECT status FROM enrollments WHERE student_id = 1`).get().status, "cancelled");
  assert.equal(db.prepare(`SELECT status, discount_amount FROM fee_records WHERE student_id = 1`).get().status, "paid");
  assert.equal(db.prepare(`SELECT opted_out_all, whatsapp_opt_in FROM crm_message_consent WHERE user_id = 1`).get().opted_out_all, 1);
  assert.equal(checkMessageSafetyGate(db, { userId: 1, phone: "9876500001", channel: "whatsapp", now: new Date("2026-11-20T08:30:00Z") }).allowed, false);

  const rejoinStu = rejoinExitedMember(db, { exitId: stuExit.exitId, rejoinNote: "Returned next term" });
  assert.equal(rejoinStu.ok, true);
  assert.equal(rejoinStu.batchesRestored, 1);
  assert.equal(db.prepare(`SELECT is_active FROM users WHERE id = 1`).get().is_active, 1);
  assert.equal(db.prepare(`SELECT status FROM enrollments WHERE student_id = 1`).get().status, "active");
  assert.equal(db.prepare(`SELECT opted_out_all FROM crm_message_consent WHERE user_id = 1`).get().opted_out_all, 0);

  // 4. Teacher 1-Click Exit with Handover + Session Revocation
  const tExit = executeMemberExit(db, {
    userId: 2,
    role: "teacher",
    exitCategory: "resigned",
    exitReason: "Joined govt job",
    duesAction: "salary_settled",
    handoverTeacherId: 3
  });
  assert.equal(tExit.handoverSlotsMoved, 1);
  assert.equal(db.prepare(`SELECT teacher_id FROM timetable_slots WHERE id = 1`).get().teacher_id, 3);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM sessions WHERE user_id = 2`).get().c, 0);

  // 5. Staff 1-Click Exit + Session Revocation + Rejoin
  const stExit = executeMemberExit(db, { userId: 4, role: "staff", exitCategory: "relieved", exitReason: "Contract ended" });
  assert.equal(stExit.ok, true);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM sessions WHERE user_id = 4`).get().c, 0);
  const stRejoin = rejoinExitedMember(db, { exitId: stExit.exitId });
  assert.equal(stRejoin.ok, true);
  assert.equal(db.prepare(`SELECT is_active FROM users WHERE id = 4`).get().is_active, 1);

  db.close();
});

test("Pure: Birthday matching (exact, Feb 29 non-leap fallback, upcoming 14-day window) & role-wise email templates", () => {
  assert.equal(isBirthdayTodayIst("2009-05-14", { year: 2026, month: 5, day: 14 }), true);
  assert.equal(isBirthdayTodayIst("2009-05-15", { year: 2026, month: 5, day: 14 }), false);
  // Feb 29 celebrant should be wished on Feb 28 in non-leap year 2026
  assert.equal(isBirthdayTodayIst("2008-02-29", { year: 2026, month: 2, day: 28 }), true);
  assert.equal(isBirthdayTodayIst("2008-02-29", { year: 2028, month: 2, day: 28 }), false);
  assert.equal(isBirthdayTodayIst("2008-02-29", { year: 2028, month: 2, day: 29 }), true);
  assert.equal(isBirthdayTodayIst("", { year: 2026, month: 5, day: 14 }), false);

  const split = getUpcomingBirthdays(
    [
      { id: 1, full_name: "Today Student", dob: "2010-05-14" },
      { id: 2, full_name: "Soon Teacher", dob: "1992-05-20" },
      { id: 3, full_name: "Far Staff", dob: "1990-08-10" }
    ],
    { year: 2026, month: 5, day: 14 },
    14
  );
  assert.equal(split.today.length, 1);
  assert.equal(split.upcoming.length, 1);
  assert.equal(split.upcoming[0].daysUntil, 6);

  for (const role of ["student", "teacher", "staff", "parent"]) {
    const bday = buildBirthdayEmailTemplate({ fullName: "Aarav Verma", role });
    assert.ok(bday.subject.includes("Happy Birthday"), `birthday subject for ${role}`);
    assert.ok(bday.htmlBody.includes("Aarav Verma"), `birthday html for ${role}`);
    assert.ok(bday.whatsappText.includes("Yuitor"), `birthday whatsapp for ${role}`);

    const welcome = buildRoleWelcomeEmailTemplate({
      fullName: "Aarav Verma",
      role,
      rollNumber: "YSC-2026-01",
      batchName: "CBSE Class 10 Morning",
      courseTitle: "CBSE Board Mastery"
    });
    assert.ok(welcome.subject.includes("Welcome"), `welcome subject for ${role}`);
    assert.ok(welcome.htmlBody.includes("Aarav Verma"), `welcome html for ${role}`);
  }
});

test("DB Integration: Idempotent yearly birthday wishes (skips inactive/left members) & Role-Wise Welcome Kit", async () => {
  const db = createTestDb();
  const now = new Date("2026-05-14T04:00:00.000Z"); // 09:30 AM IST on 2026-05-14
  const nowStr = now.toISOString();
  db.prepare(`INSERT INTO users (id, role, full_name, email, phone, password_hash, is_active, dob, unsubscribe_token, created_at, updated_at) VALUES (10, 'student', 'Riya Sharma', 'riya@test.com', '9876543211', 'x', 1, '2010-05-14', 'tok10', ?, ?)`).run(nowStr, nowStr);
  db.prepare(`INSERT INTO users (id, role, full_name, email, phone, password_hash, is_active, dob, unsubscribe_token, created_at, updated_at) VALUES (11, 'teacher', 'Dr. Vivek Nair', 'vivek@test.com', '9876543212', 'x', 1, '1988-05-14', 'tok11', ?, ?)`).run(nowStr, nowStr);
  db.prepare(`INSERT INTO users (id, role, full_name, email, phone, password_hash, is_active, dob, unsubscribe_token, created_at, updated_at) VALUES (12, 'student', 'Left Student', 'left@test.com', '9876543213', 'x', 0, '2010-05-14', 'tok12', ?, ?)`).run(nowStr, nowStr);

  const sentEmails = [];
  const fakeMailer = async (payload) => {
    sentEmails.push(payload);
    return { ok: true, mode: "smtp" };
  };

  // First run wishes 2 active members and skips inactive (left) member #12
  const run1 = await sendBirthdayWishesForToday(db, fakeMailer, { now });
  assert.equal(run1.matched, 2);
  assert.equal(run1.wished, 2);
  assert.equal(run1.alreadyWished, 0);
  assert.equal(sentEmails.length, 2);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM crm_celebration_logs WHERE event_type = 'birthday'`).get().c, 2);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM notifications WHERE user_id IN (10, 11)`).get().c, 2);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM notifications WHERE user_id = 12`).get().c, 0);

  // Second run same year must be 100% idempotent (0 duplicate wishes)
  const run2 = await sendBirthdayWishesForToday(db, fakeMailer, { now });
  assert.equal(run2.matched, 2);
  assert.equal(run2.wished, 0);
  assert.equal(run2.alreadyWished, 2);
  assert.equal(sentEmails.length, 2);

  // Welcome kit for Teacher logs in crm_celebration_logs + creates portal notification + sends email
  const welcomeOut = await sendRoleWelcomeKit(db, fakeMailer, { userId: 11, courseTitle: "Physics Faculty" });
  assert.equal(welcomeOut.ok, true);
  assert.equal(welcomeOut.role, "teacher");
  assert.equal(welcomeOut.emailStatus, "sent");
  assert.equal(sentEmails.length, 3);
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM crm_celebration_logs WHERE user_id = 11 AND event_type = 'welcome_joining'`).get().c, 1);

  db.close();
});


