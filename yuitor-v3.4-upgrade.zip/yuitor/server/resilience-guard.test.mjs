import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import express, { Router } from "express";
import {
  ensureResilienceSchema,
  isModuleEnabled,
  protectRouter,
  recordSystemError,
  safeJsonParse,
  setModuleState
} from "./resilience-guard.mjs";

function makeInMemoryDb() {
  const db = new DatabaseSync(":memory:");
  ensureResilienceSchema(db);
  return db;
}

test("safeJsonParse handles invalid JSON cleanly without throwing", () => {
  assert.deepEqual(safeJsonParse("{bad-json", { ok: false }), { ok: false });
  assert.deepEqual(safeJsonParse("", []), []);
  assert.deepEqual(safeJsonParse('{"a":1}', {}), { a: 1 });
});

test("recordSystemError redacts secrets and updates module error count", () => {
  const db = makeInMemoryDb();
  const entry = recordSystemError(db, {
    source: "backend-route",
    moduleName: "chatbot",
    route: "POST /api/public/chatbot/message",
    message: "Failed with Bearer secretToken123456 and password=MyPass99"
  });
  assert.doesNotMatch(entry.message, /secretToken123456/);
  assert.doesNotMatch(entry.message, /MyPass99/);
  const row = db.prepare("SELECT total_errors FROM system_module_states WHERE module_name = 'chatbot'").get();
  assert.equal(Number(row.total_errors), 1);
});

test("protectRouter isolates async/sync route errors and trips optional module circuit breaker without crashing", async () => {
  const db = makeInMemoryDb();
  setModuleState(db, "chatbot", { enabled: true, resetCircuit: true });
  const app = express();

  const failingOptional = Router();
  failingOptional.get("/boom-async", async () => {
    throw new Error("Simulated async failure");
  });
  failingOptional.get("/boom-sync", () => {
    throw new Error("Simulated sync failure");
  });

  const healthyCore = Router();
  healthyCore.get("/ok", (_req, res) => {
    res.json({ ok: true });
  });

  app.use("/opt", protectRouter(failingOptional, "chatbot", db, { optionalModule: true }));
  app.use("/core", protectRouter(healthyCore, "core_public", db));

  const server = await new Promise((resolve) => {
    const srv = app.listen(0, "127.0.0.1", () => resolve(srv));
  });
  try {
    const port = server.address().port;
    const base = `http://127.0.0.1:${port}`;

    // 5 errors trip the circuit breaker on 'chatbot'
    for (let i = 0; i < 5; i++) {
      const r = await fetch(`${base}/opt/${i % 2 === 0 ? "boom-async" : "boom-sync"}`);
      assert.equal(r.status, 500);
      const body = await r.json();
      assert.equal(body.isolatedModule, "chatbot");
    }

    // 6th call is immediately isolated (503 moduleDisabled)
    const isolatedRes = await fetch(`${base}/opt/boom-async`);
    assert.equal(isolatedRes.status, 503);
    const isolatedBody = await isolatedRes.json();
    assert.equal(isolatedBody.moduleDisabled, true);
    assert.equal(isolatedBody.module, "chatbot");
    assert.equal(isModuleEnabled(db, "chatbot"), false);

    // Core website & admin routes remain 100% healthy
    const coreRes = await fetch(`${base}/core/ok`);
    assert.equal(coreRes.status, 200);
    assert.deepEqual(await coreRes.json(), { ok: true });

    // Admin resets circuit / toggles module back ON
    const toggled = setModuleState(db, "chatbot", { enabled: true, resetCircuit: true });
    assert.equal(toggled.ok, true);
    assert.equal(isModuleEnabled(db, "chatbot"), true);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
