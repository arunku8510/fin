import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { describe, it } from "node:test";
import express from "express";

import {
  V33_VERSION,
  buildRevenueCsv,
  calculateDynamicCheckoutQuote,
  calculateProfileCompletion,
  computeDurationPrice,
  computeMultiSubjectDiscount,
  computeSmartUpgradePricing,
  csvCellSafe,
  ensureV33Schema,
  getV33PricingConfig,
  renderMessagePreview,
  runCourseRenewalV33Sweep,
  runInvoiceFollowupSweep,
} from "./v33-engine.mjs";
import { createV33Router } from "./v33-routes.mjs";

function createTestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec(`
    CREATE TABLE branches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT UNIQUE,
      address TEXT DEFAULT '',
      city TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      email TEXT DEFAULT '',
      timing_note TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      role TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      password_hash TEXT DEFAULT '',
      avatar_url TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      mobile_verified INTEGER DEFAULT 0,
      verification_status TEXT DEFAULT 'approved',
      referral_code TEXT DEFAULT '',
      referred_by TEXT DEFAULT '',
      branch_id INTEGER DEFAULT 1,
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE student_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE,
      roll_number TEXT DEFAULT '',
      class_level TEXT DEFAULT 'Class 10',
      board TEXT DEFAULT 'CBSE',
      branch_id INTEGER DEFAULT 1,
      address TEXT DEFAULT '',
      parent_name TEXT DEFAULT '',
      parent_phone TEXT DEFAULT '',
      subjects_json TEXT DEFAULT '[]',
      school_name TEXT DEFAULT '',
      course_duration_months INTEGER DEFAULT 12,
      billing_cycle TEXT DEFAULT 'monthly',
      total_fee REAL DEFAULT 0,
      paid_fee REAL DEFAULT 0,
      remaining_fee REAL DEFAULT 0,
      admission_date TEXT DEFAULT '',
      enrollment_status TEXT DEFAULT 'active'
    );
    CREATE TABLE parent_links (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_user_id INTEGER,
      student_user_id INTEGER,
      relation TEXT DEFAULT 'Parent',
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE staff_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE,
      permissions_json TEXT DEFAULT '[]'
    );
    CREATE TABLE courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT UNIQUE,
      title TEXT NOT NULL,
      category TEXT DEFAULT 'School',
      class_range TEXT DEFAULT 'Class 10',
      board TEXT DEFAULT 'CBSE',
      monthly_fee REAL DEFAULT 800,
      yearly_fee REAL DEFAULT 8640,
      duration_months INTEGER DEFAULT 12,
      description TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      batch_id INTEGER,
      status TEXT DEFAULT 'active',
      progress_percent INTEGER DEFAULT 0,
      enrolled_at TEXT DEFAULT '',
      expires_at TEXT DEFAULT ''
    );
    CREATE TABLE fee_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      title TEXT DEFAULT '',
      total_amount REAL DEFAULT 0,
      discount_amount REAL DEFAULT 0,
      paid_amount REAL DEFAULT 0,
      due_date TEXT DEFAULT '',
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT '',
      branch_id INTEGER DEFAULT 1,
      billing_cycle TEXT DEFAULT 'monthly',
      billing_month TEXT DEFAULT ''
    );
    CREATE TABLE payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      enrollment_id INTEGER,
      plan TEXT DEFAULT 'monthly',
      base_amount REAL DEFAULT 0,
      discount_amount REAL DEFAULT 0,
      amount REAL DEFAULT 0,
      coupon_code TEXT DEFAULT '',
      payment_method TEXT DEFAULT 'upi',
      utr_reference TEXT DEFAULT '',
      gateway_order_id TEXT DEFAULT '',
      gateway_payment_id TEXT DEFAULT '',
      gateway_signature TEXT DEFAULT '',
      verification_status TEXT DEFAULT 'pending',
      refund_status TEXT DEFAULT 'none',
      refund_reason TEXT DEFAULT '',
      invoice_number TEXT DEFAULT '',
      receipt_number TEXT DEFAULT '',
      paid_at TEXT,
      created_at TEXT DEFAULT '',
      idempotency_key TEXT DEFAULT '',
      collected_by INTEGER,
      notes TEXT DEFAULT ''
    );
    CREATE TABLE notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      role_target TEXT DEFAULT 'student',
      title TEXT DEFAULT '',
      message TEXT DEFAULT '',
      is_read INTEGER DEFAULT 0,
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE otp_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      phone TEXT,
      email TEXT,
      purpose TEXT,
      otp_hash TEXT,
      attempts INTEGER DEFAULT 0,
      expires_at INTEGER,
      consumed_at TEXT,
      created_at TEXT DEFAULT ''
    );
    CREATE TABLE system_settings (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at TEXT DEFAULT ''
    );
    CREATE TABLE inquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT,
      email TEXT,
      class_or_course TEXT DEFAULT '',
      message TEXT,
      source TEXT DEFAULT 'website',
      status TEXT DEFAULT 'new',
      created_at TEXT DEFAULT '',
      branch_id INTEGER DEFAULT 1,
      follow_up_date TEXT DEFAULT '',
      follow_up_notes TEXT DEFAULT '',
      converted_student_id INTEGER
    );
    CREATE TABLE offline_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_name TEXT,
      max_marks REAL DEFAULT 100
    );
    CREATE TABLE offline_test_marks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER,
      student_id INTEGER,
      marks_obtained REAL,
      is_absent INTEGER DEFAULT 0
    );
    CREATE TABLE attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      status TEXT DEFAULT 'present',
      att_date TEXT DEFAULT ''
    );
    CREATE TABLE v31_mail_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      template_key TEXT UNIQUE,
      name TEXT,
      audience TEXT DEFAULT 'student',
      category TEXT DEFAULT 'general',
      theme_key TEXT DEFAULT 'burgundy_gold',
      subject TEXT,
      body_html TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT '',
      updated_at TEXT DEFAULT ''
    );
    CREATE TABLE v32_reminder_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reminder_key TEXT UNIQUE,
      reminder_type TEXT,
      user_id INTEGER,
      email TEXT,
      meta_json TEXT,
      sent_at TEXT
    );
  `);
  ensureV33Schema(db);
  return db;
}

describe("Yuitor Smart Classes v3.3 — Pure Pricing & Utility Logic", () => {
  it("computes duration pricing with configured discounts", () => {
    const res12 = computeDurationPrice(800, 12, { "12": 20 });
    assert.equal(res12.grossAmount, 9600);
    assert.equal(res12.discountPercent, 20);
    assert.equal(res12.discountAmount, 1920);
    assert.equal(res12.finalPrice, 7680);
  });

  it("computes multi-subject discount slabs accurately", () => {
    assert.equal(computeMultiSubjectDiscount(10000, 1).discountPercent, 0);
    assert.equal(computeMultiSubjectDiscount(10000, 2).discountPercent, 5);
    assert.equal(computeMultiSubjectDiscount(10000, 3).discountPercent, 10);
    assert.equal(computeMultiSubjectDiscount(10000, 4).discountPercent, 15);
    assert.equal(computeMultiSubjectDiscount(10000, 6).discountPercent, 20);
    assert.equal(computeMultiSubjectDiscount(10000, 3).discountAmount, 1000);
  });

  it("computes smart upgrade pricing without double-charging", () => {
    const up = computeSmartUpgradePricing({ previousPaidAmount: 1800, newPackagePrice: 5400 });
    assert.equal(up.creditApplied, 1800);
    assert.equal(up.remainingPayable, 3600);
    const fullCredit = computeSmartUpgradePricing({ previousPaidAmount: 6000, newPackagePrice: 5000 });
    assert.equal(fullCredit.remainingPayable, 0);
  });

  it("calculates dynamic checkout quotes from DB with duration + multi-subject + upgrade deduction", () => {
    const db = createTestDb();
    const quote = calculateDynamicCheckoutQuote(db, {
      classNumber: "10",
      subjects: ["Maths", "Science", "English"],
      durationMonths: 12,
      isUpgrade: true,
      studentId: 999,
      explicitPreviousPaid: 2000,
    });
    assert.equal(quote.baseAmount, 800 * 3 * 12);
    assert.ok(quote.breakdown.durationDiscount > 0);
    assert.ok(quote.breakdown.multiSubjectDiscount > 0);
    assert.equal(quote.breakdown.upgradeCredit, 2000);
    assert.ok(quote.finalPayableAmount > 0 && quote.finalPayableAmount < quote.baseAmount);
  });

  it("computes profile completion percentage and never requires parent details for 100%", () => {
    const partial = calculateProfileCompletion({ class_level: "Class 10" }, { avatar_url: "" });
    assert.ok(partial.percent > 0 && partial.percent < 100);
    const full = calculateProfileCompletion(
      {
        address: "123 Gandhi Nagar, Muradnagar",
        school_name: "DPS Ghaziabad",
        board: "CBSE",
        class_level: "Class 10",
        subjects_json: '["Maths","Science"]',
        branch_id: 1,
        parent_name: "",
        parent_phone: "",
      },
      { avatar_url: "/assets/avatar.png", branch_id: 1 }
    );
    assert.equal(full.percent, 100);
    assert.equal(full.isComplete, true);
  });

  it("renders dynamic message preview placeholders safely and neutralizes CSV injection", () => {
    const rendered = renderMessagePreview({
      subject: "Fee Due for {{student_name}}",
      bodyHtml: "<p>Hi {{student_name}}, pending ₹{{pending_amount}} for {{course}} at {{branch}} due {{due_date}}.</p>",
      context: { studentName: "Aarav", pendingAmount: 2400, course: "Class 10", branch: "Muradnagar", dueDate: "2026-12-01" },
    });
    assert.match(rendered.subject, /Aarav/);
    assert.match(rendered.plainText, /2400/);
    assert.match(rendered.plainText, /Muradnagar/);
    assert.equal(csvCellSafe("=SUM(A1:A5)"), `"'=SUM(A1:A5)"`);
    const csv = buildRevenueCsv({
      studentPurchaseHistory: [
        { paymentId: 1, date: "2026-11-23", studentName: "=EVIL", branch: "Muradnagar", course: "Class 10", amount: 5000, discount: 0, method: "upi" },
      ],
    });
    assert.ok(csv.includes("'=EVIL"));
  });
});

describe("Yuitor Smart Classes v3.3 — End-to-End SQLite & Express Workflows", () => {
  it("verifies schema seeding, strict payment verification, historical pricing protection, follow-ups, renewals, recommendations & RBAC", async () => {
    const db = createTestDb();
    assert.equal(V33_VERSION, "3.3.0");

    // Seeded defaults present
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM branches").get().c >= 4);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM courses").get().c >= 20);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v33_bundles").get().c >= 8);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v33_scholarships").get().c >= 6);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v33_addons").get().c >= 8);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v33_cross_sell_rules").get().c >= 10);
    assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v31_mail_templates").get().c >= 12);

    // Create Admin, Student, Parent
    const adminId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone) VALUES ('admin', 'Admin User', 'admin@yuitor.com', '9999999999')").run().lastInsertRowid
    );
    const studentId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone, branch_id) VALUES ('student', 'Ananya Sharma', 'ananya@example.com', '9811112222', 1)").run().lastInsertRowid
    );
    db.prepare("INSERT INTO student_profiles (user_id, roll_number, class_level, board, branch_id, subjects_json) VALUES (?, 'YTR-100', 'Class 10', 'CBSE', 1, '[\"Maths\"]')").run(studentId);
    const parentId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone) VALUES ('parent', 'Rajesh Sharma', 'rajesh@example.com', '9811113333')").run().lastInsertRowid
    );
    db.prepare("INSERT INTO parent_links (parent_user_id, student_user_id, relation) VALUES (?, ?, 'Father')").run(parentId, studentId);

    // Seed an existing invoice (₹4000) and weak test score (Science 40%)
    const course = db.prepare("SELECT * FROM courses LIMIT 1").get();
    const invId = Number(
      db.prepare(
        "INSERT INTO fee_records (student_id, course_id, invoice_number, title, total_amount, discount_amount, paid_amount, due_date, status, created_at) VALUES (?, ?, 'INV-HIST-1', 'Class 10 Maths', 4000, 0, 0, '2026-12-15', 'pending', '2026-11-01')"
      ).run(studentId, course.id).lastInsertRowid
    );
    const testId = Number(db.prepare("INSERT INTO offline_tests (subject_name, max_marks) VALUES ('Science', 100)").run().lastInsertRowid);
    db.prepare("INSERT INTO offline_test_marks (test_id, student_id, marks_obtained, is_absent) VALUES (?, ?, 40, 0)").run(testId, studentId);

    const sentEmails = [];
    const app = express();
    app.use(express.json());
    app.use(
      "/api/v33",
      createV33Router(db, {
        getSessionContext: (database, req) => {
          const uid = Number(req.headers["x-test-user-id"] || 0);
          if (!uid) return null;
          const user = database.prepare("SELECT * FROM users WHERE id = ?").get(uid);
          return user ? { user } : null;
        },
        createSession: () => "tok-test",
        setSessionCookie: () => {},
        sendTransactionalEmail: async (payload) => {
          sentEmails.push(payload);
          return { ok: true };
        },
        writeAuditLog: () => {},
        clientIp: () => "127.0.0.1",
      })
    );

    const server = await new Promise((resolve) => {
      const s = app.listen(0, () => resolve(s));
    });
    const base = `http://127.0.0.1:${server.address().port}/api/v33`;

    try {
      // 1. RBAC: Student blocked from Admin endpoints
      const forbiddenRes = await fetch(`${base}/admin/pricing-hub`, { headers: { "x-test-user-id": String(studentId) } });
      assert.equal(forbiddenRes.status, 403);

      // 2. Strict Payment Rule: Student submits part payment ₹1500 -> MUST stay pending, NOT mark invoice paid
      const payRes = await fetch(`${base}/student/pay`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(studentId) },
        body: JSON.stringify({ feeRecordId: invId, amount: 1500, paymentMode: "part", paymentMethod: "upi", utrReference: "UTR123456" }),
      });
      assert.equal(payRes.status, 201);
      const payData = await payRes.json();
      assert.equal(payData.verificationStatus, "pending_verification");
      const finBefore = await (await fetch(`${base}/student/finance`, { headers: { "x-test-user-id": String(studentId) } })).json();
      assert.equal(finBefore.summary.amountPaid, 0);
      assert.equal(finBefore.summary.pendingAmount, 4000);

      // Receipt PDF blocked before verification
      const unverifiedReceipt = await fetch(`${base}/student/receipt/${payData.paymentId}/pdf`, {
        headers: { "x-test-user-id": String(studentId) },
      });
      assert.equal(unverifiedReceipt.status, 400);

      // 3. Admin verifies payment -> balance auto-recalculates (Paid ₹1500, Pending ₹2500) & PDF Receipt works!
      const verRes = await fetch(`${base}/admin/payments/${payData.paymentId}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ action: "verify" }),
      });
      assert.equal(verRes.status, 200);
      const verData = await verRes.json();
      assert.equal(verData.summary.summary.amountPaid, 1500);
      assert.equal(verData.summary.summary.pendingAmount, 2500);

      const recPdfRes = await fetch(`${base}/student/receipt/${payData.paymentId}/pdf`, {
        headers: { "x-test-user-id": String(studentId) },
      });
      assert.equal(recPdfRes.status, 200);
      const recPdfText = await recPdfRes.text();
      assert.ok(recPdfText.startsWith("%PDF-1.4"));

      // 4. Historical Pricing Protection: Admin edits Class 10 fee to ₹1100 -> historical invoice remains ₹4000!
      const updRes = await fetch(`${base}/admin/pricing-config`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ schoolSubjectFees: { ...getV33PricingConfig(db).schoolSubjectFees, "10": 1100 } }),
      });
      assert.equal(updRes.status, 200);
      const histInv = db.prepare("SELECT total_amount FROM fee_records WHERE id = ?").get(invId);
      assert.equal(histInv.total_amount, 4000);
      assert.ok(db.prepare("SELECT COUNT(*) AS c FROM v33_pricing_audit").get().c >= 1);

      // 5. Automated Follow-Up Scheduler + Duplicate Prevention
      const fuRes = await fetch(`${base}/admin/students/${studentId}/followups`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ followUpDate: "2020-01-01", followUpTime: "09:00", reminderType: "overdue_alert", customMessage: "Call parent" }),
      });
      assert.equal(fuRes.status, 201);
      const sweep1 = await runInvoiceFollowupSweep(db, { sendTransactionalEmail: async (m) => { sentEmails.push(m); return { ok: true }; } });
      assert.equal(sweep1.dispatched, 1);
      const sweep2 = await runInvoiceFollowupSweep(db, { sendTransactionalEmail: async (m) => { sentEmails.push(m); return { ok: true }; } });
      assert.equal(sweep2.dispatched, 0);

      // 6. Course Renewal Sweep (7 days before expiry) + Duplicate Prevention
      const nowFixed = new Date("2026-11-23T04:00:00Z");
      const exp7 = "2026-11-30";
      db.prepare("INSERT INTO enrollments (student_id, course_id, status, expires_at) VALUES (?, ?, 'active', ?)").run(studentId, course.id, exp7);
      const ren1 = await runCourseRenewalV33Sweep(db, { sendTransactionalEmail: async (m) => { sentEmails.push(m); return { ok: true }; } }, { now: nowFixed });
      assert.equal(ren1.triggered, 1);
      const ren2 = await runCourseRenewalV33Sweep(db, { sendTransactionalEmail: async (m) => { sentEmails.push(m); return { ok: true }; } }, { now: nowFixed });
      assert.equal(ren2.triggered, 0);

      // 7. Simplified 3-Field Student Registration + OTP
      const qRegRes = await fetch(`${base}/auth/quick-register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName: "Kabir Verma", phone: "9899001122", referralCode: "", otpChannel: "sms" }),
      });
      assert.equal(qRegRes.status, 200);
      const qRegData = await qRegRes.json();
      assert.ok(qRegData.devOtp && qRegData.devOtp.length === 6);
      const qVerRes = await fetch(`${base}/auth/quick-verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: "9899001122", otp: qRegData.devOtp }),
      });
      assert.equal(qVerRes.status, 200);
      const qVerData = await qVerRes.json();
      assert.equal(qVerData.authenticated, true);
      assert.equal(qVerData.redirectUrl, "/student");

      // 8. Parent Insights & Weak Subject Detection
      const pInsRes = await fetch(`${base}/parent/insights/${studentId}`, { headers: { "x-test-user-id": String(parentId) } });
      assert.equal(pInsRes.status, 200);
      const pInsData = await pInsRes.json();
      assert.ok(pInsData.weakSubjects.some((w) => w.subject === "Science"));
      assert.ok(pInsData.skillAndExamCourses.length > 0);

      // 9. Smart Notification Center Status Filter & Patch
      const nRes = await fetch(`${base}/notifications?status=new`, { headers: { "x-test-user-id": String(studentId) } });
      assert.equal(nRes.status, 200);
      const nData = await nRes.json();
      assert.ok(nData.notifications.length >= 1);
      const nid = nData.notifications[0].id;
      const patchN = await fetch(`${base}/notifications/${nid}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(studentId) },
        body: JSON.stringify({ status: "important" }),
      });
      assert.equal(patchN.status, 200);

      // 10. CRM Lead-to-Student Duplicate-Free Conversion
      const leadId = Number(
        db.prepare("INSERT INTO inquiries (name, phone, email, message, source, status) VALUES ('Meera Nair', '9877665544', 'meera@example.com', 'Interested in Class 12', 'whatsapp', 'qualified')").run().lastInsertRowid
      );
      const conv1 = await fetch(`${base}/admin/leads/${leadId}/convert`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ classLevel: "Class 12", board: "CBSE" }),
      });
      assert.equal(conv1.status, 201);
      const conv1Data = await conv1.json();
      assert.equal(conv1Data.alreadyExisted, false);
      const conv2 = await fetch(`${base}/admin/leads/${leadId}/convert`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ classLevel: "Class 12" }),
      });
      const conv2Data = await conv2.json();
      assert.equal(conv2Data.alreadyExisted, true);
      assert.equal(conv2Data.studentId, conv1Data.studentId);

      // 11. Revenue Analytics
      const revRes = await fetch(`${base}/admin/revenue-analytics`, { headers: { "x-test-user-id": String(adminId) } });
      assert.equal(revRes.status, 200);
      const revData = await revRes.json();
      assert.equal(revData.analytics.kpis.totalCollected, 1500);
      assert.equal(revData.analytics.kpis.pendingRevenue, 2500);
    } finally {
      server.close();
    }
  });

  it("confirms 'Install Yuitor App' is completely removed from frontend scripts", () => {
    const root = process.cwd();
    const v32Pub = fs.readFileSync(path.join(root, "public/assets/v32-public.js"), "utf8");
    const chatWidget = fs.readFileSync(path.join(root, "public/assets/chatbot-widget.js"), "utf8");
    assert.equal(/install\s+yuitor\s+app/i.test(v32Pub), false);
    assert.equal(/install\s+yuitor\s+app/i.test(chatWidget), false);
    assert.ok(v32Pub.includes("/sw.js"), "Service worker registration preserved");
  });

  it("enforces staff permissions via users table, verifyNow, course promoFee, scholarship category & classLevel quote alias", async () => {
    const db = createTestDb();
    db.exec("ALTER TABLE users ADD COLUMN staff_role TEXT DEFAULT ''");
    db.exec("ALTER TABLE users ADD COLUMN staff_permissions_json TEXT DEFAULT '[]'");
    const adminId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone) VALUES ('super_admin', 'Root Admin', 'root@yuitor.com', '9000000010')").run().lastInsertRowid
    );
    const staffId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone, staff_role, staff_permissions_json) VALUES ('staff', 'Accounts Staff', 'acct@yuitor.com', '9000000011', 'accountant', '[\"fees\",\"reports\"]')").run().lastInsertRowid
    );
    const studentId = Number(
      db.prepare("INSERT INTO users (role, full_name, email, phone) VALUES ('student', 'Priya Verma', 'priya@yuitor.com', '9000000012')").run().lastInsertRowid
    );
    db.prepare("INSERT INTO student_profiles (user_id, class_level, board) VALUES (?, '10th', 'CBSE')").run(studentId);

    const app = express();
    app.use(express.json());
    app.use(
      "/api/v33",
      createV33Router(db, {
        getSessionContext: (database, req) => {
          const uid = Number(req.headers["x-test-user-id"] || 0);
          if (!uid) return null;
          const u = database.prepare("SELECT * FROM users WHERE id = ?").get(uid);
          return u ? { user: u } : null;
        },
        createSession: () => "test-sess",
        setSessionCookie: () => {},
        sendTransactionalEmail: async () => ({ ok: true }),
      })
    );

    const server = await new Promise((resolve) => {
      const s = app.listen(0, "127.0.0.1", () => resolve(s));
    });
    const base = `http://127.0.0.1:${server.address().port}/api/v33`;

    try {
      // 1. Checkout quote accepts classLevel alias cleanly
      const qRes = await fetch(`${base}/checkout/quote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ classLevel: "10th", subjects: ["Maths", "Science"], durationMonths: 6 }),
      });
      assert.equal(qRes.status, 200);
      const qData = await qRes.json();
      assert.equal(qData.quote.lineItems.length, 2);

      // 2. Staff accountant authorized via users.staff_permissions_json / staff_role can access invoices & verifyNow
      const invRes = await fetch(`${base}/admin/students/${studentId}/invoices`, {
        headers: { "x-test-user-id": String(staffId) },
      });
      assert.equal(invRes.status, 200);

      const recRes = await fetch(`${base}/admin/students/${studentId}/record-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(staffId) },
        body: JSON.stringify({ amount: 600, totalFee: 1200, paymentMethod: "cash", verifyNow: true }),
      });
      assert.equal(recRes.status, 201);
      const recData = await recRes.json();
      assert.equal(recData.verificationStatus, "verified");
      assert.ok(recData.receiptNumber);

      // 3. Course promoFee & Scholarship category saved cleanly
      const cRes = await fetch(`${base}/admin/courses`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ title: "AI Junior Lab", category: "Technology", monthlyFee: 1200, promoFee: 999 }),
      });
      assert.equal(cRes.status, 201);
      const cData = await cRes.json();
      assert.equal(Number(cData.course.promo_price), 999);
      assert.equal(Number(cData.course.promo_enabled), 1);

      const sRes = await fetch(`${base}/admin/scholarships`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-test-user-id": String(adminId) },
        body: JSON.stringify({ name: "Beti Padhao Grant", category: "Girl Child", discountType: "percent", discountValue: 20 }),
      });
      assert.equal(sRes.status, 201);
      const sData = await sRes.json();
      const sRow = db.prepare("SELECT scholarship_type FROM v33_scholarships WHERE id = ?").get(sData.id);
      assert.equal(sRow.scholarship_type, "Girl Child");
    } finally {
      server.close();
    }
  });
});
