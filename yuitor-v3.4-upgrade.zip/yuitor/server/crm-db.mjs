import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { nowIso } from "./addons-db.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MIGRATION_003_PATH = path.resolve(__dirname, "..", "database", "migrations", "003_crm_v25_automation.sql");

export const STAFF_ROLE_TEMPLATES = {
  receptionist_counsellor: {
    key: "receptionist_counsellor",
    label: "Receptionist / Counsellor",
    description: "Manages inquiries, follow-ups, demo scheduling, and fast admissions.",
    permissions: ["inquiries", "admissions", "alerts"]
  },
  fee_clerk_accountant: {
    key: "fee_clerk_accountant",
    label: "Fee Clerk / Accountant",
    description: "Collects cash/UPI fees, issues receipts, records expenses, and exports financial reports without unauthorized edits.",
    permissions: ["fees", "expenses", "reports"]
  },
  academic_coordinator: {
    key: "academic_coordinator",
    label: "Academic Coordinator",
    description: "Manages batch attendance, timetable, offline marks, CBT exams, and batch notices.",
    permissions: ["batches", "timetable", "attendance", "tests", "alerts"]
  }
};

export const DEFAULT_AUTOMATION_RULES = [
  {
    rule_key: "lead_instant_welcome_and_sla",
    name: "New Lead Scoring, Counsellor Assignment & 15-Min SLA",
    description: "Scores new inquiries (0-100), assigns a counsellor, schedules 15-minute SLA check, and queues welcome follow-up.",
    event_name: "lead.created",
    conditions: {},
    actions: [
      { type: "assign_counsellor" },
      { type: "enqueue_message", channel: "whatsapp", template: "lead_welcome" }
    ],
    priority: 10
  },
  {
    rule_key: "lead_followup_escalation",
    name: "Lead Follow-up SLA Escalation",
    description: "Creates an exception & escalates overdue leads when follow-up SLA is missed.",
    event_name: "lead.followup_due",
    conditions: {},
    actions: [
      { type: "create_task", taskType: "lead_followup", priority: "high" },
      { type: "create_exception", category: "sla_breach", severity: "medium" }
    ],
    priority: 20
  },
  {
    rule_key: "admission_onboarding_pack",
    name: "Admission Onboarding Pack (ID Card, Checklist & Welcome)",
    description: "Creates document checklist, assigns roll number if missing, updates seat count, and sends welcome message.",
    event_name: "admission.completed",
    conditions: {},
    actions: [
      { type: "ensure_checklist" },
      { type: "enqueue_message", channel: "email", template: "admission_welcome" }
    ],
    priority: 15
  },
  {
    rule_key: "payment_receipt_notification",
    name: "Verified Payment Receipt Delivery",
    description: "Sends verified payment confirmation and receipt link after payment confirmation.",
    event_name: "payment.received",
    conditions: {},
    actions: [
      { type: "enqueue_message", channel: "email", template: "payment_receipt" }
    ],
    priority: 10
  },
  {
    rule_key: "payment_overdue_reminder",
    name: "Automatic Fee Overdue Reminder",
    description: "Sends polite fee reminder with fallback channel chain (WhatsApp -> SMS -> Email -> Call Task).",
    event_name: "payment.overdue",
    conditions: {},
    actions: [
      { type: "enqueue_message", channel: "whatsapp", template: "fee_reminder" }
    ],
    priority: 25
  },
  {
    rule_key: "attendance_absent_parent_alert",
    name: "Instant Parent Absence Alert & 3-Day Counsellor Task",
    description: "Alerts parents when a student is marked absent and creates a counsellor task after 3 consecutive absences.",
    event_name: "attendance.absent",
    conditions: {},
    actions: [
      { type: "enqueue_message", channel: "whatsapp", template: "absence_alert" },
      { type: "check_consecutive_absences" }
    ],
    priority: 12
  },
  {
    rule_key: "attendance_low_threshold_alert",
    name: "Low Attendance (<75%) Early Warning",
    description: "Notifies student and parent when cumulative attendance falls below the configured threshold.",
    event_name: "attendance.submitted",
    conditions: { belowThreshold: true },
    actions: [
      { type: "enqueue_message", channel: "email", template: "low_attendance_warning" }
    ],
    priority: 30
  },
  {
    rule_key: "live_class_15min_reminder",
    name: "Live Class Starting Reminder & Teacher No-Show Guard",
    description: "Alerts enrolled batch students 15 minutes before class and flags teacher no-show.",
    event_name: "class.started",
    conditions: {},
    actions: [
      { type: "notify_batch_class_start" }
    ],
    priority: 18
  },
  {
    rule_key: "test_weak_topic_remediation",
    name: "Weak-Topic Practice Set & 7-Day Re-Test Scheduler",
    description: "When test score is below 40%, identifies weak topics, assigns extra practice set, and schedules a 7-day re-test.",
    event_name: "test.completed",
    conditions: { maxPercent: 40 },
    actions: [
      { type: "schedule_remediation" }
    ],
    priority: 22
  },
  {
    rule_key: "teacher_leave_substitute_workflow",
    name: "Teacher Leave Approved -> Substitute Assignment Prompt",
    description: "Flags affected timetable slots in Exception Inbox for substitute teacher assignment.",
    event_name: "teacher.leave_approved",
    conditions: {},
    actions: [
      { type: "flag_substitute_needed" }
    ],
    priority: 16
  },
  {
    rule_key: "course_renewal_45day_campaign",
    name: "45-Day Course Renewal Campaign",
    description: "Queues renewal outreach to students whose course enrollment ends within 45 days.",
    event_name: "course.ending",
    conditions: {},
    actions: [
      { type: "enqueue_message", channel: "email", template: "course_renewal" }
    ],
    priority: 40
  }
];

function addColIfMissing(db, table, col, ddl) {
  try {
    const cols = db.prepare(`PRAGMA table_info(${table})`).all();
    if (!cols.some((c) => c.name === col)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
    }
  } catch {
    // Table may not exist in minimal unit-test DBs
  }
}

export function ensureCrmV25Schema(db, migrationPath = MIGRATION_003_PATH) {
  const sql = fs.readFileSync(migrationPath, "utf8");
  db.exec(sql);

  // Additive upgrades on existing tables (zero destructive changes)
  addColIfMissing(db, "batches", "delivery_mode", "delivery_mode TEXT NOT NULL DEFAULT 'hybrid'");
  addColIfMissing(db, "batches", "waitlist_enabled", "waitlist_enabled INTEGER NOT NULL DEFAULT 1");

  addColIfMissing(db, "inquiries", "lead_score", "lead_score INTEGER NOT NULL DEFAULT 40");
  addColIfMissing(db, "inquiries", "priority", "priority TEXT NOT NULL DEFAULT 'medium'");
  addColIfMissing(db, "inquiries", "utm_source", "utm_source TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "inquiries", "utm_medium", "utm_medium TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "inquiries", "utm_campaign", "utm_campaign TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "inquiries", "sla_due_at", "sla_due_at TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "inquiries", "followup_stage", "followup_stage INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "inquiries", "last_contacted_at", "last_contacted_at TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "inquiries", "converted_student_id", "converted_student_id INTEGER");
  addColIfMissing(db, "inquiries", "assigned_staff_id", "assigned_staff_id INTEGER");

  addColIfMissing(db, "timetable_slots", "meeting_url", "meeting_url TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "timetable_slots", "meeting_platform", "meeting_platform TEXT NOT NULL DEFAULT 'google_meet'");
  addColIfMissing(db, "timetable_slots", "substitute_teacher_id", "substitute_teacher_id INTEGER");
  addColIfMissing(db, "timetable_slots", "delivery_mode", "delivery_mode TEXT NOT NULL DEFAULT 'hybrid'");

  addColIfMissing(db, "quizzes", "positive_marks", "positive_marks REAL NOT NULL DEFAULT 4");
  addColIfMissing(db, "quizzes", "negative_marks", "negative_marks REAL NOT NULL DEFAULT 1");
  addColIfMissing(db, "quizzes", "duration_minutes", "duration_minutes INTEGER NOT NULL DEFAULT 30");
  addColIfMissing(db, "quizzes", "exam_pattern", "exam_pattern TEXT NOT NULL DEFAULT 'JEE/NEET (+4/-1)'");
  addColIfMissing(db, "quizzes", "batch_id", "batch_id INTEGER");
  addColIfMissing(db, "quizzes", "subject_name", "subject_name TEXT NOT NULL DEFAULT 'General'");

  addColIfMissing(db, "quiz_attempts", "percentile", "percentile REAL NOT NULL DEFAULT 0");
  addColIfMissing(db, "quiz_attempts", "batch_rank", "batch_rank INTEGER");
  addColIfMissing(db, "quiz_attempts", "weak_topics_json", "weak_topics_json TEXT NOT NULL DEFAULT '[]'");
  addColIfMissing(db, "quiz_attempts", "status_map_json", "status_map_json TEXT NOT NULL DEFAULT '{}'");
  addColIfMissing(db, "quiz_attempts", "positive_count", "positive_count INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "quiz_attempts", "negative_count", "negative_count INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "quiz_attempts", "unanswered_count", "unanswered_count INTEGER NOT NULL DEFAULT 0");

  addColIfMissing(db, "lessons", "video_provider", "video_provider TEXT NOT NULL DEFAULT 'youtube_unlisted'");
  addColIfMissing(db, "lessons", "duration_seconds", "duration_seconds INTEGER NOT NULL DEFAULT 1800");

  addColIfMissing(db, "lesson_progress", "watch_seconds", "watch_seconds INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "lesson_progress", "watch_percent", "watch_percent INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "lesson_progress", "last_position_seconds", "last_position_seconds INTEGER NOT NULL DEFAULT 0");

  addColIfMissing(db, "teacher_profiles", "salary_type", "salary_type TEXT NOT NULL DEFAULT 'hybrid'");
  addColIfMissing(db, "teacher_profiles", "per_class_rate", "per_class_rate INTEGER NOT NULL DEFAULT 400");
  addColIfMissing(db, "teacher_profiles", "fixed_monthly_salary", "fixed_monthly_salary INTEGER NOT NULL DEFAULT 15000");

  addColIfMissing(db, "student_profiles", "fee_lock_exempt", "fee_lock_exempt INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "student_profiles", "parent_consent_verified", "parent_consent_verified INTEGER NOT NULL DEFAULT 0");
  addColIfMissing(db, "student_profiles", "dob", "dob TEXT NOT NULL DEFAULT ''");

  addColIfMissing(db, "fee_records", "billing_month", "billing_month TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "payments", "idempotency_key", "idempotency_key TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "payments", "collected_by", "collected_by INTEGER");
  addColIfMissing(db, "payments", "notes", "notes TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "users", "dob", "dob TEXT NOT NULL DEFAULT ''");
  addColIfMissing(db, "crm_automation_config", "mask_student_phones_for_teachers", "mask_student_phones_for_teachers INTEGER NOT NULL DEFAULT 1");
  addColIfMissing(db, "crm_automation_config", "auto_substitute_on_leave", "auto_substitute_on_leave INTEGER NOT NULL DEFAULT 1");
  addColIfMissing(db, "crm_automation_config", "birthday_wishes_enabled", "birthday_wishes_enabled INTEGER NOT NULL DEFAULT 1");
  addColIfMissing(db, "crm_automation_config", "welcome_emails_enabled", "welcome_emails_enabled INTEGER NOT NULL DEFAULT 1");
  addColIfMissing(db, "teacher_leave_requests", "substitute_teacher_id", "substitute_teacher_id INTEGER");
  addColIfMissing(db, "teacher_leave_requests", "substitute_assigned_at", "substitute_assigned_at TEXT NOT NULL DEFAULT ''");

  try {
    db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_idempotency_key ON payments(idempotency_key) WHERE idempotency_key != ''`);
    db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_fee_records_student_month ON fee_records(student_id, billing_month) WHERE billing_month != ''`);
  } catch {
    // Safe fallback if existing duplicate rows exist
  }

  seedCrmDefaults(db);
}

export function seedCrmDefaults(db) {
  const now = nowIso();
  db.prepare(
    `INSERT OR IGNORE INTO crm_automation_config (id, founder_report_email, updated_at)
     VALUES (1, ?, ?)`
  ).run(process.env.ADMIN_NOTIFY_EMAIL || "admission@yuitor.com", now);

  const insRule = db.prepare(
    `INSERT OR IGNORE INTO crm_automation_rules (
      rule_key, name, description, event_name, conditions_json, actions_json,
      priority, version, is_enabled, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?)`
  );
  for (const r of DEFAULT_AUTOMATION_RULES) {
    insRule.run(
      r.rule_key,
      r.name,
      r.description,
      r.event_name,
      JSON.stringify(r.conditions || {}),
      JSON.stringify(r.actions || []),
      r.priority,
      now,
      now
    );
  }
}

export function getAutomationConfig(db) {
  seedCrmDefaults(db);
  return db.prepare("SELECT * FROM crm_automation_config WHERE id = 1").get();
}

export function updateAutomationConfig(db, patch = {}, actorId = null) {
  const cur = getAutomationConfig(db);
  const now = nowIso();
  const next = {
    global_kill_switch: patch.global_kill_switch !== undefined ? (Number(patch.global_kill_switch) ? 1 : 0) : cur.global_kill_switch,
    quiet_hours_enabled: patch.quiet_hours_enabled !== undefined ? (Number(patch.quiet_hours_enabled) ? 1 : 0) : cur.quiet_hours_enabled,
    quiet_start_hour: patch.quiet_start_hour !== undefined ? Math.max(0, Math.min(23, Number(patch.quiet_start_hour))) : cur.quiet_start_hour,
    quiet_end_hour: patch.quiet_end_hour !== undefined ? Math.max(0, Math.min(23, Number(patch.quiet_end_hour))) : cur.quiet_end_hour,
    max_auto_messages_per_day: patch.max_auto_messages_per_day !== undefined ? Math.max(1, Math.min(10, Number(patch.max_auto_messages_per_day))) : cur.max_auto_messages_per_day,
    fee_reminders_enabled: patch.fee_reminders_enabled !== undefined ? (Number(patch.fee_reminders_enabled) ? 1 : 0) : cur.fee_reminders_enabled,
    fee_reminder_schedule_json: Array.isArray(patch.fee_reminder_schedule)
      ? JSON.stringify(patch.fee_reminder_schedule.map((n) => Number(n)).filter((n) => Number.isFinite(n)))
      : cur.fee_reminder_schedule_json,
    absent_alerts_enabled: patch.absent_alerts_enabled !== undefined ? (Number(patch.absent_alerts_enabled) ? 1 : 0) : cur.absent_alerts_enabled,
    low_attendance_threshold: patch.low_attendance_threshold !== undefined ? Math.max(30, Math.min(95, Number(patch.low_attendance_threshold))) : cur.low_attendance_threshold,
    consecutive_absent_task_days: patch.consecutive_absent_task_days !== undefined ? Math.max(2, Math.min(15, Number(patch.consecutive_absent_task_days))) : cur.consecutive_absent_task_days,
    defaulter_soft_lock_enabled: patch.defaulter_soft_lock_enabled !== undefined ? (Number(patch.defaulter_soft_lock_enabled) ? 1 : 0) : cur.defaulter_soft_lock_enabled,
    defaulter_soft_lock_days: patch.defaulter_soft_lock_days !== undefined ? Math.max(7, Math.min(90, Number(patch.defaulter_soft_lock_days))) : cur.defaulter_soft_lock_days,
    doubt_sla_hours: patch.doubt_sla_hours !== undefined ? Math.max(1, Math.min(72, Number(patch.doubt_sla_hours))) : cur.doubt_sla_hours,
    monthly_fee_auto_generate: patch.monthly_fee_auto_generate !== undefined ? (Number(patch.monthly_fee_auto_generate) ? 1 : 0) : cur.monthly_fee_auto_generate,
    monthly_fee_due_day: patch.monthly_fee_due_day !== undefined ? Math.max(1, Math.min(28, Number(patch.monthly_fee_due_day))) : cur.monthly_fee_due_day,
    payroll_draft_day: patch.payroll_draft_day !== undefined ? Math.max(1, Math.min(28, Number(patch.payroll_draft_day))) : cur.payroll_draft_day,
    renewal_campaign_days_before: patch.renewal_campaign_days_before !== undefined ? Math.max(7, Math.min(120, Number(patch.renewal_campaign_days_before))) : cur.renewal_campaign_days_before,
    whatsapp_api_enabled: patch.whatsapp_api_enabled !== undefined ? (Number(patch.whatsapp_api_enabled) ? 1 : 0) : cur.whatsapp_api_enabled,
    sms_dlt_enabled: patch.sms_dlt_enabled !== undefined ? (Number(patch.sms_dlt_enabled) ? 1 : 0) : cur.sms_dlt_enabled,
    email_channel_enabled: patch.email_channel_enabled !== undefined ? (Number(patch.email_channel_enabled) ? 1 : 0) : cur.email_channel_enabled,
    founder_report_email: patch.founder_report_email !== undefined ? String(patch.founder_report_email || "").trim().slice(0, 160) : cur.founder_report_email,
    founder_report_phone: patch.founder_report_phone !== undefined ? String(patch.founder_report_phone || "").trim().slice(0, 30) : cur.founder_report_phone,
    mask_student_phones_for_teachers:
      patch.mask_student_phones_for_teachers !== undefined
        ? (Number(patch.mask_student_phones_for_teachers) ? 1 : 0)
        : Number(cur.mask_student_phones_for_teachers ?? 1),
    auto_substitute_on_leave:
      patch.auto_substitute_on_leave !== undefined
        ? (Number(patch.auto_substitute_on_leave) ? 1 : 0)
        : Number(cur.auto_substitute_on_leave ?? 1),
    birthday_wishes_enabled:
      patch.birthday_wishes_enabled !== undefined
        ? (Number(patch.birthday_wishes_enabled) ? 1 : 0)
        : Number(cur.birthday_wishes_enabled ?? 1),
    welcome_emails_enabled:
      patch.welcome_emails_enabled !== undefined
        ? (Number(patch.welcome_emails_enabled) ? 1 : 0)
        : Number(cur.welcome_emails_enabled ?? 1)
  };
  db.prepare(
    `UPDATE crm_automation_config SET
       global_kill_switch = ?, quiet_hours_enabled = ?, quiet_start_hour = ?, quiet_end_hour = ?,
       max_auto_messages_per_day = ?, fee_reminders_enabled = ?, fee_reminder_schedule_json = ?,
       absent_alerts_enabled = ?, low_attendance_threshold = ?, consecutive_absent_task_days = ?,
       defaulter_soft_lock_enabled = ?, defaulter_soft_lock_days = ?, doubt_sla_hours = ?,
       monthly_fee_auto_generate = ?, monthly_fee_due_day = ?, payroll_draft_day = ?,
       renewal_campaign_days_before = ?, whatsapp_api_enabled = ?, sms_dlt_enabled = ?,
       email_channel_enabled = ?, founder_report_email = ?, founder_report_phone = ?,
       mask_student_phones_for_teachers = ?, auto_substitute_on_leave = ?,
       birthday_wishes_enabled = ?, welcome_emails_enabled = ?,
       updated_by = ?, updated_at = ?
     WHERE id = 1`
  ).run(
    next.global_kill_switch,
    next.quiet_hours_enabled,
    next.quiet_start_hour,
    next.quiet_end_hour,
    next.max_auto_messages_per_day,
    next.fee_reminders_enabled,
    next.fee_reminder_schedule_json,
    next.absent_alerts_enabled,
    next.low_attendance_threshold,
    next.consecutive_absent_task_days,
    next.defaulter_soft_lock_enabled,
    next.defaulter_soft_lock_days,
    next.doubt_sla_hours,
    next.monthly_fee_auto_generate,
    next.monthly_fee_due_day,
    next.payroll_draft_day,
    next.renewal_campaign_days_before,
    next.whatsapp_api_enabled,
    next.sms_dlt_enabled,
    next.email_channel_enabled,
    next.founder_report_email,
    next.founder_report_phone,
    next.mask_student_phones_for_teachers,
    next.auto_substitute_on_leave,
    next.birthday_wishes_enabled,
    next.welcome_emails_enabled,
    actorId,
    now
  );
  return getAutomationConfig(db);
}
