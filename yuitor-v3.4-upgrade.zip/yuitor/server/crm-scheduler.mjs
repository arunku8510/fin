import fs from "node:fs";
import path from "node:path";
import { nowIso } from "./addons-db.mjs";
import { getAutomationConfig } from "./crm-db.mjs";
import {
  calculateStudentRiskScore,
  calculateTeacherPayroll,
  createExceptionItem,
  detectTimetableClash,
  emitSystemEvent,
  generateMonthlyFeeInvoices,
  getIstDateParts,
  processJobQueueBatch,
  sendBirthdayWishesForToday
} from "./crm-engine.mjs";
import { runCrossSellWeeklyDispatch } from "./v31-engine.mjs";
import { getV32Settings, runAbandonedCartReminderSweep, runPlanExpiryRenewalSweep } from "./v32-engine.mjs";
import { runCourseRenewalV33Sweep, runInvoiceFollowupSweep } from "./v33-engine.mjs";

const activeLocks = new Set();

function runTrackedJob(db, jobName, runKey, fn) {
  const lockKey = `${jobName}:${runKey}`;
  if (activeLocks.has(lockKey)) {
    return { skipped: true, reason: "in_memory_overlap_lock" };
  }
  const existing = db.prepare("SELECT id, status FROM crm_scheduler_runs WHERE run_key = ?").get(runKey);
  if (existing) {
    return { skipped: true, reason: "already_executed", runId: existing.id };
  }

  activeLocks.add(lockKey);
  const startMs = Date.now();
  const startedAt = nowIso();
  const ins = db
    .prepare(
      `INSERT INTO crm_scheduler_runs (job_name, run_key, timezone, status, started_at)
       VALUES (?, ?, 'Asia/Kolkata', 'running', ?)`
    )
    .run(jobName, runKey, startedAt);
  const runId = Number(ins.lastInsertRowid);

  return Promise.resolve()
    .then(() => fn())
    .then((summary) => {
      const durationMs = Date.now() - startMs;
      db.prepare(
        `UPDATE crm_scheduler_runs
         SET status = 'completed', finished_at = ?, duration_ms = ?, summary_json = ?
         WHERE id = ?`
      ).run(nowIso(), durationMs, JSON.stringify(summary || {}), runId);
      return { ok: true, runId, durationMs, summary };
    })
    .catch((err) => {
      const durationMs = Date.now() - startMs;
      const errMsg = String(err?.message || "Scheduler task failed").slice(0, 500);
      db.prepare(
        `UPDATE crm_scheduler_runs
         SET status = 'failed', finished_at = ?, duration_ms = ?, error_message = ?
         WHERE id = ?`
      ).run(nowIso(), durationMs, errMsg, runId);
      createExceptionItem(db, {
        category: "cron_alert",
        severity: "critical",
        title: `Scheduler Job Failed: ${jobName}`,
        summary: errMsg,
        entityType: "crm_scheduler_runs",
        entityId: String(runId),
        details: { jobName, runKey, error: errMsg },
        escalationLevel: "owner"
      });
      return { ok: false, runId, durationMs, error: errMsg };
    })
    .finally(() => {
      activeLocks.delete(lockKey);
    });
}

export function computeFounderDailyMetrics(db, dateStr = getIstDateParts().dateStr) {
  const cashCollection = Number(
    db
      .prepare(
        `SELECT COALESCE(SUM(amount), 0) AS total FROM payments
         WHERE verification_status = 'verified' AND payment_method = 'cash' AND substr(COALESCE(paid_at, created_at), 1, 10) = ?`
      )
      .get(dateStr)?.total || 0
  );
  const onlineCollection = Number(
    db
      .prepare(
        `SELECT COALESCE(SUM(amount), 0) AS total FROM payments
         WHERE verification_status = 'verified' AND payment_method != 'cash' AND substr(COALESCE(paid_at, created_at), 1, 10) = ?`
      )
      .get(dateStr)?.total || 0
  );
  const newInquiries = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM inquiries WHERE substr(created_at, 1, 10) = ?`).get(dateStr)?.c || 0
  );
  const admissions = Number(
    db
      .prepare(`SELECT COUNT(*) AS c FROM users WHERE role = 'student' AND substr(created_at, 1, 10) = ?`)
      .get(dateStr)?.c || 0
  );
  const absentStudents = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM attendance WHERE att_date = ? AND status = 'absent'`).get(dateStr)?.c || 0
  );
  const teachersOnLeave = Number(
    db
      .prepare(
        `SELECT COUNT(DISTINCT teacher_id) AS c FROM teacher_leave_requests
         WHERE status = 'approved' AND from_date <= ? AND to_date >= ?`
      )
      .get(dateStr, dateStr)?.c || 0
  );
  const pendingTeacherLeaves = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM teacher_leave_requests WHERE status = 'pending'`).get()?.c || 0
  );
  const totalPendingFees = Number(
    db
      .prepare(
        `SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) AS total
         FROM fee_records WHERE status IN ('pending', 'partial', 'overdue')`
      )
      .get()?.total || 0
  );
  const feesDueToday = Number(
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM fee_records
         WHERE status IN ('pending', 'partial', 'overdue') AND due_date IS NOT NULL AND due_date != '' AND due_date <= ?`
      )
      .get(dateStr)?.c || 0
  );
  const todaysFollowups = Number(
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM inquiries
         WHERE status NOT IN ('admitted', 'closed', 'cold') AND follow_up_date != '' AND follow_up_date <= ?`
      )
      .get(dateStr)?.c || 0
  );
  const failedAutomations = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM crm_job_queue WHERE status IN ('failed', 'dead_letter')`).get()?.c || 0
  );
  const openExceptions = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM crm_exception_inbox WHERE status = 'open'`).get()?.c || 0
  );
  const openDoubts = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM crm_doubts WHERE status IN ('open', 'escalated')`).get()?.c || 0
  );

  return {
    dateStr,
    cashCollection,
    onlineCollection,
    totalCollection: cashCollection + onlineCollection,
    newInquiries,
    admissions,
    absentStudents,
    teachersOnLeave,
    pendingTeacherLeaves,
    totalPendingFees,
    feesDueToday,
    todaysFollowups,
    failedAutomations,
    openExceptions,
    openDoubts
  };
}

export function saveDailyReport(db, reportType = "founder_8pm", dateStr = getIstDateParts().dateStr) {
  const m = computeFounderDailyMetrics(db, dateStr);
  const summaryText = [
    `Yuitor Smart Institute — ${reportType === "owner_930pm" ? "Detailed Owner Report" : reportType === "weekly_monday" ? "Weekly Executive Digest" : "Founder Daily Report"} (${dateStr})`,
    `Collection: ₹${m.totalCollection.toLocaleString("en-IN")} (Cash ₹${m.cashCollection.toLocaleString("en-IN")} | Online ₹${m.onlineCollection.toLocaleString("en-IN")})`,
    `Inquiries: ${m.newInquiries} | Admissions: ${m.admissions} | Today's Follow-ups: ${m.todaysFollowups}`,
    `Absentees: ${m.absentStudents} | Teachers on Leave: ${m.teachersOnLeave} | Pending Fees: ₹${m.totalPendingFees.toLocaleString("en-IN")}`,
    `Failed Automation Jobs: ${m.failedAutomations} | Open Exceptions: ${m.openExceptions}`
  ].join("\n");

  db.prepare(
    `INSERT INTO crm_daily_reports (report_date, report_type, metrics_json, summary_text, dispatched_channels, created_at)
     VALUES (?, ?, ?, ?, 'dashboard', ?)
     ON CONFLICT(report_date, report_type) DO UPDATE SET
       metrics_json = excluded.metrics_json,
       summary_text = excluded.summary_text,
       created_at = excluded.created_at`
  ).run(dateStr, reportType, JSON.stringify(m), summaryText, nowIso());

  return { metrics: m, summaryText };
}

export function runLeadSlaCheck(db) {
  const now = nowIso();
  const overdueLeads = db
    .prepare(
      `SELECT id, name, phone, class_or_course, assigned_staff, sla_due_at, followup_stage
       FROM inquiries
       WHERE status IN ('new', 'contacted') AND sla_due_at != '' AND sla_due_at <= ?
       LIMIT 50`
    )
    .all(now);

  let escalated = 0;
  let markedCold = 0;
  for (const lead of overdueLeads) {
    const stage = Number(lead.followup_stage || 0);
    if (stage >= 6) {
      db.prepare(`UPDATE inquiries SET status = 'cold' WHERE id = ?`).run(lead.id);
      markedCold += 1;
      continue;
    }
    emitSystemEvent(
      db,
      "lead.followup_due",
      {
        inquiryId: lead.id,
        name: lead.name,
        phone: lead.phone,
        title: `Lead SLA Overdue: ${lead.name}`,
        summary: `Follow-up SLA missed for ${lead.name} (${lead.phone}, ${lead.class_or_course}).`
      },
      { idempotencyKey: `lead_sla:${lead.id}:${stage}`, entityType: "inquiry", entityId: String(lead.id) }
    );
    const nextMins = [30, 60, 180, 1440, 4320, 10080][Math.min(stage, 5)];
    const nextSla = new Date(Date.now() + nextMins * 60000).toISOString();
    db.prepare(`UPDATE inquiries SET followup_stage = followup_stage + 1, sla_due_at = ? WHERE id = ?`).run(nextSla, lead.id);
    escalated += 1;
  }
  return { checked: overdueLeads.length, escalated, markedCold };
}

export function runPaymentReconciliation(db) {
  const now = nowIso();
  const pendingRows = db
    .prepare(
      `SELECT id, student_id, amount, gateway_order_id, gateway_payment_id, verification_status, created_at
       FROM payments WHERE verification_status = 'pending_verification' ORDER BY id DESC LIMIT 100`
    )
    .all();

  const dupRows = db
    .prepare(
      `SELECT gateway_payment_id, COUNT(*) AS cnt FROM payments
       WHERE gateway_payment_id != '' GROUP BY gateway_payment_id HAVING cnt > 1`
    )
    .all();

  let staleFlagged = 0;
  const staleCutoff = new Date(Date.now() - 30 * 60 * 1000).toISOString();
  for (const p of pendingRows) {
    if (p.created_at && p.created_at < staleCutoff) {
      staleFlagged += 1;
    }
  }
  if (dupRows.length > 0) {
    createExceptionItem(db, {
      category: "payment_reconciliation",
      severity: "critical",
      title: `Duplicate Gateway Payment Detected (${dupRows.length})`,
      summary: "Reconciliation detected duplicate gateway payment references requiring review.",
      details: { duplicates: dupRows },
      escalationLevel: "owner"
    });
  }

  db.prepare(
    `INSERT INTO crm_payment_reconciliations (run_at, checked_count, verified_count, pending_count, failed_count, duplicate_count, summary_json)
     VALUES (?, ?, 0, ?, 0, ?, ?)`
  ).run(now, pendingRows.length, pendingRows.length, dupRows.length, JSON.stringify({ staleFlagged }));

  return { checked: pendingRows.length, pending: pendingRows.length, duplicates: dupRows.length, staleFlagged };
}

export function runFeeReminderSweep(db, dateStr = getIstDateParts().dateStr) {
  const cfg = getAutomationConfig(db);
  if (Number(cfg.fee_reminders_enabled) !== 1) return { skipped: true, reason: "disabled" };
  let offsets = [-7, -3, 0, 1, 3, 7, 15];
  try {
    const parsed = JSON.parse(cfg.fee_reminder_schedule_json || "[]");
    if (Array.isArray(parsed) && parsed.length) offsets = parsed.map(Number);
  } catch {
    // default offsets
  }

  const todayMs = Date.parse(dateStr);
  const dueRows = db
    .prepare(
      `SELECT fr.id, fr.student_id, fr.title, fr.total_amount, fr.discount_amount, fr.paid_amount, fr.due_date,
              u.full_name, u.phone, u.email, sp.parent_phone
       FROM fee_records fr
       JOIN users u ON u.id = fr.student_id
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       WHERE fr.status IN ('pending', 'partial', 'overdue') AND fr.due_date IS NOT NULL AND fr.due_date != ''`
    )
    .all();

  let triggered = 0;
  for (const r of dueRows) {
    const balance = Math.max(0, Number(r.total_amount || 0) - Number(r.discount_amount || 0) - Number(r.paid_amount || 0));
    if (balance <= 0) continue;
    const dueMs = Date.parse(r.due_date);
    if (!Number.isFinite(dueMs)) continue;
    const diffDays = Math.round((todayMs - dueMs) / 86400000); // negative = before due, positive = after due
    if (diffDays > 0) {
      db.prepare(`UPDATE fee_records SET status = 'overdue' WHERE id = ? AND status = 'pending'`).run(r.id);
    }
    if (offsets.includes(diffDays)) {
      emitSystemEvent(
        db,
        "payment.overdue",
        {
          studentId: r.student_id,
          studentName: r.full_name,
          phone: r.parent_phone || r.phone,
          email: r.email,
          amount: balance,
          dueDate: r.due_date,
          diffDays,
          template: "fee_reminder"
        },
        { idempotencyKey: `fee_rem:${r.id}:${dateStr}`, entityType: "fee_record", entityId: String(r.id) }
      );
      triggered += 1;
    }
  }
  return { scanned: dueRows.length, triggered };
}

export function runDoubtSlaSweep(db) {
  const now = nowIso();
  const breached = db
    .prepare(`SELECT id, student_id, subject_name, assigned_teacher_id FROM crm_doubts WHERE status = 'open' AND sla_breached = 0 AND sla_due_at <= ?`)
    .all(now);
  for (const d of breached) {
    db.prepare(`UPDATE crm_doubts SET sla_breached = 1, status = 'escalated', updated_at = ? WHERE id = ?`).run(now, d.id);
    createExceptionItem(db, {
      category: "doubt_sla",
      severity: "medium",
      title: `Doubt #${d.id} (${d.subject_name}) Exceeded 12h SLA`,
      summary: "Assigned subject teacher has not replied within the configured SLA window.",
      entityType: "crm_doubts",
      entityId: String(d.id),
      assignedTo: d.assigned_teacher_id || null,
      escalationLevel: "team_lead"
    });
  }
  return { breached: breached.length };
}

export function runStudentRiskCalculation(db, dateStr = getIstDateParts().dateStr) {
  const students = db
    .prepare(`SELECT id, full_name FROM users WHERE role = 'student' AND is_active = 1`)
    .all();
  const todayMs = Date.parse(dateStr);
  let highRiskCount = 0;

  for (const s of students) {
    const att = db
      .prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END) AS present_cnt FROM attendance WHERE student_id = ?`)
      .get(s.id);
    const attPct = Number(att?.total || 0) > 0 ? Math.round((Number(att.present_cnt || 0) / Number(att.total)) * 100) : 100;

    const overdueRow = db
      .prepare(`SELECT MIN(due_date) AS oldest_due FROM fee_records WHERE student_id = ? AND status IN ('pending','partial','overdue') AND due_date < ?`)
      .get(s.id, dateStr);
    const overdueDays = overdueRow?.oldest_due ? Math.max(0, Math.floor((todayMs - Date.parse(overdueRow.oldest_due)) / 86400000)) : 0;

    const avgRow = db
      .prepare(`SELECT AVG(CASE WHEN t.max_marks > 0 THEN (m.marks_obtained * 100.0 / t.max_marks) ELSE NULL END) AS avg_pct FROM offline_test_marks m JOIN offline_tests t ON t.id = m.test_id WHERE m.student_id = ? AND m.is_absent = 0`)
      .get(s.id);
    const avgTestPct = Math.round(Number(avgRow?.avg_pct || 0));

    const { riskScore, riskLevel } = calculateStudentRiskScore({
      attendancePercent: attPct,
      overdueDays,
      avgTestPercent: avgTestPct
    });
    const recommendedAction =
      riskLevel === "critical" || riskLevel === "high"
        ? "Schedule immediate parent-mentor call & remedial plan"
        : riskLevel === "medium"
          ? "Monitor attendance & weekly test progress"
          : "On track";

    db.prepare(
      `INSERT INTO crm_student_risk_scores (
        student_id, calculated_date, risk_score, risk_level, attendance_percent, overdue_days, avg_test_percent, recommended_action, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(student_id, calculated_date) DO UPDATE SET
        risk_score = excluded.risk_score, risk_level = excluded.risk_level,
        attendance_percent = excluded.attendance_percent, overdue_days = excluded.overdue_days,
        avg_test_percent = excluded.avg_test_percent, recommended_action = excluded.recommended_action`
    ).run(s.id, dateStr, riskScore, riskLevel, attPct, overdueDays, avgTestPct, recommendedAction, nowIso());

    if (riskLevel === "high" || riskLevel === "critical") {
      highRiskCount += 1;
      const existing = db
        .prepare(`SELECT id FROM crm_counsellor_tasks WHERE student_id = ? AND task_type = 'dropout_risk' AND status IN ('open','in_progress') LIMIT 1`)
        .get(s.id);
      if (!existing) {
        db.prepare(
          `INSERT INTO crm_counsellor_tasks (task_type, title, description, student_id, priority, due_date, status, created_at, updated_at)
           VALUES ('dropout_risk', ?, ?, ?, ?, ?, 'open', ?, ?)`
        ).run(
          `High Dropout Risk (${riskScore}/100): ${s.full_name}`,
          `Attendance ${attPct}%, Overdue ${overdueDays}d, Avg Test ${avgTestPct}%. ${recommendedAction}`,
          s.id,
          riskLevel === "critical" ? "urgent" : "high",
          dateStr,
          nowIso(),
          nowIso()
        );
      }
    }
  }
  return { evaluated: students.length, highRiskCount };
}

export function generateTeacherPayrollDrafts(db, salaryMonth = getIstDateParts().monthStr) {
  const teachers = db
    .prepare(
      `SELECT u.id, u.full_name, u.branch_id,
              tp.salary_type, tp.per_class_rate, tp.fixed_monthly_salary, tp.monthly_payout_rate
       FROM users u
       LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
       WHERE u.role = 'teacher' AND u.is_active = 1`
    )
    .all();

  let created = 0;
  let skipped = 0;
  const now = nowIso();
  for (const t of teachers) {
    const exists = db
      .prepare(`SELECT id FROM teacher_payouts WHERE teacher_id = ? AND salary_month = ? LIMIT 1`)
      .get(t.id, salaryMonth);
    if (exists) {
      skipped += 1;
      continue;
    }
    const classesConducted = Number(
      db
        .prepare(`SELECT COUNT(DISTINCT att_date || ':' || course_id) AS c FROM attendance WHERE teacher_id = ? AND substr(att_date, 1, 7) = ?`)
        .get(t.id, salaryMonth)?.c || 0
    );
    const leaveDays = Number(
      db
        .prepare(`SELECT COUNT(*) AS c FROM teacher_leave_requests WHERE teacher_id = ? AND status = 'approved' AND substr(from_date, 1, 7) = ?`)
        .get(t.id, salaryMonth)?.c || 0
    );
    const fixedMonthly = Number(t.fixed_monthly_salary || t.monthly_payout_rate || 15000);
    const calc = calculateTeacherPayroll({
      salaryType: t.salary_type || "hybrid",
      fixedMonthly,
      perClassRate: Number(t.per_class_rate || 400),
      classesConducted,
      unpaidLeaveDays: Math.max(0, leaveDays - 2) // 2 paid casual leaves/month
    });

    db.prepare(
      `INSERT INTO teacher_payouts (
        teacher_id, branch_id, salary_month, base_amount, bonus_amount, deduction_amount,
        net_amount, payment_method, status, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'upi', 'pending', ?, ?)`
    ).run(
      t.id,
      t.branch_id || null,
      salaryMonth,
      calc.baseAmount,
      calc.bonusAmount,
      calc.deductionAmount,
      calc.netAmount,
      `Auto-draft (${t.salary_type || "hybrid"}): ${classesConducted} classes, ${leaveDays} approved leave(s).`,
      now
    );
    created += 1;
  }
  return { salaryMonth, teachersEvaluated: teachers.length, created, skipped };
}

export function runDatabaseBackupJob(db, backupsDir) {
  if (!backupsDir) return { skipped: true, reason: "no_backup_dir" };
  fs.mkdirSync(backupsDir, { recursive: true });
  const stamp = getIstDateParts().dateStr;
  const dest = path.join(backupsDir, `yuitor-auto-${stamp}.db`);
  try {
    db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
    return { ok: true, file: path.basename(dest), sizeBytes: fs.statSync(dest).size };
  } catch (err) {
    throw new Error(`Auto backup failed: ${err?.message || err}`);
  }
}

export async function runCentralSchedulerTick(db, deps = {}, { forceJob = "", now = new Date() } = {}) {
  const ist = getIstDateParts(now);
  const cfg = getAutomationConfig(db);
  const results = {};

  // 1. Every minute: Queue processing + Lead SLA + v3.3 Automated Invoice Follow-Ups
  if (!forceJob || forceJob === "queue_and_sla") {
    const runKey = forceJob ? `manual:queue_and_sla:${Date.now()}` : `queue_and_sla:${ist.dateStr}:${ist.hm}`;
    results.queue_and_sla = await runTrackedJob(db, "queue_and_sla", runKey, async () => {
      const queue = await processJobQueueBatch(db, deps, { limit: 30 });
      const sla = runLeadSlaCheck(db);
      const v33Followups = await runInvoiceFollowupSweep(db, deps, { now });
      return { queue, sla, v33Followups };
    });
  }

  // 2. Every 5 minutes: Payment reconciliation & Live attendance sync
  if (forceJob === "payment_reconciliation" || (!forceJob && ist.minute % 5 === 0)) {
    const runKey = forceJob ? `manual:reconcile:${Date.now()}` : `reconcile:${ist.dateStr}:${ist.hm}`;
    results.payment_reconciliation = await runTrackedJob(db, "payment_reconciliation", runKey, () => runPaymentReconciliation(db));
  }

  // 3. Every 15 minutes: Doubt SLA + Live class reminders
  if (forceJob === "class_and_doubt_check" || (!forceJob && ist.minute % 15 === 0)) {
    const runKey = forceJob ? `manual:class_doubt:${Date.now()}` : `class_doubt:${ist.dateStr}:${ist.hm}`;
    results.class_and_doubt_check = await runTrackedJob(db, "class_and_doubt_check", runKey, () => runDoubtSlaSweep(db));
  }

  // 4. 06:30 IST: Timetable validation
  if (forceJob === "timetable_validation" || (!forceJob && ist.hour === 6 && ist.minute === 30)) {
    const runKey = forceJob ? `manual:timetable:${Date.now()}` : `timetable_validation:${ist.dateStr}`;
    results.timetable_validation = await runTrackedJob(db, "timetable_validation", runKey, () => {
      const slots = db.prepare("SELECT * FROM timetable_slots").all();
      let clashes = 0;
      for (const s of slots) {
        const res = detectTimetableClash(slots, s);
        if (res.clash) clashes += 1;
      }
      if (clashes > 0) {
        createExceptionItem(db, {
          category: "timetable_clash",
          severity: "high",
          title: `Timetable Validation Found ${clashes} Clash(es)`,
          summary: "Check Academic Hub -> Timetable to resolve overlapping room/teacher/batch schedules.",
          escalationLevel: "team_lead"
        });
      }
      return { checkedSlots: slots.length, clashes };
    });
  }

  // 5. 08:00 IST: Fee reminders
  if (forceJob === "fee_reminders" || (!forceJob && ist.hour === 8 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:fee_reminders:${Date.now()}` : `fee_reminders:${ist.dateStr}`;
    results.fee_reminders = await runTrackedJob(db, "fee_reminders", runKey, () => runFeeReminderSweep(db, ist.dateStr));
  }

  // 5B. 09:00 IST: Automatic Daily Birthday Wishes (Students, Teachers & Staff)
  if (forceJob === "daily_birthdays" || (!forceJob && ist.hour === 9 && ist.minute === 0 && Number(cfg.birthday_wishes_enabled ?? 1) === 1)) {
    const runKey = forceJob ? `manual:birthdays:${Date.now()}` : `daily_birthdays:${ist.dateStr}`;
    results.daily_birthdays = await runTrackedJob(db, "daily_birthdays", runKey, () =>
      sendBirthdayWishesForToday(db, deps.sendTransactionalEmail || null, { now })
    );
  }

  // 6. 20:00 IST: Founder 8 PM Report & Parent Digest
  if (forceJob === "founder_8pm" || (!forceJob && ist.hour === 20 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:founder_8pm:${Date.now()}` : `founder_8pm:${ist.dateStr}`;
    results.founder_8pm = await runTrackedJob(db, "founder_8pm", runKey, () => saveDailyReport(db, "founder_8pm", ist.dateStr));
  }

  // 7. 21:30 IST: Detailed Owner Report
  if (forceJob === "owner_930pm" || (!forceJob && ist.hour === 21 && ist.minute === 30)) {
    const runKey = forceJob ? `manual:owner_930pm:${Date.now()}` : `owner_930pm:${ist.dateStr}`;
    results.owner_930pm = await runTrackedJob(db, "owner_930pm", runKey, () => saveDailyReport(db, "owner_930pm", ist.dateStr));
  }

  // 8. 23:30 IST: Cleanup stale sessions/OTPs
  if (forceJob === "nightly_cleanup" || (!forceJob && ist.hour === 23 && ist.minute === 30)) {
    const runKey = forceJob ? `manual:cleanup:${Date.now()}` : `cleanup:${ist.dateStr}`;
    results.nightly_cleanup = await runTrackedJob(db, "nightly_cleanup", runKey, () => {
      const nowSec = Math.floor(Date.now() / 1000);
      const sDel = db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(nowSec).changes || 0;
      const oDel = db.prepare("DELETE FROM otp_tokens WHERE expires_at < ?").run(nowSec - 86400).changes || 0;
      return { expiredSessionsDeleted: Number(sDel), expiredOtpsDeleted: Number(oDel) };
    });
  }

  // 9. 02:00 IST: Automated DB Backup
  if (forceJob === "daily_backup" || (!forceJob && ist.hour === 2 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:backup:${Date.now()}` : `daily_backup:${ist.dateStr}`;
    results.daily_backup = await runTrackedJob(db, "daily_backup", runKey, () => runDatabaseBackupJob(db, deps.backupsDir));
  }

  // 10. 03:00 IST: Student Dropout-Risk Calculation
  if (forceJob === "student_risk_score" || (!forceJob && ist.hour === 3 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:risk:${Date.now()}` : `risk_score:${ist.dateStr}`;
    results.student_risk_score = await runTrackedJob(db, "student_risk_score", runKey, () => runStudentRiskCalculation(db, ist.dateStr));
  }

  // 11. Monday 08:00 IST: Weekly Executive Report
  if (forceJob === "weekly_monday" || (!forceJob && ist.weekday === "Monday" && ist.hour === 8 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:weekly:${Date.now()}` : `weekly_monday:${ist.dateStr}`;
    results.weekly_monday = await runTrackedJob(db, "weekly_monday", runKey, () => saveDailyReport(db, "weekly_monday", ist.dateStr));
  }

  // 12. 1st of month: Auto Monthly Fee Invoice Generation
  if (forceJob === "monthly_invoices" || (!forceJob && ist.day === 1 && ist.hour === 7 && ist.minute === 0 && Number(cfg.monthly_fee_auto_generate) === 1)) {
    const runKey = forceJob ? `manual:monthly_inv:${Date.now()}` : `monthly_invoices:${ist.monthStr}`;
    results.monthly_invoices = await runTrackedJob(db, "monthly_invoices", runKey, () =>
      generateMonthlyFeeInvoices(db, { billingMonth: ist.monthStr, dueDay: cfg.monthly_fee_due_day || 10 })
    );
  }

  // 13. 25th of month: Payroll Draft Generation
  if (forceJob === "payroll_draft" || (!forceJob && ist.day === Number(cfg.payroll_draft_day || 25) && ist.hour === 9 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:payroll:${Date.now()}` : `payroll_draft:${ist.monthStr}`;
    results.payroll_draft = await runTrackedJob(db, "payroll_draft", runKey, () => generateTeacherPayrollDrafts(db, ist.monthStr));
  }

  // 14. 28th of month: 45-Day Course Renewal Campaign
  if (forceJob === "course_renewal" || (!forceJob && ist.day === 28 && ist.hour === 10 && ist.minute === 0)) {
    const runKey = forceJob ? `manual:renewal:${Date.now()}` : `course_renewal:${ist.monthStr}`;
    results.course_renewal = await runTrackedJob(db, "course_renewal", runKey, () => {
      const cutoff = new Date(Date.now() + Number(cfg.renewal_campaign_days_before || 45) * 86400000).toISOString().slice(0, 10);
      const expiring = db
        .prepare(
          `SELECT e.id, e.student_id, e.expires_at, u.full_name, u.phone, u.email, c.title AS course_title
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           JOIN courses c ON c.id = e.course_id
           WHERE e.status = 'active' AND e.expires_at IS NOT NULL AND e.expires_at != '' AND substr(e.expires_at, 1, 10) <= ?`
        )
        .all(cutoff);
      for (const row of expiring) {
        emitSystemEvent(
          db,
          "course.ending",
          {
            studentId: row.student_id,
            studentName: row.full_name,
            phone: row.phone,
            email: row.email,
            courseTitle: row.course_title,
            template: "course_renewal"
          },
          { idempotencyKey: `renewal:${row.id}:${ist.monthStr}`, entityType: "enrollment", entityId: String(row.id) }
        );
      }
      return { eligible: expiring.length };
    });
  }

  // 15. Daily 10:30 IST: Weekly Cross-Sell Auto-Mail Dispatch (strictly respects Master Switch default OFF & max 1/week/student)
  if (forceJob === "v31_cross_sell_weekly" || (!forceJob && ist.hour === 10 && ist.minute === 30)) {
    const runKey = forceJob ? `manual:v31_cross_sell:${Date.now()}` : `v31_cross_sell:${ist.dateStr}`;
    results.v31_cross_sell_weekly = await runTrackedJob(db, "v31_cross_sell_weekly", runKey, () =>
      runCrossSellWeeklyDispatch(db, deps, { dryRun: false, nowDate: now })
    );
  }

  // 16. Hourly (:15 IST): Abandoned Cart Reminder Mail (1-2 hours after cart add, duplicate-protected)
  if (forceJob === "v32_abandoned_cart" || (!forceJob && ist.minute === 15)) {
    const runKey = forceJob ? `manual:v32_abandoned_cart:${Date.now()}` : `v32_abandoned_cart:${ist.dateStr}:${ist.hour}`;
    results.v32_abandoned_cart = await runTrackedJob(db, "v32_abandoned_cart", runKey, () => {
      const s = getV32Settings(db);
      return runAbandonedCartReminderSweep(db, deps, { nowDate: now, minAgeMinutes: Math.max(60, Number(s.abandonedCartHours || 1) * 60) });
    });
  }

  // 17. Daily 08:30 IST: Plan Expiry Renewal Auto-Reminder (v3.2 + v3.3 configurable [30,15,7,3,1] days)
  if (forceJob === "v32_plan_expiry_renewal" || forceJob === "v33_course_renewals" || (!forceJob && ist.hour === 8 && ist.minute === 30)) {
    const runKey = forceJob ? `manual:v32_plan_expiry:${Date.now()}` : `v32_plan_expiry:${ist.dateStr}`;
    results.v32_plan_expiry_renewal = await runTrackedJob(db, "v32_plan_expiry_renewal", runKey, async () => {
      const v32 = await runPlanExpiryRenewalSweep(db, deps, { nowDate: now });
      const v33 = await runCourseRenewalV33Sweep(db, deps, { now });
      return { v32, v33 };
    });
  }

  return { timezone: "Asia/Kolkata", ist, results };
}

let schedulerTimer = null;

export function startCentralCrmScheduler(db, deps = {}) {
  if (schedulerTimer || process.env.NODE_ENV === "test" || process.env.YUITOR_DISABLE_SCHEDULER === "1") return;
  // Single minute-level internal tick matching `* * * * *`
  schedulerTimer = setInterval(() => {
    runCentralSchedulerTick(db, deps).catch((err) => {
      console.error("[Yuitor CRM Scheduler Error]", err?.message || err);
    });
  }, 60 * 1000);
  if (typeof schedulerTimer.unref === "function") schedulerTimer.unref();
}
