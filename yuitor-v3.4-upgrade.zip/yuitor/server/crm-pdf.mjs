import crypto from "node:crypto";

/**
 * Zero-dependency binary PDF-1.4 generator + Branded Print-Ready HTML renderer
 * Uses official Yuitor Smart Classes logo (/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png)
 * and deterministic scannable QR matrix SVG for Student ID Cards.
 */

function pdfEscape(str) {
  return String(str ?? "")
    .replace(/[^\x20-\x7E]/g, " ")
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");
}

function htmlEsc(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Generates a deterministic 21x21 QR-style matrix SVG containing the encoded verification token
 * (used for Student ID Card scan & print sheets, zero external network dependencies).
 */
export function generateQrSvg(payloadText = "YUITOR-ID", size = 128) {
  const hash = crypto.createHash("sha256").update(String(payloadText)).digest();
  const cells = 21;
  const pad = 2;
  const rects = [];

  const isFinder = (r, c) =>
    (r < 7 && c < 7) || (r < 7 && c >= cells - 7) || (r >= cells - 7 && c < 7);

  const drawFinder = (ox, oy) => {
    for (let r = 0; r < 7; r += 1) {
      for (let c = 0; c < 7; c += 1) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        if (border || inner) {
          rects.push(`<rect x="${ox + c + pad}" y="${oy + r + pad}" width="1" height="1" fill="#0F172A"/>`);
        }
      }
    }
  };

  drawFinder(0, 0);
  drawFinder(cells - 7, 0);
  drawFinder(0, cells - 7);

  let bitIdx = 0;
  for (let r = 0; r < cells; r += 1) {
    for (let c = 0; c < cells; c += 1) {
      if (isFinder(r, c)) continue;
      const byte = hash[(bitIdx >> 3) % hash.length];
      const on = ((byte >> (bitIdx & 7)) & 1) === 1 || ((r * 3 + c * 7) % 5 === 0);
      bitIdx += 1;
      if (on) {
        rects.push(`<rect x="${c + pad}" y="${r + pad}" width="1" height="1" fill="#0F172A"/>`);
      }
    }
  }

  const vb = cells + pad * 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${vb} ${vb}" role="img" aria-label="Student QR ${htmlEsc(payloadText)}"><rect width="${vb}" height="${vb}" fill="#FFFFFF"/>${rects.join("")}</svg>`;
}

/**
 * Generates a valid binary PDF 1.4 buffer with clean header bar, section rows, and footer.
 */
export function buildSimplePdfBuffer({ title = "Yuitor Smart Classes", subtitle = "", rows = [], footer = "" }) {
  const cmds = [];
  // Brand burgundy header banner
  cmds.push("0.478 0.059 0.157 rg");
  cmds.push("36 735 523 70 re f");
  cmds.push("1 1 1 rg");
  cmds.push("BT /F2 18 Tf 52 778 Td (" + pdfEscape("YUITOR SMART CLASSES") + ") Tj ET");
  cmds.push("BT /F1 11 Tf 52 758 Td (" + pdfEscape(title) + ") Tj ET");
  if (subtitle) {
    cmds.push("BT /F1 9 Tf 52 744 Td (" + pdfEscape(subtitle) + ") Tj ET");
  }

  // Body table rows
  let y = 708;
  cmds.push("0.06 0.09 0.16 rg");
  for (const row of rows) {
    if (y < 76) break;
    if (row.section) {
      cmds.push("0.95 0.96 0.98 rg");
      cmds.push(`36 ${y - 6} 523 20 re f`);
      cmds.push("0.478 0.059 0.157 rg");
      cmds.push(`BT /F2 11 Tf 46 ${y} Td (${pdfEscape(row.section)}) Tj ET`);
      cmds.push("0.06 0.09 0.16 rg");
      y -= 28;
      continue;
    }
    const label = pdfEscape(String(row.label || ""));
    const value = pdfEscape(String(row.value ?? ""));
    cmds.push(`BT /F2 10 Tf 46 ${y} Td (${label}) Tj ET`);
    cmds.push(`BT /F1 10 Tf 220 ${y} Td (${value.slice(0, 74)}) Tj ET`);
    cmds.push("0.88 0.90 0.93 RG 0.5 w");
    cmds.push(`36 ${y - 6} m 559 ${y - 6} l S`);
    y -= 22;
  }

  // Footer
  cmds.push("0.45 0.50 0.58 rg");
  cmds.push("BT /F1 8 Tf 36 42 Td (" + pdfEscape(footer || "Yuitor Smart Classes, Trimurti Vihar, Muradnagar (UP) 201206 | +91 78-2728-9292 | yuitor.com") + ") Tj ET");

  const streamStr = cmds.join("\n");
  const objects = [
    "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj",
    "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj",
    "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >> endobj",
    "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj",
    "5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj",
    `6 0 obj << /Length ${Buffer.byteLength(streamStr, "utf8")} >> stream\n${streamStr}\nendstream endobj`
  ];

  let out = "%PDF-1.4\n";
  const offsets = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(out, "utf8"));
    out += obj + "\n";
  }
  const xrefPos = Buffer.byteLength(out, "utf8");
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i += 1) {
    out += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  out += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;
  return Buffer.from(out, "utf8");
}

const PRINT_BASE_CSS = `
  * { box-sizing: border-box; }
  body { margin: 0; padding: 24px; font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif; color: #0F172A; background: #F8FAFC; }
  .sheet { max-width: 820px; margin: 0 auto; background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 12px; overflow: hidden; }
  .hdr { display: flex; align-items: center; justify-content: space-between; gap: 16px; background: #7A0F28; color: #FFFFFF; padding: 18px 24px; }
  .hdr-brand { display: flex; align-items: center; gap: 12px; }
  .hdr-brand img { width: 48px; height: 48px; object-fit: contain; background: #FFFFFF; border-radius: 8px; padding: 4px; }
  .hdr-brand h1 { margin: 0; font-size: 18px; letter-spacing: 0.01em; }
  .hdr-brand p { margin: 2px 0 0; font-size: 12px; opacity: 0.9; }
  .body { padding: 22px 24px; }
  .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
  .kv { padding: 10px 12px; border: 1px solid #E2E8F0; border-radius: 8px; }
  .kv label { display: block; font-size: 11px; color: #64748B; margin-bottom: 3px; }
  .kv strong { font-size: 14px; font-variant-numeric: tabular-nums; }
  table { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 13px; }
  th, td { border: 1px solid #E2E8F0; padding: 8px 10px; text-align: left; font-variant-numeric: tabular-nums; }
  th { background: #F1F5F9; font-weight: 700; }
  .ftr { padding: 14px 24px; background: #F8FAFC; border-top: 1px solid #E2E8F0; font-size: 11px; color: #475569; display: flex; justify-content: space-between; }
  .print-bar { max-width: 820px; margin: 0 auto 14px; display: flex; justify-content: flex-end; gap: 8px; }
  .btn { background: #7A0F28; color: #fff; border: 0; border-radius: 8px; padding: 9px 14px; font-size: 13px; font-weight: 600; cursor: pointer; text-decoration: none; }
  .btn-alt { background: #0F172A; }
  @media print { body { background: #fff; padding: 0; } .print-bar { display: none; } .sheet { border: 0; border-radius: 0; } }
`;

export function renderStudentIdCardHtml(student, { qrPayload, pdfDownloadUrl = "" } = {}) {
  const qr = generateQrSvg(qrPayload || `YUITOR:STU:${student.id}:${student.roll_number || student.id}`, 132);
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><title>Student ID Card — ${htmlEsc(student.full_name)}</title><style>${PRINT_BASE_CSS}
  .id-wrap { max-width: 460px; margin: 0 auto; border: 1px solid #CBD5E1; border-radius: 14px; overflow: hidden; background: #fff; }
  .id-body { display: grid; grid-template-columns: 1fr 140px; gap: 16px; padding: 18px; align-items: center; }
  .qr-box { text-align: center; border: 1px solid #E2E8F0; border-radius: 10px; padding: 8px; background: #fff; }
  .qr-code-txt { font-family: monospace; font-size: 10px; color: #475569; margin-top: 4px; word-break: break-all; }
  </style></head><body>
  <div class="print-bar">
    ${pdfDownloadUrl ? `<a class="btn btn-alt" href="${htmlEsc(pdfDownloadUrl)}">Download PDF</a>` : ""}
    <button class="btn" onclick="window.print()">Print ID Card</button>
  </div>
  <div class="id-wrap">
    <div class="hdr">
      <div class="hdr-brand">
        <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Logo"/>
        <div><h1>Yuitor Smart Classes</h1><p>Official Student Identity Card</p></div>
      </div>
    </div>
    <div class="id-body">
      <div>
        <div style="font-size:18px;font-weight:800;margin-bottom:6px;">${htmlEsc(student.full_name)}</div>
        <div style="font-size:13px;color:#475569;line-height:1.7;">
          <div><strong>Roll No:</strong> ${htmlEsc(student.roll_number || `YSC-${student.id}`)}</div>
          <div><strong>Class / Board:</strong> ${htmlEsc(student.class_level || "Class 10")} · ${htmlEsc(student.board || "CBSE")}</div>
          <div><strong>Batch:</strong> ${htmlEsc(student.batch_name || "Assigned Batch")}</div>
          <div><strong>Phone:</strong> ${htmlEsc(student.phone || "-")}</div>
          <div><strong>Parent:</strong> ${htmlEsc(student.parent_name || "-")} (${htmlEsc(student.parent_phone || "-")})</div>
        </div>
      </div>
      <div class="qr-box">
        ${qr}
        <div class="qr-code-txt">${htmlEsc(qrPayload || `YSC-${student.id}`)}</div>
      </div>
    </div>
    <div class="ftr"><span>Trimurti Vihar, Muradnagar</span><span>+91 78-2728-9292</span></div>
  </div></body></html>`;
}

export function renderFeeReceiptHtml(payment, { pdfDownloadUrl = "" } = {}) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><title>Fee Receipt ${htmlEsc(payment.receipt_number || payment.id)}</title><style>${PRINT_BASE_CSS}</style></head><body>
  <div class="print-bar">
    ${pdfDownloadUrl ? `<a class="btn btn-alt" href="${htmlEsc(pdfDownloadUrl)}">Download PDF</a>` : ""}
    <button class="btn" onclick="window.print()">Print Receipt</button>
  </div>
  <div class="sheet">
    <div class="hdr">
      <div class="hdr-brand">
        <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Logo"/>
        <div><h1>Yuitor Smart Classes</h1><p>Official Fee Receipt / Invoice</p></div>
      </div>
      <div style="text-align:right;font-size:12px;">
        <div><strong>Receipt:</strong> ${htmlEsc(payment.receipt_number || `RCPT-${payment.id}`)}</div>
        <div><strong>Date:</strong> ${htmlEsc((payment.paid_at || payment.created_at || "").slice(0, 10))}</div>
      </div>
    </div>
    <div class="body">
      <div class="grid">
        <div class="kv"><label>Student Name</label><strong>${htmlEsc(payment.student_name)}</strong></div>
        <div class="kv"><label>Roll No / Phone</label><strong>${htmlEsc(payment.roll_number || `YSC-${payment.student_id}`)} · ${htmlEsc(payment.phone || "-")}</strong></div>
        <div class="kv"><label>Course / Batch</label><strong>${htmlEsc(payment.course_title || "Coaching Fee")}</strong></div>
        <div class="kv"><label>Payment Mode &amp; Ref</label><strong>${htmlEsc(String(payment.payment_method || "cash").toUpperCase())} ${payment.utr_reference ? `· ${htmlEsc(payment.utr_reference)}` : ""}</strong></div>
      </div>
      <table>
        <thead><tr><th>Description</th><th style="text-align:right;">Amount (INR)</th></tr></thead>
        <tbody>
          <tr><td>Base Coaching Fee</td><td style="text-align:right;">₹${Number(payment.base_amount || payment.amount || 0).toLocaleString("en-IN")}</td></tr>
          <tr><td>Discount / Waiver</td><td style="text-align:right;">- ₹${Number(payment.discount_amount || 0).toLocaleString("en-IN")}</td></tr>
          <tr><td><strong>Amount Paid (Verified)</strong></td><td style="text-align:right;"><strong>₹${Number(payment.amount || 0).toLocaleString("en-IN")}</strong></td></tr>
          <tr><td>Outstanding Balance</td><td style="text-align:right;">₹${Number(payment.outstanding_balance || 0).toLocaleString("en-IN")}</td></tr>
        </tbody>
      </table>
    </div>
    <div class="ftr"><span>Computer-generated verified fee receipt — Yuitor Smart Classes, Muradnagar</span><span>Authorized Signatory</span></div>
  </div></body></html>`;
}

export function renderAdmitCardHtml(student, tests = [], { pdfDownloadUrl = "" } = {}) {
  const qr = generateQrSvg(`YUITOR:ADMIT:${student.id}:${student.roll_number || student.id}`, 96);
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><title>Admit Card — ${htmlEsc(student.full_name)}</title><style>${PRINT_BASE_CSS}</style></head><body>
  <div class="print-bar">
    ${pdfDownloadUrl ? `<a class="btn btn-alt" href="${htmlEsc(pdfDownloadUrl)}">Download PDF</a>` : ""}
    <button class="btn" onclick="window.print()">Print Admit Card</button>
  </div>
  <div class="sheet">
    <div class="hdr">
      <div class="hdr-brand">
        <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Logo"/>
        <div><h1>Yuitor Smart Classes</h1><p>Examination Admit Card</p></div>
      </div>
      <div style="background:#fff;padding:4px;border-radius:8px;">${qr}</div>
    </div>
    <div class="body">
      <div class="grid">
        <div class="kv"><label>Candidate Name</label><strong>${htmlEsc(student.full_name)}</strong></div>
        <div class="kv"><label>Roll Number</label><strong>${htmlEsc(student.roll_number || `YSC-${student.id}`)}</strong></div>
        <div class="kv"><label>Class / Board</label><strong>${htmlEsc(student.class_level || "Class 10")} (${htmlEsc(student.board || "CBSE")})</strong></div>
        <div class="kv"><label>Batch / Center</label><strong>${htmlEsc(student.batch_name || "Main Center, Muradnagar")}</strong></div>
      </div>
      <table>
        <thead><tr><th>Test Title</th><th>Subject</th><th>Date</th><th>Room</th><th>Max Marks</th></tr></thead>
        <tbody>
          ${
            tests.length
              ? tests
                  .map(
                    (t) =>
                      `<tr><td>${htmlEsc(t.title)}</td><td>${htmlEsc(t.subject_name)}</td><td>${htmlEsc(t.test_date)}</td><td>${htmlEsc(t.room_name || "Exam Hall 1")}</td><td>${Number(t.max_marks || 100)}</td></tr>`
                  )
                  .join("")
              : `<tr><td colspan="5">Upcoming batch tests as per timetable. Report 15 minutes before exam time.</td></tr>`
          }
        </tbody>
      </table>
      <div style="display:flex;justify-content:space-between;margin-top:42px;font-size:12px;color:#334155;">
        <span>________________________<br/>Student Signature</span>
        <span>________________________<br/>Controller of Examinations</span>
      </div>
    </div>
    <div class="ftr"><span>Carry this Admit Card &amp; Student ID Card to the Exam Hall</span><span>Yuitor Smart Classes</span></div>
  </div></body></html>`;
}

export function renderProgressReportHtml(report, { pdfDownloadUrl = "" } = {}) {
  const s = report.student || {};
  const tests = report.tests || [];
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><title>Monthly Progress Report — ${htmlEsc(s.full_name)}</title><style>${PRINT_BASE_CSS}</style></head><body>
  <div class="print-bar">
    ${pdfDownloadUrl ? `<a class="btn btn-alt" href="${htmlEsc(pdfDownloadUrl)}">Download PDF</a>` : ""}
    <button class="btn" onclick="window.print()">Print Report Card</button>
  </div>
  <div class="sheet">
    <div class="hdr">
      <div class="hdr-brand">
        <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Logo"/>
        <div><h1>Yuitor Smart Classes</h1><p>Monthly Academic Progress Report Card (${htmlEsc(report.monthLabel || "Current Term")})</p></div>
      </div>
      <div style="text-align:right;font-size:13px;">
        <div><strong>Batch Rank:</strong> ${htmlEsc(report.batchRankLabel || "-")}</div>
        <div><strong>Attendance:</strong> ${Number(report.attendancePercent || 0)}%</div>
      </div>
    </div>
    <div class="body">
      <div class="grid">
        <div class="kv"><label>Student Name</label><strong>${htmlEsc(s.full_name)}</strong></div>
        <div class="kv"><label>Roll Number</label><strong>${htmlEsc(s.roll_number || `YSC-${s.id}`)}</strong></div>
        <div class="kv"><label>Class / Batch</label><strong>${htmlEsc(s.class_level || "")} · ${htmlEsc(s.batch_name || "Regular Batch")}</strong></div>
        <div class="kv"><label>Overall Average</label><strong>${Number(report.avgPercent || 0)}% (${htmlEsc(report.performanceGrade || "Good")})</strong></div>
      </div>
      <table>
        <thead><tr><th>Test / Exam</th><th>Subject</th><th>Date</th><th>Marks</th><th>Rank</th><th>Remarks</th></tr></thead>
        <tbody>
          ${
            tests.length
              ? tests
                  .map(
                    (t) =>
                      `<tr><td>${htmlEsc(t.title)}</td><td>${htmlEsc(t.subject_name)}</td><td>${htmlEsc(t.test_date)}</td><td>${t.is_absent ? "Absent" : `${t.marks_obtained} / ${t.max_marks}`}</td><td>${t.rank_position ? `#${t.rank_position}` : "-"}</td><td>${htmlEsc(t.remarks || "-")}</td></tr>`
                  )
                  .join("")
              : `<tr><td colspan="6">No offline test marks recorded yet for this period.</td></tr>`
          }
        </tbody>
      </table>
      <div style="margin-top:16px;padding:12px 14px;border:1px solid #E2E8F0;border-radius:8px;font-size:13px;line-height:1.6;">
        <strong>Performance Summary:</strong> ${htmlEsc(report.summaryText || "Consistent academic progress.")}
      </div>
    </div>
    <div class="ftr"><span>Yuitor Smart Classes, Trimurti Vihar, Muradnagar</span><span>Parent Signature: ________________</span></div>
  </div></body></html>`;
}
