import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import {
  BILLING_CYCLES,
  CLASS_FEE_PLANS,
  calculateClassFeePlan,
  parseClassNumberFromLabel,
} from "./fee-plans.mjs";
import { buildSpreadsheetXml, rowsToCsv } from "./referral-math.mjs";
import {
  escapeHtml,
  getAppBaseUrl,
  getIstDateKey,
  getIstTimestamp,
  logV31Audit,
  sendV31Mail,
} from "./v31-engine.mjs";
import { generateQrSvg, buildSimplePdfBuffer } from "./crm-pdf.mjs";

export const MAX_SHREYA_UPLOAD_BYTES = 5 * 1024 * 1024; // Strictly 5 MB
export const ALLOWED_SHREYA_MIMES = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "application/pdf",
]);
export const ALLOWED_SHREYA_EXTS = new Set([".jpg", ".jpeg", ".png", ".webp", ".pdf"]);

function safeAddColumn(db, table, colDef) {
  try {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${colDef}`);
  } catch {
    // Column already exists
  }
}

export function ensureV32Schema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS v32_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      combo_discount_enabled INTEGER NOT NULL DEFAULT 1,
      combo_discount_percent INTEGER NOT NULL DEFAULT 10,
      guest_daily_ai_questions INTEGER NOT NULL DEFAULT 5,
      guest_daily_ai_uploads INTEGER NOT NULL DEFAULT 2,
      student_daily_ai_questions INTEGER NOT NULL DEFAULT 30,
      student_daily_ai_uploads INTEGER NOT NULL DEFAULT 10,
      abandoned_cart_hours INTEGER NOT NULL DEFAULT 1,
      updated_by INTEGER,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS ai_daily_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_key TEXT NOT NULL,
      usage_date_ist TEXT NOT NULL,
      question_count INTEGER NOT NULL DEFAULT 0,
      upload_count INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(subject_key, usage_date_ist)
    );
    CREATE INDEX IF NOT EXISTS idx_ai_daily_usage_key_date ON ai_daily_usage(subject_key, usage_date_ist);

    CREATE TABLE IF NOT EXISTS v32_reminder_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dedupe_key TEXT UNIQUE NOT NULL,
      reminder_type TEXT NOT NULL,
      user_id INTEGER,
      email TEXT DEFAULT '',
      details_json TEXT DEFAULT '{}',
      sent_at_ist TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS v32_certificates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      certificate_code TEXT UNIQUE NOT NULL,
      student_id INTEGER,
      student_name TEXT NOT NULL,
      class_label TEXT DEFAULT '',
      course_title TEXT DEFAULT '',
      cert_type TEXT NOT NULL DEFAULT 'completion',
      rank_or_score TEXT DEFAULT '',
      issued_date_ist TEXT NOT NULL,
      issued_by INTEGER,
      is_valid INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  db.prepare(`
    INSERT OR IGNORE INTO v32_settings
      (id, combo_discount_enabled, combo_discount_percent, guest_daily_ai_questions, guest_daily_ai_uploads, student_daily_ai_questions, student_daily_ai_uploads, abandoned_cart_hours)
    VALUES (1, 1, 10, 5, 2, 30, 10, 1)
  `).run();

  // Additive upgrades on existing tables (zero destructive changes)
  safeAddColumn(db, "cart_items", "subject_label TEXT DEFAULT ''");
  safeAddColumn(db, "cart_items", "reminder_sent_at TEXT DEFAULT ''");
  safeAddColumn(db, "announcements", "target_class TEXT DEFAULT 'all'");
  safeAddColumn(db, "crm_study_materials", "is_free_sample INTEGER NOT NULL DEFAULT 0");
  safeAddColumn(db, "crm_study_materials", "class_number INTEGER");
  safeAddColumn(db, "crm_doubts", "ai_hint_text TEXT DEFAULT ''");
  safeAddColumn(db, "crm_doubts", "teacher_verified INTEGER NOT NULL DEFAULT 0");
  safeAddColumn(db, "fee_installments", "receipt_number TEXT DEFAULT ''");
  safeAddColumn(db, "fee_installments", "paid_at TEXT DEFAULT ''");

  // Seed v3.2 email templates into existing v31_mail_templates table
  const v32Templates = [
    {
      template_key: "abandoned_cart_reminder",
      name: "Abandoned Cart Reminder (Direct Checkout Link)",
      audience: "student",
      category: "transactional",
      theme_key: "yuitor_navy",
      subject: "Complete Your Yuitor Enrollment — Seats Filling Fast!",
      body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>You left <strong>{{course}}</strong> in your Yuitor Smart Classes cart. Complete your fee payment to lock your seat and activate instant portal access.</p>
<p><strong>Cart Payable:</strong> {{total_fee}}</p>
<p style="margin:20px 0;"><a href="{{login_link}}" style="display:inline-block;background:#7A0F28;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:700;">Complete Checkout Now</a></p>
<p>Need help? Call/WhatsApp +91 78-2728-9292.<br/><strong>Yuitor Admissions Desk</strong></p>`,
    },
    {
      template_key: "payment_receipt_batch_slip",
      name: "Official Fee Receipt & Assigned Batch Slip",
      audience: "student",
      category: "transactional",
      theme_key: "yuitor_emerald",
      subject: "Fee Receipt {{note}} & Batch Slip — Yuitor Smart Classes",
      body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>Your payment has been <strong>verified</strong> and your Student Account + Course Access are now <strong>ACTIVE</strong>!</p>
<table style="width:100%;border-collapse:collapse;margin:14px 0;background:#F8FAFC;border:1px solid #E2E8F0;">
  <tr><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;"><strong>Receipt Number</strong></td><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;">{{note}}</td></tr>
  <tr><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;"><strong>Course(s) &amp; Plan</strong></td><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;">{{course}}</td></tr>
  <tr><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;"><strong>Amount Paid</strong></td><td style="padding:9px 12px;border-bottom:1px solid #E2E8F0;"><strong>{{paid_fee}}</strong></td></tr>
  <tr><td style="padding:9px 12px;"><strong>Assigned Batch &amp; Teacher</strong></td><td style="padding:9px 12px;">{{reason}}</td></tr>
</table>
<p style="margin:20px 0;"><a href="{{login_link}}" style="display:inline-block;background:#16A34A;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:700;">Open Student Portal &amp; Download Receipt</a></p>
<p>Warm regards,<br/><strong>Yuitor Accounts &amp; Academics</strong></p>`,
    },
    {
      template_key: "plan_expiry_renewal",
      name: "Plan Expiry & Renewal Reminder (7d / 2d)",
      audience: "student",
      category: "transactional",
      theme_key: "yuitor_violet",
      subject: "Action Needed: Your Yuitor Plan Expires in {{note}} — Renew in 1 Click",
      body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>Your coaching plan for <strong>{{course}}</strong> expires on <strong>{{reason}}</strong> ({{note}} remaining).</p>
<p>Renew today for uninterrupted classes, notes, MCQ tests, and doubt support (save 10% automatically on the 12-Month Yearly plan!).</p>
<p style="margin:20px 0;"><a href="{{login_link}}" style="display:inline-block;background:#7A0F28;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:700;">Pay Now &amp; Renew</a></p>
<p>Warm regards,<br/><strong>Yuitor Smart Classes</strong></p>`,
    },
  ];
  try {
    const insTpl = db.prepare(`
      INSERT OR IGNORE INTO v31_mail_templates
        (template_key, name, audience, category, theme_key, subject, body_html)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const t of v32Templates) {
      insTpl.run(t.template_key, t.name, t.audience, t.category, t.theme_key, t.subject, t.body_html);
    }
  } catch {
    // v31_mail_templates may not exist in isolated minimal test DB
  }

  // Zero-data-loss upgrade for legacy v3.1 databases whose cart_items.plan has CHECK (plan IN ('monthly', 'yearly'))
  try {
    const tbl = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='cart_items'").get();
    if (tbl?.sql && /plan\s+IN\s*\(\s*'monthly'\s*,\s*'yearly'\s*\)/i.test(tbl.sql)) {
      db.exec(`
        PRAGMA foreign_keys = OFF;
        BEGIN IMMEDIATE;
        CREATE TABLE cart_items_v32_tmp (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
          guest_token TEXT NOT NULL DEFAULT '',
          course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
          batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
          plan TEXT NOT NULL DEFAULT '1m' CHECK (plan IN ('monthly', '1m', '3m', '6m', '9m', 'yearly')),
          subject_label TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        INSERT INTO cart_items_v32_tmp (id, user_id, guest_token, course_id, batch_id, plan, created_at, updated_at)
        SELECT id, user_id, guest_token, course_id, batch_id, plan, created_at, updated_at FROM cart_items;
        DROP TABLE cart_items;
        ALTER TABLE cart_items_v32_tmp RENAME TO cart_items;
        CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);
        CREATE INDEX IF NOT EXISTS idx_cart_guest ON cart_items(guest_token);
        COMMIT;
        PRAGMA foreign_keys = ON;
      `);
    }
  } catch {
    try { db.exec("ROLLBACK; PRAGMA foreign_keys = ON;"); } catch { /* ignore */ }
  }
}

export function getV32Settings(db) {
  try {
    const row = db.prepare("SELECT * FROM v32_settings WHERE id = 1").get();
    if (row) {
      return {
        comboDiscountEnabled: Number(row.combo_discount_enabled ?? 1) === 1,
        comboDiscountPercent: Number(row.combo_discount_percent ?? 10),
        guestDailyAiQuestions: Number(row.guest_daily_ai_questions ?? 5),
        guestDailyAiUploads: Number(row.guest_daily_ai_uploads ?? 2),
        studentDailyAiQuestions: Number(row.student_daily_ai_questions ?? 30),
        studentDailyAiUploads: Number(row.student_daily_ai_uploads ?? 10),
        abandonedCartHours: Number(row.abandoned_cart_hours ?? 1),
        updatedAt: row.updated_at || "",
      };
    }
  } catch {
    // fallback defaults
  }
  return {
    comboDiscountEnabled: true,
    comboDiscountPercent: 10,
    guestDailyAiQuestions: 5,
    guestDailyAiUploads: 2,
    studentDailyAiQuestions: 30,
    studentDailyAiUploads: 10,
    abandonedCartHours: 1,
    updatedAt: "",
  };
}

export function updateV32Settings(db, patch = {}, actorId = null) {
  const cur = getV32Settings(db);
  const comboEnabled = patch.comboDiscountEnabled !== undefined ? (patch.comboDiscountEnabled ? 1 : 0) : (cur.comboDiscountEnabled ? 1 : 0);
  const comboPercent = patch.comboDiscountPercent !== undefined ? Math.min(50, Math.max(0, Math.round(Number(patch.comboDiscountPercent) || 0))) : cur.comboDiscountPercent;
  const guestQ = patch.guestDailyAiQuestions !== undefined ? Math.min(50, Math.max(1, Math.round(Number(patch.guestDailyAiQuestions) || 5))) : cur.guestDailyAiQuestions;
  const guestU = patch.guestDailyAiUploads !== undefined ? Math.min(20, Math.max(0, Math.round(Number(patch.guestDailyAiUploads) || 2))) : cur.guestDailyAiUploads;
  const stuQ = patch.studentDailyAiQuestions !== undefined ? Math.min(500, Math.max(5, Math.round(Number(patch.studentDailyAiQuestions) || 30))) : cur.studentDailyAiQuestions;
  const stuU = patch.studentDailyAiUploads !== undefined ? Math.min(100, Math.max(1, Math.round(Number(patch.studentDailyAiUploads) || 10))) : cur.studentDailyAiUploads;
  const cartHrs = patch.abandonedCartHours !== undefined ? Math.min(24, Math.max(1, Math.round(Number(patch.abandonedCartHours) || 1))) : cur.abandonedCartHours;

  db.prepare(`
    UPDATE v32_settings
    SET combo_discount_enabled = ?, combo_discount_percent = ?,
        guest_daily_ai_questions = ?, guest_daily_ai_uploads = ?,
        student_daily_ai_questions = ?, student_daily_ai_uploads = ?,
        abandoned_cart_hours = ?, updated_by = ?, updated_at = datetime('now')
    WHERE id = 1
  `).run(comboEnabled, comboPercent, guestQ, guestU, stuQ, stuU, cartHrs, actorId ?? null);

  return getV32Settings(db);
}

/**
 * Syncs individual Class 6th–12th courses & batches cleanly without deleting any existing records.
 * Deactivates old grouped 6-8 / 9-10 / 11-12 placeholder courses from catalog while keeping historical enrollments safe.
 */
export function syncIndividualClassCoursesAndBatches(db) {
  const now = new Date().toISOString();
  const branch = db.prepare("SELECT id FROM branches ORDER BY id ASC LIMIT 1").get();
  const teacher = db.prepare("SELECT id FROM users WHERE role = 'teacher' ORDER BY id ASC LIMIT 1").get();

  const classDescriptions = {
    6: "Class 6th Foundation — Maths, Science, English & SST with weekly tests and doubt clearing.",
    7: "Class 7th Strong Concept Builder — NCERT Maths, Science, English & Olympiad foundation.",
    8: "Class 8th Pre-Board Foundation — Maths, Science, Grammar & chapter-wise practice tests.",
    9: "Class 9th Board Prep — Complete NCERT + Exemplar Maths, Science, English & Sunday tests.",
    10: "Class 10th Board Mastery — Full Board Syllabus, PYQs, Sample Papers & Weekly Rank Tests.",
    11: "Class 11th Science & Commerce — Physics, Chemistry, Maths/Bio, Accountancy & Economics.",
    12: "Class 12th Board + CUET Mastery — Intensive Board Revision, Numericals, PYQs & Mock Series.",
  };

  const classThumbs = {
    6: "/assets/images/teacher-led-class.webp",
    7: "/assets/images/teacher-small-group.webp",
    8: "/assets/images/student-books.webp",
    9: "/assets/images/math-board.webp",
    10: "/assets/images/teacher-classroom-guidance.webp",
    11: "/assets/images/science-lab.webp",
    12: "/assets/images/exam-writing.webp",
  };

  const timings = [
    ["15:30", "16:45", "Room 101"],
    ["16:00", "17:15", "Room 102"],
    ["16:30", "17:45", "Room 103"],
    ["17:00", "18:15", "Room 104"],
    ["17:30", "18:45", "Room 105"],
    ["18:00", "19:30", "Room 106"],
    ["18:30", "20:00", "Room 107"],
  ];

  // Hide legacy combined range courses from active storefront (data stays preserved!)
  try {
    db.prepare(`
      UPDATE courses
      SET is_active = 0
      WHERE slug IN ('class-6-8-foundation', 'class-9-10-board-mastery', 'class-11-12-board-stream')
    `).run();
  } catch {
    // ignore
  }

  for (let i = 0; i < CLASS_FEE_PLANS.length; i += 1) {
    const plan = CLASS_FEE_PLANS[i];
    const slug = `class-${plan.classNumber}-coaching`;
    const title = `${plan.classLabel} Coaching`;
    const existing = db.prepare("SELECT id FROM courses WHERE slug = ? OR slug = ? LIMIT 1").get(slug, `class-${plan.classNumber}`);
    let courseId = existing?.id ? Number(existing.id) : null;

    if (courseId) {
      db.prepare(`
        UPDATE courses
        SET title = ?, category = ?, class_range = ?, monthly_fee = ?, yearly_fee = ?, is_active = 1
        WHERE id = ?
      `).run(title, plan.classLabel, plan.classLabel, plan.monthly, plan.yearlyTotal, courseId);
    } else {
      const ins = db.prepare(`
        INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, thumbnail_url, is_active, created_at)
        VALUES (?, ?, ?, ?, 'CBSE / UP Board / ICSE', ?, 12, ?, ?, ?, 1, ?)
      `).run(
        title,
        slug,
        plan.classLabel,
        plan.classLabel,
        classDescriptions[plan.classNumber],
        plan.monthly,
        plan.yearlyTotal,
        classThumbs[plan.classNumber],
        now
      );
      courseId = Number(ins.lastInsertRowid);
    }

    // Ensure at least 1 active individual batch exists for each class (6th–12th)
    const batchCode = `CLS-${plan.classNumber}-REG`;
    const existingBatch = db.prepare("SELECT id FROM batches WHERE code = ? OR (course_id = ? AND is_active = 1) LIMIT 1").get(batchCode, courseId);
    if (!existingBatch) {
      const [st, et, room] = timings[i];
      try {
        db.prepare(`
          INSERT INTO batches (course_id, branch_id, teacher_id, name, code, room_name, seat_limit, total_seats, class_name, schedule_days, start_time, end_time, start_date, duration, is_active, created_at)
          VALUES (?, ?, ?, ?, ?, ?, 30, 30, ?, 'Mon-Sat', ?, ?, ?, '12 Months', 1, ?)
        `).run(
          courseId,
          branch?.id || null,
          teacher?.id || null,
          `${plan.classLabel} Regular Batch`,
          batchCode,
          room,
          plan.classLabel,
          st,
          et,
          getIstDateKey(),
          now
        );
      } catch {
        // fallback if optional columns differ
        try {
          db.prepare(`
            INSERT INTO batches (course_id, branch_id, teacher_id, name, code, room_name, seat_limit, schedule_days, start_time, end_time, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 30, 'Mon-Sat', ?, ?, 1, ?)
          `).run(courseId, branch?.id || null, teacher?.id || null, `${plan.classLabel} Regular Batch`, batchCode, room, st, et, now);
        } catch {
          // ignore
        }
      }
    } else {
      try {
        db.prepare("UPDATE batches SET class_name = ? WHERE id = ? AND COALESCE(class_name, '') = ''").run(plan.classLabel, existingBatch.id);
      } catch {
        // ignore
      }
    }

    // Seed 1 Free Sample PDF + 1 Enrolled-Only Full Notes entry per class in existing crm_study_materials (only if empty for that class)
    try {
      const matCount = Number(
        db.prepare("SELECT COUNT(*) AS c FROM crm_study_materials WHERE course_id = ? AND is_active = 1").get(courseId)?.c || 0
      );
      if (matCount === 0) {
        db.prepare(`
          INSERT INTO crm_study_materials (course_id, subject_name, chapter_name, material_type, title, description, file_url, file_name, is_free_sample, class_number, is_active, created_at)
          VALUES (?, 'Mathematics', 'Chapter 1 · Quick Formula Sheet', 'notes', ?, ?, ?, ?, 1, ?, 1, ?)
        `).run(
          courseId,
          `${plan.classLabel} Free Sample — Maths Formula Sheet & PYQ`,
          `Free public sample PDF for ${plan.classLabel} students covering key concepts and 10 important board questions.`,
          `/api/public/study-library/sample-pdf/${plan.classNumber}`,
          `yuitor-class-${plan.classNumber}-sample-notes.pdf`,
          plan.classNumber,
          now
        );
        db.prepare(`
          INSERT INTO crm_study_materials (course_id, subject_name, chapter_name, material_type, title, description, file_url, file_name, is_free_sample, class_number, is_active, created_at)
          VALUES (?, 'Science & Maths', 'Full Syllabus Chapter-Wise Notes + 5-Year PYQs', 'pyq', ?, ?, ?, ?, 0, ?, 1, ?)
        `).run(
          courseId,
          `${plan.classLabel} Complete Chapter Notes & Solved PYQ Bank`,
          `Unlocked exclusively for active enrolled ${plan.classLabel} students inside Student Portal.`,
          `/api/student/study-library/pdf/${plan.classNumber}`,
          `yuitor-class-${plan.classNumber}-full-notes.pdf`,
          plan.classNumber,
          now
        );
      }
    } catch {
      // crm_study_materials optional in minimal tests
    }
  }
}

/**
 * Buffer-based magic-byte & MIME validator for Shreya / Hybrid Doubt uploads (strictly <= 5 MB).
 * Accepts ONLY genuine JPG, PNG, WebP, or PDF. Blocks executables, scripts, spoofed headers, and >5 MB files.
 */
export function validateMediaUploadBuffer(buf, originalName = "", mimeType = "", maxBytes = MAX_SHREYA_UPLOAD_BYTES) {
  if (!Buffer.isBuffer(buf) || buf.length === 0) {
    return { ok: false, error: "Uploaded file is empty." };
  }
  if (buf.length > maxBytes) {
    return { ok: false, error: `File exceeds the strict ${Math.round(maxBytes / (1024 * 1024))} MB limit.` };
  }

  const cleanName = path.basename(String(originalName || "").trim());
  const parts = cleanName.split(".");
  if (parts.length > 2) {
    const forbiddenMiddle = parts.slice(1, -1).some((p) => /^(php|phtml|js|mjs|cjs|sh|bat|exe|dll|svg|html|htm)$/i.test(p));
    if (forbiddenMiddle) {
      return { ok: false, error: "Double-extension or executable filename blocked." };
    }
  }
  const ext = path.extname(cleanName).toLowerCase();
  if (ext && !ALLOWED_SHREYA_EXTS.has(ext)) {
    return { ok: false, error: "Only JPG, PNG, WebP, and PDF files are allowed." };
  }
  const normalizedMime = String(mimeType || "").toLowerCase().trim();
  if (normalizedMime && !ALLOWED_SHREYA_MIMES.has(normalizedMime)) {
    return { ok: false, error: "Unsupported MIME type. Allowed: JPG, PNG, WebP, PDF." };
  }

  // Block executable / HTML / SVG payloads
  const headAscii = buf.subarray(0, Math.min(buf.length, 512)).toString("latin1");
  if (
    (buf[0] === 0x4d && buf[1] === 0x5a) || // MZ (Windows PE)
    (buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46) || // ELF
    /^#!\s*\//.test(headAscii) ||
    /<\s*(?:script|svg|html|!doctype|iframe)/i.test(headAscii)
  ) {
    return { ok: false, error: "Unsafe or executable file payload rejected." };
  }

  const isJpeg = buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isPng =
    buf.length >= 8 &&
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a;
  const isWebp =
    buf.length >= 12 &&
    buf.subarray(0, 4).toString("ascii") === "RIFF" &&
    buf.subarray(8, 12).toString("ascii") === "WEBP";
  const isPdf = buf.length >= 5 && buf.subarray(0, 5).toString("ascii") === "%PDF-";

  let detectedMime = "";
  let detectedExt = "";
  if (isJpeg) {
    detectedMime = "image/jpeg";
    detectedExt = ".jpg";
  } else if (isPng) {
    detectedMime = "image/png";
    detectedExt = ".png";
  } else if (isWebp) {
    detectedMime = "image/webp";
    detectedExt = ".webp";
  } else if (isPdf) {
    detectedMime = "application/pdf";
    detectedExt = ".pdf";
  } else {
    return { ok: false, error: "Invalid file signature. Upload a genuine JPG, PNG, WebP image or PDF." };
  }

  // Cross-check extension vs detected magic bytes to block spoofed extensions
  if (ext) {
    const extMatches =
      (detectedExt === ".jpg" && (ext === ".jpg" || ext === ".jpeg")) ||
      (detectedExt === ext);
    if (!extMatches) {
      return { ok: false, error: `File signature (${detectedExt}) does not match extension (${ext}).` };
    }
  }

  return { ok: true, mimeType: detectedMime, ext: detectedExt, sizeBytes: buf.length };
}

/**
 * Daily AI Question & Upload Rate Limiter (API Cost Control).
 * Guests: max 5 questions/day & 2 uploads/day (default, configurable).
 * Active Enrolled Students: higher configurable limit (default 30 questions/day & 10 uploads/day).
 */
export function checkAndConsumeAiDailyQuota(db, { user = null, visitorKey = "", isUpload = false, consume = true, dateIst = getIstDateKey() } = {}) {
  const settings = getV32Settings(db);
  const isActiveStudent = Boolean(
    user &&
    user.role === "student" &&
    Number(user.is_active) === 1 &&
    String(user.verification_status || "").toLowerCase() === "approved" &&
    (() => {
      try {
        const enr = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND status IN ('active', 'completed') LIMIT 1").get(user.id);
        return Boolean(enr);
      } catch {
        return false;
      }
    })()
  );
  const isPrivileged = Boolean(user && (user.role === "admin" || user.role === "super_admin" || user.role === "teacher"));

  const maxQuestions = isPrivileged ? 200 : isActiveStudent ? settings.studentDailyAiQuestions : settings.guestDailyAiQuestions;
  const maxUploads = isPrivileged ? 100 : isActiveStudent ? settings.studentDailyAiUploads : settings.guestDailyAiUploads;
  const subjectKey = user?.id ? `user:${user.id}` : `guest:${String(visitorKey || "anon").slice(0, 80)}`;

  db.prepare(`
    INSERT OR IGNORE INTO ai_daily_usage (subject_key, usage_date_ist, question_count, upload_count)
    VALUES (?, ?, 0, 0)
  `).run(subjectKey, dateIst);

  const row = db.prepare(`
    SELECT question_count, upload_count FROM ai_daily_usage WHERE subject_key = ? AND usage_date_ist = ?
  `).get(subjectKey, dateIst) || { question_count: 0, upload_count: 0 };

  const usedQuestions = Number(row.question_count || 0);
  const usedUploads = Number(row.upload_count || 0);

  if (usedQuestions >= maxQuestions) {
    return {
      allowed: false,
      tier: isActiveStudent ? "active_student" : isPrivileged ? "staff" : "guest",
      reason: "question_limit",
      error: isActiveStudent
        ? `Daily AI question limit (${maxQuestions}/day) reached. Resets tomorrow (IST).`
        : `Guest daily limit (${maxQuestions} questions/day) reached. Enroll or sign in as an active student for ${settings.studentDailyAiQuestions} questions/day!`,
      usedQuestions,
      maxQuestions,
      usedUploads,
      maxUploads,
    };
  }

  if (isUpload && usedUploads >= maxUploads) {
    return {
      allowed: false,
      tier: isActiveStudent ? "active_student" : isPrivileged ? "staff" : "guest",
      reason: "upload_limit",
      error: isActiveStudent
        ? `Daily question photo/PDF upload limit (${maxUploads}/day) reached. Resets tomorrow (IST).`
        : `Guest daily upload limit (${maxUploads} files/day) reached. Sign in as an active enrolled student for ${settings.studentDailyAiUploads} uploads/day!`,
      usedQuestions,
      maxQuestions,
      usedUploads,
      maxUploads,
    };
  }

  if (consume) {
    db.prepare(`
      UPDATE ai_daily_usage
      SET question_count = question_count + 1,
          upload_count = upload_count + ?,
          updated_at = datetime('now')
      WHERE subject_key = ? AND usage_date_ist = ?
    `).run(isUpload ? 1 : 0, subjectKey, dateIst);
  }

  return {
    allowed: true,
    tier: isActiveStudent ? "active_student" : isPrivileged ? "staff" : "guest",
    usedQuestions: usedQuestions + (consume ? 1 : 0),
    maxQuestions,
    usedUploads: usedUploads + (consume && isUpload ? 1 : 0),
    maxUploads,
    remainingQuestions: Math.max(0, maxQuestions - (usedQuestions + (consume ? 1 : 0))),
    remainingUploads: Math.max(0, maxUploads - (usedUploads + (consume && isUpload ? 1 : 0))),
  };
}

/**
 * Auto-Activates a Student Account + Selected Course/Batch Enrollment upon Backend-Verified Payment
 * (Razorpay signature/webhook verified OR Admin backend payment verified) and issues Receipt + Batch Slip.
 */
export async function activateStudentOnVerifiedPayment(db, deps = {}, { studentId, paymentIds = [], orderCode = "", receiptNumber = "", totalAmount = 0, courseTitles = [] } = {}) {
  const sid = Number(studentId);
  if (!sid) return { activated: false };

  const user = db.prepare("SELECT * FROM users WHERE id = ? LIMIT 1").get(sid);
  if (!user) return { activated: false };

  const now = new Date().toISOString();

  // Auto-activate student account if still pending (never reactivate explicitly suspended/terminated accounts)
  const curStatus = String(user.verification_status || "").toLowerCase();
  let accountActivatedNow = false;
  if (user.role === "student" && !["suspended", "terminated", "deleted"].includes(curStatus)) {
    if (curStatus !== "approved" || Number(user.is_active) !== 1) {
      db.prepare(`
        UPDATE users
        SET is_active = 1, verification_status = 'approved', mobile_verified = 1, updated_at = ?
        WHERE id = ?
      `).run(now, sid);
      accountActivatedNow = true;
    }
  }

  // Ensure all enrollments tied to these verified paymentIds are ACTIVE and have an assigned batch if available
  const batchSlips = [];
  for (const pid of paymentIds) {
    const pay = db.prepare(`
      SELECT p.*, c.title AS course_title
      FROM payments p
      LEFT JOIN courses c ON c.id = p.course_id
      WHERE p.id = ? LIMIT 1
    `).get(Number(pid));
    if (!pay) continue;

    let enr = pay.enrollment_id
      ? db.prepare("SELECT * FROM enrollments WHERE id = ? LIMIT 1").get(pay.enrollment_id)
      : db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ? LIMIT 1").get(sid, pay.course_id);

    let batchId = enr?.batch_id || null;
    if (!batchId && pay.course_id) {
      const autoBatch = db.prepare(`
        SELECT b.id FROM batches b
        WHERE b.course_id = ? AND b.is_active = 1
        ORDER BY b.id ASC LIMIT 1
      `).get(pay.course_id);
      if (autoBatch) batchId = Number(autoBatch.id);
    }

    if (enr) {
      try {
        db.prepare("UPDATE enrollments SET status = 'active', batch_id = COALESCE(batch_id, ?) WHERE id = ?").run(batchId, enr.id);
      } catch {
        db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(enr.id);
      }
    }

    // Fetch batch + teacher details for Batch Slip
    const batchRow = batchId
      ? db.prepare(`
          SELECT b.name, b.schedule_days, b.start_time, b.end_time, b.room_name, u.full_name AS teacher_name
          FROM batches b LEFT JOIN users u ON u.id = b.teacher_id
          WHERE b.id = ? LIMIT 1
        `).get(batchId)
      : null;

    batchSlips.push({
      paymentId: pay.id,
      receiptNumber: pay.receipt_number || receiptNumber,
      courseTitle: pay.course_title || "Yuitor Course",
      plan: pay.plan || "1m",
      amount: Number(pay.amount || 0),
      batchName: batchRow?.name || "Regular Batch (Assigned)",
      timing: batchRow ? `${batchRow.schedule_days || "Mon-Sat"} · ${batchRow.start_time || "16:00"}–${batchRow.end_time || "17:30"} IST` : "Mon–Sat · Evening Batch",
      roomName: batchRow?.room_name || "Muradnagar Campus",
      teacherName: batchRow?.teacher_name || "Yuitor Senior Faculty",
    });
  }

  // In-app notification with Receipt + Batch Slip
  const slipSummary = batchSlips
    .map((s) => `${s.courseTitle}: ${s.batchName} (${s.timing}, Teacher: ${s.teacherName})`)
    .join(" | ");
  const finalRcp = receiptNumber || batchSlips[0]?.receiptNumber || `YTR-RCP-${Date.now().toString().slice(-6)}`;

  try {
    db.prepare(`
      INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at)
      VALUES (?, '', ?, ?, 0, ?)
    `).run(
      sid,
      `Admission Active · Receipt ${finalRcp}`,
      `Payment verified (₹${totalAmount || batchSlips.reduce((a, b) => a + b.amount, 0)}). ${slipSummary || "Your course access is active."}`,
      now
    );
  } catch {
    // ignore if notifications table missing in minimal test
  }

  // Send Instant Receipt + Batch Slip email (duplicate-protected via dedupeKey)
  if (user.email) {
    const baseUrl = getAppBaseUrl(deps);
    await sendV31Mail(db, deps, {
      userId: sid,
      to: user.email,
      templateKey: "payment_receipt_batch_slip",
      category: "transactional",
      dedupeKey: `receipt_slip:${finalRcp}:${sid}`,
      vars: {
        name: user.full_name || "Student",
        note: finalRcp,
        course: courseTitles.length ? courseTitles.join(", ") : batchSlips.map((s) => `${s.courseTitle} (${s.plan})`).join(", "),
        paid_fee: `₹${Number(totalAmount || batchSlips.reduce((a, b) => a + b.amount, 0)).toLocaleString("en-IN")}`,
        reason: slipSummary || "Assigned Regular Batch · Mon–Sat",
        login_link: `${baseUrl}/student/`,
      },
    }).catch(() => null);
  }

  logV31Audit(db, {
    actorId: sid,
    actorName: user.full_name || "Student",
    actorRole: "student",
    action: "auto_activated_on_payment",
    entityType: "student",
    entityId: String(sid),
    summary: `Auto-activated student & enrollment(s) on verified payment (${orderCode || finalRcp})`,
    after: { accountActivatedNow, receiptNumber: finalRcp, batchSlips },
  });

  return { activated: true, accountActivatedNow, receiptNumber: finalRcp, batchSlips };
}

/**
 * Abandoned Cart Reminder Sweep (1–2 hours after cart add without completed payment, duplicate-protected).
 */
export async function runAbandonedCartReminderSweep(db, deps = {}, { nowDate = new Date(), minAgeMinutes = 60 } = {}) {
  const cutoffIso = new Date(nowDate.getTime() - minAgeMinutes * 60 * 1000).toISOString();
  const staleCarts = db.prepare(`
    SELECT ci.user_id, u.full_name, u.email,
           GROUP_CONCAT(c.title, ', ') AS course_titles,
           SUM(CASE WHEN ci.plan = 'yearly' THEN c.yearly_fee ELSE c.monthly_fee END) AS est_total,
           MAX(ci.updated_at) AS last_touched
    FROM cart_items ci
    JOIN users u ON u.id = ci.user_id
    JOIN courses c ON c.id = ci.course_id
    WHERE ci.user_id IS NOT NULL
      AND COALESCE(ci.reminder_sent_at, '') = ''
      AND ci.updated_at <= ?
      AND COALESCE(u.email, '') != ''
    GROUP BY ci.user_id
    LIMIT 50
  `).all(cutoffIso);

  const baseUrl = getAppBaseUrl(deps);
  let sent = 0;
  let skipped = 0;
  const dateKey = getIstDateKey(nowDate);

  for (const cart of staleCarts) {
    const dedupeKey = `abandoned_cart:${cart.user_id}:${dateKey}`;
    const already = db.prepare("SELECT id FROM v32_reminder_logs WHERE dedupe_key = ? LIMIT 1").get(dedupeKey);
    if (already) {
      skipped += 1;
      continue;
    }

    const res = await sendV31Mail(db, deps, {
      userId: cart.user_id,
      to: cart.email,
      templateKey: "abandoned_cart_reminder",
      category: "transactional",
      dedupeKey,
      vars: {
        name: cart.full_name || "Student",
        course: cart.course_titles || "Selected Yuitor Courses",
        total_fee: `₹${Number(cart.est_total || 0).toLocaleString("en-IN")}`,
        login_link: `${baseUrl}/?openCart=1`,
      },
    });

    if (res?.ok && !res?.duplicate) {
      db.prepare("UPDATE cart_items SET reminder_sent_at = ? WHERE user_id = ?").run(getIstTimestamp(nowDate), cart.user_id);
      db.prepare(`
        INSERT OR IGNORE INTO v32_reminder_logs (dedupe_key, reminder_type, user_id, email, details_json, sent_at_ist)
        VALUES (?, 'abandoned_cart', ?, ?, ?, ?)
      `).run(dedupeKey, cart.user_id, cart.email, JSON.stringify({ courses: cart.course_titles }), getIstTimestamp(nowDate));
      sent += 1;
    } else {
      skipped += 1;
    }
  }

  return { checked: staleCarts.length, sent, skipped };
}

/**
 * Plan Expiry Renewal Reminder Sweep — triggers strictly at 7 days and 2 days before enrollment expiry (duplicate-protected).
 */
export async function runPlanExpiryRenewalSweep(db, deps = {}, { nowDate = new Date() } = {}) {
  const baseUrl = getAppBaseUrl(deps);
  const targets = [7, 2];
  let sent = 0;
  let skipped = 0;

  for (const daysBefore of targets) {
    const targetDate = new Date(nowDate.getTime() + daysBefore * 86400000);
    const targetYmd = getIstDateKey(targetDate);

    const rows = db.prepare(`
      SELECT e.id AS enrollment_id, e.student_id, e.course_id, e.plan, e.expires_at,
             u.full_name, u.email, c.title AS course_title
      FROM enrollments e
      JOIN users u ON u.id = e.student_id
      JOIN courses c ON c.id = e.course_id
      WHERE e.status = 'active'
        AND substr(COALESCE(e.expires_at, ''), 1, 10) = ?
        AND COALESCE(u.email, '') != ''
        AND u.is_active = 1
    `).all(targetYmd);

    for (const row of rows) {
      const dedupeKey = `plan_renewal:${row.enrollment_id}:${daysBefore}d:${targetYmd}`;
      const exists = db.prepare("SELECT id FROM v32_reminder_logs WHERE dedupe_key = ? LIMIT 1").get(dedupeKey);
      if (exists) {
        skipped += 1;
        continue;
      }

      const payUrl = `${baseUrl}/?renewCourse=${row.course_id}&plan=${encodeURIComponent(row.plan || "1m")}&openCart=1`;
      const res = await sendV31Mail(db, deps, {
        userId: row.student_id,
        to: row.email,
        templateKey: "plan_expiry_renewal",
        category: "transactional",
        dedupeKey,
        vars: {
          name: row.full_name || "Student",
          course: `${row.course_title} (${row.plan || "1m"})`,
          note: `${daysBefore} days`,
          reason: targetYmd,
          login_link: payUrl,
        },
      });

      if (res?.ok && !res?.duplicate) {
        db.prepare(`
          INSERT OR IGNORE INTO v32_reminder_logs (dedupe_key, reminder_type, user_id, email, details_json, sent_at_ist)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(dedupeKey, `plan_renewal_${daysBefore}d`, row.student_id, row.email, JSON.stringify({ enrollmentId: row.enrollment_id, expiresAt: targetYmd }), getIstTimestamp(nowDate));
        sent += 1;
      } else {
        skipped += 1;
      }
    }
  }

  return { sent, skipped };
}

/**
 * Class 6th–12th Revenue, Dues, Admissions & Vacant Seats Report + Formula-Safe CSV/Excel Export.
 */
export function buildClassWiseFinanceReport(db) {
  const rows = CLASS_FEE_PLANS.map((plan) => {
    const clsNum = plan.classNumber;
    const clsLabel = plan.classLabel;

    // Match students belonging to this individual class
    const students = db.prepare(`
      SELECT u.id, sp.class_level
      FROM users u
      LEFT JOIN student_profiles sp ON sp.user_id = u.id
      WHERE u.role = 'student' AND COALESCE(u.deleted_at, '') = ''
    `).all().filter((s) => parseClassNumberFromLabel(s.class_level) === clsNum);
    const studentIds = students.map((s) => Number(s.id));

    // Find courses for this class
    const courses = db.prepare(`SELECT id, title, class_range, slug FROM courses WHERE is_active = 1`).all()
      .filter((c) => {
        if (/\d+\s*[-–]\s*\d+/.test(String(c.class_range || ""))) return false;
        return parseClassNumberFromLabel(c.class_range) === clsNum || parseClassNumberFromLabel(c.title) === clsNum;
      });
    const courseIds = courses.map((c) => Number(c.id));

    let feeCollected = 0;
    let pendingDues = 0;

    if (studentIds.length > 0) {
      const ph = studentIds.map(() => "?").join(",");
      feeCollected = Number(
        db.prepare(`SELECT COALESCE(SUM(amount), 0) AS s FROM payments WHERE verification_status = 'verified' AND student_id IN (${ph})`).get(...studentIds)?.s || 0
      );
      pendingDues = Number(
        db.prepare(`SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) AS s FROM fee_records WHERE status IN ('pending', 'partial', 'overdue') AND student_id IN (${ph})`).get(...studentIds)?.s || 0
      );
    }

    // Batches & vacant seats
    let totalSeats = 0;
    let filledSeats = 0;
    if (courseIds.length > 0) {
      const phc = courseIds.map(() => "?").join(",");
      const batches = db.prepare(`
        SELECT b.id, COALESCE(b.seat_limit, b.total_seats, 30) AS seat_cap,
               (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) AS used
        FROM batches b
        WHERE b.is_active = 1 AND b.course_id IN (${phc})
      `).all(...courseIds);
      for (const b of batches) {
        totalSeats += Number(b.seat_cap || 30);
        filledSeats += Number(b.used || 0);
      }
    }
    const vacantSeats = Math.max(0, totalSeats - filledSeats);

    return {
      classNumber: clsNum,
      classLabel: clsLabel,
      monthlyFee: plan.monthly,
      yearlyFee: plan.yearlyTotal,
      admissions: studentIds.length,
      feeCollected,
      pendingDues,
      totalSeats,
      filledSeats,
      vacantSeats,
    };
  });

  const totals = rows.reduce(
    (acc, r) => ({
      admissions: acc.admissions + r.admissions,
      feeCollected: acc.feeCollected + r.feeCollected,
      pendingDues: acc.pendingDues + r.pendingDues,
      totalSeats: acc.totalSeats + r.totalSeats,
      filledSeats: acc.filledSeats + r.filledSeats,
      vacantSeats: acc.vacantSeats + r.vacantSeats,
    }),
    { admissions: 0, feeCollected: 0, pendingDues: 0, totalSeats: 0, filledSeats: 0, vacantSeats: 0 }
  );

  return { generatedAtIst: getIstTimestamp(), rows, totals };
}

export function exportClassFinanceReport(db, format = "csv") {
  const report = buildClassWiseFinanceReport(db);
  const headers = [
    "Class",
    "Monthly Fee (INR)",
    "Yearly Fee 10% OFF (INR)",
    "Admissions",
    "Fee Collected (INR)",
    "Pending Dues (INR)",
    "Total Seats",
    "Filled Seats",
    "Vacant Seats",
  ];
  const matrix = report.rows.map((r) => [
    r.classLabel,
    r.monthlyFee,
    r.yearlyFee,
    r.admissions,
    r.feeCollected,
    r.pendingDues,
    r.totalSeats,
    r.filledSeats,
    r.vacantSeats,
  ]);
  matrix.push([
    "TOTAL (Classes 6th-12th)",
    "-",
    "-",
    report.totals.admissions,
    report.totals.feeCollected,
    report.totals.pendingDues,
    report.totals.totalSeats,
    report.totals.filledSeats,
    report.totals.vacantSeats,
  ]);

  if (format === "excel" || format === "xls") {
    return {
      contentType: "application/vnd.ms-excel; charset=utf-8",
      filename: `yuitor-class-finance-report-${getIstDateKey()}.xls`,
      body: buildSpreadsheetXml([{ name: "Class 6-12 Finance", headers, rows: matrix }]),
    };
  }

  return {
    contentType: "text/csv; charset=utf-8",
    filename: `yuitor-class-finance-report-${getIstDateKey()}.csv`,
    body: rowsToCsv(headers, matrix),
  };
}

/**
 * Teacher Monthly Payout & Class Log Summary (Classes Taken + Verified Referrals + Payout).
 */
export function buildTeacherMonthlyPayoutLog(db, salaryMonth = getIstDateKey().slice(0, 7)) {
  const userCols = new Set(db.prepare("PRAGMA table_info(users)").all().map((c) => c.name));
  const deletedFilter = userCols.has("deleted_at") ? "AND COALESCE(u.deleted_at, '') = ''" : "";
  const teachers = db.prepare(`
    SELECT u.id, u.full_name, u.phone, u.email
    FROM users u
    WHERE u.role = 'teacher' AND u.is_active = 1 ${deletedFilter}
    ORDER BY u.full_name ASC
  `).all();

  return teachers.map((t) => {
    let tp = null;
    try {
      tp = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ? LIMIT 1").get(t.id);
    } catch {
      tp = null;
    }

    let classesTaken = 0;
    try {
      classesTaken = Number(
        db.prepare(`
          SELECT COUNT(DISTINCT att_date || ':' || course_id) AS c
          FROM attendance
          WHERE teacher_id = ? AND substr(att_date, 1, 7) = ?
        `).get(t.id, salaryMonth)?.c || 0
      );
    } catch {
      try {
        classesTaken = Number(
          db.prepare(`
            SELECT COUNT(DISTINCT attendance_date || ':' || batch_id) AS c
            FROM attendance
            WHERE marked_by = ? AND substr(attendance_date, 1, 7) = ?
          `).get(t.id, salaryMonth)?.c || 0
        );
      } catch {
        classesTaken = 0;
      }
    }

    let verifiedReferrals = 0;
    let referralBonus = 0;
    try {
      const refStats = db.prepare(`
        SELECT COUNT(*) AS cnt, COALESCE(SUM(reward_amount), 0) AS reward
        FROM referrals
        WHERE referrer_user_id = ? AND status IN ('qualified', 'rewarded')
      `).get(t.id);
      verifiedReferrals = Number(refStats?.cnt || 0);
      referralBonus = Number(refStats?.reward || 0);
    } catch {
      verifiedReferrals = 0;
    }

    let payoutRow = null;
    try {
      payoutRow = db.prepare(`
        SELECT * FROM teacher_payouts WHERE teacher_id = ? AND salary_month = ? ORDER BY id DESC LIMIT 1
      `).get(t.id, salaryMonth);
    } catch {
      payoutRow = null;
    }

    const baseRate = Number(tp?.monthly_payout_rate || tp?.salary_monthly || payoutRow?.base_amount || 0);
    const perClassEst = baseRate > 0 ? baseRate : classesTaken * 300;
    const netAmount = payoutRow ? Number(payoutRow.net_amount || 0) : perClassEst + referralBonus;

    return {
      teacherId: Number(t.id),
      teacherName: t.full_name,
      fullName: t.full_name,
      phone: t.phone || "",
      payoutUpi: tp?.payout_upi || "",
      salaryMonth,
      classesTaken,
      verifiedReferrals,
      referralBonus,
      baseAmount: Number(payoutRow?.base_amount ?? perClassEst),
      netAmount,
      estimatedMonthlyPayout: netAmount,
      status: payoutRow?.status || "calculated",
      payoutId: payoutRow?.id || null,
    };
  });
}

/**
 * 1-Click Ready WhatsApp Templates (Zero Extra API Cost) for Admin & Teacher.
 */
export function buildWhatsAppTemplates({ studentName = "Student", className = "Class 10th", amountDue = 0, date = getIstDateKey(), examName = "Weekly Test", score = "" } = {}) {
  return [
    {
      id: "fee_reminder",
      label: "Fee Reminder",
      text: `Namaste! Yuitor Smart Classes se reminder: ${studentName} (${className}) ki coaching fee ₹${Number(amountDue || 0).toLocaleString("en-IN")} due hai. Kripya samay par submit karein. Help: +91 78-2728-9292`,
    },
    {
      id: "absent_notice",
      label: "Absent Notice",
      text: `Namaste! Aaj (${date}) ${studentName} (${className}) Yuitor Smart Classes mein absent the. Kripya regular attendance ensure karein ya reason share karein. — Yuitor Faculty`,
    },
    {
      id: "exam_schedule",
      label: "Exam Schedule",
      text: `Yuitor Smart Classes Notice (${className}): "${examName}" date ${date} ko scheduled hai. Sabhi students time par revision karke aayein. All the best!`,
    },
    {
      id: "result_share",
      label: "Result Share",
      text: `Yuitor Smart Classes Result Update: ${studentName} (${className}) ne "${examName}" mein ${score || "outstanding marks"} score kiya hai! Student/Parent Portal par detailed rank card dekhein.`,
    },
  ];
}

/**
 * Free 5-Question Quick Quiz Bank (Classes 6th–12th) — No-login Lead Magnet.
 */
export const QUICK_QUIZ_BANK = {
  6: [
    { q: "What is the LCM of 12 and 18?", options: ["24", "36", "48", "72"], correctIndex: 1 },
    { q: "Which gas do plants absorb during photosynthesis?", options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"], correctIndex: 2 },
    { q: "What is 3/4 expressed as a percentage?", options: ["65%", "70%", "75%", "80%"], correctIndex: 2 },
    { q: "Which planet is known as the Red Planet?", options: ["Venus", "Mars", "Jupiter", "Saturn"], correctIndex: 1 },
    { q: "Choose the correct plural of 'Child':", options: ["Childs", "Children", "Childrens", "Childes"], correctIndex: 1 },
  ],
  7: [
    { q: "Solve: 3x - 7 = 14. Find x.", options: ["5", "6", "7", "8"], correctIndex: 2 },
    { q: "What is the SI unit of Temperature?", options: ["Celsius", "Kelvin", "Joule", "Watt"], correctIndex: 1 },
    { q: "Sum of interior angles of a triangle is:", options: ["90°", "180°", "270°", "360°"], correctIndex: 1 },
    { q: "Which acid is present in lemon?", options: ["Citric acid", "Acetic acid", "Lactic acid", "Oxalic acid"], correctIndex: 0 },
    { q: "Who was the founder of the Mughal Empire in India?", options: ["Akbar", "Babur", "Humayun", "Shah Jahan"], correctIndex: 1 },
  ],
  8: [
    { q: "What is the square root of 1,296?", options: ["34", "36", "38", "42"], correctIndex: 1 },
    { q: "Which organelle is the 'Powerhouse of the Cell'?", options: ["Nucleus", "Ribosome", "Mitochondria", "Golgi body"], correctIndex: 2 },
    { q: "Factorise: x² - 9", options: ["(x-3)(x-3)", "(x+3)(x+3)", "(x-3)(x+3)", "(x-9)(x+1)"], correctIndex: 2 },
    { q: "Force per unit area is called:", options: ["Momentum", "Pressure", "Work", "Energy"], correctIndex: 1 },
    { q: "Which metal is liquid at room temperature?", options: ["Sodium", "Mercury", "Iron", "Copper"], correctIndex: 1 },
  ],
  9: [
    { q: "What is the value of (a + b)²?", options: ["a² + b²", "a² + 2ab + b²", "a² - 2ab + b²", "2a² + 2b²"], correctIndex: 1 },
    { q: "Newton's Second Law states F =", options: ["m / a", "m × v", "m × a", "v / t"], correctIndex: 2 },
    { q: "Atomic number of Carbon is:", options: ["4", "6", "8", "12"], correctIndex: 1 },
    { q: "If two angles are complementary and one is 35°, the other is:", options: ["45°", "55°", "65°", "145°"], correctIndex: 1 },
    { q: "Which tissue transports water in plants?", options: ["Phloem", "Xylem", "Epidermis", "Cortex"], correctIndex: 1 },
  ],
  10: [
    { q: "If sin θ = 1/2, then θ (acute angle) is:", options: ["15°", "30°", "45°", "60°"], correctIndex: 1 },
    { q: "Ohm's Law relation is:", options: ["V = I/R", "V = IR", "R = VI", "I = VR"], correctIndex: 1 },
    { q: "pH of pure neutral water at 25°C is:", options: ["5", "6", "7", "8"], correctIndex: 2 },
    { q: "Sum of roots of x² - 5x + 6 = 0 is:", options: ["-5", "5", "6", "-6"], correctIndex: 1 },
    { q: "Mirror formula is:", options: ["1/f = 1/v + 1/u", "1/f = 1/v - 1/u", "f = u + v", "1/f = u × v"], correctIndex: 0 },
  ],
  11: [
    { q: "Derivative of sin(x) with respect to x is:", options: ["-cos(x)", "cos(x)", "tan(x)", "-sin(x)"], correctIndex: 1 },
    { q: "Value of Avogadro's number is approximately:", options: ["6.022 × 10²³", "3.14 × 10²³", "9.8 × 10²²", "1.6 × 10⁻¹⁹"], correctIndex: 0 },
    { q: "Dimensional formula of Force is:", options: ["[MLT⁻¹]", "[MLT⁻²]", "[ML²T⁻²]", "[M⁰LT⁻²]"], correctIndex: 1 },
    { q: "How many terms are in the expansion of (a + b)⁵?", options: ["5", "6", "7", "10"], correctIndex: 1 },
    { q: "SI unit of Work and Energy is:", options: ["Newton", "Watt", "Joule", "Pascal"], correctIndex: 2 },
  ],
  12: [
    { q: "∫ x² dx equals:", options: ["2x + C", "x³/3 + C", "x³ + C", "x²/2 + C"], correctIndex: 1 },
    { q: "SI unit of Electric Capacitance is:", options: ["Ohm", "Henry", "Farad", "Tesla"], correctIndex: 2 },
    { q: "Order of reaction for rate = k[A]¹[B]² is:", options: ["1", "2", "3", "0"], correctIndex: 2 },
    { q: "Determinant of identity matrix I₃ is:", options: ["0", "1", "3", "9"], correctIndex: 1 },
    { q: "Which wave is NOT an electromagnetic wave?", options: ["X-rays", "Sound waves", "Microwaves", "Gamma rays"], correctIndex: 1 },
  ],
};

export function gradeQuickQuiz(classNumber, answers = []) {
  const cls = Number(classNumber);
  const bank = QUICK_QUIZ_BANK[cls] || QUICK_QUIZ_BANK[10];
  let correct = 0;
  const details = bank.map((q, idx) => {
    const selected = Number(answers[idx]);
    const isCorrect = selected === q.correctIndex;
    if (isCorrect) correct += 1;
    return { index: idx, selected, correctIndex: q.correctIndex, isCorrect };
  });
  const total = bank.length;
  const percent = Math.round((correct / total) * 100);
  const feePlan = calculateClassFeePlan(cls, "1m");
  return {
    classNumber: feePlan.classNumber,
    classLabel: feePlan.classLabel,
    correct,
    score: correct,
    total,
    percent,
    badge: percent >= 80 ? "Topper Potential" : percent >= 60 ? "Strong Foundation" : "Needs Guided Practice",
    monthlyFee: feePlan.monthlyRate,
    yearlyFee: calculateClassFeePlan(cls, "yearly").totalPayable,
    details,
  };
}

/**
 * QR-Verified Printable Topper / Course Completion Certificate HTML & PDF generator.
 */
export function renderQrCertificateHtml(cert, { baseUrl = "https://yuitor.com", pdfUrl = "" } = {}) {
  const verifyUrl = `${baseUrl.replace(/\/+$/, "")}/api/certificates/verify/${encodeURIComponent(cert.certificate_code)}`;
  const qr = generateQrSvg(verifyUrl, 118);
  const isTopper = String(cert.cert_type || "").toLowerCase() === "topper";
  const heading = isTopper ? "CERTIFICATE OF MERIT & TOPPER EXCELLENCE" : "CERTIFICATE OF COURSE COMPLETION";

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(heading)} — ${escapeHtml(cert.student_name)}</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; padding: 24px; background: #F8FAFC; font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #0F172A; }
    .toolbar { max-width: 920px; margin: 0 auto 14px; display: flex; justify-content: flex-end; gap: 10px; }
    .btn { background: #7A0F28; color: #fff; border: 0; padding: 10px 16px; border-radius: 8px; font-weight: 700; cursor: pointer; text-decoration: none; font-size: 13px; }
    .btn-alt { background: #0F172A; }
    .cert { max-width: 920px; margin: 0 auto; background: #FFFDF8; border: 10px double #7A0F28; border-radius: 14px; padding: 38px 46px; position: relative; box-shadow: 0 20px 50px rgba(15,23,42,0.12); }
    .cert-top { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #E6B450; padding-bottom: 18px; }
    .brand { display: flex; align-items: center; gap: 14px; }
    .brand img { width: 58px; height: 58px; object-fit: contain; background: #fff; border-radius: 10px; padding: 4px; border: 1px solid #E2E8F0; }
    .brand h1 { margin: 0; font-size: 22px; color: #7A0F28; letter-spacing: 0.04em; }
    .brand p { margin: 2px 0 0; font-size: 12px; color: #64748B; font-weight: 600; }
    .cert-code { text-align: right; font-size: 12px; color: #475569; font-family: monospace; }
    .cert-body { text-align: center; padding: 30px 12px; }
    .kicker { font-size: 13px; font-weight: 800; letter-spacing: 0.16em; color: #B45309; text-transform: uppercase; margin-bottom: 12px; }
    .student-name { font-family: Georgia, serif; font-size: 38px; font-weight: 700; color: #1E1B4B; margin: 8px 0 14px; border-bottom: 2px solid #E2E8F0; display: inline-block; padding: 0 24px 6px; }
    .desc { font-size: 16px; line-height: 1.7; color: #334155; max-width: 680px; margin: 0 auto; }
    .highlight { color: #7A0F28; font-weight: 800; }
    .cert-foot { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 28px; padding-top: 18px; border-top: 1px solid #E2E8F0; gap: 20px; }
    .sig { text-align: center; min-width: 180px; }
    .sig-line { border-top: 1.5px solid #0F172A; padding-top: 6px; font-size: 12px; font-weight: 700; color: #334155; }
    .qr-wrap { text-align: center; }
    .qr-wrap small { display: block; font-size: 10px; color: #475569; margin-top: 4px; font-family: monospace; }
    @media print { body { background: #fff; padding: 0; } .toolbar { display: none; } .cert { box-shadow: none; } }
  </style>
</head>
<body>
  <div class="toolbar">
    ${pdfUrl ? `<a class="btn btn-alt" href="${escapeHtml(pdfUrl)}">Download PDF</a>` : ""}
    <button class="btn" onclick="window.print()">Print Certificate</button>
  </div>
  <div class="cert">
    <div class="cert-top">
      <div class="brand">
        <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Smart Classes" />
        <div>
          <h1>YUITOR SMART CLASSES</h1>
          <p>Ek Kadam Safalta Ki Our · Trimurti Vihar, Muradnagar</p>
        </div>
      </div>
      <div class="cert-code">
        <div><strong>Cert ID:</strong> ${escapeHtml(cert.certificate_code)}</div>
        <div><strong>Issued:</strong> ${escapeHtml(cert.issued_date_ist || getIstDateKey())}</div>
      </div>
    </div>
    <div class="cert-body">
      <div class="kicker">${escapeHtml(heading)}</div>
      <div style="font-size:14px;color:#64748B;">This proudly certifies that</div>
      <div class="student-name">${escapeHtml(cert.student_name)}</div>
      <p class="desc">
        ${isTopper
          ? `has demonstrated outstanding academic excellence in <span class="highlight">${escapeHtml(cert.class_label || cert.course_title || "Yuitor Program")}</span>${cert.rank_or_score ? ` achieving <span class="highlight">${escapeHtml(cert.rank_or_score)}</span>` : ""}.`
          : `has successfully completed the academic program <span class="highlight">${escapeHtml(cert.course_title || cert.class_label || "Yuitor Program")}</span>${cert.rank_or_score ? ` with <span class="highlight">${escapeHtml(cert.rank_or_score)}</span>` : ""}.`
        }
      </p>
    </div>
    <div class="cert-foot">
      <div class="sig">
        <div style="font-family:Georgia,serif;font-style:italic;font-size:18px;color:#7A0F28;margin-bottom:6px;">Yuitor Academics</div>
        <div class="sig-line">Academic Director</div>
      </div>
      <div class="qr-wrap">
        ${qr}
        <small>Scan to Verify · ${escapeHtml(cert.certificate_code)}</small>
      </div>
      <div class="sig">
        <div style="font-size:13px;font-weight:700;color:#0F172A;margin-bottom:6px;">${escapeHtml(cert.issued_date_ist || getIstDateKey())}</div>
        <div class="sig-line">Date of Issue (IST)</div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

export function generateSampleNotesPdfBuffer(classNumber) {
  const plan = calculateClassFeePlan(classNumber, "1m");
  return buildSimplePdfBuffer({
    title: `${plan.classLabel} Free Sample Notes & Important PYQs`,
    subtitle: "Yuitor Smart Classes · Muradnagar (Free Public Preview — Full Notes Unlock on Enrollment)",
    rows: [
      { section: `1. ${plan.classLabel} Core Formulas & Key Concepts` },
      { label: "Mathematics Focus", value: "NCERT Examples, Chapter Exercises, Short Tricks & Step-Marking Format" },
      { label: "Science Focus", value: "Diagrams, Numericals, Definitions & Board Expected 3-Mark / 5-Mark Qs" },
      { section: "2. Important Sample Questions (Practice)" },
      { label: "Q1 (Concept)", value: "Define the fundamental theorem / law covered in Chapter 1 with 1 solved example." },
      { label: "Q2 (Numerical)", value: "Solve step-by-step and verify units clearly for full board credit." },
      { label: "Q3 (PYQ)", value: "Explain with a labelled neat diagram and list 2 real-life applications." },
      { section: "3. Unlock Complete Chapter-Wise Notes & 5-Year Solved PYQ Bank" },
      { label: "Monthly Fee", value: `Rs. ${plan.monthlyRate}/month (1m / 3m / 6m / 9m / 12m Yearly 10% OFF)` },
      { label: "Admissions", value: "Add to Cart on yuitor.com or Call/WhatsApp +91 78-2728-9292" },
    ],
  });
}

export function createV32Certificate(db, { studentId = null, studentName, classLabel = "", courseTitle = "", certType = "completion", rankOrScore = "", issuedBy = null } = {}) {
  const code = `YTR-CERT-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
  const issuedDate = getIstDateKey();
  const ins = db.prepare(`
    INSERT INTO v32_certificates (certificate_code, student_id, student_name, class_label, course_title, cert_type, rank_or_score, issued_date_ist, issued_by, is_valid)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `).run(
    code,
    studentId ? Number(studentId) : null,
    String(studentName || "Student").trim(),
    String(classLabel || "").trim(),
    String(courseTitle || "").trim(),
    certType === "topper" ? "topper" : "completion",
    String(rankOrScore || "").trim(),
    issuedDate,
    issuedBy ?? null
  );
  return db.prepare("SELECT * FROM v32_certificates WHERE id = ?").get(Number(ins.lastInsertRowid));
}
