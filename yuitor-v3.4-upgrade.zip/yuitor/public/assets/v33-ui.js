/* ============================================================================
 * Yuitor Smart Classes v3.3 — Frontend UI & Interactive Workflows
 * Preserves existing DreamsERP Burgundy (#4A0E1C) & Gold (#D4AF37) aesthetic,
 * light/dark parity, responsive layout, CSRF safety, and zero fake data.
 * ============================================================================ */
(() => {
  "use strict";

  const V33_STYLE_ID = "yu-v33-styles";
  let countdownTimerId = null;

  function esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function inr(n) {
    const val = Math.round(Number(n || 0));
    return `₹${val.toLocaleString("en-IN")}`;
  }

  function readCsrfToken() {
    const m = document.cookie.match(/(?:^|;\s*)(?:yu_csrf|yuitor_csrf)=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function apiV33(path, opts = {}) {
    const method = (opts.method || "GET").toUpperCase();
    const headers = { ...(opts.headers || {}) };
    if (opts.body && !(opts.body instanceof FormData) && !headers["Content-Type"]) {
      headers["Content-Type"] = "application/json";
    }
    if (["POST", "PUT", "PATCH", "DELETE"].includes(method)) {
      const csrf = readCsrfToken();
      if (csrf) headers["X-CSRF-Token"] = csrf;
    }
    const res = await fetch(path.startsWith("/") ? path : `/api/v33/${path}`, {
      method,
      credentials: "include",
      headers,
      body: opts.body && !(opts.body instanceof FormData) && typeof opts.body !== "string"
        ? JSON.stringify(opts.body)
        : opts.body,
    });
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = { raw: text };
    }
    if (!res.ok) {
      throw new Error(data.error || data.message || `Request failed (${res.status})`);
    }
    return data;
  }

  function toast(msg, type = "success") {
    if (window.YuitorUI?.Toast?.[type]) {
      window.YuitorUI.Toast[type](msg);
      return;
    }
    const el = document.createElement("div");
    el.className = `v33-toast v33-toast--${type}`;
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  function statusPill(status) {
    const label = String(status || "pending").replace(/_/g, " ").trim();
    const s = label.toLowerCase();
    let cls = "v33-pill";
    if (["paid", "verified", "verified & paid", "approved", "sent", "completed", "active"].includes(s)) cls += " v33-pill--ok";
    else if (["partial", "partially paid", "pending", "pending verification", "pending approval", "scheduled", "important", "new"].includes(s)) cls += " v33-pill--warn";
    else if (["overdue", "partially paid (overdue)", "rejected", "failed", "unpaid", "expired"].includes(s)) cls += " v33-pill--bad";
    return `<span class="${cls}">${esc(label)}</span>`;
  }

  function injectStyles() {
    if (document.getElementById(V33_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = V33_STYLE_ID;
    style.textContent = `
      .v33-card{background:var(--pt-surface,#fff);border:1px solid var(--pt-border,#e5e7eb);border-radius:14px;padding:18px;margin-bottom:16px;box-shadow:0 2px 10px rgba(15,23,42,.04);max-width:100%;box-sizing:border-box;}
      .v33-card *,.v33-modal *{box-sizing:border-box;}
      .v33-header-row{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;}
      .v33-title{margin:0;font-size:16px;font-weight:750;color:var(--pt-text,#111827);line-height:1.3;}
      .v33-sub{margin:3px 0 0;font-size:12.5px;color:var(--pt-muted,#6b7280);line-height:1.45;}
      .v33-kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:10px;margin-bottom:14px;}
      .v33-kpi{background:var(--pt-surface-soft,#f8fafc);border:1px solid var(--pt-border,#e5e7eb);border-radius:10px;padding:12px;min-width:0;}
      .v33-kpi > span{display:block;font-size:11.5px;color:var(--pt-muted,#6b7280);margin-bottom:4px;}
      .v33-kpi strong{font-size:15.5px;font-weight:750;color:var(--pt-text,#111827);word-break:break-word;}
      .v33-kpi--accent{border-left:3px solid #4A0E1C;}
      .v33-kpi--gold{border-left:3px solid #D4AF37;}
      .v33-pill{display:inline-flex;align-items:center;padding:2px 9px;border-radius:999px;font-size:11.5px;font-weight:700;text-transform:capitalize;background:#e5e7eb;color:#374151;white-space:nowrap;}
      .v33-pill--ok{background:#dcfce7;color:#166534;}
      .v33-pill--warn{background:#fef3c7;color:#92400e;}
      .v33-pill--bad{background:#fee2e2;color:#991b1b;}
      .v33-grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;}
      .v33-grid-3{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;}
      .v33-item-card{background:var(--pt-surface-soft,#f9fafb);border:1px solid var(--pt-border,#e5e7eb);border-radius:12px;padding:14px;display:flex;flex-direction:column;justify-content:space-between;gap:8px;min-width:0;}
      .v33-countdown-banner{background:linear-gradient(135deg,#4A0E1C 0%,#6B1429 65%,#8A1C35 100%);color:#fff;border-radius:12px;padding:14px 16px;margin-bottom:14px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;border:1px solid rgba(212,175,55,.45);}
      .v33-countdown-clock{background:rgba(212,175,55,.18);border:1px solid #D4AF37;color:#FDE68A;padding:6px 12px;border-radius:8px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:800;font-size:13.5px;letter-spacing:.4px;}
      .v33-progress-track{height:10px;border-radius:999px;background:var(--pt-border,#e5e7eb);overflow:hidden;margin:8px 0;}
      .v33-progress-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#4A0E1C,#D4AF37);transition:width .25s ease;}
      .v33-chip-group{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;}
      .v33-chip{display:inline-flex;align-items:center;justify-content:flex-start;text-align:left;gap:7px;padding:6px 10px;border-radius:8px;border:1px solid var(--pt-border,#d1d5db);background:var(--pt-surface,#fff);color:var(--pt-text,#111827);font-size:12.5px;line-height:1.3;cursor:pointer;user-select:none;width:auto;max-width:100%;}
      .v33-chip input,.v33-chip input[type="checkbox"],.v33-chip input[type="radio"]{accent-color:#4A0E1C;width:15px !important;min-width:15px !important;max-width:15px !important;height:15px !important;flex:0 0 15px !important;margin:0 !important;padding:0 !important;}
      .v33-chip.is-selected{border-color:#4A0E1C;background:rgba(74,14,28,.08);font-weight:650;}
      .v33-modal-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.62);backdrop-filter:blur(3px);z-index:10050;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto;overscroll-behavior:contain;}
      .v33-modal{background:var(--pt-surface,#fff);color:var(--pt-text,#111827);border:1px solid var(--pt-border,#e5e7eb);border-radius:16px;width:min(1040px,100%);max-height:92dvh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.28);}
      .v33-modal--narrow{width:min(680px,100%);}
      .v33-modal-head{padding:14px 20px;border-bottom:1px solid var(--pt-border,#e5e7eb);display:flex;justify-content:space-between;align-items:center;gap:12px;background:linear-gradient(90deg,#4A0E1C,#66162A);color:#fff;flex-shrink:0;}
      .v33-modal-head h2{margin:0;font-size:16.5px;font-weight:750;color:#fff;line-height:1.25;}
      .v33-modal-close{background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.28);color:#fff;width:36px;height:36px;min-width:36px;border-radius:8px;font-size:18px;cursor:pointer;line-height:1;display:inline-flex;align-items:center;justify-content:center;}
      .v33-modal-body{padding:18px 20px;overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1 1 auto;min-width:0;}
      .v33-tabs{display:flex;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--pt-border,#e5e7eb);padding-bottom:10px;margin-bottom:16px;}
      .v33-tab{padding:7px 12px;border-radius:8px;border:1px solid var(--pt-border,#e5e7eb);background:var(--pt-surface-soft,#f8fafc);color:var(--pt-text,#374151);font-size:12.5px;font-weight:650;cursor:pointer;white-space:nowrap;flex-shrink:0;}
      .v33-tab.is-active{background:#4A0E1C;color:#fff;border-color:#4A0E1C;}
      .v33-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:8px 13px;min-height:36px;border-radius:8px;border:1px solid #4A0E1C;background:#4A0E1C;color:#fff;font-size:12.5px;font-weight:650;cursor:pointer;text-decoration:none;white-space:nowrap;}
      .v33-btn:hover{filter:brightness(1.08);}
      .v33-btn:disabled{opacity:.55;cursor:not-allowed;}
      .v33-btn--quiet{background:var(--pt-surface,#fff);color:var(--pt-text,#1f2937);border-color:var(--pt-border,#d1d5db);}
      .v33-btn--gold{background:#D4AF37;border-color:#B59225;color:#1F1304;}
      .v33-btn--ok{background:#15803d;border-color:#15803d;color:#fff;}
      .v33-btn--danger{background:#b91c1c;border-color:#b91c1c;color:#fff;}
      .v33-table-wrap{width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;border:1px solid var(--pt-border,#e5e7eb);border-radius:10px;margin-bottom:14px;}
      .v33-table{width:100%;border-collapse:collapse;font-size:12.5px;}
      .v33-table th,.v33-table td{padding:9px 10px;border-bottom:1px solid var(--pt-border,#e5e7eb);text-align:left;vertical-align:middle;}
      .v33-table th{background:var(--pt-surface-soft,#f8fafc);font-weight:700;color:var(--pt-muted,#4b5563);white-space:nowrap;}
      .v33-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin-bottom:12px;}
      .v33-field{display:flex;flex-direction:column;gap:4px;min-width:0;}
      .v33-field label{font-size:12px;font-weight:650;color:var(--pt-muted,#4b5563);}
      .v33-field input,.v33-field select,.v33-field textarea{padding:8px 10px;min-height:38px;border-radius:8px;border:1px solid var(--pt-border,#d1d5db);background:var(--pt-surface,#fff);color:var(--pt-text,#111827);font-size:13px;width:100%;box-sizing:border-box;}
      .v33-preview-box{background:var(--pt-surface-soft,#f9fafb);border:1px solid var(--pt-border,#d1d5db);border-radius:10px;padding:12px;font-size:13px;white-space:pre-wrap;word-break:break-word;}
      .v33-toast{position:fixed;bottom:20px;right:20px;z-index:10099;padding:10px 16px;border-radius:10px;background:#4A0E1C;color:#fff;font-size:13px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.22);max-width:min(380px,calc(100vw - 24px));}
      .v33-toast--error{background:#b91c1c;}
      .v33-notif-item{padding:9px 10px;border-radius:9px;border:1px solid var(--pt-border,#e5e7eb);margin-bottom:7px;background:var(--pt-surface-soft,#f9fafb);cursor:pointer;transition:border-color .15s;}
      .v33-notif-item:hover{border-color:#4A0E1C;}
      .v33-notif-item.is-unread{border-left:3px solid #D4AF37;background:var(--pt-surface,#fff);}
      .v33-sidebar-btn{width:100%;margin-top:6px;padding:9px 12px;border-radius:10px;border:1px solid rgba(212,175,55,.45);background:linear-gradient(135deg,#4A0E1C,#66162A);color:#fff;font-size:12.5px;font-weight:700;cursor:pointer;text-align:left;display:flex;align-items:center;justify-content:space-between;}
      .v33-sidebar-btn:hover{filter:brightness(1.08);}
      [data-theme="dark"] .v33-card,.portal-dark .v33-card,[data-theme="dark"] .v33-modal,.portal-dark .v33-modal,[data-theme="dark"] .v33-field input,.portal-dark .v33-field input,[data-theme="dark"] .v33-field select,.portal-dark .v33-field select,[data-theme="dark"] .v33-field textarea,.portal-dark .v33-field textarea,[data-theme="dark"] .v33-chip,.portal-dark .v33-chip,[data-theme="dark"] .v33-btn--quiet,.portal-dark .v33-btn--quiet{background:#111827;color:#f3f4f6;border-color:#2d3748;}
      [data-theme="dark"] .v33-kpi,.portal-dark .v33-kpi,[data-theme="dark"] .v33-item-card,.portal-dark .v33-item-card,[data-theme="dark"] .v33-tab,.portal-dark .v33-tab,[data-theme="dark"] .v33-table th,.portal-dark .v33-table th,[data-theme="dark"] .v33-preview-box,.portal-dark .v33-preview-box,[data-theme="dark"] .v33-notif-item,.portal-dark .v33-notif-item{background:#1f2937;color:#f3f4f6;border-color:#374151;}
      [data-theme="dark"] .v33-title,.portal-dark .v33-title,[data-theme="dark"] .v33-kpi strong,.portal-dark .v33-kpi strong{color:#f9fafb;}

      /* Tablet Responsive (768px - 1024px) */
      @media (max-width:1024px){
        .v33-modal-backdrop{padding:12px;}
        .v33-modal{width:min(96vw,960px);max-height:92dvh;}
        .v33-kpi-grid{grid-template-columns:repeat(3,minmax(0,1fr));}
        .v33-grid-2{grid-template-columns:1fr;}
        .v33-grid-3{grid-template-columns:repeat(2,minmax(0,1fr));}
        .v33-tabs{flex-wrap:nowrap;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:8px;scrollbar-width:thin;}
      }

      /* Mobile Responsive (<= 767px) */
      @media (max-width:767px){
        .v33-card{padding:14px;border-radius:12px;}
        .v33-header-row{flex-direction:column;align-items:flex-start;gap:8px;}
        .v33-header-row > div:last-child{display:flex;flex-wrap:wrap;gap:6px;width:100%;}
        .v33-kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;}
        .v33-kpi{padding:10px;}
        .v33-kpi strong{font-size:14px;}
        .v33-grid-2,.v33-grid-3,.v33-form-grid{grid-template-columns:1fr;gap:10px;}
        .v33-modal-backdrop{padding:8px;align-items:flex-end;}
        .v33-modal,.v33-modal--narrow{width:100%;max-height:94dvh;border-radius:14px;}
        .v33-modal-head{padding:12px 14px;}
        .v33-modal-head h2{font-size:15px;}
        .v33-modal-body{padding:14px 12px 24px;}
        .v33-btn{min-height:40px;padding:8px 12px;font-size:13px;}
        .v33-field input,.v33-field select,.v33-field textarea{min-height:42px;font-size:15px;}
        .v33-countdown-banner{flex-direction:column;align-items:stretch;}
        .v33-countdown-banner .v33-btn{width:100%;}
        .v33-table th,.v33-table td{padding:8px 8px;font-size:12px;}
        .v33-toast{left:12px;right:12px;bottom:70px;text-align:center;}
      }

      @media (max-width:340px){
        .v33-kpi-grid{grid-template-columns:1fr;}
      }
    `;
    document.head.appendChild(style);
  }

  function startCountdownTicker() {
    if (countdownTimerId) return;
    countdownTimerId = setInterval(() => {
      const els = document.querySelectorAll("[data-v33-countdown]");
      const now = Date.now();
      els.forEach((el) => {
        const endIso = el.getAttribute("data-v33-countdown");
        const endMs = endIso ? Date.parse(endIso) : 0;
        const diff = Math.max(0, Math.floor((endMs - now) / 1000));
        if (!endMs || diff <= 0) {
          el.textContent = "Offer Ended";
          return;
        }
        const hrs = String(Math.floor(diff / 3600)).padStart(2, "0");
        const mins = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
        const secs = String(diff % 60).padStart(2, "0");
        el.textContent = `Offer Ends In ${hrs}:${mins}:${secs}`;
      });
    }, 1000);
  }

  function openModal({ title, bodyHtml, narrow = false, onMount }) {
    injectStyles();
    const backdrop = document.createElement("div");
    backdrop.className = "v33-modal-backdrop";
    backdrop.innerHTML = `
      <div class="v33-modal ${narrow ? "v33-modal--narrow" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="v33-modal-head">
          <h2>${esc(title)}</h2>
          <button type="button" class="v33-modal-close" data-v33-close aria-label="Close">&times;</button>
        </div>
        <div class="v33-modal-body">${bodyHtml}</div>
      </div>
    `;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (e) => {
      if (e.key === "Escape") close();
    };
    const close = () => {
      document.removeEventListener("keydown", onKeyDown);
      backdrop.remove();
      if (!document.querySelector(".v33-modal-backdrop")) {
        document.body.style.overflow = prevOverflow || "";
      }
    };
    document.addEventListener("keydown", onKeyDown);
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop || e.target.closest("[data-v33-close]")) close();
    });
    document.body.appendChild(backdrop);
    if (typeof onMount === "function") onMount(backdrop, close);
    return { backdrop, close };
  }

  /* ==========================================================================
   * 1. SIMPLIFIED 3-FIELD STUDENT REGISTRATION + OTP
   * ========================================================================== */
  function mountQuickRegisterForm(container) {
    if (!container) return;
    injectStyles();
    let step = "form";
    let pendingPhone = "";
    let pendingEmail = "";
    let pendingChannel = "sms";
    let infoMsg = "";
    let errMsg = "";
    const storedRef = window.YuitorAddons?.getStoredReferralCode?.() || "";

    function draw() {
      if (step === "otp") {
        container.innerHTML = `
          <div class="v33-card" data-testid="v33-quick-register-otp">
            <div class="v33-header-row">
              <div>
                <h3 class="v33-title">Verify 6-Digit OTP</h3>
                <p class="v33-sub">Enter the OTP sent to <strong>${esc(pendingChannel === "email" ? pendingEmail : pendingPhone)}</strong> to enter your Student Dashboard immediately.</p>
              </div>
            </div>
            ${infoMsg ? `<div class="portal-message portal-message--success" style="margin-bottom:10px;">${esc(infoMsg)}</div>` : ""}
            ${errMsg ? `<div class="portal-message portal-message--error" style="margin-bottom:10px;">${esc(errMsg)}</div>` : ""}
            <form data-v33-qotp-form>
              <div class="v33-field" style="margin-bottom:10px;">
                <label>6-Digit Verification OTP *</label>
                <input name="otp" maxlength="6" inputmode="numeric" required placeholder="Enter 6-digit OTP" autocomplete="one-time-code">
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="submit" class="v33-btn" style="flex:1;">Verify OTP &amp; Enter Student Dashboard</button>
                <button type="button" class="v33-btn v33-btn--quiet" data-v33-qotp-back>Back</button>
              </div>
            </form>
          </div>`;
        container.querySelector("[data-v33-qotp-back]")?.addEventListener("click", () => {
          step = "form";
          errMsg = "";
          draw();
        });
        container.querySelector("[data-v33-qotp-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          errMsg = "";
          try {
            const res = await apiV33("/api/v33/auth/quick-verify-otp", {
              method: "POST",
              body: { phone: pendingPhone, otp: String(fd.get("otp") || "").trim() },
            });
            toast("OTP verified! Opening Student Dashboard...");
            window.location.assign(res.redirectUrl || "/student");
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
        return;
      }

      container.innerHTML = `
        <div class="v33-card" style="border-color:rgba(74,14,28,.35);" data-testid="v33-quick-register-box">
          <div class="v33-header-row" style="margin-bottom:10px;">
            <div>
              <h3 class="v33-title">Quick 1-Minute Student Registration</h3>
              <p class="v33-sub">Just 3 fields + OTP verification &rarr; instant access to Student Dashboard &amp; Profile Wizard.</p>
            </div>
            <span class="v33-pill v33-pill--ok">Fast Track</span>
          </div>
          ${errMsg ? `<div class="portal-message portal-message--error" style="margin-bottom:10px;">${esc(errMsg)}</div>` : ""}
          <form data-v33-qreg-form>
            <div class="v33-form-grid">
              <div class="v33-field"><label>Full Name *</label><input name="fullName" required placeholder="Student full name"></div>
              <div class="v33-field"><label>Mobile Number *</label><input name="phone" required inputmode="tel" placeholder="10-digit mobile number"></div>
              <div class="v33-field"><label>Referral Code (Optional)</label><input name="referralCode" value="${esc(storedRef)}" placeholder="e.g. YTR-STU01" style="text-transform:uppercase;"></div>
              <div class="v33-field"><label>OTP Channel</label>
                <select name="otpChannel" data-v33-qreg-ch>
                  <option value="sms">Mobile SMS OTP</option>
                  <option value="email">Email OTP (Optional Email)</option>
                </select>
              </div>
              <div class="v33-field" data-v33-qreg-email-wrap hidden><label>Email (for Email OTP)</label><input name="email" type="email" placeholder="student@example.com"></div>
            </div>
            <button type="submit" class="v33-btn" style="width:100%;">Send Verification OTP &amp; Continue</button>
          </form>
        </div>`;

      const chSel = container.querySelector("[data-v33-qreg-ch]");
      const emailWrap = container.querySelector("[data-v33-qreg-email-wrap]");
      chSel?.addEventListener("change", () => {
        if (emailWrap) emailWrap.hidden = chSel.value !== "email";
      });
      container.querySelector("[data-v33-qreg-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        errMsg = "";
        try {
          const res = await apiV33("/api/v33/auth/quick-register", {
            method: "POST",
            body: {
              fullName: String(fd.get("fullName") || "").trim(),
              phone: String(fd.get("phone") || "").trim(),
              referralCode: String(fd.get("referralCode") || "").trim().toUpperCase(),
              otpChannel: String(fd.get("otpChannel") || "sms"),
              email: String(fd.get("email") || "").trim(),
            },
          });
          pendingPhone = res.phone || res.target || String(fd.get("phone") || "").trim();
          pendingEmail = String(fd.get("email") || "").trim();
          pendingChannel = res.otpChannel || "sms";
          infoMsg = res.message || "6-digit OTP sent.";
          if (res.devOtp || res.previewOtp) infoMsg += ` (Verification OTP: ${res.devOtp || res.previewOtp})`;
          step = "otp";
          draw();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      // Collapse legacy 10-field registration form into an expandable option so 3-field quick register is clean & primary
      const legacyForm = container.parentElement?.querySelector("form[data-reg-form]");
      if (legacyForm && !legacyForm.hasAttribute("data-v33-toggle-wired")) {
        legacyForm.setAttribute("data-v33-toggle-wired", "1");
        legacyForm.hidden = true;
        const toggleWrap = document.createElement("div");
        toggleWrap.style.cssText = "margin-top:10px;text-align:center;";
        toggleWrap.innerHTML = `<button type="button" class="v33-btn v33-btn--quiet" data-v33-legacy-toggle style="font-size:12px;">Or use Full Classic Registration Form (with Password)</button>`;
        legacyForm.parentNode.insertBefore(toggleWrap, legacyForm);
        toggleWrap.querySelector("[data-v33-legacy-toggle]")?.addEventListener("click", (ev) => {
          legacyForm.hidden = !legacyForm.hidden;
          ev.currentTarget.textContent = legacyForm.hidden
            ? "Or use Full Classic Registration Form (with Password)"
            : "Hide Classic Registration Form";
        });
      }
    }

    draw();
  }

  /* ==========================================================================
   * 2. STUDENT PROFILE COMPLETION WIZARD (0% - 100%)
   * ========================================================================== */
  async function mountStudentProfileWizard(container, onSaved) {
    if (!container) return;
    injectStyles();
    try {
      const data = await apiV33("/api/v33/student/profile-wizard");
      const completion = data.completion || { percent: 0, isComplete: false, checks: [] };
      const profile = data.profile || {};
      const catalog = data.subjectCatalog || {};
      const branches = data.branches || [];
      const classOptions = data.classes || ["6th", "7th", "8th", "9th", "10th", "11th", "12th"];
      const normClassKey = (v) => String(v || "10").replace(/[^0-9]/g, "") || "10";
      let selectedClassNum = normClassKey(profile.classLevel || "10th");
      let selectedSubjects = Array.isArray(profile.subjects) ? [...profile.subjects] : [];

      function renderWizard() {
        const subjectList = catalog[selectedClassNum] || catalog["10"] || ["Maths", "Science", "English"];
        container.innerHTML = `
          <div class="v33-card" data-testid="v33-profile-wizard">
            <div class="v33-header-row">
              <div>
                <h3 class="v33-title">Profile Completion Wizard (${completion.percent}%)</h3>
                <p class="v33-sub">${completion.isComplete ? "100% Profile Completed — personalized study plans & fee calculators unlocked!" : "Complete your address, school, board, class & subjects. Parent Name/Mobile are optional and never block access."}</p>
              </div>
              ${completion.isComplete ? `<span class="v33-pill v33-pill--ok">100% Completed Badge</span>` : `<span class="v33-pill v33-pill--warn">${completion.percent}% Done</span>`}
            </div>
            <div class="v33-progress-track"><div class="v33-progress-fill" style="width:${completion.percent}%;"></div></div>
            <div class="v33-chip-group" style="margin-bottom:10px;">
              ${(completion.checks || []).map((c) => `<span class="v33-pill ${c.done ? "v33-pill--ok" : ""}">${c.done ? "✓ " : "○ "}${esc(c.label)}</span>`).join("")}
            </div>
            <form data-v33-wizard-form style="margin-top:10px;">
              <div class="v33-form-grid">
                <div class="v33-field"><label>Class (6th–12th) *</label>
                  <select name="classLevel" data-v33-wiz-class>
                    ${classOptions.map((c) => `<option value="Class ${esc(c)}"${normClassKey(c) === selectedClassNum ? " selected" : ""}>Class ${esc(c)}</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>Board *</label>
                  <select name="board">
                    ${(data.boards || ["CBSE", "ICSE", "UP Board", "State Board"]).map((b) => `<option value="${esc(b)}"${b === (profile.board || "CBSE") ? " selected" : ""}>${esc(b)}</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>Preferred Branch *</label>
                  <select name="branchId">
                    ${branches.map((br) => `<option value="${br.id}"${Number(br.id) === Number(profile.branchId) ? " selected" : ""}>${esc(br.name)} (${esc(br.city)})</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>School Name *</label><input name="schoolName" value="${esc(profile.schoolName || "")}" placeholder="Your school name"></div>
                <div class="v33-field"><label>Full Address *</label><input name="address" value="${esc(profile.address || "")}" placeholder="House/Street, City"></div>
                <div class="v33-field"><label>Parent Name (Optional)</label><input name="parentName" value="${esc(profile.parentName || "")}" placeholder="Optional — never blocks access"></div>
                <div class="v33-field"><label>Parent Mobile (Optional)</label><input name="parentPhone" value="${esc(profile.parentPhone || "")}" inputmode="tel" placeholder="Optional 10-digit mobile"></div>
              </div>
              <div class="v33-field" style="margin-bottom:12px;">
                <label>Dynamic Subjects for Class ${esc(selectedClassNum)}th (Select 1 or more)</label>
                <div class="v33-chip-group" data-v33-wiz-subjects>
                  ${subjectList.map((subj) => {
                    const checked = selectedSubjects.includes(subj);
                    return `<label class="v33-chip ${checked ? "is-selected" : ""}"><input type="checkbox" name="subjects" value="${esc(subj)}"${checked ? " checked" : ""}> ${esc(subj)}</label>`;
                  }).join("")}
                </div>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                <button type="submit" class="v33-btn">Save Profile Progress</button>
                <button type="button" class="v33-btn v33-btn--gold" data-v33-open-checkout>Dynamic Fee &amp; Subject Checkout</button>
              </div>
            </form>
          </div>`;

        container.querySelector("[data-v33-wiz-class]")?.addEventListener("change", (e) => {
          selectedClassNum = normClassKey(e.target.value);
          const allowed = catalog[selectedClassNum] || [];
          selectedSubjects = selectedSubjects.filter((s) => allowed.includes(s));
          renderWizard();
        });
        container.querySelectorAll('[data-v33-wiz-subjects] input[type="checkbox"]').forEach((cb) => {
          cb.addEventListener("change", () => {
            cb.closest(".v33-chip")?.classList.toggle("is-selected", cb.checked);
            selectedSubjects = Array.from(container.querySelectorAll('[data-v33-wiz-subjects] input:checked')).map((el) => el.value);
          });
        });
        container.querySelector("[data-v33-open-checkout]")?.addEventListener("click", () => openDynamicCheckoutModal({ classNumber: selectedClassNum, subjects: selectedSubjects }));
        container.querySelector("[data-v33-wizard-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            const res = await apiV33("/api/v33/student/profile-wizard", {
              method: "POST",
              body: {
                classLevel: fd.get("classLevel"),
                board: fd.get("board"),
                branchId: Number(fd.get("branchId") || 1),
                schoolName: fd.get("schoolName"),
                address: fd.get("address"),
                parentName: fd.get("parentName"),
                parentPhone: fd.get("parentPhone"),
                subjects: selectedSubjects,
              },
            });
            Object.assign(completion, res.completion || {});
            Object.assign(profile, {
              classLevel: fd.get("classLevel"),
              board: fd.get("board"),
              branchId: Number(fd.get("branchId") || 1),
              schoolName: fd.get("schoolName"),
              address: fd.get("address"),
              parentName: fd.get("parentName"),
              parentPhone: fd.get("parentPhone"),
              subjects: selectedSubjects,
            });
            toast(res.message || `Profile saved (${completion.percent}% complete)!`);
            renderWizard();
            if (typeof onSaved === "function") onSaved();
          } catch (err) {
            toast(err.message, "error");
          }
        });
      }

      renderWizard();
    } catch {
      // silent if unauthenticated
    }
  }

  /* ==========================================================================
   * 3. STUDENT PANEL — ADVANCED INVOICE & PAYMENT SECTION
   * ========================================================================== */
  async function mountStudentFinance(container, onUpdated) {
    if (!container) return;
    injectStyles();
    container.innerHTML = `<div class="v33-card"><p class="v33-sub">Loading your financial summary, invoices &amp; payment history...</p></div>`;
    try {
      const data = await apiV33("/api/v33/student/finance");
      const s = data.summary || {};
      const invoices = data.invoices || [];
      const payments = data.payments || [];

      container.innerHTML = `
        <div class="v33-card" data-testid="v33-student-finance">
          <div class="v33-header-row">
            <div>
              <h3 class="v33-title">Advanced Invoice &amp; Payment Summary</h3>
              <p class="v33-sub">Verified balance tracking — unverified payments stay Pending until confirmed by Accounts/Razorpay.</p>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              ${s.pendingAmount > 0 ? `<button type="button" class="v33-btn" data-v33-pay-now="full">Pay Full (${inr(s.pendingAmount)})</button>` : ""}
              ${s.pendingAmount > 0 ? `<button type="button" class="v33-btn v33-btn--gold" data-v33-pay-now="part">Part Payment</button>` : ""}
              <button type="button" class="v33-btn v33-btn--quiet" data-v33-add-course-checkout>+ Add Subjects / Upgrade</button>
            </div>
          </div>

          <div class="v33-kpi-grid">
            <div class="v33-kpi v33-kpi--accent"><span>Total Course Fees</span><strong>${inr(s.totalCourseFees)}</strong></div>
            <div class="v33-kpi v33-kpi--gold"><span>Amount Paid (Verified)</span><strong>${inr(s.amountPaid)}</strong></div>
            <div class="v33-kpi"><span>Pending Amount</span><strong>${inr(s.pendingAmount)}</strong></div>
            <div class="v33-kpi"><span>Payment Status</span><strong>${statusPill(s.paymentStatus)}</strong></div>
            <div class="v33-kpi"><span>Verification Status</span><strong>${statusPill(s.verificationStatus)}</strong></div>
            <div class="v33-kpi"><span>Course Duration</span><strong>${esc(s.courseDuration || "12 Months")}</strong></div>
            <div class="v33-kpi"><span>Course Expiry Date</span><strong>${esc(s.courseExpiryDate || "Active Plan")}</strong></div>
            <div class="v33-kpi"><span>Due Date</span><strong>${esc(s.dueDate || "-")}</strong></div>
          </div>

          <h4 style="margin:14px 0 8px;font-size:14px;">Invoices (${invoices.length})</h4>
          <div class="v33-table-wrap">
            <table class="v33-table">
              <thead><tr><th>Invoice #</th><th>Course / Plan</th><th>Net Fee</th><th>Paid</th><th>Pending</th><th>Due Date</th><th>Status</th><th>PDF</th></tr></thead>
              <tbody>
                ${invoices.map((inv) => `
                  <tr>
                    <td><strong>${esc(inv.invoice_number)}</strong></td>
                    <td>${esc(inv.course_title || inv.title || "Course Fee")}</td>
                    <td>${inr(inv.net_amount)}</td>
                    <td>${inr(inv.paid_amount)}</td>
                    <td><strong>${inr(inv.pending_amount)}</strong></td>
                    <td>${esc(inv.due_date || "-")}</td>
                    <td>${statusPill(inv.status)}</td>
                    <td><a class="v33-btn v33-btn--quiet" href="/api/v33/student/invoice/${inv.id}/pdf" target="_blank" rel="noopener">Invoice PDF</a></td>
                  </tr>
                `).join("") || `<tr><td colspan="8" style="text-align:center;color:var(--pt-muted);">No invoices generated yet.</td></tr>`}
              </tbody>
            </table>
          </div>

          <h4 style="margin:14px 0 8px;font-size:14px;">Payment &amp; Verification History (${payments.length})</h4>
          <div class="v33-table-wrap">
            <table class="v33-table">
              <thead><tr><th>Payment Date</th><th>Amount</th><th>Mode</th><th>Transaction ID</th><th>Verification</th><th>Payment Status</th><th>Receipt</th></tr></thead>
              <tbody>
                ${payments.map((p) => `
                  <tr>
                    <td>${esc(String(p.paid_at || p.created_at || "").slice(0, 10))}</td>
                    <td><strong>${inr(p.amount)}</strong></td>
                    <td>${esc(p.payment_method || "upi")}</td>
                    <td><code>${esc(p.transaction_id || "-")}</code></td>
                    <td>${statusPill(p.verification_status)}</td>
                    <td>${statusPill(p.payment_status)}</td>
                    <td>${p.verification_status === "verified" ? `<a class="v33-btn v33-btn--quiet" href="/api/v33/student/receipt/${p.id}/pdf" target="_blank" rel="noopener">Receipt PDF</a>` : `<span class="v33-sub">Pending verification</span>`}</td>
                  </tr>
                `).join("") || `<tr><td colspan="7" style="text-align:center;color:var(--pt-muted);">No payments recorded yet.</td></tr>`}
              </tbody>
            </table>
          </div>
        </div>
      `;

      container.querySelectorAll("[data-v33-pay-now]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const mode = btn.getAttribute("data-v33-pay-now");
          const openInv = invoices.find((i) => i.pending_amount > 0) || invoices[0];
          openModal({
            title: mode === "part" ? "Submit Part Payment" : "Submit Full Fee Payment",
            narrow: true,
            bodyHtml: `
              <form data-v33-pay-form>
                <div class="v33-form-grid">
                  <div class="v33-field">
                    <label>Invoice</label>
                    <select name="feeRecordId">
                      ${invoices.map((i) => `<option value="${i.id}"${openInv && i.id === openInv.id ? " selected" : ""}>${esc(i.invoice_number)} — Pending ${inr(i.pending_amount)}</option>`).join("")}
                    </select>
                  </div>
                  <div class="v33-field">
                    <label>Payment Amount (₹) *</label>
                    <input name="amount" type="number" min="${Math.min(100, Math.max(1, s.pendingAmount))}" max="${Math.max(1, s.pendingAmount)}" value="${mode === "part" ? Math.min(s.pendingAmount, Math.max(Math.min(500, s.pendingAmount), Math.round(s.pendingAmount / 2))) : s.pendingAmount}" required>
                  </div>
                  <div class="v33-field">
                    <label>Payment Mode</label>
                    <select name="paymentMethod">
                      <option value="upi">UPI Transfer</option>
                      <option value="bank_transfer">Bank Transfer (NEFT/IMPS)</option>
                      <option value="razorpay">Online Gateway (Razorpay)</option>
                      <option value="cash">Centre Cash Desk</option>
                    </select>
                  </div>
                  <div class="v33-field">
                    <label>UTR / Transaction Reference *</label>
                    <input name="utrReference" required placeholder="Enter UPI UTR or Txn Ref">
                  </div>
                </div>
                <p class="v33-sub" style="margin-bottom:12px;">Your payment is saved as <strong>Pending Verification</strong>. Invoice balances &amp; Receipt PDF unlock automatically once verified.</p>
                <div style="display:flex;justify-content:flex-end;gap:8px;">
                  <button type="button" class="v33-btn v33-btn--quiet" data-v33-close>Cancel</button>
                  <button type="submit" class="v33-btn">Submit Payment for Verification</button>
                </div>
              </form>
            `,
            onMount: (backdrop, close) => {
              backdrop.querySelector("[data-v33-pay-form]")?.addEventListener("submit", async (e) => {
                e.preventDefault();
                const fd = new FormData(e.target);
                try {
                  const res = await apiV33("/api/v33/student/pay", {
                    method: "POST",
                    body: {
                      feeRecordId: Number(fd.get("feeRecordId") || 0) || undefined,
                      amount: Number(fd.get("amount")),
                      paymentMode: mode,
                      paymentMethod: fd.get("paymentMethod"),
                      utrReference: String(fd.get("utrReference") || "").trim(),
                    },
                  });
                  toast(res.message || "Payment submitted as Pending Verification.");
                  close();
                  mountStudentFinance(container, onUpdated);
                  if (typeof onUpdated === "function") onUpdated();
                } catch (err) {
                  toast(err.message, "error");
                }
              });
            },
          });
        });
      });

      container.querySelector("[data-v33-add-course-checkout]")?.addEventListener("click", () => openDynamicCheckoutModal());
    } catch (err) {
      container.innerHTML = `<div class="v33-card"><p class="v33-sub">Could not load v3.3 finance summary: ${esc(err.message)}</p></div>`;
    }
  }

  /* ==========================================================================
   * 4. STUDENT SMART RECOMMENDATIONS, COUNTDOWN OFFERS, UPGRADE & ADD-ONS
   * ========================================================================== */
  async function mountStudentRecommendations(container) {
    if (!container) return;
    injectStyles();
    startCountdownTicker();
    try {
      const data = await apiV33("/api/v33/student/recommendations");
      const offers = data.activeOffers || [];
      const recs = data.recommendations || [];
      const alsoBought = data.alsoBought || [];
      const bundles = data.bundles || [];
      const addons = data.addons || [];
      const gp = data.gamifiedPath || { progressPercent: 0, prompt: "" };

      container.innerHTML = `
        <div class="v33-card" data-testid="v33-student-recs">
          ${offers.map((o) => `
            <div class="v33-countdown-banner" data-testid="v33-promo-countdown">
              <div>
                <div style="font-size:11.5px;text-transform:uppercase;letter-spacing:.6px;color:#FDE68A;font-weight:700;">Limited-Time Offer ${o.code ? `· Code: ${esc(o.code)}` : ""}</div>
                <strong style="font-size:15.5px;display:block;margin-top:2px;">${esc(o.bannerText || o.title)}</strong>
              </div>
              <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span class="v33-countdown-clock" data-v33-countdown="${esc(o.endAt)}">Offer Ends In --:--:--</span>
                <button type="button" class="v33-btn v33-btn--gold" data-v33-claim-offer="${esc(o.code || "")}">Claim Offer</button>
              </div>
            </div>
          `).join("")}

          <div class="v33-header-row">
            <div>
              <h3 class="v33-title">Smart Learning Path &amp; Personalized Recommendations</h3>
              <p class="v33-sub">Driven by your real class (${esc(data.studentClass || "-")}), board (${esc(data.board || "-")}), actual test scores &amp; verified enrollments.</p>
            </div>
            <button type="button" class="v33-btn" data-v33-open-dyn-checkout>Open Dynamic Checkout Calculator</button>
          </div>

          <div class="v33-kpi" style="margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span>Gamified Learning Path Progress</span>
              <strong>${Number(gp.progressPercent || 0)}% Complete</strong>
            </div>
            <div class="v33-progress-track"><div class="v33-progress-fill" style="width:${Number(gp.progressPercent || 0)}%;"></div></div>
            <div class="v33-sub">${esc(gp.prompt || "")}</div>
          </div>

          ${recs.length ? `
            <h4 style="margin:12px 0 8px;font-size:14px;">Recommended For You</h4>
            <div class="v33-grid-3" style="margin-bottom:14px;">
              ${recs.slice(0, 6).map((c) => `
                <div class="v33-item-card">
                  <div>
                    <span class="v33-pill v33-pill--warn">${esc(c.reason || c.category || "Recommended")}</span>
                    <strong style="display:block;margin-top:6px;font-size:14px;">${esc(c.title)}</strong>
                    <div class="v33-sub">${inr(c.monthlyFee || c.monthly_fee || 0)}/mo · ${esc(c.category || "Course")}</div>
                  </div>
                  <button type="button" class="v33-btn v33-btn--quiet" data-v33-pick-course="${c.id || ""}">Calculate Fee / Enroll</button>
                </div>
              `).join("")}
            </div>
          ` : ""}

          ${alsoBought.length ? `
            <h4 style="margin:12px 0 8px;font-size:14px;">Students Also Bought (Verified Enrollments)</h4>
            <div class="v33-grid-3" style="margin-bottom:14px;">
              ${alsoBought.map((ab) => `
                <div class="v33-item-card">
                  <div>
                    <strong>${esc(ab.title)}</strong>
                    <div class="v33-sub">${Number(ab.coCount || ab.co_enrollments || 0)} peer enrollment(s) · ${inr(ab.monthlyFee || ab.monthly_fee || 0)}/mo</div>
                  </div>
                  <button type="button" class="v33-btn v33-btn--quiet" data-v33-pick-course="${ab.id}">Add to Plan</button>
                </div>
              `).join("")}
            </div>
          ` : ""}

          ${bundles.length ? `
            <h4 style="margin:12px 0 8px;font-size:14px;">Smart Value Bundles &amp; One-Click Upgrade</h4>
            <div class="v33-grid-3" style="margin-bottom:14px;">
              ${bundles.slice(0, 6).map((b) => `
                <div class="v33-item-card">
                  <div>
                    <span class="v33-pill v33-pill--ok">Save ${Number(b.discountPercent || b.discount_percent || 0)}%</span>
                    <strong style="display:block;margin-top:6px;">${esc(b.name)}</strong>
                    <div class="v33-sub">${esc(b.description || "")}</div>
                  </div>
                  <button type="button" class="v33-btn" data-v33-upgrade-bundle="${b.id}">One-Click Upgrade Quote</button>
                </div>
              `).join("")}
            </div>
          ` : ""}

          ${addons.length ? `
            <h4 style="margin:12px 0 8px;font-size:14px;">Add-On Study Products</h4>
            <div class="v33-grid-3">
              ${addons.slice(0, 6).map((a) => `
                <div class="v33-item-card">
                  <div>
                    <strong>${esc(a.title || a.name)}</strong>
                    <div class="v33-sub">${esc(a.category || a.addon_type || "Add-On")} · ${inr(a.effectivePrice || a.price)}</div>
                  </div>
                  <button type="button" class="v33-btn v33-btn--quiet" data-v33-pick-addon="${a.id}">Add to Checkout</button>
                </div>
              `).join("")}
            </div>
          ` : ""}
        </div>
      `;

      container.querySelector("[data-v33-open-dyn-checkout]")?.addEventListener("click", () => openDynamicCheckoutModal());
      container.querySelectorAll("[data-v33-claim-offer]").forEach((b) => {
        b.addEventListener("click", () => openDynamicCheckoutModal({ promoCode: b.getAttribute("data-v33-claim-offer") || "" }));
      });
      container.querySelectorAll("[data-v33-pick-course]").forEach((b) => {
        const cid = Number(b.getAttribute("data-v33-pick-course") || 0);
        b.addEventListener("click", () => openDynamicCheckoutModal({ preselectedCourseId: cid || null }));
      });
      container.querySelectorAll("[data-v33-upgrade-bundle]").forEach((b) => {
        b.addEventListener("click", () => openDynamicCheckoutModal({ preselectedBundleId: Number(b.getAttribute("data-v33-upgrade-bundle")), isUpgrade: true }));
      });
      container.querySelectorAll("[data-v33-pick-addon]").forEach((b) => {
        b.addEventListener("click", () => openDynamicCheckoutModal({ preselectedAddonId: Number(b.getAttribute("data-v33-pick-addon")) }));
      });
    } catch {
      // silent
    }
  }

  /* ==========================================================================
   * 5. INTERACTIVE REAL-TIME DYNAMIC CHECKOUT & AUTOMATIC INVOICE CALCULATOR
   * ========================================================================== */
  async function openDynamicCheckoutModal(opts = {}) {
    try {
      const catalog = await apiV33("/api/v33/pricing/catalog");
      const courses = catalog.courses || [];
      const bundles = catalog.bundles || [];
      const addons = catalog.addons || [];
      const branches = catalog.branches || [];
      const scholarships = catalog.scholarships || [];
      const subjectCatalog = catalog.subjectCatalog || {};

      const state = {
        classNumber: String(opts.classNumber || "10").replace(/[^0-9]/g, "") || "10",
        subjects: Array.isArray(opts.subjects) ? [...opts.subjects] : [],
        courseIds: opts.preselectedCourseId ? [opts.preselectedCourseId] : [],
        bundleId: opts.preselectedBundleId || "",
        addonIds: opts.preselectedAddonId ? [opts.preselectedAddonId] : [],
        durationMonths: 6,
        branchId: branches[0]?.id || 1,
        scholarshipCode: "",
        promoCode: opts.promoCode || "",
        couponCode: opts.couponCode || "",
        isUpgrade: Boolean(opts.isUpgrade),
      };

      openModal({
        title: "Dynamic Course, Subject & Bundle Checkout",
        bodyHtml: `
          <div class="v33-grid-2">
            <div>
              <div class="v33-form-grid">
                <div class="v33-field"><label>Branch / Franchise Pricing</label>
                  <select data-co-branch>
                    ${branches.map((br) => `<option value="${br.id}">${esc(br.name)} (${esc(br.city || "")})</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>School Class (for Subject Pricing)</label>
                  <select data-co-class>
                    ${["6", "7", "8", "9", "10", "11", "12"].map((c) => `<option value="${c}"${c === state.classNumber ? " selected" : ""}>Class ${c}th</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>Duration Package</label>
                  <select data-co-duration>
                    <option value="1">1 Month</option>
                    <option value="3">3 Months (Quarterly)</option>
                    <option value="6" selected>6 Months (Half-Yearly)</option>
                    <option value="9">9 Months</option>
                    <option value="12">12 Months (Annual)</option>
                  </select>
                </div>
                <div class="v33-field"><label>Optional Bundle Package</label>
                  <select data-co-bundle>
                    <option value="">-- Individual Courses / Subjects --</option>
                    ${bundles.map((b) => `<option value="${b.id}"${Number(b.id) === Number(state.bundleId) ? " selected" : ""}>${esc(b.name)} (${b.discountPercent ?? b.discount_percent ?? 0}% OFF)</option>`).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>Scholarship (Optional)</label>
                  <select data-co-scholarship>
                    <option value="">None</option>
                    ${scholarships.map((sc) => {
                      const dType = sc.discountType ?? sc.discount_type;
                      const dVal = sc.discountValue ?? sc.discount_value ?? 0;
                      return `<option value="${esc(sc.code)}">${esc(sc.name)} (${dType === "fixed" ? inr(dVal) : `${dVal}%`})</option>`;
                    }).join("")}
                  </select>
                </div>
                <div class="v33-field"><label>Promo / Coupon Code</label><input data-co-coupon value="${esc(state.promoCode || state.couponCode)}" placeholder="Optional promo/coupon"></div>
              </div>

              <div class="v33-field" style="margin-bottom:10px;">
                <label class="v33-chip ${state.isUpgrade ? "is-selected" : ""}">
                  <input type="checkbox" data-co-upgrade${state.isUpgrade ? " checked" : ""}> <span>Apply Smart Upgrade Credit (Deduct Eligible Paid Amount)</span>
                </label>
              </div>

              <div class="v33-field" style="margin-bottom:10px;">
                <label>School Subjects (Multi-Subject Discount Auto-Applies)</label>
                <div class="v33-chip-group" data-co-subjects></div>
              </div>

              <div class="v33-field" style="margin-bottom:10px;">
                <label>Competitive / Tech / Spoken English Courses</label>
                <div class="v33-chip-group" style="max-height:150px;overflow-y:auto;padding:8px;border:1px solid var(--pt-border);border-radius:10px;" data-co-courses>
                  ${courses.map((c) => {
                    const checked = state.courseIds.includes(c.id);
                    const rate = c.effectiveMonthly ?? c.monthlyFee ?? c.monthly_fee ?? 0;
                    return `<label class="v33-chip ${checked ? "is-selected" : ""}"><input type="checkbox" value="${c.id}"${checked ? " checked" : ""}> <span>${esc(c.title)} (${inr(rate)}/mo)</span></label>`;
                  }).join("")}
                </div>
              </div>

              <div class="v33-field">
                <label>Add-On Products (Notes, PYQs, Test Series, Doubt Packs)</label>
                <div class="v33-chip-group" data-co-addons>
                  ${addons.map((a) => {
                    const checked = state.addonIds.includes(a.id);
                    const p = a.effectivePrice ?? ((a.promoPrice ?? a.promo_price) > 0 ? (a.promoPrice ?? a.promo_price) : a.price);
                    return `<label class="v33-chip ${checked ? "is-selected" : ""}"><input type="checkbox" value="${a.id}"${checked ? " checked" : ""}> <span>${esc(a.title)} (${inr(p)})</span></label>`;
                  }).join("")}
                </div>
              </div>
            </div>

            <div>
              <div class="v33-card" style="margin-bottom:0;" data-co-quote-box>
                <h3 class="v33-title">Live Server-Validated Price Breakdown</h3>
                <p class="v33-sub">Select subjects, courses, a bundle, or add-ons to calculate your exact invoice.</p>
              </div>
            </div>
          </div>
        `,
        onMount: (backdrop, close) => {
          const quoteBox = backdrop.querySelector("[data-co-quote-box]");
          const subjWrap = backdrop.querySelector("[data-co-subjects]");

          function renderSubjects() {
            const list = subjectCatalog[state.classNumber] || ["Maths", "Science", "English"];
            subjWrap.innerHTML = list.map((s) => {
              const checked = state.subjects.includes(s);
              return `<label class="v33-chip ${checked ? "is-selected" : ""}"><input type="checkbox" value="${esc(s)}"${checked ? " checked" : ""}> ${esc(s)}</label>`;
            }).join("");
            subjWrap.querySelectorAll("input").forEach((cb) => {
              cb.addEventListener("change", () => {
                cb.closest(".v33-chip")?.classList.toggle("is-selected", cb.checked);
                state.subjects = Array.from(subjWrap.querySelectorAll("input:checked")).map((el) => el.value);
                refreshQuote();
              });
            });
          }

          async function refreshQuote() {
            if (!state.subjects.length && !state.courseIds.length && !state.bundleId && !state.addonIds.length) {
              quoteBox.innerHTML = `<h3 class="v33-title">Live Server-Validated Price Breakdown</h3><p class="v33-sub">Select at least one subject, course, bundle, or add-on to calculate your quote.</p>`;
              return;
            }
            quoteBox.innerHTML = `<p class="v33-sub">Recalculating server-validated quote...</p>`;
            try {
              const res = await apiV33("/api/v33/checkout/quote", {
                method: "POST",
                body: {
                  classNumber: state.classNumber,
                  subjects: state.subjects,
                  courseIds: state.courseIds,
                  bundleId: state.bundleId ? Number(state.bundleId) : null,
                  addonIds: state.addonIds,
                  durationMonths: Number(state.durationMonths),
                  branchId: Number(state.branchId),
                  scholarshipCode: state.scholarshipCode,
                  promoCode: state.promoCode,
                  couponCode: state.couponCode,
                  isUpgrade: state.isUpgrade,
                },
              });
              const q = res.quote || {};
              const br = q.breakdown || {};
              quoteBox.innerHTML = `
                <h3 class="v33-title" style="margin-bottom:10px;">Live Server-Validated Quote</h3>
                <div class="v33-kpi-grid" style="grid-template-columns:repeat(auto-fit,minmax(135px,1fr));">
                  <div class="v33-kpi"><span>Gross Base${q.addonsTotal > 0 ? " (incl. Add-Ons)" : ""}</span><strong>${inr(q.baseAmount || 0)}</strong></div>
                  <div class="v33-kpi"><span>Duration Discount</span><strong>-${inr(br.durationDiscount || 0)}</strong></div>
                  <div class="v33-kpi"><span>Multi-Subject / Bundle</span><strong>-${inr((br.multiSubjectDiscount || 0) + (br.bundleSavings || 0))}</strong></div>
                  <div class="v33-kpi"><span>Scholarship / Promo / Coupon</span><strong>-${inr((br.scholarshipDiscount || 0) + (br.promoDiscount || 0) + (br.couponDiscount || 0))}</strong></div>
                  ${br.upgradeCredit > 0 ? `<div class="v33-kpi v33-kpi--gold"><span>Smart Upgrade Credit</span><strong>-${inr(br.upgradeCredit)}</strong></div>` : ""}
                  <div class="v33-kpi v33-kpi--accent"><span>Final Payable</span><strong>${inr(q.finalPayableAmount || 0)}</strong></div>
                </div>
                ${(q.warnings || []).map((w) => `<p class="v33-sub" style="color:#92400e;margin-bottom:6px;">${esc(w)}</p>`).join("")}
                <p class="v33-sub" style="margin-bottom:12px;">Total Savings: <strong>${inr(br.totalDiscountAmount || 0)}</strong> · Strictly validated by backend.</p>
                <button type="button" class="v33-btn" style="width:100%;" data-co-confirm>Generate Invoice &amp; Proceed (${inr(q.finalPayableAmount || 0)})</button>
              `;
              quoteBox.querySelector("[data-co-confirm]")?.addEventListener("click", async () => {
                try {
                  const created = await apiV33("/api/v33/checkout/create-order", {
                    method: "POST",
                    body: {
                      classNumber: state.classNumber,
                      subjects: state.subjects,
                      courseIds: state.courseIds,
                      bundleId: state.bundleId ? Number(state.bundleId) : null,
                      addonIds: state.addonIds,
                      durationMonths: Number(state.durationMonths),
                      branchId: Number(state.branchId),
                      scholarshipCode: state.scholarshipCode,
                      promoCode: state.promoCode,
                      couponCode: state.couponCode,
                      isUpgrade: state.isUpgrade,
                    },
                  });
                  toast(`Invoice ${created.invoiceNumber} created for ${inr(created.quote?.finalPayableAmount || 0)}!`);
                  close();
                  const finEl = document.querySelector("[data-v33-student-finance]");
                  if (finEl) mountStudentFinance(finEl);
                } catch (err) {
                  toast(err.message, "error");
                }
              });
            } catch (err) {
              quoteBox.innerHTML = `<p class="v33-sub" style="color:#b91c1c;">${esc(err.message)}</p>`;
            }
          }

          backdrop.querySelector("[data-co-branch]")?.addEventListener("change", (e) => { state.branchId = Number(e.target.value); refreshQuote(); });
          backdrop.querySelector("[data-co-class]")?.addEventListener("change", (e) => { state.classNumber = e.target.value; state.subjects = []; renderSubjects(); refreshQuote(); });
          backdrop.querySelector("[data-co-duration]")?.addEventListener("change", (e) => { state.durationMonths = Number(e.target.value); refreshQuote(); });
          backdrop.querySelector("[data-co-bundle]")?.addEventListener("change", (e) => { state.bundleId = e.target.value; refreshQuote(); });
          backdrop.querySelector("[data-co-scholarship]")?.addEventListener("change", (e) => { state.scholarshipCode = e.target.value; refreshQuote(); });
          backdrop.querySelector("[data-co-coupon]")?.addEventListener("change", (e) => {
            const v = e.target.value.trim().toUpperCase();
            state.promoCode = v;
            state.couponCode = v;
            refreshQuote();
          });
          backdrop.querySelector("[data-co-upgrade]")?.addEventListener("change", (e) => {
            state.isUpgrade = e.target.checked;
            e.target.closest(".v33-chip")?.classList.toggle("is-selected", e.target.checked);
            refreshQuote();
          });
          backdrop.querySelectorAll("[data-co-courses] input").forEach((cb) => {
            cb.addEventListener("change", () => {
              cb.closest(".v33-chip")?.classList.toggle("is-selected", cb.checked);
              state.courseIds = Array.from(backdrop.querySelectorAll("[data-co-courses] input:checked")).map((el) => Number(el.value));
              refreshQuote();
            });
          });
          backdrop.querySelectorAll("[data-co-addons] input").forEach((cb) => {
            cb.addEventListener("change", () => {
              cb.closest(".v33-chip")?.classList.toggle("is-selected", cb.checked);
              state.addonIds = Array.from(backdrop.querySelectorAll("[data-co-addons] input:checked")).map((el) => Number(el.value));
              refreshQuote();
            });
          });

          renderSubjects();
          refreshQuote();
        },
      });
    } catch (err) {
      toast(err.message, "error");
    }
  }

  /* ==========================================================================
   * 6. ADMIN & STAFF — DEDICATED INVOICE MANAGEMENT + AUTOMATED FOLLOW-UP
   * ========================================================================== */
  async function openAdminInvoiceManagement(studentId, onRefresh) {
    const sid = Number(studentId);
    if (!sid) return;

    const { backdrop } = openModal({
      title: `Invoice Management · Student #${sid}`,
      bodyHtml: `<p class="v33-sub">Loading student invoices, payments &amp; follow-up scheduler...</p>`,
    });
    const bodyEl = backdrop.querySelector(".v33-modal-body");

    async function draw() {
      try {
        const data = await apiV33(`/api/v33/admin/students/${sid}/invoices`);
        const st = data.student || {};
        const s = data.summary || {};
        const invoices = data.invoices || [];
        const payments = data.payments || [];
        const followups = data.followups || [];
        const today = new Date().toISOString().slice(0, 10);

        bodyEl.innerHTML = `
          <div class="v33-header-row">
            <div>
              <h3 class="v33-title">${esc(st.fullName || `Student #${sid}`)} (${esc(st.classLevel || "Student")})</h3>
              <p class="v33-sub">${esc(st.email || "")} · ${esc(st.phone || "")} · Roll: ${esc(st.rollNumber || "-")} · ${esc(st.branchName || "")}</p>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <button type="button" class="v33-btn v33-btn--quiet" data-im-msg-preview>Message Preview &amp; Send</button>
            </div>
          </div>

          <div class="v33-kpi-grid" data-testid="v33-admin-invoice-summary">
            <div class="v33-kpi v33-kpi--accent"><span>Total Course Fees</span><strong>${inr(s.totalCourseFees)}</strong></div>
            <div class="v33-kpi v33-kpi--gold"><span>Amount Received (Verified)</span><strong>${inr(s.amountReceived)}</strong></div>
            <div class="v33-kpi"><span>Pending / Outstanding</span><strong>${inr(s.pendingAmount)}</strong></div>
            <div class="v33-kpi"><span>Overdue Fees</span><strong>${inr(s.overdueFees)}</strong></div>
            <div class="v33-kpi"><span>Payment Status</span><strong>${statusPill(s.paymentStatus)}</strong></div>
            <div class="v33-kpi"><span>Verification Status</span><strong>${statusPill(s.verificationStatus)}</strong></div>
            <div class="v33-kpi"><span>Next Due / Last Paid</span><strong>${esc(s.dueDate || "-")} / ${esc(s.lastPaymentDate || "-")}</strong></div>
            <div class="v33-kpi"><span>Next Follow-Up</span><strong>${esc(s.nextFollowUpDate || "-")}</strong></div>
          </div>

          <div class="v33-grid-2">
            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Record Full / Part Payment</h4>
              <form data-im-record-pay>
                <div class="v33-form-grid">
                  <div class="v33-field"><label>Invoice</label>
                    <select name="feeRecordId">
                      ${invoices.map((i) => `<option value="${i.id}">${esc(i.invoice_number)} (Due ${inr(i.pending_amount)})</option>`).join("") || `<option value="">General Account Ledger</option>`}
                    </select>
                  </div>
                  <div class="v33-field"><label>Amount (₹) *</label><input name="amount" type="number" min="1" value="${Math.max(500, s.pendingAmount || 0)}" required></div>
                  <div class="v33-field"><label>Mode</label>
                    <select name="paymentMethod"><option value="upi">UPI</option><option value="cash">Cash Desk</option><option value="bank_transfer">Bank Transfer</option><option value="razorpay">Razorpay</option></select>
                  </div>
                  <div class="v33-field"><label>UTR / Ref No.</label><input name="utrReference" placeholder="Optional txn ref"></div>
                  <div class="v33-field"><label>Verification Action</label>
                    <select name="verifyNow">
                      <option value="0">Save as Pending Verification (Strict)</option>
                      <option value="1">Verify &amp; Issue Receipt Now</option>
                    </select>
                  </div>
                </div>
                <button type="submit" class="v33-btn">Record Payment</button>
              </form>
            </div>

            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Schedule Automated Payment Follow-Up</h4>
              <form data-im-followup-form>
                <div class="v33-form-grid">
                  <div class="v33-field"><label>Follow-Up Date *</label><input name="followUpDate" type="date" value="${today}" required></div>
                  <div class="v33-field"><label>Follow-Up Time *</label><input name="followUpTime" type="time" value="10:00" required></div>
                  <div class="v33-field"><label>Reminder Type *</label>
                    <select name="reminderType">
                      <option value="due_payment">Due Payment Reminder</option>
                      <option value="overdue_alert">Overdue Alert</option>
                      <option value="partial_balance">Part Payment Balance Follow-Up</option>
                      <option value="renewal">Course Renewal Reminder</option>
                    </select>
                  </div>
                  <div class="v33-field"><label>Invoice (Optional)</label>
                    <select name="feeRecordId">
                      <option value="">All Pending Invoices</option>
                      ${invoices.map((i) => `<option value="${i.id}">${esc(i.invoice_number)}</option>`).join("")}
                    </select>
                  </div>
                </div>
                <div class="v33-field" style="margin-bottom:10px;"><label>Custom Message / Note</label><input name="customMessage" placeholder="e.g. Promised to pay balance by Friday"></div>
                <button type="submit" class="v33-btn v33-btn--gold">Schedule Automated Follow-Up (Email + WhatsApp + In-App)</button>
              </form>
            </div>
          </div>

          <h4 style="margin:12px 0 8px;font-size:14px;">Invoices (${invoices.length})</h4>
          <div class="v33-table-wrap">
            <table class="v33-table">
              <thead><tr><th>Invoice #</th><th>Course</th><th>Net Fee</th><th>Paid</th><th>Pending</th><th>Due Date</th><th>Status</th><th>PDF</th></tr></thead>
              <tbody>
                ${invoices.map((i) => `
                  <tr>
                    <td><strong>${esc(i.invoice_number)}</strong></td>
                    <td>${esc(i.course_title || i.title || "-")}</td>
                    <td>${inr(i.net_amount)}</td>
                    <td>${inr(i.paid_amount)}</td>
                    <td><strong>${inr(i.pending_amount)}</strong></td>
                    <td>${esc(i.due_date || "-")}</td>
                    <td>${statusPill(i.status)}</td>
                    <td><a class="v33-btn v33-btn--quiet" href="/api/v33/student/invoice/${i.id}/pdf" target="_blank" rel="noopener">PDF</a></td>
                  </tr>`).join("") || `<tr><td colspan="8" style="text-align:center;">No invoices yet.</td></tr>`}
              </tbody>
            </table>
          </div>

          <h4 style="margin:12px 0 8px;font-size:14px;">Payment Verification &amp; History (${payments.length})</h4>
          <div class="v33-table-wrap">
            <table class="v33-table">
              <thead><tr><th>Date</th><th>Amount</th><th>Mode</th><th>Txn ID</th><th>Verification</th><th>Receipt</th><th>Actions</th></tr></thead>
              <tbody>
                ${payments.map((p) => `
                  <tr>
                    <td>${esc(String(p.paid_at || p.created_at || "").slice(0, 10))}</td>
                    <td><strong>${inr(p.amount)}</strong></td>
                    <td>${esc(p.payment_method)}</td>
                    <td><code>${esc(p.transaction_id || "-")}</code></td>
                    <td>${statusPill(p.verification_status)}</td>
                    <td>${p.verification_status === "verified" ? `<a class="v33-btn v33-btn--quiet" href="/api/v33/student/receipt/${p.id}/pdf" target="_blank" rel="noopener">${esc(p.receipt_number || "PDF")}</a>` : "-"}</td>
                    <td>
                      ${p.verification_status !== "verified" ? `<button type="button" class="v33-btn v33-btn--ok" data-im-verify="${p.id}" data-im-act="verify">Verify</button>` : ""}
                      ${["pending", "pending_verification"].includes(p.verification_status) ? `<button type="button" class="v33-btn v33-btn--danger" data-im-verify="${p.id}" data-im-act="reject">Reject</button>` : ""}
                    </td>
                  </tr>`).join("") || `<tr><td colspan="7" style="text-align:center;">No payments recorded yet.</td></tr>`}
              </tbody>
            </table>
          </div>

          <h4 style="margin:12px 0 8px;font-size:14px;">Scheduled Automated Follow-Ups &amp; Delivery Logs (${followups.length})</h4>
          <div class="v33-table-wrap">
            <table class="v33-table">
              <thead><tr><th>Schedule</th><th>Type</th><th>Status</th><th>Message</th><th>Delivery Log</th><th>Action</th></tr></thead>
              <tbody>
                ${followups.map((f) => `
                  <tr>
                    <td><strong>${esc(f.follow_up_date)} ${esc(f.follow_up_time)}</strong></td>
                    <td>${esc(f.reminder_type)}</td>
                    <td>${statusPill(f.status)}</td>
                    <td>${esc(f.custom_message || "-")}</td>
                    <td><span class="v33-sub">${esc(f.delivery_log_json || "Scheduled")}</span></td>
                    <td>${f.status === "scheduled" ? `<button type="button" class="v33-btn v33-btn--quiet" data-im-run-fu="${f.id}">Dispatch Now</button>` : "Sent"}</td>
                  </tr>`).join("") || `<tr><td colspan="6" style="text-align:center;">No follow-ups scheduled yet.</td></tr>`}
              </tbody>
            </table>
          </div>
        `;

        bodyEl.querySelector("[data-im-msg-preview]")?.addEventListener("click", () => {
          openMessagePreviewModal({ studentId: sid, studentName: st.fullName });
        });

        bodyEl.querySelector("[data-im-record-pay]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await apiV33(`/api/v33/admin/students/${sid}/record-payment`, {
              method: "POST",
              body: {
                feeRecordId: Number(fd.get("feeRecordId") || 0) || undefined,
                amount: Number(fd.get("amount")),
                paymentMethod: fd.get("paymentMethod"),
                utrReference: String(fd.get("utrReference") || "").trim(),
                verifyNow: fd.get("verifyNow") === "1",
              },
            });
            toast("Payment recorded!");
            draw();
            if (typeof onRefresh === "function") onRefresh();
          } catch (err) {
            toast(err.message, "error");
          }
        });

        bodyEl.querySelectorAll("[data-im-verify]").forEach((btn) => {
          btn.addEventListener("click", async () => {
            try {
              await apiV33(`/api/v33/admin/payments/${btn.getAttribute("data-im-verify")}/verify`, {
                method: "POST",
                body: { action: btn.getAttribute("data-im-act") },
              });
              toast("Payment verification updated & balances recalculated!");
              draw();
              if (typeof onRefresh === "function") onRefresh();
            } catch (err) {
              toast(err.message, "error");
            }
          });
        });

        bodyEl.querySelector("[data-im-followup-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await apiV33(`/api/v33/admin/students/${sid}/followups`, {
              method: "POST",
              body: {
                followUpDate: fd.get("followUpDate"),
                followUpTime: fd.get("followUpTime"),
                reminderType: fd.get("reminderType"),
                feeRecordId: Number(fd.get("feeRecordId") || 0) || null,
                customMessage: String(fd.get("customMessage") || "").trim(),
                channels: ["email", "whatsapp", "in_app"],
              },
            });
            toast("Automated follow-up scheduled!");
            draw();
          } catch (err) {
            toast(err.message, "error");
          }
        });

        bodyEl.querySelectorAll("[data-im-run-fu]").forEach((btn) => {
          btn.addEventListener("click", async () => {
            try {
              await apiV33(`/api/v33/admin/followups/${btn.getAttribute("data-im-run-fu")}/run-now`, { method: "POST" });
              toast("Follow-up dispatched across Email, WhatsApp & In-App!");
              draw();
            } catch (err) {
              toast(err.message, "error");
            }
          });
        });
      } catch (err) {
        bodyEl.innerHTML = `<div class="portal-message portal-message--error">${esc(err.message)}</div>`;
      }
    }

    draw();
  }

  /* ==========================================================================
   * 7. LIVE MESSAGE PREVIEW & TEMPLATE SEND MODAL
   * ========================================================================== */
  async function openMessagePreviewModal({ studentId, studentName = "", defaultChannel = "email" } = {}) {
    try {
      const tplRes = await apiV33("/api/v33/admin/message-templates");
      const templates = tplRes.templates || [];
      const selectedTpl = templates[0] || { template_key: "v33_fee_due", subject: "Fee Reminder for {{student_name}}", body_html: "Dear {{student_name}}, pending amount is {{pending_amount}}." };

      openModal({
        title: `Live Message Preview & Send${studentName ? ` · ${studentName}` : ""}`,
        narrow: true,
        bodyHtml: `
          <form data-mp-form>
            <div class="v33-form-grid">
              <div class="v33-field"><label>Student ID *</label><input name="studentId" type="number" value="${Number(studentId || 0) || ""}" required></div>
              <div class="v33-field"><label>Channel</label>
                <select name="channel">
                  <option value="email"${defaultChannel === "email" ? " selected" : ""}>Email (SMTP)</option>
                  <option value="whatsapp"${defaultChannel === "whatsapp" ? " selected" : ""}>WhatsApp Message</option>
                  <option value="in_app"${defaultChannel === "in_app" ? " selected" : ""}>In-App Notification</option>
                </select>
              </div>
              <div class="v33-field"><label>Message Template</label>
                <select name="templateKey" data-mp-tpl>
                  ${templates.map((t) => `<option value="${esc(t.template_key)}">${esc(t.name || t.template_key)}</option>`).join("")}
                </select>
              </div>
              <div class="v33-field"><label>Schedule For Later (Optional)</label><input name="scheduledAt" type="datetime-local"></div>
            </div>
            <div class="v33-field" style="margin-bottom:8px;"><label>Subject (Supports {{student_name}}, {{course}}, {{branch}}, {{fee_amount}}, {{pending_amount}}, {{due_date}})</label><input name="subject" value="${esc(selectedTpl.subject || "")}"></div>
            <div class="v33-field" style="margin-bottom:10px;"><label>Message Body</label><textarea name="bodyHtml" rows="4">${esc((selectedTpl.body_html || "").replace(/<[^>]+>/g, ""))}</textarea></div>
            <div style="margin-bottom:10px;">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                <strong style="font-size:12.5px;">Live Rendered Preview</strong>
                <button type="button" class="v33-btn v33-btn--quiet" data-mp-refresh>Refresh Preview</button>
              </div>
              <div class="v33-preview-box" data-mp-preview>Click "Refresh Preview" to render dynamic placeholders.</div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;">
              <button type="button" class="v33-btn v33-btn--quiet" data-v33-close>Cancel</button>
              <button type="submit" class="v33-btn">Confirm &amp; Send / Schedule</button>
            </div>
          </form>
        `,
        onMount: (backdrop, close) => {
          const form = backdrop.querySelector("[data-mp-form]");
          const previewEl = backdrop.querySelector("[data-mp-preview]");
          const tplSel = backdrop.querySelector("[data-mp-tpl]");

          async function refreshPreview() {
            const fd = new FormData(form);
            const sidVal = Number(fd.get("studentId") || 0);
            if (!sidVal) return;
            try {
              const p = await apiV33("/api/v33/admin/messages/preview", {
                method: "POST",
                body: {
                  studentId: sidVal,
                  templateKey: String(fd.get("templateKey") || ""),
                  subject: String(fd.get("subject") || ""),
                  bodyHtml: String(fd.get("bodyHtml") || ""),
                },
              });
              previewEl.innerHTML = `<strong>Subject:</strong> ${esc(p.preview?.subject || "")}\n\n${esc(p.preview?.plainText || "")}`;
            } catch (err) {
              previewEl.textContent = err.message;
            }
          }

          tplSel?.addEventListener("change", () => {
            const t = templates.find((x) => x.template_key === tplSel.value);
            if (t) {
              form.querySelector('[name="subject"]').value = t.subject || "";
              form.querySelector('[name="bodyHtml"]').value = String(t.body_html || "").replace(/<[^>]+>/g, "");
              refreshPreview();
            }
          });
          backdrop.querySelector("[data-mp-refresh]")?.addEventListener("click", refreshPreview);
          if (studentId) refreshPreview();

          form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(form);
            const rawSched = String(fd.get("scheduledAt") || "").trim();
            try {
              const res = await apiV33("/api/v33/admin/messages/send", {
                method: "POST",
                body: {
                  studentId: Number(fd.get("studentId")),
                  channel: fd.get("channel"),
                  templateKey: fd.get("templateKey"),
                  subject: String(fd.get("subject") || ""),
                  bodyHtml: String(fd.get("bodyHtml") || ""),
                  scheduledAt: rawSched ? new Date(rawSched).toISOString() : "",
                },
              });
              toast(res.scheduled ? "Message scheduled!" : `Message sent via ${fd.get("channel")}!`);
              if (res.preview?.whatsappUrl && fd.get("channel") === "whatsapp") {
                const a = document.createElement("a");
                a.href = res.preview.whatsappUrl;
                a.target = "_blank";
                a.rel = "noopener noreferrer";
                a.click();
              }
              close();
            } catch (err) {
              toast(err.message, "error");
            }
          });
        },
      });
    } catch (err) {
      toast(err.message, "error");
    }
  }

  /* ==========================================================================
   * 8. ADMIN v3.3 DYNAMIC PRICING, CROSS-SELL, TEMPLATES & REVENUE HUB
   * ========================================================================== */
  async function openAdminV33Hub(initialTab = "pricing") {
    let activeTab = initialTab;
    const { backdrop } = openModal({
      title: "Yuitor v3.3 — Dynamic Pricing, Bundles, Cross-Sell & Revenue Analytics Hub",
      bodyHtml: `<div class="v33-tabs" data-hub-tabs></div><div data-hub-body><p class="v33-sub">Loading v3.3 control hub...</p></div>`,
    });
    const tabsEl = backdrop.querySelector("[data-hub-tabs]");
    const bodyEl = backdrop.querySelector("[data-hub-body]");

    const TABS = [
      ["pricing", "School & Courses"],
      ["discounts", "Discounts & Branches"],
      ["bundles", "Bundles & Add-Ons"],
      ["offers", "Offers & Scholarships"],
      ["crosssell", "Cross-Sell Rules"],
      ["messages", "Message Preview Studio"],
      ["analytics", "Revenue & Sales Analytics"],
    ];

    async function draw() {
      tabsEl.innerHTML = TABS.map(([k, label]) => `<button type="button" class="v33-tab ${activeTab === k ? "is-active" : ""}" data-hub-tab="${k}">${esc(label)}</button>`).join("");
      tabsEl.querySelectorAll("[data-hub-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          activeTab = btn.getAttribute("data-hub-tab");
          draw();
        });
      });

      bodyEl.innerHTML = `<p class="v33-sub">Loading ${esc(activeTab)}...</p>`;

      try {
        if (activeTab === "analytics") {
          const res = await apiV33("/api/v33/admin/revenue-analytics");
          const an = res.analytics || {};
          const k = an.kpis || {};
          bodyEl.innerHTML = `
            <div class="v33-header-row">
              <div><h3 class="v33-title">Revenue &amp; Sales Analytics Dashboard</h3><p class="v33-sub">Verified collections, pending fees, branch/course/subject splits &amp; conversion rates.</p></div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <a class="v33-btn v33-btn--gold" href="/api/v33/admin/revenue-analytics/csv" target="_blank" rel="noopener">Download CSV Report</a>
                <button type="button" class="v33-btn v33-btn--quiet" data-v33-run-renewals>Run Renewal Sweep Now</button>
              </div>
            </div>
            <div class="v33-kpi-grid" data-testid="v33-revenue-kpis">
              <div class="v33-kpi v33-kpi--accent"><span>Total Collected</span><strong>${inr(k.totalCollected)}</strong></div>
              <div class="v33-kpi"><span>Daily Revenue</span><strong>${inr(k.dailyRevenue)}</strong></div>
              <div class="v33-kpi"><span>Monthly Revenue</span><strong>${inr(k.monthlyRevenue)}</strong></div>
              <div class="v33-kpi"><span>Yearly Revenue</span><strong>${inr(k.yearlyRevenue)}</strong></div>
              <div class="v33-kpi v33-kpi--gold"><span>Pending Payments</span><strong>${inr(k.pendingRevenue)}</strong></div>
              <div class="v33-kpi"><span>Collection Rate</span><strong>${Number(k.collectionRate || 0)}%</strong></div>
              <div class="v33-kpi"><span>Campaign Conv. Rate</span><strong>${Number(k.campaignConversionRate || 0)}%</strong></div>
              <div class="v33-kpi"><span>Cross-Sell / Upsell / Add-On</span><strong>${inr((k.crossSellRevenue || 0) + (k.upsellRevenue || 0) + (k.addonRevenue || 0))}</strong></div>
            </div>
            <div class="v33-grid-2">
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Branch</th><th>Verified Revenue</th></tr></thead>
                  <tbody>${(an.branchWiseRevenue || []).map((r) => `<tr><td>${esc(r.branch)}</td><td><strong>${inr(r.revenue)}</strong></td></tr>`).join("") || `<tr><td colspan="2">No data yet</td></tr>`}</tbody>
                </table>
              </div>
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Most Sold Course / Package</th><th>Sales</th><th>Revenue</th></tr></thead>
                  <tbody>${(an.mostSoldCourses || []).slice(0, 8).map((r) => `<tr><td>${esc(r.title)}</td><td>${r.sales}</td><td><strong>${inr(r.revenue)}</strong></td></tr>`).join("") || `<tr><td colspan="3">No data yet</td></tr>`}</tbody>
                </table>
              </div>
            </div>
          `;
          bodyEl.querySelector("[data-v33-run-renewals]")?.addEventListener("click", async () => {
            try {
              const r = await apiV33("/api/v33/admin/renewals/run-sweep", { method: "POST" });
              toast(`Renewal sweep complete (${r.result?.triggered || 0} reminders sent).`);
            } catch (err) {
              toast(err.message, "error");
            }
          });
          return;
        }

        if (activeTab === "messages") {
          const tplRes = await apiV33("/api/v33/admin/message-templates");
          const templates = tplRes.templates || [];
          bodyEl.innerHTML = `
            <div class="v33-header-row">
              <div><h3 class="v33-title">Message Preview &amp; Template Studio (${templates.length} Templates)</h3><p class="v33-sub">Preview live dynamic placeholders before sending Email, WhatsApp, or In-App messages.</p></div>
              <button type="button" class="v33-btn" data-open-mp-studio>Open Live Preview &amp; Send Modal</button>
            </div>
            <div class="v33-table-wrap">
              <table class="v33-table">
                <thead><tr><th>Template Key</th><th>Name</th><th>Subject</th></tr></thead>
                <tbody>${templates.map((t) => `<tr><td><code>${esc(t.template_key)}</code></td><td><strong>${esc(t.name)}</strong></td><td>${esc(t.subject)}</td></tr>`).join("")}</tbody>
              </table>
            </div>
          `;
          bodyEl.querySelector("[data-open-mp-studio]")?.addEventListener("click", () => openMessagePreviewModal({}));
          return;
        }

        const hub = await apiV33("/api/v33/admin/pricing-hub");
        const cfg = hub.config || {};

        if (activeTab === "pricing") {
          const schoolFees = cfg.schoolSubjectFees || {};
          bodyEl.innerHTML = `
            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">School Subject Monthly Fees (Class 6th – 12th, 100% Admin Editable)</h4>
              <form data-v33-school-fees>
                <div class="v33-form-grid">
                  ${["6", "7", "8", "9", "10", "11", "12"].map((cls) => `
                    <div class="v33-field"><label>Class ${cls}th Monthly (₹)</label><input name="c_${cls}" type="number" min="100" value="${Number(schoolFees[cls] || 600)}"></div>
                  `).join("")}
                </div>
                <button type="submit" class="v33-btn">Save School Monthly Rates (Protects Historical Invoices)</button>
              </form>
            </div>

            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Add New Course / Competitive / Tech / Communication Program</h4>
              <form data-v33-add-course>
                <div class="v33-form-grid">
                  <div class="v33-field"><label>Course Title *</label><input name="title" required placeholder="e.g. Python + AI Bootcamp"></div>
                  <div class="v33-field"><label>Category</label>
                    <select name="category">
                      <option value="School">School Subject</option>
                      <option value="Competitive Exams">Competitive Exam</option>
                      <option value="Technology">Technology / Coding / AI</option>
                      <option value="Communication & Language">Communication &amp; Language</option>
                    </select>
                  </div>
                  <div class="v33-field"><label>Monthly Fee (₹) *</label><input name="monthlyFee" type="number" min="100" value="900" required></div>
                  <div class="v33-field"><label>Promo Fee (Optional ₹)</label><input name="promoFee" type="number" min="0" placeholder="Optional"></div>
                  <div class="v33-field"><label>Class / Track</label><input name="classRange" value="All Classes" placeholder="Class 10 / Competitive"></div>
                </div>
                <button type="submit" class="v33-btn v33-btn--gold">Create Course</button>
              </form>
            </div>

            <h4 style="margin:10px 0 8px;font-size:14px;">All Dynamic Courses (${(hub.courses || []).length})</h4>
            <div class="v33-table-wrap">
              <table class="v33-table">
                <thead><tr><th>Course</th><th>Category</th><th>Class</th><th>Monthly Fee</th><th>Status</th><th>Quick Edit</th></tr></thead>
                <tbody>${(hub.courses || []).map((c) => `<tr>
                  <td><strong>${esc(c.title)}</strong>${Number(c.promo_enabled) === 1 && Number(c.promo_price) > 0 ? `<div class="v33-sub">Promo: ${inr(c.promo_price)}/mo</div>` : ""}</td>
                  <td>${esc(c.category || "School")}</td>
                  <td>${esc(c.class_range || c.class_level || "-")}</td>
                  <td><input type="number" min="100" value="${Number(c.monthly_fee || 0)}" data-course-fee="${c.id}" style="width:92px;padding:5px 7px;border:1px solid var(--pt-border);border-radius:6px;background:var(--pt-surface);color:var(--pt-text);"></td>
                  <td>${statusPill(c.is_active ? "active" : "inactive")}</td>
                  <td style="white-space:nowrap;">
                    <button type="button" class="v33-btn v33-btn--quiet" data-course-save="${c.id}">Save Fee</button>
                    <button type="button" class="v33-btn v33-btn--quiet" data-course-toggle="${c.id}" data-course-active="${c.is_active ? 1 : 0}">${c.is_active ? "Pause" : "Activate"}</button>
                  </td>
                </tr>`).join("")}</tbody>
              </table>
            </div>
          `;
          bodyEl.querySelector("[data-v33-school-fees]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            const nextFees = {};
            ["6", "7", "8", "9", "10", "11", "12"].forEach((cls) => { nextFees[cls] = Number(fd.get(`c_${cls}`) || 600); });
            try {
              await apiV33("/api/v33/admin/pricing-config", { method: "PUT", body: { schoolSubjectFees: nextFees } });
              toast("School monthly fees updated & logged to Pricing Audit!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          bodyEl.querySelector("[data-v33-add-course]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              const promoVal = fd.get("promoFee") ? Number(fd.get("promoFee")) : 0;
              await apiV33("/api/v33/admin/courses", {
                method: "POST",
                body: {
                  title: String(fd.get("title") || "").trim(),
                  category: fd.get("category"),
                  monthlyFee: Number(fd.get("monthlyFee")),
                  promoPrice: promoVal,
                  promoEnabled: promoVal > 0,
                  classRange: String(fd.get("classRange") || "").trim(),
                },
              });
              toast("Course created!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          bodyEl.querySelectorAll("[data-course-save]").forEach((btn) => {
            btn.addEventListener("click", async () => {
              const cid = btn.getAttribute("data-course-save");
              const feeVal = Number(bodyEl.querySelector(`[data-course-fee="${cid}"]`)?.value || 0);
              if (feeVal < 100) return toast("Monthly fee must be at least ₹100.", "error");
              try {
                await apiV33(`/api/v33/admin/courses/${cid}`, { method: "PUT", body: { monthlyFee: feeVal } });
                toast("Course monthly fee updated!");
                draw();
              } catch (err) { toast(err.message, "error"); }
            });
          });
          bodyEl.querySelectorAll("[data-course-toggle]").forEach((btn) => {
            btn.addEventListener("click", async () => {
              const cid = btn.getAttribute("data-course-toggle");
              const isAct = btn.getAttribute("data-course-active") === "1";
              try {
                await apiV33(`/api/v33/admin/courses/${cid}`, { method: "PUT", body: { isActive: !isAct } });
                toast(isAct ? "Course paused." : "Course activated!");
                draw();
              } catch (err) { toast(err.message, "error"); }
            });
          });
          return;
        }

        if (activeTab === "discounts") {
          const dd = cfg.durationDiscounts || {};
          const slabs = Array.isArray(cfg.multiSubjectSlabs) ? cfg.multiSubjectSlabs : [];
          const findSlab = (n, fb) => Number(slabs.find((s) => Number(s.minSubjects) === n)?.discountPercent ?? fb);
          bodyEl.innerHTML = `
            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Duration Discounts &amp; Multi-Subject Slabs</h4>
              <form data-v33-disc-form>
                <div class="v33-form-grid">
                  <div class="v33-field"><label>1 Month Discount (%)</label><input name="d1" type="number" min="0" max="70" value="${Number(dd["1"] ?? 0)}"></div>
                  <div class="v33-field"><label>3 Months Discount (%)</label><input name="d3" type="number" min="0" max="70" value="${Number(dd["3"] ?? 5)}"></div>
                  <div class="v33-field"><label>6 Months Discount (%)</label><input name="d6" type="number" min="0" max="70" value="${Number(dd["6"] ?? 10)}"></div>
                  <div class="v33-field"><label>9 Months Discount (%)</label><input name="d9" type="number" min="0" max="70" value="${Number(dd["9"] ?? 15)}"></div>
                  <div class="v33-field"><label>12 Months Discount (%)</label><input name="d12" type="number" min="0" max="70" value="${Number(dd["12"] ?? 20)}"></div>
                  <div class="v33-field"><label>2 Subjects Slab (%)</label><input name="m2" type="number" min="0" max="60" value="${findSlab(2, 5)}"></div>
                  <div class="v33-field"><label>3 Subjects Slab (%)</label><input name="m3" type="number" min="0" max="60" value="${findSlab(3, 10)}"></div>
                  <div class="v33-field"><label>4 Subjects Slab (%)</label><input name="m4" type="number" min="0" max="60" value="${findSlab(4, 15)}"></div>
                  <div class="v33-field"><label>5+ Subjects Slab (%)</label><input name="m5" type="number" min="0" max="60" value="${findSlab(5, 20)}"></div>
                </div>
                <button type="submit" class="v33-btn">Save Discount Rules</button>
              </form>
            </div>

            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Franchise / Branch-Wise Pricing (Muradnagar, Modinagar, Ghaziabad, Online)</h4>
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Branch</th><th>City</th><th>Status</th><th>Promo Note</th><th>Save</th></tr></thead>
                  <tbody>
                    ${(hub.branches || []).map((br) => {
                      const ov = (hub.branchOverlays || []).find((x) => Number(x.branch_id) === Number(br.id)) || {};
                      return `<tr>
                        <td><strong>${esc(br.name)}</strong></td>
                        <td>${esc(br.city || "-")}</td>
                        <td>${statusPill(ov.is_active === 0 ? "inactive" : "active")}</td>
                        <td><input type="text" value="${esc(ov.promo_note || "")}" placeholder="e.g. Local launch 5% extra" data-bp-note="${br.id}" style="width:200px;padding:5px;border:1px solid var(--pt-border);border-radius:6px;"></td>
                        <td><button type="button" class="v33-btn v33-btn--quiet" data-bp-save="${br.id}">Save Override</button></td>
                      </tr>`;
                    }).join("")}
                  </tbody>
                </table>
              </div>
            </div>
          `;
          bodyEl.querySelector("[data-v33-disc-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/pricing-config", {
                method: "PUT",
                body: {
                  durationDiscounts: { "1": Number(fd.get("d1")), "3": Number(fd.get("d3")), "6": Number(fd.get("d6")), "9": Number(fd.get("d9")), "12": Number(fd.get("d12")) },
                  multiSubjectSlabs: [
                    { minSubjects: 2, discountPercent: Number(fd.get("m2")), label: "2 Subjects", active: true },
                    { minSubjects: 3, discountPercent: Number(fd.get("m3")), label: "3 Subjects", active: true },
                    { minSubjects: 4, discountPercent: Number(fd.get("m4")), label: "4 Subjects", active: true },
                    { minSubjects: 5, discountPercent: Number(fd.get("m5")), label: "5+ Subjects", active: true },
                  ],
                },
              });
              toast("Duration & Multi-Subject discount slabs saved!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          bodyEl.querySelectorAll("[data-bp-save]").forEach((btn) => {
            btn.addEventListener("click", async () => {
              const bid = btn.getAttribute("data-bp-save");
              const note = bodyEl.querySelector(`[data-bp-note="${bid}"]`)?.value || "";
              try {
                await apiV33(`/api/v33/admin/branch-pricing/${bid}`, { method: "PUT", body: { promoNote: note, isActive: true } });
                toast("Branch pricing overlay saved!");
                draw();
              } catch (err) { toast(err.message, "error"); }
            });
          });
          return;
        }

        if (activeTab === "bundles") {
          bodyEl.innerHTML = `
            <div class="v33-grid-2">
              <div class="v33-card">
                <h4 class="v33-title" style="margin-bottom:10px;">Create Custom Bundle</h4>
                <form data-v33-bundle-form>
                  <div class="v33-form-grid">
                    <div class="v33-field"><label>Bundle Name *</label><input name="name" required placeholder="e.g. Class 12 PCM Power Bundle"></div>
                    <div class="v33-field"><label>Category</label><input name="category" value="School" placeholder="School / Competitive"></div>
                    <div class="v33-field"><label>Discount (%)</label><input name="discountPercent" type="number" min="0" max="60" value="15"></div>
                    <div class="v33-field"><label>Subjects (CSV)</label><input name="subjectsCsv" placeholder="Maths, Physics, Chemistry"></div>
                  </div>
                  <div class="v33-field" style="margin-bottom:10px;"><label>Description</label><input name="description" placeholder="Included subjects & benefits"></div>
                  <button type="submit" class="v33-btn">Add Bundle</button>
                </form>
              </div>
              <div class="v33-card">
                <h4 class="v33-title" style="margin-bottom:10px;">Create Add-On Product</h4>
                <form data-v33-addon-form>
                  <div class="v33-form-grid">
                    <div class="v33-field"><label>Add-On Title *</label><input name="title" required placeholder="e.g. Board PYQ Solved Pack"></div>
                    <div class="v33-field"><label>Category</label>
                      <select name="category"><option value="Test Series">Test Series</option><option value="Handwritten Notes">Handwritten Notes</option><option value="E-Books">E-Books</option><option value="Recorded Classes">Recorded Classes</option><option value="PYQ Packs">PYQ Packs</option><option value="Doubt-Solving Packs">Doubt-Solving Packs</option><option value="Crash Courses">Crash Courses</option></select>
                    </div>
                    <div class="v33-field"><label>Price (₹) *</label><input name="price" type="number" min="49" value="299" required></div>
                  </div>
                  <button type="submit" class="v33-btn v33-btn--gold">Add Product</button>
                </form>
              </div>
            </div>
            <div class="v33-grid-2">
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Bundle (${(hub.bundles || []).length})</th><th>Category</th><th>Discount</th></tr></thead>
                  <tbody>${(hub.bundles || []).map((b) => `<tr><td><strong>${esc(b.name)}</strong><div class="v33-sub">${esc(b.description || "")}</div></td><td>${esc(b.category)}</td><td>${b.discount_percent}% OFF</td></tr>`).join("")}</tbody>
                </table>
              </div>
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Add-On (${(hub.addons || []).length})</th><th>Category</th><th>Price</th></tr></thead>
                  <tbody>${(hub.addons || []).map((a) => `<tr><td><strong>${esc(a.title)}</strong></td><td>${esc(a.category)}</td><td>${inr(a.price)}</td></tr>`).join("")}</tbody>
                </table>
              </div>
            </div>
          `;
          bodyEl.querySelector("[data-v33-bundle-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/bundles", {
                method: "POST",
                body: {
                  name: fd.get("name"),
                  category: fd.get("category"),
                  discountPercent: Number(fd.get("discountPercent") || 0),
                  subjects: String(fd.get("subjectsCsv") || "").split(",").map((s) => s.trim()).filter(Boolean),
                  description: fd.get("description"),
                },
              });
              toast("Bundle created!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          bodyEl.querySelector("[data-v33-addon-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/addons", {
                method: "POST",
                body: { title: fd.get("title"), category: fd.get("category"), price: Number(fd.get("price")) },
              });
              toast("Add-on created!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          return;
        }

        if (activeTab === "offers") {
          const endDefault = new Date(Date.now() + 72 * 3600 * 1000).toISOString().slice(0, 16);
          bodyEl.innerHTML = `
            <div class="v33-grid-2">
              <div class="v33-card">
                <h4 class="v33-title" style="margin-bottom:10px;">Create Limited-Time Countdown Offer</h4>
                <form data-v33-offer-form>
                  <div class="v33-form-grid">
                    <div class="v33-field"><label>Offer Title *</label><input name="title" required placeholder="e.g. Board Exam Booster Flash Sale"></div>
                    <div class="v33-field"><label>Discount (%)</label><input name="discountValue" type="number" min="1" max="60" value="15"></div>
                    <div class="v33-field"><label>Promo Code</label><input name="code" placeholder="e.g. FLASH15" style="text-transform:uppercase;"></div>
                    <div class="v33-field"><label>Ends At *</label><input name="endAt" type="datetime-local" value="${endDefault}" required></div>
                  </div>
                  <button type="submit" class="v33-btn v33-btn--gold">Launch Countdown Offer</button>
                </form>
              </div>
              <div class="v33-card">
                <h4 class="v33-title" style="margin-bottom:10px;">Create Scholarship Rule</h4>
                <form data-v33-schol-form>
                  <div class="v33-form-grid">
                    <div class="v33-field"><label>Scholarship Name *</label><input name="name" required placeholder="e.g. Topper Merit 25%"></div>
                    <div class="v33-field"><label>Category</label>
                      <select name="category"><option value="Merit">Merit</option><option value="Girl Child">Girl Child</option><option value="Referral">Referral</option><option value="Festival">Festival</option><option value="Early Bird">Early Bird</option><option value="Financial Assistance">Financial Assistance</option></select>
                    </div>
                    <div class="v33-field"><label>Discount Value</label><input name="discountValue" type="number" min="1" value="15"></div>
                    <div class="v33-field"><label>Value Type</label><select name="discountType"><option value="percent">Percent (%)</option><option value="fixed">Fixed (₹)</option></select></div>
                  </div>
                  <button type="submit" class="v33-btn">Add Scholarship</button>
                </form>
              </div>
            </div>
            <div class="v33-grid-2">
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Promo Offer</th><th>Discount</th><th>Code</th><th>Ends At</th></tr></thead>
                  <tbody>${(hub.promoOffers || []).map((o) => `<tr><td><strong>${esc(o.title)}</strong></td><td>${o.discount_value}%</td><td><code>${esc(o.code || "-")}</code></td><td>${esc(String(o.end_at || "").slice(0, 16))}</td></tr>`).join("") || `<tr><td colspan="4">No promo offers yet</td></tr>`}</tbody>
                </table>
              </div>
              <div class="v33-table-wrap">
                <table class="v33-table">
                  <thead><tr><th>Scholarship</th><th>Category</th><th>Value</th></tr></thead>
                  <tbody>${(hub.scholarships || []).map((sc) => `<tr><td><strong>${esc(sc.name)}</strong></td><td>${esc(sc.scholarship_type || sc.category || "Merit")}</td><td>${sc.discount_type === "fixed" ? inr(sc.discount_value) : `${sc.discount_value}%`}</td></tr>`).join("")}</tbody>
                </table>
              </div>
            </div>
          `;
          bodyEl.querySelector("[data-v33-offer-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/promo-offers", {
                method: "POST",
                body: {
                  title: fd.get("title"),
                  discountType: "percent",
                  discountValue: Number(fd.get("discountValue") || 10),
                  code: String(fd.get("code") || "").toUpperCase(),
                  endAt: new Date(String(fd.get("endAt"))).toISOString(),
                },
              });
              toast("Countdown offer launched!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          bodyEl.querySelector("[data-v33-schol-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/scholarships", {
                method: "POST",
                body: {
                  name: fd.get("name"),
                  category: fd.get("category"),
                  discountType: fd.get("discountType"),
                  discountValue: Number(fd.get("discountValue") || 10),
                },
              });
              toast("Scholarship added!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
          return;
        }

        if (activeTab === "crosssell") {
          bodyEl.innerHTML = `
            <div class="v33-card">
              <h4 class="v33-title" style="margin-bottom:10px;">Add Smart Cross-Selling / Upselling Rule</h4>
              <form data-v33-cs-form>
                <div class="v33-form-grid">
                  <div class="v33-field"><label>Rule Type</label>
                    <select name="ruleType"><option value="subject">Subject</option><option value="board">Board</option><option value="class_group">Class Group</option><option value="branch">Branch</option></select>
                  </div>
                  <div class="v33-field"><label>Trigger Value *</label><input name="triggerValue" required placeholder="e.g. Maths or CBSE or 9-10"></div>
                  <div class="v33-field"><label>Recommended Items (CSV) *</label><input name="recommendedItemsCsv" required placeholder="Science, Coding Classes"></div>
                  <div class="v33-field"><label>Category</label><input name="category" value="School Subjects" placeholder="School Subjects / Competitive / Tech"></div>
                </div>
                <button type="submit" class="v33-btn">Add Cross-Sell Rule</button>
              </form>
            </div>
            <div class="v33-table-wrap">
              <table class="v33-table">
                <thead><tr><th>Rule Type</th><th>Trigger</th><th>Recommended Items</th><th>Category</th></tr></thead>
                <tbody>${(hub.crossSellRules || []).map((r) => `<tr><td><strong>${esc(r.rule_type)}</strong></td><td><code>${esc(r.trigger_value)}</code></td><td>${esc((r.recommendedItems || []).join(", "))}</td><td>${esc(r.category || "-")}</td></tr>`).join("")}</tbody>
              </table>
            </div>
          `;
          bodyEl.querySelector("[data-v33-cs-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await apiV33("/api/v33/admin/cross-sell-rules", {
                method: "POST",
                body: {
                  ruleType: fd.get("ruleType"),
                  triggerValue: fd.get("triggerValue"),
                  recommendedItems: String(fd.get("recommendedItemsCsv") || "").split(",").map((s) => s.trim()).filter(Boolean),
                  category: fd.get("category"),
                },
              });
              toast("Cross-sell rule saved!");
              draw();
            } catch (err) { toast(err.message, "error"); }
          });
        }
      } catch (err) {
        bodyEl.innerHTML = `<div class="portal-message portal-message--error">${esc(err.message)}</div>`;
      }
    }

    draw();
  }

  /* ==========================================================================
   * 9. PARENT DASHBOARD — CHILD ENGAGEMENT & RECOMMENDATIONS
   * ========================================================================== */
  async function mountParentInsights(container, studentId) {
    if (!container || !studentId) return;
    injectStyles();
    try {
      const data = await apiV33(`/api/v33/parent/insights/${Number(studentId)}`);
      const weak = data.weakSubjects || [];
      const recs = data.recommendedForChild || [];
      const skillCourses = data.skillAndExamCourses || [];
      const fin = data.feeStatus || {};

      container.innerHTML = `
        <div class="v33-card" data-testid="v33-parent-insights">
          <div class="v33-header-row">
            <div>
              <h3 class="v33-title">Recommended For Your Child · Growth &amp; Fee Insights</h3>
              <p class="v33-sub">Based on ${esc(data.student?.fullName || "student")}'s actual class (${esc(data.student?.classLevel || "-")}), test scores &amp; attendance.</p>
            </div>
            ${fin.pendingAmount > 0 ? `<span class="v33-pill v33-pill--warn">Pending Fee: ${inr(fin.pendingAmount)}</span>` : `<span class="v33-pill v33-pill--ok">Fees Up to Date</span>`}
          </div>

          ${weak.length ? `
            <div class="portal-message portal-message--error" style="margin-bottom:12px;">
              <strong>Weak Subject Alerts (Below 60%):</strong> ${weak.map((w) => `${esc(w.subject)} (${w.avgPercent}%)`).join(", ")} — Extra doubt-clearing &amp; revision support recommended.
            </div>
          ` : `<div class="portal-message portal-message--success" style="margin-bottom:12px;">No weak-subject alerts right now — strong academic progress!</div>`}

          <h4 style="margin:10px 0 8px;font-size:14px;">Recommended Upgrade &amp; Academic Courses</h4>
          <div class="v33-grid-3" style="margin-bottom:14px;">
            ${recs.slice(0, 4).map((c) => `
              <div class="v33-item-card">
                <div>
                  <span class="v33-pill v33-pill--warn">${esc(c.reason || c.category || "Recommended")}</span>
                  <strong style="display:block;margin-top:6px;">${esc(c.title)}</strong>
                  <div class="v33-sub">${inr(c.monthlyFee || c.monthly_fee || 0)}/mo</div>
                </div>
              </div>
            `).join("") || `<p class="v33-sub">No additional academic suggestions right now.</p>`}
          </div>

          <h4 style="margin:10px 0 8px;font-size:14px;">Exam Prep, Spoken English, Coding &amp; AI Tracks</h4>
          <div class="v33-grid-3">
            ${skillCourses.slice(0, 6).map((c) => `
              <div class="v33-item-card">
                <div>
                  <span class="v33-pill">${esc(c.category || "Skill")}</span>
                  <strong style="display:block;margin-top:6px;">${esc(c.title)}</strong>
                  <div class="v33-sub">${inr(c.monthly_fee)}/mo</div>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    } catch {
      // silent
    }
  }

  /* ==========================================================================
   * 10. SMART NOTIFICATION CENTER (STATUSES + WORKING DEEP LINKS)
   * ========================================================================== */
  async function mountSmartNotifications(menuEl, dotEl) {
    if (!menuEl) return;
    injectStyles();
    let filter = "all";

    async function load() {
      try {
        const res = await apiV33(`/api/v33/notifications?status=${encodeURIComponent(filter)}`);
        const items = res.notifications || [];
        const counts = res.counts || {};
        if (dotEl) {
          dotEl.textContent = String(counts.new || 0);
          dotEl.style.display = counts.new > 0 ? "" : "none";
        }

        menuEl.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:6px;flex-wrap:wrap;">
            <strong style="font-size:12.5px;">Smart Notifications</strong>
            <div style="display:flex;gap:4px;">
              ${["all", "new", "important", "read", "archived"].map((st) => `
                <button type="button" class="v33-tab ${filter === st ? "is-active" : ""}" style="padding:3px 7px;font-size:11px;" data-sn-filter="${st}">${st}${counts[st] ? ` (${counts[st]})` : ""}</button>
              `).join("")}
            </div>
          </div>
          <div style="max-height:310px;overflow-y:auto;">
            ${items.map((n) => `
              <div class="v33-notif-item ${!n.is_read ? "is-unread" : ""}" data-sn-open="${n.id}" data-sn-link="${esc(n.deep_link || "")}" data-sn-etype="${esc(n.entity_type || "")}" data-sn-eid="${esc(n.entity_id || "")}">
                <div style="display:flex;justify-content:space-between;gap:6px;align-items:center;margin-bottom:3px;">
                  <span style="font-size:11px;color:var(--pt-muted);">${esc(String(n.created_at || "").slice(0, 16))}</span>
                  ${statusPill(n.status || (n.is_read ? "read" : "new"))}
                </div>
                <strong style="font-size:12.5px;display:block;">${esc(n.title)}</strong>
                <div style="font-size:12px;color:var(--pt-muted);margin-top:2px;">${esc(n.message)}</div>
                <div style="display:flex;gap:5px;margin-top:6px;">
                  <button type="button" class="v33-btn v33-btn--quiet" style="padding:2px 7px;font-size:11px;" data-sn-act="important" data-sn-id="${n.id}">Important</button>
                  <button type="button" class="v33-btn v33-btn--quiet" style="padding:2px 7px;font-size:11px;" data-sn-act="archived" data-sn-id="${n.id}">Archive</button>
                </div>
              </div>
            `).join("") || `<p class="v33-sub" style="padding:8px 0;">No ${esc(filter)} notifications.</p>`}
          </div>
        `;

        menuEl.querySelectorAll("[data-sn-filter]").forEach((b) => {
          b.addEventListener("click", (e) => {
            e.stopPropagation();
            filter = b.getAttribute("data-sn-filter");
            load();
          });
        });

        menuEl.querySelectorAll("[data-sn-act]").forEach((b) => {
          b.addEventListener("click", async (e) => {
            e.stopPropagation();
            const id = b.getAttribute("data-sn-id");
            const nextStatus = b.getAttribute("data-sn-act");
            try {
              await apiV33(`/api/v33/notifications/${id}`, { method: "PATCH", body: { status: nextStatus } });
              load();
            } catch { /* ignore */ }
          });
        });

        menuEl.querySelectorAll("[data-sn-open]").forEach((row) => {
          row.addEventListener("click", async () => {
            const id = row.getAttribute("data-sn-open");
            const link = row.getAttribute("data-sn-link") || "";
            const etype = row.getAttribute("data-sn-etype") || "";
            const eid = row.getAttribute("data-sn-eid") || "";
            try {
              await apiV33(`/api/v33/notifications/${id}`, { method: "PATCH", body: { status: "read" } });
            } catch { /* ignore */ }
            menuEl.hidden = true;
            if ((etype === "invoice" || etype === "followup") && eid && document.querySelector("[data-erp-v32-slot]")) {
              const stuIdMatch = link.match(/student[=/](\d+)/i);
              if (stuIdMatch) {
                openAdminInvoiceManagement(Number(stuIdMatch[1]));
                return;
              }
            }
            if (link.startsWith("#")) {
              const tabKey = link.replace(/^#/, "").split("?")[0];
              const navBtn = document.querySelector(`[data-nav-tab="${tabKey}"]`);
              if (navBtn) {
                navBtn.click();
                return;
              }
              window.location.hash = link;
            } else if (link.startsWith("/")) {
              window.location.assign(link);
            }
          });
        });
      } catch {
        // leave default notifications untouched
      }
    }

    load();
  }

  /* ==========================================================================
   * 11. SIDEBAR SLOT SYNC FOR ADMIN v3.3 HUB BUTTON
   * ========================================================================== */
  function syncAdminSidebarSlot() {
    const slot = document.querySelector("[data-erp-v32-slot]");
    if (!slot) return;
    if (slot.querySelector("[data-v33-hub-btn]")) return;
    const isAdminPage = Boolean(window.__YU_ADMIN_GATE__) || /admin/i.test(document.querySelector('[data-testid="active-portal-badge"]')?.textContent || "");
    if (!isAdminPage) return;
    injectStyles();
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "v33-sidebar-btn";
    btn.setAttribute("data-v33-hub-btn", "1");
    btn.setAttribute("data-testid", "v33-admin-hub-btn");
    btn.innerHTML = `<span>v3.3 Pricing, CRM &amp; Revenue</span><span style="font-size:11px;color:#FDE68A;">PRO</span>`;
    btn.addEventListener("click", () => openAdminV33Hub("pricing"));
    slot.appendChild(btn);
  }

  window.YuitorV33 = {
    version: "3.3.0",
    apiV33,
    mountQuickRegisterForm,
    mountStudentProfileWizard,
    mountStudentFinance,
    mountStudentRecommendations,
    openDynamicCheckoutModal,
    openAdminInvoiceManagement,
    openMessagePreviewModal,
    openAdminV33Hub,
    mountParentInsights,
    mountSmartNotifications,
    syncAdminSidebarSlot,
  };

  function hydratePendingSlots() {
    injectStyles();
    syncAdminSidebarSlot();
    const q = document.querySelector("[data-v33-quick-register]");
    if (q && !q.children.length) mountQuickRegisterForm(q);
    const w = document.querySelector("[data-v33-student-wizard]");
    if (w && !w.children.length) mountStudentProfileWizard(w);
    const r = document.querySelector("[data-v33-student-recs]");
    if (r && !r.children.length) mountStudentRecommendations(r);
    const f = document.querySelector("[data-v33-student-finance]");
    if (f && !f.children.length) mountStudentFinance(f);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", hydratePendingSlots, { once: true });
  } else {
    hydratePendingSlots();
  }
})();
