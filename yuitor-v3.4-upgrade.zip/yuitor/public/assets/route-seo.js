(() => {
  "use strict";
  const currentOrigin =
    typeof window !== "undefined" &&
    window.location &&
    /^https?:\/\//i.test(window.location.origin)
      ? window.location.origin.replace(/\/+$/, "")
      : "https://yuitor.com";
  const defaultImage = `${currentOrigin}/opengraph-yuitor.jpg`;

  const ensureMeta = (selector, attributes, value) => {
    let node = document.head.querySelector(selector);
    if (!node) {
      node = document.createElement("meta");
      Object.entries(attributes).forEach(([key, val]) => node.setAttribute(key, val));
      document.head.appendChild(node);
    }
    node.setAttribute("content", value);
  };

  function isSecretGatePath(path) {
    const gateBase = window.__YU_ADMIN_GATE__ && window.__YU_ADMIN_GATE__.basePath;
    return Boolean(gateBase && (path === gateBase || path.startsWith(`${gateBase}/`)));
  }

  function canonicalizeAliasPath(path) {
    const clean = String(path || "/").toLowerCase().replace(/\/+$/, "") || "/";
    const staticAliases = {
      "/admissions": "/admission",
      "/apply": "/admission",
      "/demo": "/admission",
      "/book-demo": "/admission",
      "/faq": "/faqs",
      "/fees": "/fee-calculator",
      "/scholarships": "/scholarship",
      "/faculty": "/teachers",
      "/about-us": "/about",
      "/contact-us": "/contact",
      "/refund-policy": "/refund",
      "/privacy-policy": "/privacy",
      "/terms-of-service": "/terms",
      "/cookies": "/cookie-policy",
      "/student-login": "/student/login",
      "/teacher-login": "/teacher/login",
      "/parent-login": "/parent/login",
      "/student-register": "/student/register",
      "/teacher-register": "/teacher/register",
      "/parent-register": "/parent/register",
    };
    if (staticAliases[clean]) return staticAliases[clean];
    const courseClass = clean.match(/^\/(?:course|courses|classes)\/class-?(6|7|8|9|10|11|12)$/);
    if (courseClass) return `/class/${courseClass[1]}`;
    const classesNum = clean.match(/^\/classes\/(6|7|8|9|10|11|12)$/);
    if (classesNum) return `/class/${classesNum[1]}`;
    const courseExam = clean.match(/^\/(?:course|courses|exams)\/(?:exam-)?(neet|jee|cuet|nda|ssc|banking)$/);
    if (courseExam) return `/exam/${courseExam[1]}`;
    const courseBoard = clean.match(/^\/(?:course|courses|boards)\/(?:board-)?(cbse|up-board|icse|state-board)$/);
    if (courseBoard) return `/board/${courseBoard[1]}`;
    const courseSkill = clean.match(/^\/(?:course|courses)\/(?:skill-)?(computer|spoken-english|coding)$/);
    if (courseSkill) return `/course/${courseSkill[1]}`;
    return clean;
  }

  function resolveMeta(routes, path) {
    if (isSecretGatePath(path)) {
      return {
        meta: {
          title: "Yuitor Console | Yuitor Smart Classes",
          description: "Authorized administration console.",
        },
        isNotFound: false,
      };
    }
    const resolved = canonicalizeAliasPath(path);
    if (routes[resolved]) return { meta: routes[resolved], isNotFound: false };
    if (routes[path]) return { meta: routes[path], isNotFound: false };
    if (path.startsWith("/unsubscribe/") || path === "/unsubscribe") {
      return {
        meta: routes["/unsubscribe"] || {
          title: "Email Subscription Preferences | Yuitor Smart Classes",
          description: "Manage your email communication preferences with Yuitor Smart Classes.",
        },
        isNotFound: false,
      };
    }
    if (/^\/teacher(?:\/|$)/.test(resolved)) return { meta: routes["/teacher"] || routes["/"], isNotFound: false };
    if (/^\/student(?:\/|$)/.test(resolved)) return { meta: routes["/student"] || routes["/"], isNotFound: false };
    if (/^\/parent(?:\/|$)/.test(resolved)) return { meta: routes["/parent"] || routes["/"], isNotFound: false };
    if (/^\/staff(?:\/|$)/.test(resolved)) return { meta: routes["/staff"] || routes["/"], isNotFound: false };
    if (/^\/register(?:\/|$)/.test(resolved)) return { meta: routes["/register"] || routes["/"], isNotFound: false };
    return {
      meta: {
        title: "404 Page Not Found | Yuitor Smart Classes",
        description: "The requested page could not be found. Explore Yuitor Smart Classes courses, admissions, or return home.",
      },
      isNotFound: true,
    };
  }

  function applySeoTags(routes) {
    const path = decodeURI(location.pathname).replace(/\/+$/, "") || "/";
    const { meta, isNotFound } = routes
      ? resolveMeta(routes, path)
      : {
          meta: {
            title: document.title || "Yuitor Smart Classes | Ek Kadam Safalta Ki Our — Muradnagar Coaching",
            description:
              document.head.querySelector('meta[name="description"]')?.getAttribute("content") ||
              "Yuitor Smart Classes in Muradnagar — Ek Kadam Safalta Ki Our. Coaching for Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer, Spoken English & Coding Classes.",
          },
          isNotFound: false,
        };
    const canonical = `${currentOrigin}${path === "/" ? "/" : path}`;
    const isPrivate =
      isNotFound ||
      isSecretGatePath(path) ||
      /^\/(student|teacher|parent|staff|teacher-apply\.php|erp|login|register|unsubscribe)/.test(path);
    const ogType = path.startsWith("/blog/") ? "article" : "website";

    document.title = meta.title;
    ensureMeta('meta[name="description"]', { name: "description" }, meta.description);
    ensureMeta(
      'meta[name="robots"]',
      { name: "robots" },
      isPrivate ? "noindex, nofollow" : "index, follow, max-image-preview:large",
    );
    ensureMeta('meta[property="og:title"]', { property: "og:title" }, meta.title);
    ensureMeta('meta[property="og:description"]', { property: "og:description" }, meta.description);
    ensureMeta('meta[property="og:url"]', { property: "og:url" }, canonical);
    ensureMeta('meta[property="og:image"]', { property: "og:image" }, defaultImage);
    ensureMeta('meta[property="og:type"]', { property: "og:type" }, ogType);
    ensureMeta('meta[property="og:site_name"]', { property: "og:site_name" }, "Yuitor Smart Classes");
    ensureMeta('meta[property="og:locale"]', { property: "og:locale" }, "en_IN");
    ensureMeta('meta[name="twitter:card"]', { name: "twitter:card" }, "summary_large_image");
    ensureMeta('meta[name="twitter:title"]', { name: "twitter:title" }, meta.title);
    ensureMeta('meta[name="twitter:description"]', { name: "twitter:description" }, meta.description);
    ensureMeta('meta[name="twitter:image"]', { name: "twitter:image" }, defaultImage);

    let link = document.head.querySelector('link[rel="canonical"]');
    if (!link) {
      link = document.createElement("link");
      link.rel = "canonical";
      document.head.appendChild(link);
    }
    link.href = canonical;

    let bc = document.head.querySelector("script[data-yu-breadcrumb-ld]");
    if (isPrivate) {
      if (bc) bc.remove();
    } else {
      if (!bc) {
        bc = document.createElement("script");
        bc.type = "application/ld+json";
        bc.setAttribute("data-yu-breadcrumb-ld", "true");
        document.head.appendChild(bc);
      }
      const parts = path === "/" ? [] : path.split("/").filter(Boolean);
      const itemListElement = [
        { "@type": "ListItem", position: 1, name: "Home", item: `${currentOrigin}/` },
        ...parts.map((seg, i) => ({
          "@type": "ListItem",
          position: i + 2,
          name: i === parts.length - 1 ? meta.title.split("|")[0].trim() : decodeURIComponent(seg),
          item: `${currentOrigin}/${parts.slice(0, i + 1).join("/")}`,
        })),
      ];
      bc.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement,
      });
    }
  }

  let cachedRoutes = null;
  const update = () => applySeoTags(cachedRoutes);

  const originalPush = history.pushState;
  history.pushState = function (...args) {
    originalPush.apply(this, args);
    update();
  };
  const originalReplace = history.replaceState;
  history.replaceState = function (...args) {
    originalReplace.apply(this, args);
    update();
  };
  addEventListener("popstate", update);
  addEventListener("yuitor:route-changed", update);

  fetch("/assets/route-metadata.json")
    .then((response) => {
      if (!response.ok) throw new Error("Route metadata is unavailable");
      return response.json();
    })
    .then((routes) => {
      cachedRoutes = routes;
      update();
    })
    .catch(() => {
      update();
    });
})();
