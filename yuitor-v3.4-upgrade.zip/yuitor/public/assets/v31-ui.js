(() => {
  "use strict";

  if (window.YuitorV31) return;

  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* ==========================================================================
   * 1. Lucide SVG Icons Only (Zero Random Emojis)
   * ======================================================================== */
  const LUCIDE_PATHS = {
    arrowLeft: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    moreHorizontal: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    shieldAlert: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
    eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
    userCheck: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>',
    bookOpen: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    alertTriangle: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  };

  function lucideIcon(name, cls = "portal-icon-svg") {
    const p = LUCIDE_PATHS[name] || LUCIDE_PATHS.check;
    return `<svg class="${esc(cls)}" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
  }

  /* ==========================================================================
   * 2. IST & Currency Helpers
   * ======================================================================== */
  function formatINR(amount) {
    return `₹${Number(amount || 0).toLocaleString("en-IN")}`;
  }

  function formatIstDate(isoOrDate) {
    if (!isoOrDate) return "—";
    try {
      const d = new Date(isoOrDate);
      if (Number.isNaN(d.getTime())) return String(isoOrDate);
      return new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      }).format(d);
    } catch {
      return String(isoOrDate);
    }
  }

  function getTodayIstYmd() {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date());
  }

  function isDarkActive() {
    const main = document.querySelector("#root main.portal-main");
    return Boolean(main?.classList.contains("portal-dark") || localStorage.getItem("yuitor_portal_dark") === "1");
  }

  /* ==========================================================================
   * 3. API Helper (reuses CSRF cookie)
   * ======================================================================== */
  function readCsrfCookie() {
    const m = document.cookie.match(/(?:^|;\s*)(?:yu_csrf|yuitor_csrf)=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function apiJson(url, options = {}) {
    const method = (options.method || "GET").toUpperCase();
    const headers = { ...(options.headers || {}) };
    if (options.body !== undefined && !(options.body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
    }
    if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
      const csrf = readCsrfCookie();
      if (csrf) headers["X-CSRF-Token"] = csrf;
    }
    const resp = await fetch(url, {
      method,
      credentials: "same-origin",
      headers,
      body: options.body !== undefined && !(options.body instanceof FormData) ? JSON.stringify(options.body) : options.body,
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      const err = new Error(data.error || `Request failed (${resp.status})`);
      err.status = resp.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  /* ==========================================================================
   * 4. CHANGE [4], [5], [1]: Universal High-Contrast ConfirmationModal
   *    Supports standard confirmation AND mandatory Reason + Note (Suspend/Terminate)
   * ======================================================================== */
  const DEFAULT_SUSPEND_REASONS = [
    "Fee Non-Payment / Overdue Balance",
    "Discipline / Code of Conduct Violation",
    "Prolonged Unexplained Absence",
    "Duplicate or Unverified Account",
    "Course / Contract Completed",
    "Administrative Review Hold",
    "Other (Specify in Note)",
  ];

  function confirmModal(opts = {}) {
    return new Promise((resolve) => {
      const {
        title = "Confirm Action",
        message = "Are you sure you want to proceed with this action?",
        confirmLabel = "Yes, Confirm",
        cancelLabel = "Cancel",
        variant = "primary", // 'primary' | 'danger' | 'warning'
        requireReason = false,
        reasonLabel = "Reason *",
        reasonOptions = DEFAULT_SUSPEND_REASONS,
        noteLabel = "Detailed Note (included in email) *",
        notePlaceholder = "Provide clear reason & next steps for the user...",
      } = opts;

      const backdrop = document.createElement("div");
      backdrop.className = `v31-modal-backdrop${isDarkActive() ? " is-dark" : ""}`;
      backdrop.setAttribute("role", "dialog");
      backdrop.setAttribute("aria-modal", "true");
      backdrop.setAttribute("data-testid", "v31-confirmation-modal");

      const btnVariantClass =
        variant === "danger"
          ? "v31-modal-btn--danger"
          : variant === "warning"
            ? "v31-modal-btn--warning"
            : "v31-modal-btn--primary";

      backdrop.innerHTML = `
        <div class="v31-modal-card">
          <h3>${esc(title)}</h3>
          <p>${esc(message)}</p>
          ${
            requireReason
              ? `<div style="display:grid;gap:12px;margin-bottom:8px;">
                   <div>
                     <label for="v31-cm-reason">${esc(reasonLabel)}</label>
                     <select id="v31-cm-reason" data-cm-reason required>
                       <option value="">-- Select mandatory reason --</option>
                       ${reasonOptions.map((r) => `<option value="${esc(r)}">${esc(r)}</option>`).join("")}
                     </select>
                   </div>
                   <div>
                     <label for="v31-cm-note">${esc(noteLabel)}</label>
                     <textarea id="v31-cm-note" data-cm-note rows="3" placeholder="${esc(notePlaceholder)}" required></textarea>
                   </div>
                   <div data-cm-err style="color:#DC2626;font-size:12.5px;font-weight:700;" hidden></div>
                 </div>`
              : ""
          }
          <div class="v31-modal-actions">
            <button type="button" class="v31-modal-btn v31-modal-btn--cancel" data-cm-cancel>${esc(cancelLabel)}</button>
            <button type="button" class="v31-modal-btn ${btnVariantClass}" data-cm-confirm data-testid="v31-confirm-yes">${esc(confirmLabel)}</button>
          </div>
        </div>
      `;

      const cleanup = (val) => {
        document.removeEventListener("keydown", onKey);
        if (backdrop.parentNode) backdrop.parentNode.removeChild(backdrop);
        resolve(val);
      };

      const onKey = (e) => {
        if (e.key === "Escape") cleanup(false);
      };

      backdrop.querySelector("[data-cm-cancel]")?.addEventListener("click", () => cleanup(false));
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) cleanup(false);
      });
      backdrop.querySelector("[data-cm-confirm]")?.addEventListener("click", () => {
        if (requireReason) {
          const reason = backdrop.querySelector("[data-cm-reason]")?.value?.trim() || "";
          const note = backdrop.querySelector("[data-cm-note]")?.value?.trim() || "";
          const errEl = backdrop.querySelector("[data-cm-err]");
          if (!reason) {
            if (errEl) {
              errEl.textContent = "Please select a mandatory reason before confirming.";
              errEl.hidden = false;
            }
            backdrop.querySelector("[data-cm-reason]")?.focus();
            return;
          }
          if (note.length < 3) {
            if (errEl) {
              errEl.textContent = "Please enter a brief note (at least 3 characters) to include in the notification email.";
              errEl.hidden = false;
            }
            backdrop.querySelector("[data-cm-note]")?.focus();
            return;
          }
          cleanup({ confirmed: true, reason, note });
          return;
        }
        cleanup(true);
      });

      document.addEventListener("keydown", onKey);
      document.body.appendChild(backdrop);
      setTimeout(() => {
        const focusTarget = requireReason ? backdrop.querySelector("[data-cm-reason]") : backdrop.querySelector("[data-cm-confirm]");
        focusTarget?.focus();
      }, 20);
    });
  }

  /* ==========================================================================
   * 5. CHANGE [6]: Global Auto-Scroll to Edit & Focus First Input
   * ======================================================================== */
  function scrollToAndFocus(targetOrSelector) {
    setTimeout(() => {
      const el =
        typeof targetOrSelector === "string"
          ? document.querySelector(targetOrSelector)
          : targetOrSelector instanceof HTMLElement
            ? targetOrSelector
            : null;
      if (!el) return;
      const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      el.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "center" });
      el.classList.add("v31-focus-highlight");
      setTimeout(() => el.classList.remove("v31-focus-highlight"), 1400);
      const firstInput = el.matches("input, select, textarea")
        ? el
        : el.querySelector('input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled])');
      if (firstInput && typeof firstInput.focus === "function") {
        try {
          firstInput.focus({ preventScroll: true });
        } catch {
          firstInput.focus();
        }
      }
    }, 60);
  }

  /* ==========================================================================
   * 6. CHANGE [3]: Unsaved Form Dirty Tracker + Navigation History + BackButton
   * ======================================================================== */
  let formDirtyFlag = false;
  const navStack = [];

  function setFormDirty(dirty) {
    formDirtyFlag = Boolean(dirty);
  }

  function isFormDirty() {
    return formDirtyFlag;
  }

  function bindDirtyFormTracking(container) {
    formDirtyFlag = false;
    if (!container) return;
    container.querySelectorAll("form").forEach((form) => {
      if (form.dataset.v31DirtyBound === "1") return;
      form.dataset.v31DirtyBound = "1";
      form.addEventListener("input", () => {
        if (!form.hasAttribute("data-no-dirty")) formDirtyFlag = true;
      });
      form.addEventListener("change", () => {
        if (!form.hasAttribute("data-no-dirty")) formDirtyFlag = true;
      });
      form.addEventListener("submit", () => {
        formDirtyFlag = false;
      });
    });
  }

  async function confirmDiscardIfDirty() {
    if (!formDirtyFlag) return true;
    const ok = await confirmModal({
      title: "Unsaved Changes",
      message: "You have unsaved edits on this form. Leave without saving?",
      confirmLabel: "Yes, Leave Page",
      cancelLabel: "Stay & Keep Editing",
      variant: "warning",
    });
    if (ok) formDirtyFlag = false;
    return Boolean(ok);
  }

  function pushNavState(entry) {
    if (!entry) return;
    const key = JSON.stringify(entry);
    const last = navStack[navStack.length - 1];
    if (last && JSON.stringify(last) === key) return;
    navStack.push(entry);
    if (navStack.length > 40) navStack.shift();
  }

  function popPreviousNavState() {
    if (navStack.length >= 2) {
      navStack.pop();
      return navStack[navStack.length - 1];
    }
    return null;
  }

  function renderPageHeader({ title, subtitle = "", backLabel = "Back", breadcrumbsHtml = "", actionsHtml = "" }) {
    return `
      <div class="v31-page-header" data-testid="v31-page-header">
        <div class="v31-page-header-left">
          <button type="button" class="v31-back-btn" data-v31-back data-testid="v31-back-btn" aria-label="Go back">
            ${lucideIcon("arrowLeft")}
            <span>${esc(backLabel)}</span>
          </button>
          <div>
            <h2 class="v31-page-title">${esc(title || "Dashboard")}</h2>
            ${subtitle ? `<p class="v31-page-subtitle">${esc(subtitle)}</p>` : ""}
            ${breadcrumbsHtml || ""}
          </div>
        </div>
        ${actionsHtml ? `<div class="portal-actions">${actionsHtml}</div>` : ""}
      </div>
    `;
  }

  function bindBackButton(rootEl, onFallbackBack) {
    rootEl?.querySelectorAll("[data-v31-back]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const canLeave = await confirmDiscardIfDirty();
        if (!canLeave) return;
        const prev = popPreviousNavState();
        if (typeof onFallbackBack === "function") {
          onFallbackBack(prev);
        } else if (window.history.length > 1) {
          window.history.back();
        }
      });
    });
  }

  /* ==========================================================================
   * 7. Phase 1 Navbar "More ▾" Overflow Manager + Ctrl+K Quick Search
   * ======================================================================== */
  function initOverflowNavbar(navEl) {
    if (!navEl) return;
    const existingMore = navEl.querySelector("[data-v31-more-wrap]");
    if (existingMore) existingMore.remove();

    const directItems = Array.from(navEl.children).filter(
      (el) => !el.hasAttribute("data-v31-more-wrap")
    );
    directItems.forEach((el) => {
      el.style.display = "";
      el.dataset.v31Overflowed = "0";
    });

    if (window.innerWidth <= 768 || directItems.length === 0) return;

    const maxW = navEl.clientWidth - 96;
    if (maxW <= 120) return;

    let used = 0;
    const overflowed = [];
    directItems.forEach((el) => {
      const w = el.offsetWidth + 6;
      if (used + w > maxW && used > 0) {
        overflowed.push(el);
      } else {
        used += w;
      }
    });

    if (overflowed.length === 0) return;

    const moreWrap = document.createElement("div");
    moreWrap.className = "portal-unav-group";
    moreWrap.setAttribute("data-v31-more-wrap", "1");
    moreWrap.innerHTML = `
      <button type="button" class="portal-unav-link" data-v31-more-toggle aria-haspopup="menu" aria-expanded="false">
        <span>More</span>
        ${lucideIcon("chevronDown", "portal-icon-svg portal-unav-caret")}
      </button>
      <div class="v31-more-dropdown" data-v31-more-menu role="menu" hidden></div>
    `;
    const menu = moreWrap.querySelector("[data-v31-more-menu]");

    overflowed.forEach((el) => {
      el.style.display = "none";
      el.dataset.v31Overflowed = "1";
      const subBtns = el.querySelectorAll("[data-ws-nav-key]");
      const tabBtn = el.matches("[data-ws-tab]") ? el : el.querySelector("[data-ws-tab]");
      if (subBtns.length > 1) {
        const grpLabel = el.querySelector(".portal-unav-link span")?.textContent?.trim() || "Section";
        const hdr = document.createElement("div");
        hdr.className = "v31-more-group-label";
        hdr.textContent = grpLabel;
        menu.appendChild(hdr);
        subBtns.forEach((sb) => {
          const clone = document.createElement("button");
          clone.type = "button";
          clone.className = "portal-unav-dropitem";
          clone.setAttribute("role", "menuitem");
          clone.setAttribute("aria-current", sb.getAttribute("aria-current") || "false");
          clone.textContent = sb.textContent.trim();
          clone.addEventListener("click", () => {
            menu.hidden = true;
            sb.click();
          });
          menu.appendChild(clone);
        });
      } else {
        const trigger = subBtns[0] || tabBtn;
        if (!trigger) return;
        const clone = document.createElement("button");
        clone.type = "button";
        clone.className = "portal-unav-dropitem";
        clone.setAttribute("role", "menuitem");
        clone.setAttribute("aria-current", trigger.getAttribute("aria-current") || "false");
        clone.textContent = trigger.textContent.trim();
        clone.addEventListener("click", () => {
          menu.hidden = true;
          trigger.click();
        });
        menu.appendChild(clone);
      }
    });

    const toggleBtn = moreWrap.querySelector("[data-v31-more-toggle]");
    toggleBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      const willOpen = menu.hidden;
      menu.hidden = !willOpen;
      toggleBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    });
    document.addEventListener("click", (e) => {
      if (!moreWrap.contains(e.target)) {
        menu.hidden = true;
        toggleBtn?.setAttribute("aria-expanded", "false");
      }
    });

    navEl.appendChild(moreWrap);
  }

  let quickSearchItems = [];
  let quickSearchOnSelect = null;

  function registerQuickSearch(items, onSelect) {
    quickSearchItems = Array.isArray(items) ? items : [];
    quickSearchOnSelect = typeof onSelect === "function" ? onSelect : null;
  }

  function openQuickSearchModal() {
    if (document.querySelector("[data-v31-qs-modal]")) return;
    const backdrop = document.createElement("div");
    backdrop.className = `v31-modal-backdrop${isDarkActive() ? " is-dark" : ""}`;
    backdrop.setAttribute("data-v31-qs-modal", "1");
    backdrop.innerHTML = `
      <div class="v31-modal-card" style="width:min(560px,100%);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
          <h3 style="margin:0;">Quick Navigation Search</h3>
          <button type="button" class="v31-modal-btn v31-modal-btn--cancel" style="min-height:32px;padding:4px 10px;" data-qs-close>Esc</button>
        </div>
        <input type="search" data-qs-input placeholder="Jump to any module, tab, or tool..." autocomplete="off" style="margin-bottom:12px;">
        <div data-qs-list style="max-height:340px;overflow-y:auto;display:grid;gap:6px;"></div>
      </div>
    `;
    const listEl = backdrop.querySelector("[data-qs-list]");
    const inputEl = backdrop.querySelector("[data-qs-input]");
    const close = () => {
      document.removeEventListener("keydown", onKey);
      backdrop.remove();
    };
    const onKey = (e) => {
      if (e.key === "Escape") close();
    };

    const drawList = (q = "") => {
      const term = q.trim().toLowerCase();
      const matched = quickSearchItems.filter((it) =>
        !term || `${it.label} ${it.group || ""}`.toLowerCase().includes(term)
      );
      if (!matched.length) {
        listEl.innerHTML = `<div class="v31-empty-state" style="padding:18px;">No matching sections found.</div>`;
        return;
      }
      listEl.innerHTML = matched
        .slice(0, 24)
        .map(
          (it, idx) => `
          <button type="button" class="portal-unav-dropitem" data-qs-idx="${idx}" style="border:1px solid var(--v31-border);">
            <span><strong>${esc(it.label)}</strong></span>
            <span style="font-size:11.5px;opacity:0.75;">${esc(it.group || "Portal")}</span>
          </button>`
        )
        .join("");
      listEl.querySelectorAll("[data-qs-idx]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const item = matched[Number(btn.getAttribute("data-qs-idx"))];
          close();
          if (item && quickSearchOnSelect) quickSearchOnSelect(item);
        });
      });
    };

    inputEl?.addEventListener("input", () => drawList(inputEl.value));
    backdrop.querySelector("[data-qs-close]")?.addEventListener("click", close);
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) close();
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(backdrop);
    drawList("");
    setTimeout(() => inputEl?.focus(), 20);
  }

  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
      if (document.querySelector(".portal-workspace")) {
        e.preventDefault();
        openQuickSearchModal();
      }
    }
  });

  /* ==========================================================================
   * 8. CHANGE [2]: StatusTabs Component (Active, Suspended, Terminated, Others)
   * ======================================================================== */
  function renderStatusTabs(activeStatusTab, counts = {}) {
    const tabs = [
      ["active", "Active", counts.active ?? 0],
      ["suspended", "Suspended", counts.suspended ?? 0],
      ["terminated", "Terminated", counts.terminated ?? 0],
      ["others", "Others", counts.others ?? 0],
    ];
    return `
      <div class="v31-status-tabs" role="tablist" aria-label="User status tabs" data-testid="v31-status-tabs">
        ${tabs
          .map(
            ([key, label, count]) => `
            <button type="button" role="tab" aria-selected="${activeStatusTab === key ? "true" : "false"}"
              class="v31-status-tab ${activeStatusTab === key ? "is-active" : ""}"
              data-v31-status-tab="${key}" data-testid="status-tab-${key}">
              <span>${esc(label)}</span>
              <span class="v31-status-tab-count">${Number(count)}</span>
            </button>`
          )
          .join("")}
      </div>
    `;
  }

  /* ==========================================================================
   * 9. CHANGE [7]: Settings -> "Mail Templates" Tab + Mail Logs Viewer
   * ======================================================================== */
  async function renderMailTemplatesTab(container, adminApiUrl) {
    if (!container) return;
    container.innerHTML = `<div class="portal-card portal-profile"><div class="v31-skeleton" style="width:40%;margin-bottom:10px;"></div><div class="v31-skeleton" style="width:100%;height:180px;"></div></div>`;
    try {
      const [tplRes, logsRes] = await Promise.all([
        apiJson(adminApiUrl("/v31/mail-templates")),
        apiJson(adminApiUrl("/v31/mail-logs")),
      ]);
      const templates = tplRes.templates || [];
      const themes = tplRes.themes || [];
      const placeholders = tplRes.placeholders || [];
      let logs = logsRes.logs || [];
      let selected = templates[0] || null;
      let creatingNew = false;
      let subMode = "editor"; // 'editor' | 'logs'

      const draw = async () => {
        container.innerHTML = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">Mail Templates &amp; HTML Theme Studio</h3>
                <p class="portal-hint" style="margin:4px 0 0;">Paste raw HTML to apply the selected theme automatically. All scripts, inline handlers, and unsafe links are stripped on save &amp; preview.</p>
              </div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small ${subMode === "editor" ? "" : "portal-button--quiet"}" data-mt-mode="editor">Templates Editor (${templates.length})</button>
                <button type="button" class="portal-button portal-button--small ${subMode === "logs" ? "" : "portal-button--quiet"}" data-mt-mode="logs">Mail Logs (${logs.length})</button>
                <button type="button" class="portal-button portal-button--small v31-btn-success" data-mt-new>${lucideIcon("plus")} Add Template</button>
              </div>
            </div>

            ${
              subMode === "logs"
                ? `<div class="portal-table-scroll">
                     <table class="portal-table" data-yu-table="v31_mail_logs">
                       <thead><tr><th>Recipient</th><th>Subject</th><th>Type</th><th>Status</th><th>Attempts</th><th>IST Time</th><th data-yu-locked="1">Action</th></tr></thead>
                       <tbody>
                         ${
                           logs
                             .map(
                               (l) => `
                           <tr>
                             <td><strong>${esc(l.recipient_name || "-")}</strong><span class="portal-cell-sub">${esc(l.recipient_email)}</span></td>
                             <td>${esc(l.subject)}${l.error_message ? `<span class="portal-cell-sub" style="color:#DC2626;">${esc(l.error_message)}</span>` : ""}</td>
                             <td>${esc(l.mail_type)}</td>
                             <td><span class="portal-status portal-status--${esc(l.status === "sent" ? "approved" : l.status === "failed" ? "failed" : "pending")}">${esc(l.status)}</span></td>
                             <td>${Number(l.attempts || 0)}</td>
                             <td>${esc(l.sent_at || l.created_at)}</td>
                             <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-mt-resend="${l.id}">${lucideIcon("refresh")} Resend</button></td>
                           </tr>`
                             )
                             .join("") || `<tr><td colspan="7" class="portal-empty">No mail delivery logs recorded yet.</td></tr>`
                         }
                       </tbody>
                     </table>
                   </div>`
                : `<div class="v31-mail-studio">
                     <div class="v31-mail-list">
                       ${templates
                         .map(
                           (t) => `
                         <button type="button" class="v31-mail-list-item ${!creatingNew && selected?.id === t.id ? "is-active" : ""}" data-mt-select="${t.id}">
                           <strong>${esc(t.name)}</strong>
                           <span>${esc(t.category)} · ${esc(t.theme_key)}${Number(t.is_long_mail) ? " · Long Mail" : ""}</span>
                         </button>`
                         )
                         .join("")}
                     </div>
                     <form class="portal-form" data-mt-form>
                       <div class="portal-form-grid">
                         <div class="portal-field"><label>Template Name *</label><input name="name" required value="${esc(creatingNew ? "" : selected?.name || "")}" placeholder="e.g. Admission Follow-up"></div>
                         <div class="portal-field"><label>Category</label>
                           <select name="category">
                             ${["student", "teacher", "staff", "cross_sell", "system", "custom"]
                               .map((c) => `<option value="${c}" ${(creatingNew ? "custom" : selected?.category) === c ? "selected" : ""}>${c}</option>`)
                               .join("")}
                           </select>
                         </div>
                         <div class="portal-field"><label>HTML Email Theme</label>
                           <select name="themeKey" data-mt-theme>
                             ${themes
                               .map((th) => `<option value="${esc(th.key)}" ${(creatingNew ? "yuitor_navy" : selected?.theme_key) === th.key ? "selected" : ""}>${esc(th.label)}</option>`)
                               .join("")}
                           </select>
                         </div>
                         <div class="portal-field"><label>Mail Length Mode</label>
                           <label style="display:flex;align-items:center;gap:8px;min-height:42px;font-weight:600;">
                             <input type="checkbox" name="isLongMail" style="width:auto;min-height:auto;" ${!creatingNew && Number(selected?.is_long_mail) ? "checked" : ""}>
                             <span>Long Detailed Mail Format</span>
                           </label>
                         </div>
                       </div>
                       <div class="portal-field"><label>Email Subject *</label><input name="subject" required value="${esc(creatingNew ? "" : selected?.subject || "")}" placeholder="Subject with {{name}}, {{discount}}, {{course}}..."></div>
                       <div>
                         <label style="display:block;font-size:12px;font-weight:700;margin-bottom:6px;">Insert Placeholders</label>
                         <div class="v31-placeholder-chips">
                           ${placeholders.map((ph) => `<button type="button" class="v31-chip-btn" data-mt-insert="${esc(ph)}">${esc(ph)}</button>`).join("")}
                         </div>
                       </div>
                       <div class="v31-mail-editor-split">
                         <div class="portal-field">
                           <label>HTML Body Editor (Paste HTML to auto-apply theme)</label>
                           <textarea name="htmlBody" data-mt-body rows="16" style="font-family:ui-monospace,monospace;font-size:12.5px;" required>${esc(creatingNew ? "<p>Dear {{name}},</p><p>Write your message here.</p>" : selected?.html_body || "")}</textarea>
                         </div>
                         <div class="portal-field">
                           <label>Live Themed Preview (Sanitized)</label>
                           <iframe class="v31-preview-frame" sandbox="" data-mt-preview title="Email Live Preview"></iframe>
                         </div>
                       </div>
                       <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;padding-top:10px;border-top:1px solid var(--v31-border);">
                         <div class="portal-actions">
                           <button type="submit" class="portal-button portal-button--small">${creatingNew ? "Create Template" : "Save Template"}</button>
                           ${!creatingNew && selected && !Number(selected.is_system) ? `<button type="button" class="portal-button portal-button--small portal-button--danger" data-mt-delete="${selected.id}">Delete</button>` : ""}
                         </div>
                         <div class="portal-actions">
                           <input type="email" data-mt-test-email placeholder="Test recipient email..." style="min-height:34px;padding:4px 10px;border:1px solid var(--v31-border);border-radius:8px;background:var(--v31-card);color:var(--v31-text);">
                           <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mt-test-send>${lucideIcon("send")} Send Test Mail</button>
                         </div>
                       </div>
                     </form>
                   </div>`
            }
          </div>
        `;

        container.querySelectorAll("[data-mt-mode]").forEach((b) => {
          b.addEventListener("click", () => {
            subMode = b.getAttribute("data-mt-mode");
            draw();
          });
        });

        container.querySelector("[data-mt-new]")?.addEventListener("click", () => {
          creatingNew = true;
          subMode = "editor";
          draw();
          scrollToAndFocus(container.querySelector("[data-mt-form]"));
        });

        container.querySelectorAll("[data-mt-select]").forEach((b) => {
          b.addEventListener("click", () => {
            const id = Number(b.getAttribute("data-mt-select"));
            selected = templates.find((t) => Number(t.id) === id) || selected;
            creatingNew = false;
            draw();
          });
        });

        container.querySelectorAll("[data-mt-resend]").forEach((b) => {
          b.addEventListener("click", async () => {
            const ok = await confirmModal({
              title: "Resend Email",
              message: "Are you sure you want to resend this email now?",
              confirmLabel: "Yes, Resend",
            });
            if (!ok) return;
            try {
              const r = await apiJson(adminApiUrl(`/v31/mail-logs/${b.getAttribute("data-mt-resend")}/resend`), { method: "POST" });
              window.YuitorUI?.Toast?.success(r.ok ? "Email resent successfully." : r.error || "Resend failed.");
              const refreshed = await apiJson(adminApiUrl("/v31/mail-logs"));
              logs = refreshed.logs || [];
              draw();
            } catch (err) {
              window.YuitorUI?.Toast?.error(err.message);
            }
          });
        });

        const form = container.querySelector("[data-mt-form]");
        if (form) {
          const previewFrame = form.querySelector("[data-mt-preview]");
          const bodyTa = form.querySelector("[data-mt-body]");
          const themeSel = form.querySelector("[data-mt-theme]");
          const subjInput = form.querySelector('input[name="subject"]');

          const refreshPreview = async () => {
            try {
              const pr = await apiJson(adminApiUrl("/v31/mail-templates/preview"), {
                method: "POST",
                body: {
                  themeKey: themeSel?.value || "yuitor_navy",
                  subject: subjInput?.value || "Preview",
                  htmlBody: bodyTa?.value || "",
                },
              });
              if (previewFrame) previewFrame.srcdoc = pr.themedHtml || "";
            } catch {}
          };

          let deb = null;
          const schedulePreview = () => {
            clearTimeout(deb);
            deb = setTimeout(refreshPreview, 220);
          };
          bodyTa?.addEventListener("input", schedulePreview);
          bodyTa?.addEventListener("paste", () => setTimeout(refreshPreview, 80));
          themeSel?.addEventListener("change", refreshPreview);
          subjInput?.addEventListener("input", schedulePreview);
          refreshPreview();

          form.querySelectorAll("[data-mt-insert]").forEach((chip) => {
            chip.addEventListener("click", () => {
              const token = chip.getAttribute("data-mt-insert") || "";
              if (!bodyTa) return;
              const start = bodyTa.selectionStart || bodyTa.value.length;
              bodyTa.value = bodyTa.value.slice(0, start) + token + bodyTa.value.slice(bodyTa.selectionEnd || start);
              bodyTa.focus();
              schedulePreview();
            });
          });

          form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(form);
            const payload = {
              name: fd.get("name"),
              category: fd.get("category"),
              themeKey: fd.get("themeKey"),
              subject: fd.get("subject"),
              htmlBody: fd.get("htmlBody"),
              isLongMail: form.querySelector('input[name="isLongMail"]')?.checked || false,
            };
            try {
              if (creatingNew) {
                const res = await apiJson(adminApiUrl("/v31/mail-templates"), { method: "POST", body: payload });
                window.YuitorUI?.Toast?.success("Mail template created.");
                const fresh = await apiJson(adminApiUrl("/v31/mail-templates"));
                templates.splice(0, templates.length, ...(fresh.templates || []));
                selected = templates.find((t) => Number(t.id) === Number(res.id)) || templates[0];
                creatingNew = false;
                draw();
              } else if (selected) {
                await apiJson(adminApiUrl(`/v31/mail-templates/${selected.id}`), { method: "PUT", body: payload });
                window.YuitorUI?.Toast?.success("Mail template saved & HTML sanitized.");
                const fresh = await apiJson(adminApiUrl("/v31/mail-templates"));
                templates.splice(0, templates.length, ...(fresh.templates || []));
                selected = templates.find((t) => Number(t.id) === Number(selected.id)) || templates[0];
                draw();
              }
            } catch (err) {
              window.YuitorUI?.Toast?.error(err.message);
            }
          });

          form.querySelector("[data-mt-delete]")?.addEventListener("click", async () => {
            const ok = await confirmModal({
              title: "Delete Mail Template",
              message: `Delete custom template "${selected?.name}"?`,
              confirmLabel: "Yes, Delete",
              variant: "danger",
            });
            if (!ok) return;
            try {
              await apiJson(adminApiUrl(`/v31/mail-templates/${selected.id}`), { method: "DELETE" });
              window.YuitorUI?.Toast?.success("Template deleted.");
              const fresh = await apiJson(adminApiUrl("/v31/mail-templates"));
              templates.splice(0, templates.length, ...(fresh.templates || []));
              selected = templates[0] || null;
              draw();
            } catch (err) {
              window.YuitorUI?.Toast?.error(err.message);
            }
          });

          form.querySelector("[data-mt-test-send]")?.addEventListener("click", async () => {
            const to = form.querySelector("[data-mt-test-email]")?.value?.trim() || "";
            try {
              const r = await apiJson(adminApiUrl("/v31/mail-templates/test-send"), {
                method: "POST",
                body: {
                  to,
                  themeKey: themeSel?.value || "yuitor_navy",
                  subject: subjInput?.value || "Test Mail",
                  htmlBody: bodyTa?.value || "",
                  slug: selected?.slug || "test_preview",
                },
              });
              window.YuitorUI?.Toast?.success(r.ok ? `Test mail sent to ${to || "Admin email"}!` : r.error || "Failed to send test mail.");
            } catch (err) {
              window.YuitorUI?.Toast?.error(err.message);
            }
          });
        }
      };

      draw();
    } catch (err) {
      container.innerHTML = `<div class="v31-error-state">${esc(err.message || "Unable to load Mail Templates.")}</div>`;
    }
  }

  /* ==========================================================================
   * 10. CHANGE [14]: Cross-Selling Admin Settings + Dry-Run Preview
   * ======================================================================== */
  async function renderCrossSellAdminSection(container, adminApiUrl) {
    if (!container) return;
    container.innerHTML = `<div class="v31-skeleton" style="height:120px;"></div>`;
    try {
      let cfg = await apiJson(adminApiUrl("/v31/cross-sell/settings"));
      let previewData = null;

      const draw = () => {
        container.innerHTML = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;" data-testid="v31-cross-sell-admin">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">Cross-Selling Automation &amp; Weekly Discount Engine</h3>
                <p class="portal-hint" style="margin:4px 0 0;">Active students ONLY (unpurchased courses in current class). Week 1: 10% · Week 2: 20% · Week 3: 30% · Week 4: 40%. Server-side tamper-proof checkout (no coupon stacking).</p>
              </div>
              <span class="portal-status portal-status--${cfg.masterSwitch ? "approved" : "pending"}" data-testid="cross-sell-switch-badge">
                Master Switch: ${cfg.masterSwitch ? "ON" : "OFF (Safe Default)"}
              </span>
            </div>
            <form class="portal-form" data-cs-settings-form>
              <div class="portal-form-grid">
                <div class="portal-field">
                  <label>Master Switch (Auto Weekly Cross-Sell Mails)</label>
                  <select name="masterSwitch" data-testid="cross-sell-master-select">
                    <option value="0" ${!cfg.masterSwitch ? "selected" : ""}>OFF — Zero auto-mails sent (Default)</option>
                    <option value="1" ${cfg.masterSwitch ? "selected" : ""}>ON — Send max 1 auto-mail/week/active student</option>
                  </select>
                </div>
                <div class="portal-field">
                  <label>Post-4-Week Behaviour</label>
                  <select name="post4WeekBehavior" data-testid="cross-sell-post4-select">
                    <option value="stop" ${cfg.post4WeekBehavior === "stop" ? "selected" : ""}>Stop after Week 4 (Default)</option>
                    <option value="hold_40" ${cfg.post4WeekBehavior === "hold_40" ? "selected" : ""}>Hold at 40% OFF</option>
                  </select>
                </div>
              </div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">Save Cross-Sell Settings</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cs-preview data-testid="cross-sell-dry-run-btn">${lucideIcon("eye")} Preview Eligible Students (Dry-Run)</button>
                <button type="button" class="portal-button portal-button--small v31-btn-warning" data-cs-dispatch ${!cfg.masterSwitch ? "disabled title='Turn Master Switch ON first'" : ""}>${lucideIcon("send")} Run Weekly Dispatch Now</button>
              </div>
            </form>
            ${
              previewData
                ? `<div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--v31-border);">
                     <h4 style="margin:0 0 10px;font-size:14px;font-weight:800;">Dry-Run Eligible Active Students (${previewData.totalEligible}) — Zero Mails Sent</h4>
                     <div class="portal-table-scroll"><table class="portal-table">
                       <thead><tr><th>Student</th><th>Current Class</th><th>Week</th><th>Discount</th><th>Unpurchased Courses</th><th>This Week Mail</th></tr></thead>
                       <tbody>
                         ${
                           (previewData.students || [])
                             .map(
                               (s) => `
                             <tr>
                               <td><strong>${esc(s.name)}</strong><span class="portal-cell-sub">${esc(s.email)}</span></td>
                               <td>${esc(s.classLevel)}</td>
                               <td>Week ${s.weekNumber}</td>
                               <td><strong style="color:#16A34A;">${s.discountPercent}% OFF</strong></td>
                               <td>${esc((s.availableCourses || []).join(", "))}</td>
                               <td>${s.alreadyMailedThisWeek ? "Already Sent" : "Ready"}</td>
                             </tr>`
                             )
                             .join("") || `<tr><td colspan="6" class="portal-empty">No eligible active students with unpurchased courses in their current class right now.</td></tr>`
                         }
                       </tbody>
                     </table></div>
                   </div>`
                : ""
            }
          </div>
        `;

        container.querySelector("[data-cs-settings-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const nextSwitch = fd.get("masterSwitch") === "1";
          const nextPost4 = fd.get("post4WeekBehavior") || "stop";
          const ok = await confirmModal({
            title: "Confirm Cross-Sell Settings Update",
            message: `Save Master Switch as ${nextSwitch ? "ON" : "OFF"} and Post-4-Week behaviour as "${nextPost4 === "hold_40" ? "Hold at 40%" : "Stop"}"?`,
            confirmLabel: "Yes, Save Settings",
          });
          if (!ok) return;
          try {
            cfg = await apiJson(adminApiUrl("/v31/cross-sell/settings"), {
              method: "PATCH",
              body: { masterSwitch: nextSwitch, post4WeekBehavior: nextPost4 },
            });
            window.YuitorUI?.Toast?.success("Cross-sell settings updated.");
            draw();
          } catch (err) {
            window.YuitorUI?.Toast?.error(err.message);
          }
        });

        container.querySelector("[data-cs-preview]")?.addEventListener("click", async () => {
          try {
            previewData = await apiJson(adminApiUrl("/v31/cross-sell/preview-eligible"));
            draw();
          } catch (err) {
            window.YuitorUI?.Toast?.error(err.message);
          }
        });

        container.querySelector("[data-cs-dispatch]")?.addEventListener("click", async () => {
          const ok = await confirmModal({
            title: "Run Weekly Cross-Sell Mail Dispatch",
            message: "Send batched cross-sell offer emails (max 1/week/student) to eligible active students now?",
            confirmLabel: "Yes, Dispatch",
            variant: "warning",
          });
          if (!ok) return;
          try {
            const r = await apiJson(adminApiUrl("/v31/cross-sell/run-dispatch"), { method: "POST" });
            window.YuitorUI?.Toast?.success(
              r.skipped ? "Master Switch is OFF — 0 mails sent." : `Dispatch complete: ${r.sent} sent, ${r.failed} failed, ${r.skippedCount} skipped.`
            );
          } catch (err) {
            window.YuitorUI?.Toast?.error(err.message);
          }
        });
      };

      draw();
    } catch (err) {
      container.innerHTML = `<div class="v31-error-state">${esc(err.message)}</div>`;
    }
  }

  /* ==========================================================================
   * 11. SAFETY RULE 5: IST Audit Log Viewer (Admin)
   * ======================================================================== */
  async function renderAuditLogViewer(container, adminApiUrl) {
    if (!container) return;
    container.innerHTML = `<div class="v31-skeleton" style="height:100px;"></div>`;
    try {
      let actionFilter = "all";
      let searchQ = "";
      const loadAndDraw = async () => {
        const res = await apiJson(
          adminApiUrl(`/v31/audit-logs?action=${encodeURIComponent(actionFilter)}&search=${encodeURIComponent(searchQ)}`)
        );
        const logs = res.logs || [];
        container.innerHTML = `
          <div class="portal-card portal-profile" data-testid="v31-audit-log-viewer">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">IST Audit Log Viewer (Suspend / Terminate / Delete / Restore / Class / Discount)</h3>
                <p class="portal-hint" style="margin:3px 0 0;">Server IST Time: <strong>${esc(res.serverTimeIst || "")}</strong></p>
              </div>
              <div class="portal-actions">
                <select data-al-action style="min-height:36px;padding:4px 10px;border:1px solid var(--v31-border);border-radius:8px;background:var(--v31-card);color:var(--v31-text);">
                  <option value="all" ${actionFilter === "all" ? "selected" : ""}>All Audit Actions</option>
                  <option value="suspend" ${actionFilter === "suspend" ? "selected" : ""}>Suspensions</option>
                  <option value="terminate" ${actionFilter === "terminate" ? "selected" : ""}>Terminations</option>
                  <option value="delete" ${actionFilter === "delete" ? "selected" : ""}>Soft Deletes</option>
                  <option value="restore" ${actionFilter === "restore" ? "selected" : ""}>Restores</option>
                  <option value="class" ${actionFilter === "class" ? "selected" : ""}>Class Changes</option>
                  <option value="cross_sell" ${actionFilter === "cross_sell" ? "selected" : ""}>Cross-Sell / Discounts</option>
                </select>
                <input type="search" data-al-search value="${esc(searchQ)}" placeholder="Search actor, target, details..." style="min-height:36px;padding:4px 10px;border:1px solid var(--v31-border);border-radius:8px;background:var(--v31-card);color:var(--v31-text);">
              </div>
            </div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>Details</th><th>IST Timestamp</th></tr></thead>
              <tbody>
                ${
                  logs
                    .map(
                      (a) => `
                  <tr>
                    <td><strong>${esc(a.action)}</strong></td>
                    <td>${esc(a.actor_name || "-")}</td>
                    <td>${esc(a.target_name || "-")}</td>
                    <td>${esc(a.details || "-")}</td>
                    <td style="white-space:nowrap;">${esc(formatIstDate(a.created_at))}</td>
                  </tr>`
                    )
                    .join("") || `<tr><td colspan="5" class="portal-empty">No audit events match this filter.</td></tr>`
                }
              </tbody>
            </table></div>
          </div>
        `;
        container.querySelector("[data-al-action]")?.addEventListener("change", (e) => {
          actionFilter = e.target.value;
          loadAndDraw();
        });
        let t = null;
        container.querySelector("[data-al-search]")?.addEventListener("input", (e) => {
          searchQ = e.target.value;
          clearTimeout(t);
          t = setTimeout(loadAndDraw, 260);
        });
      };
      loadAndDraw();
    } catch (err) {
      container.innerHTML = `<div class="v31-error-state">${esc(err.message)}</div>`;
    }
  }

  /* ==========================================================================
   * 12. CHANGE [9]: Post-Registration Profile Details Editor (Student / Teacher / Staff)
   * ======================================================================== */
  async function renderPostRegProfileCard(container, session, onSaved) {
    if (!container || !["student", "teacher", "staff"].includes(session?.user?.role)) return;
    try {
      const res = await apiJson("/api/v31/my-profile");
      const u = res.user || {};
      const todayIst = res.todayIst || getTodayIstYmd();
      const isStudent = u.role === "student";

      container.innerHTML = `
        <div class="portal-card portal-profile" style="margin-bottom:16px;" data-testid="v31-post-reg-profile">
          <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
            <div>
              <h3 class="portal-section-title" style="margin:0;">${u.completed ? "My Profile Details" : "Complete Your Post-Registration Profile"}</h3>
              <p class="portal-hint" style="margin:3px 0 0;">${
                u.completed
                  ? "Keep your profile photo and personal details up to date."
                  : "Save your photo & date of birth" + (isStudent ? " along with Address & School Name" : "") + " to receive your official Yuitor welcome confirmation mail."
              }</p>
            </div>
            <span class="portal-status portal-status--${u.completed ? "approved" : "pending"}">${u.completed ? "Profile Verified" : "Action Needed"}</span>
          </div>
          <form class="portal-form" data-v31-profile-form>
            <div class="portal-photo-preview-wrap">
              <img src="${esc(u.photoUrl || "/yuitor-icon-192.png")}" alt="Profile preview" data-v31-photo-preview>
              <div style="flex:1;min-width:180px;">
                <label style="display:block;font-size:12px;font-weight:700;margin-bottom:4px;">Profile Photo (JPG or PNG only, max 2 MB)</label>
                <input type="file" accept=".jpg,.jpeg,.png,image/jpeg,image/png" data-v31-photo-file>
              </div>
            </div>
            <div class="portal-form-grid">
              <div class="portal-field">
                <label>Date of Birth (IST — No Future Date) *</label>
                <input type="date" name="dob" max="${esc(todayIst)}" value="${esc(u.dob || "")}" required>
              </div>
              ${
                isStudent
                  ? `<div class="portal-field">
                       <label>School Name *</label>
                       <input type="text" name="schoolName" value="${esc(u.schoolName || "")}" placeholder="Enter your school name" required>
                     </div>
                     <div class="portal-field" style="grid-column:1 / -1;">
                       <label>Residential Address *</label>
                       <input type="text" name="address" value="${esc(u.address || "")}" placeholder="House No., Street, Locality, City" required>
                     </div>`
                  : ""
              }
            </div>
            <div class="portal-message" data-v31-prof-msg hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button portal-button--small" data-testid="v31-save-profile-btn">Save Profile Details</button>
            </div>
          </form>
        </div>
      `;

      let pendingPhotoDataUrl = "";
      const fileInput = container.querySelector("[data-v31-photo-file]");
      const previewImg = container.querySelector("[data-v31-photo-preview]");
      const msgEl = container.querySelector("[data-v31-prof-msg]");

      fileInput?.addEventListener("change", () => {
        const f = fileInput.files?.[0];
        if (!f) return;
        if (!["image/jpeg", "image/png"].includes(f.type)) {
          window.YuitorUI?.Toast?.error("Only JPG or PNG images are allowed.");
          fileInput.value = "";
          return;
        }
        if (f.size > 2 * 1024 * 1024) {
          window.YuitorUI?.Toast?.error("Photo size must be under 2 MB.");
          fileInput.value = "";
          return;
        }
        const reader = new FileReader();
        reader.onload = () => {
          pendingPhotoDataUrl = String(reader.result || "");
          if (previewImg && pendingPhotoDataUrl) previewImg.src = pendingPhotoDataUrl;
        };
        reader.readAsDataURL(f);
      });

      container.querySelector("[data-v31-profile-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const dob = String(fd.get("dob") || "").trim();
        if (dob > todayIst) {
          window.YuitorUI?.Toast?.error("Date of Birth cannot be a future IST date.");
          return;
        }
        try {
          const r = await apiJson("/api/v31/my-profile", {
            method: "POST",
            body: {
              dob,
              photoDataUrl: pendingPhotoDataUrl || undefined,
              address: isStudent ? String(fd.get("address") || "").trim() : undefined,
              schoolName: isStudent ? String(fd.get("schoolName") || "").trim() : undefined,
            },
          });
          setFormDirty(false);
          if (msgEl) {
            msgEl.className = "portal-message portal-message--success";
            msgEl.textContent = r.message || "Profile saved.";
            msgEl.hidden = false;
          }
          window.YuitorUI?.Toast?.success(r.message || "Profile saved.");
          if (r.photoUrl) {
            document.querySelectorAll("[data-topbar-avatar]").forEach((img) => {
              img.src = r.photoUrl;
            });
          }
          if (typeof onSaved === "function") onSaved(r);
        } catch (err) {
          if (msgEl) {
            msgEl.className = "portal-message portal-message--error";
            msgEl.textContent = err.message;
            msgEl.hidden = false;
          }
          window.YuitorUI?.Toast?.error(err.message);
        }
      });
    } catch {
      // non-fatal
    }
  }

  /* ==========================================================================
   * 13. Auto-inject v31-theme.css if not linked in HTML
   * ======================================================================== */
  if (!document.querySelector('link[href*="v31-theme.css"]')) {
    const lnk = document.createElement("link");
    lnk.rel = "stylesheet";
    lnk.href = "/assets/v31-theme.css?v=310";
    document.head.appendChild(lnk);
  }

  window.YuitorV31 = {
    esc,
    lucideIcon,
    formatINR,
    formatIstDate,
    getTodayIstYmd,
    apiJson,
    confirmModal,
    scrollToAndFocus,
    setFormDirty,
    isFormDirty,
    bindDirtyFormTracking,
    confirmDiscardIfDirty,
    pushNavState,
    popPreviousNavState,
    renderPageHeader,
    bindBackButton,
    initOverflowNavbar,
    registerQuickSearch,
    openQuickSearchModal,
    renderStatusTabs,
    renderMailTemplatesTab,
    renderCrossSellAdminSection,
    renderAuditLogViewer,
    renderPostRegProfileCard,
    DEFAULT_SUSPEND_REASONS,
  };
})();
