(() => {
  "use strict";

  if (window.__YUITOR_GUARD_INSTALLED__) return;
  window.__YUITOR_GUARD_INSTALLED__ = true;

  const clientErrors = [];
  const reportedKeys = new Set();
  let moduleStatusCache = null;

  function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[c]));
  }

  function getCsrfToken() {
    try {
      const m = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : "";
    } catch {
      return "";
    }
  }

  function safeJsonParse(raw, fallback) {
    if (raw === null || raw === undefined || raw === "") return fallback;
    if (typeof raw !== "string") return raw;
    try {
      const parsed = JSON.parse(raw);
      return parsed === undefined ? fallback : parsed;
    } catch {
      return fallback;
    }
  }

  function guessModuleFromFilename(src) {
    const s = String(src || "").toLowerCase();
    if (s.includes("chatbot-widget")) return "chatbot";
    if (s.includes("festival-")) return "festival_engine";
    if (s.includes("site-customizations")) return "custom_scripts";
    if (s.includes("addons-portal")) return "addons_cart_wallet";
    if (s.includes("crm-v25")) return "crm_automation";
    if (s.includes("v31-ui")) return "v31_campaigns";
    if (s.includes("v32-public")) return "v32_public";
    if (s.includes("v33-ui")) return "v33_hub";
    if (s.includes("portals")) return "portals_ui";
    return "frontend_shell";
  }

  function reportError(moduleName, message, stack) {
    const cleanMsg = String(message || "Unknown client error").slice(0, 500);
    const cleanMod = String(moduleName || "frontend_shell").slice(0, 64);
    const dedupKey = `${cleanMod}:${cleanMsg.slice(0, 120)}`;
    if (reportedKeys.has(dedupKey) || reportedKeys.size > 25) return;
    reportedKeys.add(dedupKey);

    const record = {
      moduleName: cleanMod,
      message: cleanMsg,
      stack: String(stack || "").slice(0, 1000),
      route: String(location.pathname || "/").slice(0, 180),
      at: new Date().toISOString()
    };
    clientErrors.unshift(record);
    if (clientErrors.length > 50) clientErrors.length = 50;

    try {
      const csrf = getCsrfToken();
      fetch("/api/public/client-error", {
        method: "POST",
        credentials: "same-origin",
        keepalive: true,
        headers: {
          "Content-Type": "application/json",
          ...(csrf ? { "X-CSRF-Token": csrf } : {})
        },
        body: JSON.stringify(record)
      }).catch(() => {});
    } catch {
      // Never throw inside error reporter
    }
  }

  window.addEventListener("error", (event) => {
    try {
      const msg = event?.message || "Script runtime error";
      // Ignore noisy browser-extension or ResizeObserver loop warnings
      if (/ResizeObserver loop/i.test(msg)) return;
      const mod = guessModuleFromFilename(event?.filename);
      reportError(mod, msg, event?.error?.stack || `${event?.filename || ""}:${event?.lineno || 0}`);
    } catch {
      // ignore
    }
  });

  window.addEventListener("unhandledrejection", (event) => {
    try {
      const reason = event?.reason;
      const msg = reason?.message || String(reason || "Unhandled promise rejection");
      const stack = reason?.stack || "";
      const mod = guessModuleFromFilename(stack);
      reportError(mod, msg, stack);
    } catch {
      // ignore
    }
  });

  function safeRun(moduleName, fn) {
    try {
      const res = fn();
      if (res && typeof res.then === "function") {
        return res.catch((err) => {
          reportError(moduleName, err?.message || String(err), err?.stack);
          return null;
        });
      }
      return res;
    } catch (err) {
      reportError(moduleName, err?.message || String(err), err?.stack);
      return null;
    }
  }

  async function loadModuleStatuses() {
    if (moduleStatusCache) return moduleStatusCache;
    try {
      const res = await fetch("/api/public/modules-status", { credentials: "same-origin" });
      if (res.ok) {
        const data = await res.json();
        if (data && data.modules) {
          moduleStatusCache = data.modules;
          applyDisabledWidgetCleanups(moduleStatusCache);
          return moduleStatusCache;
        }
      }
    } catch {
      // Keep default active map on transient network glitch
    }
    return {};
  }

  function applyDisabledWidgetCleanups(mods) {
    if (!mods || typeof mods !== "object") return;
    if (mods.chatbot === false) {
      const chatRoot = document.getElementById("yu-ai-guide-root");
      if (chatRoot) chatRoot.style.display = "none";
    }
    if (mods.festival_engine === false) {
      const festBanner = document.getElementById("yu-festival-banner");
      if (festBanner) festBanner.style.display = "none";
    }
  }

  window.YuitorGuard = {
    safeJsonParse,
    safeRun,
    reportError,
    getClientErrors: () => clientErrors.slice(),
    loadModuleStatuses,
    isModuleActive: (name) => (moduleStatusCache ? moduleStatusCache[name] !== false : true)
  };

  // Non-blocking public module status sync on non-admin pages
  if (!window.__YU_ADMIN_GATE__) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => void loadModuleStatuses());
    } else {
      void loadModuleStatuses();
    }
    return;
  }

  // ============================================================================
  // ADMIN GATE ISOLATION, SYSTEM SHIELD DRAWER & EMERGENCY RESCUE FALLBACK
  // ============================================================================
  const gate = window.__YU_ADMIN_GATE__;
  const adminApiBase = String(gate.apiBase || "").replace(/\/+$/, "");

  async function adminFetch(suffix, opts = {}) {
    const csrf = getCsrfToken();
    const headers = {
      Accept: "application/json",
      ...(opts.body ? { "Content-Type": "application/json" } : {}),
      ...(csrf ? { "X-CSRF-Token": csrf } : {}),
      ...(opts.headers || {})
    };
    const res = await fetch(`${adminApiBase}${suffix}`, {
      method: opts.method || "GET",
      credentials: "same-origin",
      headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error || `Request failed (${res.status})`);
    return data;
  }

  function ensureShieldStyles() {
    if (document.getElementById("yu-shield-styles")) return;
    const style = document.createElement("style");
    style.id = "yu-shield-styles";
    style.textContent = `
      .yu-shield-fab {
        position: fixed; bottom: 18px; right: 18px; z-index: 99990;
        background: #0f172a; color: #f8fafc; border: 1px solid #334155;
        border-radius: 999px; padding: 10px 16px; font: 600 13px/1.2 system-ui,sans-serif;
        cursor: pointer; box-shadow: 0 10px 28px rgba(15,23,42,.35);
        display: inline-flex; align-items: center; gap: 8px;
      }
      .yu-shield-fab:hover { background: #1e293b; }
      .yu-shield-dot { width: 8px; height: 8px; border-radius: 999px; background: #10b981; display: inline-block; }
      .yu-shield-modal-backdrop {
        position: fixed; inset: 0; z-index: 99995; background: rgba(15,23,42,.68);
        display: flex; align-items: center; justify-content: center; padding: 16px;
        font-family: system-ui, -apple-system, sans-serif;
      }
      .yu-shield-modal {
        width: min(940px, 100%); max-height: 90vh; overflow: auto;
        background: #ffffff; color: #0f172a; border-radius: 16px;
        box-shadow: 0 24px 64px rgba(15,23,42,.35); padding: 22px;
      }
      .yu-shield-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 10px; margin: 14px 0; }
      .yu-shield-card { border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px; background: #f8fafc; }
      .yu-shield-btn {
        border: 1px solid #cbd5e1; background: #fff; color: #0f172a; border-radius: 8px;
        padding: 6px 11px; font-size: 12px; font-weight: 600; cursor: pointer;
      }
      .yu-shield-btn.primary { background: #0f172a; color: #fff; border-color: #0f172a; }
      .yu-shield-btn.danger { background: #fef2f2; color: #b91c1c; border-color: #fecaca; }
      .yu-shield-badge {
        display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 700;
      }
      .yu-shield-badge.ok { background: #dcfce7; color: #166534; }
      .yu-shield-badge.off { background: #fee2e2; color: #991b1b; }
      .yu-shield-badge.trip { background: #fef3c7; color: #92400e; }
    `;
    document.head.appendChild(style);
  }

  async function openShieldModal() {
    ensureShieldStyles();
    const existing = document.getElementById("yu-shield-backdrop");
    if (existing) existing.remove();

    const backdrop = document.createElement("div");
    backdrop.id = "yu-shield-backdrop";
    backdrop.className = "yu-shield-modal-backdrop";
    const modal = document.createElement("div");
    modal.className = "yu-shield-modal";
    modal.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
      <div>
        <h2 style="margin:0;font-size:18px;font-weight:800;">System Shield &amp; Zero-Downtime Control</h2>
        <div style="font-size:12px;color:#475569;margin-top:2px;">Isolate faulty modules without taking down Frontend or Admin</div>
      </div>
      <button type="button" class="yu-shield-btn" data-shield-close>Close</button>
    </div>
    <div id="yu-shield-body" style="margin-top:14px;font-size:13px;color:#334155;">Loading resilience telemetry...</div>`;
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop || e.target.closest("[data-shield-close]")) {
        backdrop.remove();
      }
    });

    async function refresh() {
      const bodyEl = modal.querySelector("#yu-shield-body");
      try {
        const data = await adminFetch("/resilience/overview");
        const modulesHtml = (data.modules || []).map((m) => {
          const isTripped = m.circuit_open_until && Date.parse(m.circuit_open_until) > Date.now();
          const isOn = Number(m.enabled) === 1;
          const badge = !isOn
            ? `<span class="yu-shield-badge off">OFF (Isolated)</span>`
            : isTripped
              ? `<span class="yu-shield-badge trip">Circuit Tripped</span>`
              : `<span class="yu-shield-badge ok">Active</span>`;
          return `<div class="yu-shield-card">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div>
                <div style="font-weight:700;font-size:13px;">${esc(m.label)}</div>
                <div style="font-size:11px;color:#64748b;">${esc(m.module_name)} · ${esc(m.category)}</div>
              </div>
              ${badge}
            </div>
            <div style="font-size:11.5px;color:#475569;margin:6px 0 8px;">${esc(m.description)}</div>
            ${m.last_error_message ? `<div style="font-size:11px;color:#b91c1c;background:#fef2f2;padding:5px 7px;border-radius:6px;margin-bottom:8px;">Last error: ${esc(m.last_error_message)}</div>` : ""}
            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
              <button type="button" class="yu-shield-btn ${isOn ? "danger" : "primary"}" data-mod-toggle="${esc(m.module_name)}" data-next="${isOn ? "0" : "1"}">${isOn ? "Disable Module" : "Enable Module"}</button>
              ${isTripped ? `<button type="button" class="yu-shield-btn" data-mod-reset="${esc(m.module_name)}">Reset Circuit</button>` : ""}
              <span style="font-size:11px;color:#64748b;margin-left:auto;">Errors: ${Number(m.total_errors || 0)}</span>
            </div>
          </div>`;
        }).join("");

        const errorsHtml = (data.errors || []).length === 0
          ? `<div style="padding:12px;border:1px solid #e2e8f0;border-radius:8px;color:#166534;background:#f0fdf4;">No recorded runtime errors. All systems healthy.</div>`
          : (data.errors || []).slice(0, 30).map((e) => `
            <div style="border-bottom:1px solid #e2e8f0;padding:8px 0;">
              <div style="display:flex;justify-content:space-between;gap:8px;font-size:11.5px;">
                <strong>[${esc(e.source)}] ${esc(e.module_name)} — ${esc(e.route)}</strong>
                <span style="color:#64748b;">${esc(e.created_at)}</span>
              </div>
              <div style="color:#b91c1c;font-size:12px;margin-top:2px;">${esc(e.message)}</div>
            </div>
          `).join("");

        bodyEl.innerHTML = `
          <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;background:#f1f5f9;padding:10px 12px;border-radius:10px;">
            <div style="font-size:12px;">
              <strong>Uptime:</strong> ${Number(data.uptimeSeconds || 0)}s &nbsp;|&nbsp;
              <strong>RAM:</strong> ${Number(data.memoryMb?.heapUsed || 0)} MB / ${Number(data.memoryMb?.rss || 0)} MB &nbsp;|&nbsp;
              <strong>SQLite Check:</strong> <span style="color:${data.dbQuickCheck === "ok" ? "#166534" : "#b91c1c"};font-weight:700;">${esc(data.dbQuickCheck)}</span>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              <a class="yu-shield-btn" href="/download/yuitor-v3.4-upgrade.zip" download="yuitor-v3.4-upgrade.zip" style="text-decoration:none;">Download v3.4 ZIP</a>
              <button type="button" class="yu-shield-btn" data-shield-dbcheck>Verify DB</button>
              <button type="button" class="yu-shield-btn primary" data-shield-backup>Create Snapshot Backup</button>
              <button type="button" class="yu-shield-btn danger" data-shield-clear>Clear Error Logs</button>
            </div>
          </div>
          <div id="yu-shield-flash" style="margin-top:8px;font-size:12px;"></div>
          <h3 style="margin:14px 0 6px;font-size:14px;font-weight:700;">Isolated Feature Modules &amp; Circuit Breakers</h3>
          <div class="yu-shield-grid">${modulesHtml}</div>
          <h3 style="margin:14px 0 6px;font-size:14px;font-weight:700;">Caught Error Vault (Latest 30)</h3>
          <div style="max-height:240px;overflow:auto;border:1px solid #e2e8f0;border-radius:10px;padding:8px 12px;">${errorsHtml}</div>
        `;

        const flash = (msg, ok = true) => {
          const el = bodyEl.querySelector("#yu-shield-flash");
          if (el) {
            el.style.color = ok ? "#166534" : "#b91c1c";
            el.textContent = msg;
          }
        };

        bodyEl.querySelectorAll("[data-mod-toggle]").forEach((btn) => {
          btn.addEventListener("click", async () => {
            try {
              const name = btn.getAttribute("data-mod-toggle");
              const enabled = btn.getAttribute("data-next") === "1";
              await adminFetch(`/resilience/modules/${encodeURIComponent(name)}/toggle`, {
                method: "POST",
                body: { enabled, resetCircuit: true }
              });
              await refresh();
            } catch (err) {
              flash(err.message, false);
            }
          });
        });

        bodyEl.querySelectorAll("[data-mod-reset]").forEach((btn) => {
          btn.addEventListener("click", async () => {
            try {
              const name = btn.getAttribute("data-mod-reset");
              await adminFetch(`/resilience/modules/${encodeURIComponent(name)}/toggle`, {
                method: "POST",
                body: { enabled: true, resetCircuit: true }
              });
              await refresh();
            } catch (err) {
              flash(err.message, false);
            }
          });
        });

        bodyEl.querySelector("[data-shield-dbcheck]")?.addEventListener("click", async () => {
          try {
            const res = await adminFetch("/resilience/db-check", { method: "POST" });
            flash(`SQLite quick_check: ${res.status}`, res.ok);
          } catch (err) {
            flash(err.message, false);
          }
        });

        bodyEl.querySelector("[data-shield-backup]")?.addEventListener("click", async () => {
          try {
            const res = await adminFetch("/resilience/backup-now", { method: "POST" });
            flash(`Backup snapshot created: ${res.filename}`, true);
          } catch (err) {
            flash(err.message, false);
          }
        });

        bodyEl.querySelector("[data-shield-clear]")?.addEventListener("click", async () => {
          try {
            await adminFetch("/resilience/errors/clear", { method: "POST" });
            await refresh();
          } catch (err) {
            flash(err.message, false);
          }
        });
      } catch (err) {
        bodyEl.innerHTML = `<div style="padding:12px;border:1px solid #fecaca;background:#fef2f2;color:#991b1b;border-radius:10px;">
          <strong>Sign in as Administrator to manage System Shield &amp; Error Vault.</strong><br/>
          <span style="font-size:12px;">${esc(err.message)}</span>
        </div>`;
      }
    }

    await refresh();
  }

  function mountAdminShieldFab() {
    ensureShieldStyles();
    if (document.getElementById("yu-shield-fab")) return;
    const fab = document.createElement("button");
    fab.id = "yu-shield-fab";
    fab.type = "button";
    fab.className = "yu-shield-fab";
    fab.innerHTML = `<span class="yu-shield-dot"></span><span>System Shield</span>`;
    fab.addEventListener("click", () => void openShieldModal());
    document.body.appendChild(fab);
  }

  function mountEmergencyAdminFallbackIfPortalFailed() {
    const root = document.getElementById("root");
    if (!root || root.children.length > 0) return;
    ensureShieldStyles();
    root.innerHTML = `
      <div style="max-width:560px;margin:48px auto;padding:24px;border:1px solid #e2e8f0;border-radius:16px;background:#fff;font-family:system-ui,sans-serif;box-shadow:0 12px 32px rgba(15,23,42,.08);">
        <div style="font-size:12px;font-weight:700;color:#b45309;text-transform:uppercase;">Emergency Admin Recovery Shell</div>
        <h1 style="margin:6px 0 8px;font-size:22px;">Admin Safe-Mode Active</h1>
        <p style="font-size:13.5px;color:#475569;line-height:1.5;">
          The standard UI bundle could not mount, so Yuitor automatically opened the isolated Emergency Admin Shell so you can sign in, disable faulty modules, and inspect error logs.
        </p>
        <form id="yu-rescue-login" style="display:grid;gap:10px;margin-top:14px;">
          <input name="identifier" required placeholder="Admin Email or Mobile" style="padding:10px;border:1px solid #cbd5e1;border-radius:8px;">
          <input name="password" type="password" required placeholder="Password" style="padding:10px;border:1px solid #cbd5e1;border-radius:8px;">
          <button type="submit" class="yu-shield-btn primary" style="padding:10px 14px;font-size:13px;">Sign In to Rescue Console</button>
          <div id="yu-rescue-msg" style="font-size:12px;color:#b91c1c;"></div>
        </form>
        <div style="margin-top:14px;">
          <button type="button" class="yu-shield-btn" id="yu-rescue-open-shield">Open System Shield &amp; Error Vault</button>
        </div>
      </div>
    `;
    root.querySelector("#yu-rescue-open-shield")?.addEventListener("click", () => void openShieldModal());
    root.querySelector("#yu-rescue-login")?.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const form = ev.currentTarget;
      const msg = root.querySelector("#yu-rescue-msg");
      try {
        const res = await adminFetch("/auth/login", {
          method: "POST",
          body: {
            identifier: form.identifier.value,
            password: form.password.value
          }
        });
        if (res.authenticated) {
          await openShieldModal();
          return;
        }
        if (res.otpRequired) {
          msg.style.color = "#0f172a";
          msg.textContent = res.message || "Enter 6-digit OTP sent to your verification email.";
        }
      } catch (err) {
        msg.style.color = "#b91c1c";
        msg.textContent = err.message;
      }
    });
  }

  const onReady = () => {
    mountAdminShieldFab();
    setTimeout(mountEmergencyAdminFallbackIfPortalFailed, 4000);
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", onReady);
  } else {
    onReady();
  }
})();
