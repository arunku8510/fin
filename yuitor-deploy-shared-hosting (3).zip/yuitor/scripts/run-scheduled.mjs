// server/cron.ts
import "dotenv/config";

// server/db.ts
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

// server/security.ts
import bcrypt from "bcryptjs";
var SESSION_TTL_SECONDS = 60 * 60 * 12;
var IMPERSONATION_TTL_SECONDS = 60 * 30;
var OTP_TTL_SECONDS = 60 * 10;
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function normalizePhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith("0")) {
    return digits.slice(1);
  }
  return digits;
}
function normalizeEmail(raw) {
  return String(raw ?? "").trim().toLowerCase();
}
function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] || c);
}

// server/settings.ts
var SETTING_DEFINITIONS = [
  {
    key: "APP_URL",
    category: "general",
    label: "Public App URL (APP_URL)",
    description: "Primary live domain URL used in emails, unsubscribe links, and origin checks.",
    isSecret: false,
    defaultValue: "https://yuitor.com",
    placeholder: "https://yuitor.com",
    inputType: "url"
  },
  {
    key: "SESSION_SECRET",
    category: "general",
    label: "Session Signing Secret (SESSION_SECRET)",
    description: "Strong random secret (min 16 chars, recommended 64-char hex) for signing cookies, OTPs, and download links.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter or generate a strong 64-char hex secret",
    inputType: "password"
  },
  {
    key: "YU_ADMIN_SETUP_KEY",
    category: "general",
    label: "First-Admin Setup Key (YU_ADMIN_SETUP_KEY)",
    description: "Optional security key required when creating the first Super Admin in the installer.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Optional secret key for installer setup",
    inputType: "password"
  },
  {
    key: "ADMIN_IP_ALLOWLIST",
    category: "general",
    label: "Admin IP Allow-List (Optional)",
    description: "Optional comma-separated IPs or IPv4 CIDRs allowed to sign into the Admin Gate (leave blank for any IP).",
    isSecret: false,
    defaultValue: "",
    placeholder: "e.g. 127.0.0.1, 203.0.113.0/24",
    inputType: "text"
  },
  {
    key: "ADMIN_OTP_EMAIL",
    category: "general",
    label: "Admin & Installer 2FA OTP Email (ADMIN_OTP_EMAIL)",
    description: "Verification email address that receives a 6-digit OTP for Installer verification and every Admin Console sign-in.",
    isSecret: false,
    defaultValue: "arunku8510@gmail.com",
    placeholder: "arunku8510@gmail.com",
    inputType: "email"
  },
  {
    key: "GEMINI_API_KEY",
    category: "ai",
    label: "Google Gemini API Key (GEMINI_API_KEY)",
    description: "Enables live Gemini LLM responses for Shreya Smart AI (deterministic bilingual fallback runs when unset).",
    isSecret: true,
    defaultValue: "",
    placeholder: "AIza...",
    inputType: "password"
  },
  {
    key: "GEMINI_MODEL",
    category: "ai",
    label: "Gemini Model Name (GEMINI_MODEL)",
    description: "Gemini model ID used for live Shreya AI replies (recommended: gemini-2.5-flash).",
    isSecret: false,
    defaultValue: "gemini-2.5-flash",
    placeholder: "gemini-2.5-flash",
    inputType: "text"
  },
  {
    key: "SMTP_HOST",
    category: "email",
    label: "SMTP Host (SMTP_HOST)",
    description: "Outgoing mail server hostname (e.g. smtp.hostinger.com or smtp.gmail.com).",
    isSecret: false,
    defaultValue: "",
    placeholder: "smtp.hostinger.com",
    inputType: "text"
  },
  {
    key: "SMTP_PORT",
    category: "email",
    label: "SMTP Port (SMTP_PORT)",
    description: "SMTP port number (587 for STARTTLS, 465 for SSL/TLS).",
    isSecret: false,
    defaultValue: "587",
    placeholder: "587",
    inputType: "number"
  },
  {
    key: "SMTP_SECURE",
    category: "email",
    label: "Use SSL/TLS (SMTP_SECURE)",
    description: "Enable direct TLS (true for port 465, false for port 587 STARTTLS).",
    isSecret: false,
    defaultValue: "false",
    placeholder: "false",
    inputType: "boolean"
  },
  {
    key: "SMTP_USER",
    category: "email",
    label: "SMTP Username (SMTP_USER)",
    description: "Authenticated email login username.",
    isSecret: false,
    defaultValue: "",
    placeholder: "info@yuitor.com",
    inputType: "text"
  },
  {
    key: "SMTP_PASS",
    category: "email",
    label: "SMTP Password (SMTP_PASS)",
    description: "SMTP mailbox password or app password (stored securely on server).",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter SMTP password or app password",
    inputType: "password"
  },
  {
    key: "MAIL_FROM_NAME",
    category: "email",
    label: "Sender Display Name (MAIL_FROM_NAME)",
    description: "Display name shown in outgoing emails.",
    isSecret: false,
    defaultValue: "Yuitor Smart Classes",
    placeholder: "Yuitor Smart Classes",
    inputType: "text"
  },
  {
    key: "MAIL_FROM_EMAIL",
    category: "email",
    label: "Sender Email (MAIL_FROM_EMAIL)",
    description: "From address for marketing campaigns and system emails.",
    isSecret: false,
    defaultValue: "info@yuitor.com",
    placeholder: "info@yuitor.com",
    inputType: "email"
  },
  {
    key: "REPLY_TO_EMAIL",
    category: "email",
    label: "Reply-To Email (REPLY_TO_EMAIL)",
    description: "Address where replies from students/parents are delivered.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "ADMIN_NOTIFY_EMAIL",
    category: "email",
    label: "Admin Alert Email (ADMIN_NOTIFY_EMAIL)",
    description: "Recipient email for new admission enquiries and registration approvals.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_ADMISSION",
    category: "email",
    label: "Department: Admissions Email",
    description: "Shown on Admission & Contact sections and used as Reply-To for enquiry/admission notifications.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_INQUIRY",
    category: "email",
    label: "Department: General Inquiry Email",
    description: "Primary public general inquiry address in header, footer, and contact cards.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_COMPLAIN",
    category: "email",
    label: "Department: Complaints Email",
    description: "Official complaints address displayed in footer, contact, and student support sections.",
    isSecret: false,
    defaultValue: "complain@yuitor.com",
    placeholder: "complain@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_SUPPORT",
    category: "email",
    label: "Department: Student & Portal Support Email",
    description: "Technical and student support contact inside Contact & Student Support portal tabs.",
    isSecret: false,
    defaultValue: "support@yuitor.com",
    placeholder: "support@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_GRIEVANCE",
    category: "email",
    label: "Department: Academic Grievance Email",
    description: "Escalation & dispute contact linked on Terms of Use and Student Support.",
    isSecret: false,
    defaultValue: "grievance@yuitor.com",
    placeholder: "grievance@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_FEE",
    category: "email",
    label: "Department: Fee & Billing Desk Email",
    description: "Reply-To for fee receipts and shown inside Student Fees & Receipts.",
    isSecret: false,
    defaultValue: "fee@yuitor.com",
    placeholder: "fee@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_CAREER",
    category: "email",
    label: "Department: Faculty Careers Email",
    description: "Contact email for teaching applications & resume queries on Teacher Registration.",
    isSecret: false,
    defaultValue: "career@yuitor.com",
    placeholder: "career@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_PRIVACY",
    category: "email",
    label: "Department: Privacy & Data Officer Email",
    description: "Data protection contact email displayed on Privacy Policy.",
    isSecret: false,
    defaultValue: "privacy@yuitor.com",
    placeholder: "privacy@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_REFUND",
    category: "email",
    label: "Department: Refund Desk Email",
    description: "Refund requests & withdrawal contact linked on Refund Policy and Fees.",
    isSecret: false,
    defaultValue: "refund@yuitor.com",
    placeholder: "refund@yuitor.com",
    inputType: "email"
  },
  {
    key: "FAST2SMS_API_KEY",
    category: "sms",
    label: "Fast2SMS API Key (FAST2SMS_API_KEY)",
    description: "Sends live 6-digit SMS OTPs to mobile numbers during registration and password reset.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Fast2SMS authorization key",
    inputType: "password"
  },
  {
    key: "FAST2SMS_ROUTE",
    category: "sms",
    label: "Fast2SMS Route (FAST2SMS_ROUTE)",
    description: "Choose 'q' for Quick SMS, 'otp' for OTP route, or 'dlt' for TRAI DLT approved templates.",
    isSecret: false,
    defaultValue: "q",
    placeholder: "q",
    inputType: "text"
  },
  {
    key: "FAST2SMS_SENDER_ID",
    category: "sms",
    label: "Fast2SMS Sender ID (Optional)",
    description: "Approved 6-character DLT sender ID (e.g. YUITOR) when using DLT route.",
    isSecret: false,
    defaultValue: "",
    placeholder: "YUITOR",
    inputType: "text"
  },
  {
    key: "FAST2SMS_DLT_TEMPLATE_ID",
    category: "sms",
    label: "Fast2SMS DLT Template ID (Optional)",
    description: "Registered TRAI DLT Template/Message ID when FAST2SMS_ROUTE is set to dlt.",
    isSecret: false,
    defaultValue: "",
    placeholder: "17071...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_ID",
    category: "payments",
    label: "Razorpay Key ID (RAZORPAY_KEY_ID)",
    description: "Public Razorpay Merchant Key ID (starts with rzp_live_ or rzp_test_).",
    isSecret: false,
    defaultValue: "",
    placeholder: "rzp_live_...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_SECRET",
    category: "payments",
    label: "Razorpay Key Secret (RAZORPAY_KEY_SECRET)",
    description: "Secret key used to create Razorpay orders and verify HMAC-SHA256 payment signatures.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter Razorpay key secret",
    inputType: "password"
  },
  {
    key: "RAZORPAY_WEBHOOK_SECRET",
    category: "payments",
    label: "Razorpay Webhook Secret (Optional)",
    description: "Webhook signing secret used to verify incoming Razorpay webhook events.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter webhook secret",
    inputType: "password"
  }
];
var SETTING_MAP = new Map(SETTING_DEFINITIONS.map((d) => [d.key, d]));
var ENV_BASELINE = /* @__PURE__ */ new Map();
var baselineCaptured = false;
function captureEnvBaseline() {
  if (baselineCaptured) return;
  for (const def of SETTING_DEFINITIONS) {
    ENV_BASELINE.set(def.key, process.env[def.key]);
  }
  baselineCaptured = true;
}
function hydrateRuntimeSettings(db) {
  captureEnvBaseline();
  const rows = db.prepare("SELECT key, value FROM system_settings").all();
  const dbMap = new Map(rows.map((r) => [r.key, String(r.value ?? "")]));
  for (const def of SETTING_DEFINITIONS) {
    const saved = dbMap.get(def.key);
    if (saved !== void 0 && saved.trim() !== "") {
      process.env[def.key] = saved;
    } else {
      const orig = ENV_BASELINE.get(def.key);
      if (orig !== void 0) {
        process.env[def.key] = orig;
      } else {
        delete process.env[def.key];
      }
    }
  }
  hydrateRuntimeSettingsExtra(dbMap);
}
function hydrateRuntimeSettingsExtra(dbMap) {
  const adminPathSaved = dbMap.get("ADMIN_PATH");
  if (adminPathSaved !== void 0 && adminPathSaved.trim() !== "") {
    process.env.ADMIN_PATH = adminPathSaved.trim();
  }
}
function getDepartmentEmails() {
  const pick = (key, fallback) => {
    const val = String(process.env[key] || "").trim();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val) ? val : fallback;
  };
  return {
    admission: pick("EMAIL_ADMISSION", "admission@yuitor.com"),
    support: pick("EMAIL_SUPPORT", "support@yuitor.com"),
    grievance: pick("EMAIL_GRIEVANCE", "grievance@yuitor.com"),
    fee: pick("EMAIL_FEE", "fee@yuitor.com"),
    career: pick("EMAIL_CAREER", "career@yuitor.com"),
    privacy: pick("EMAIL_PRIVACY", "privacy@yuitor.com"),
    refund: pick("EMAIL_REFUND", "refund@yuitor.com"),
    inquiry: pick("EMAIL_INQUIRY", "inquiry@yuitor.com"),
    complain: pick("EMAIL_COMPLAIN", "complain@yuitor.com")
  };
}

// server/db.ts
function resolveAppRoot() {
  const hasPublicContext = (dir) => fs.existsSync(path.join(dir, "public")) || fs.existsSync(path.join(dir, "index.html")) || fs.existsSync(path.resolve(dir, "..", "public_html"));
  const candidates = [];
  try {
    const selfDir = path.dirname(fileURLToPath(import.meta.url));
    candidates.push(selfDir, path.resolve(selfDir, ".."));
  } catch {
  }
  candidates.push(process.cwd());
  if (process.argv[1]) {
    const argvDir = path.dirname(path.resolve(process.argv[1]));
    candidates.push(argvDir, path.resolve(argvDir, ".."));
  }
  for (const dir of candidates) {
    if (fs.existsSync(path.join(dir, "database")) && hasPublicContext(dir)) {
      return dir;
    }
  }
  return process.cwd();
}
var APP_ROOT = resolveAppRoot();
function resolvePublicDir(appRoot = APP_ROOT) {
  const envDir = (process.env.YUITOR_PUBLIC_DIR || "").trim();
  if (envDir) {
    const resolved = path.isAbsolute(envDir) ? envDir : path.resolve(appRoot, envDir);
    if (fs.existsSync(resolved)) {
      return resolved;
    }
  }
  const bundledPublic = path.join(appRoot, "public");
  if (fs.existsSync(bundledPublic)) {
    return bundledPublic;
  }
  if (fs.existsSync(path.join(appRoot, "index.html"))) {
    return appRoot;
  }
  const siblingPublicHtml = path.resolve(appRoot, "..", "public_html");
  if (fs.existsSync(siblingPublicHtml)) {
    return siblingPublicHtml;
  }
  return bundledPublic;
}
var PUBLIC_DIR = resolvePublicDir();
var DATA_DIR = path.join(APP_ROOT, "data");
var BACKUPS_DIR = path.join(APP_ROOT, "backups");
var LOGS_DIR = path.join(APP_ROOT, "logs");
var UPLOADS_DIR = path.join(APP_ROOT, "uploads");
var RESUMES_DIR = path.join(UPLOADS_DIR, "resumes");
var KNOWLEDGE_DIR = path.join(UPLOADS_DIR, "knowledge");
var DB_PATH = path.join(DATA_DIR, "yuitor.db");
var LEGACY_DB_PATH = path.join(DATA_DIR, "legacy-portal.sqlite");
var MIGRATION_PATH = path.join(APP_ROOT, "database", "migrations", "001_unified_portal.sql");
var dbInstance = null;
function ensureSchemaUpgrades(db) {
  const cols = db.prepare("PRAGMA table_info(teacher_profiles)").all();
  const existing = new Set(cols.map((c) => c.name));
  const additions = [
    ["resume_url", "ALTER TABLE teacher_profiles ADD COLUMN resume_url TEXT NOT NULL DEFAULT ''"],
    ["resume_filename", "ALTER TABLE teacher_profiles ADD COLUMN resume_filename TEXT NOT NULL DEFAULT ''"],
    ["resume_mime", "ALTER TABLE teacher_profiles ADD COLUMN resume_mime TEXT NOT NULL DEFAULT ''"],
    ["resume_size", "ALTER TABLE teacher_profiles ADD COLUMN resume_size INTEGER NOT NULL DEFAULT 0"],
    ["resume_status", "ALTER TABLE teacher_profiles ADD COLUMN resume_status TEXT NOT NULL DEFAULT 'missing'"],
    ["resume_uploaded_at", "ALTER TABLE teacher_profiles ADD COLUMN resume_uploaded_at TEXT"],
    ["resume_notes", "ALTER TABLE teacher_profiles ADD COLUMN resume_notes TEXT NOT NULL DEFAULT ''"]
  ];
  for (const [col, sql] of additions) {
    if (!existing.has(col)) {
      db.exec(sql);
    }
  }
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      is_secret INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT '',
      updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS knowledge_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/pdf',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      file_path TEXT NOT NULL DEFAULT '',
      extracted_text TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS admin_login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      identifier TEXT NOT NULL DEFAULT '',
      ip_address TEXT NOT NULL DEFAULT '',
      user_agent TEXT NOT NULL DEFAULT '',
      outcome TEXT NOT NULL DEFAULT 'failed',
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_created ON admin_login_attempts(created_at DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_gateway_payment_id
      ON payments(gateway_payment_id)
      WHERE gateway_payment_id != '';
  `);
}
function ensureSessionSecret(db) {
  const cur = (process.env.SESSION_SECRET || "").trim();
  if (cur && cur !== "replace-with-64-char-random-hex-secret") {
    return;
  }
  const row = db.prepare("SELECT value FROM system_settings WHERE key = 'SESSION_SECRET'").get();
  if (row?.value && row.value.trim().length >= 16) {
    process.env.SESSION_SECRET = row.value.trim();
    return;
  }
  const generated = crypto.randomBytes(32).toString("hex");
  db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES ('SESSION_SECRET', ?, 1, ?, NULL)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, is_secret = 1, updated_at = excluded.updated_at`
  ).run(generated, nowIso());
  process.env.SESSION_SECRET = generated;
}
function getDb() {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  fs.mkdirSync(RESUMES_DIR, { recursive: true });
  fs.mkdirSync(KNOWLEDGE_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec("PRAGMA busy_timeout = 5000;");
  const schemaSql = fs.readFileSync(MIGRATION_PATH, "utf8");
  db.exec(schemaSql);
  ensureSchemaUpgrades(db);
  hydrateRuntimeSettings(db);
  ensureSessionSecret(db);
  migrateLegacySqliteIfNeeded(db);
  seedDefaultContent(db);
  ensureStartupBackup(db);
  dbInstance = db;
  return db;
}
function migrateLegacySqliteIfNeeded(db) {
  const migratedFlag = db.prepare("SELECT value FROM schema_meta WHERE key = 'legacy_portal_migrated'").get();
  if (migratedFlag?.value === "1") return;
  if (!fs.existsSync(LEGACY_DB_PATH)) {
    db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
    return;
  }
  try {
    const legacy = new DatabaseSync(LEGACY_DB_PATH, { readOnly: true });
    const now = nowIso();
    const admins = legacy.prepare("SELECT * FROM admins").all();
    for (const a of admins) {
      const email = normalizeEmail(a.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
           VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', ?, 0, ?, ?, ?, ?)`
        ).run(
          a.display_name || "Admin",
          email,
          normalizePhone(a.phone || "7827289292"),
          a.password_hash,
          Number(a.is_active ?? 1),
          crypto.randomBytes(18).toString("hex"),
          a.last_login_at || null,
          a.created_at || now,
          now
        );
      }
    }
    const students = legacy.prepare("SELECT * FROM students").all();
    for (const s of students) {
      const email = normalizeEmail(s.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        const vStatus = s.registration_status === "active" || s.registration_status === "completed" ? "approved" : s.registration_status === "inactive" ? "suspended" : "pending_approval";
        const res = db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
             VALUES ('student', ?, ?, ?, ?, 1, ?, ?, 1, ?, ?, ?, ?)`
        ).run(
          s.full_name || "Student",
          email,
          normalizePhone(s.phone || ""),
          s.password_hash,
          vStatus,
          Number(s.is_active ?? 1),
          crypto.randomBytes(18).toString("hex"),
          s.last_login_at || null,
          s.created_at || now,
          s.updated_at || now
        );
        const uid = Number(res.lastInsertRowid);
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, admission_date, enrollment_status)
           VALUES (?, ?, 'CBSE', ?, ?, ?, ?)`
        ).run(
          uid,
          s.class_level ? `Class ${s.class_level}`.replace(/^Class Class /i, "Class ") : "Class 10",
          JSON.stringify(s.selected_subject ? [s.selected_subject] : ["Mathematics", "Science"]),
          Number(s.course_duration_months || 12),
          s.admission_date || null,
          s.registration_status || "active"
        );
      }
    }
    const inqs = legacy.prepare("SELECT * FROM inquiries").all();
    for (const q of inqs) {
      const exists = db.prepare("SELECT id FROM inquiries WHERE name = ? AND phone = ? AND created_at = ?").get(q.name || "", q.phone || "", q.received_at || now);
      if (!exists) {
        const mappedStatus = q.status === "converted" ? "admitted" : ["new", "contacted", "admitted", "closed"].includes(q.status) ? q.status : "new";
        db.prepare(
          `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
           VALUES (?, ?, ?, ?, ?, 'legacy_import', ?, ?)`
        ).run(
          q.name || "Visitor",
          q.phone || "",
          q.email || "",
          q.course || "General Inquiry",
          q.message || "",
          mappedStatus,
          q.received_at || now
        );
      }
    }
    const fest = legacy.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    if (fest) {
      db.prepare(
        `INSERT OR REPLACE INTO festival_settings (id, mode, manual_festival_id, simulated_date_ist, overrides_json, updated_at)
         VALUES (1, ?, ?, ?, ?, ?)`
      ).run(
        fest.mode || "automatic",
        fest.manual_festival_id || null,
        fest.simulated_date_ist || null,
        fest.overrides_json || "{}",
        fest.updated_at || now
      );
    }
    legacy.close();
  } catch (err) {
    console.warn("[Yuitor DB] Legacy SQLite migration skipped:", err);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
}
function seedDefaultContent(db) {
  const now = nowIso();
  const courseCount = db.prepare("SELECT COUNT(*) as c FROM courses").get().c;
  if (courseCount === 0) {
    const courses = [
      {
        title: "Class 6th\u20138th Foundation Batch",
        slug: "class-6-8-foundation",
        category: "Classes 6-12",
        class_range: "Classes 6\u20138",
        board: "CBSE / ICSE / UP Board",
        description: "Strong conceptual foundation in Mathematics, Science, English, and Social Studies with weekly unit tests and doubt-clearing sessions.",
        duration_months: 12,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/teacher-led-class.webp"
      },
      {
        title: "Class 9th\u201310th Board Mastery Batch",
        slug: "class-9-10-board-mastery",
        category: "Classes 6-12",
        class_range: "Classes 9\u201310",
        board: "CBSE / UP Board / ICSE",
        description: "Complete NCERT + reference syllabus coverage, board sample papers, practical prep, and personal mentor tracking in Muradnagar.",
        duration_months: 12,
        monthly_fee: 1400,
        yearly_fee: 14300,
        thumbnail_url: "/assets/images/math-board.webp"
      },
      {
        title: "Class 11th\u201312th Science & Commerce",
        slug: "class-11-12-board-stream",
        category: "Classes 6-12",
        class_range: "Classes 11\u201312",
        board: "CBSE / UP Board",
        description: "In-depth coaching for Physics, Chemistry, Mathematics, Biology, Accountancy, and Economics with full board mock series.",
        duration_months: 12,
        monthly_fee: 1700,
        yearly_fee: 17300,
        thumbnail_url: "/assets/images/science-lab.webp"
      },
      {
        title: "NEET UG & JEE Foundation / Target",
        slug: "neet-jee-target",
        category: "Competitive",
        class_range: "Classes 11\u201312 & Dropper",
        board: "NTA / Competitive",
        description: "Structured Physics, Chemistry, Biology & Mathematics coaching with daily DPPs, OMR/CBT mock tests, and error analysis.",
        duration_months: 12,
        monthly_fee: 2400,
        yearly_fee: 24500,
        thumbnail_url: "/assets/images/exam-writing.webp"
      },
      {
        title: "CUET UG Entrance Preparation",
        slug: "cuet-ug-prep",
        category: "Competitive",
        class_range: "Class 12 & Graduates",
        board: "NTA CUET",
        description: "Domain subjects, General Test (Quant & Reasoning), and English Language speed-accuracy drills for top central universities.",
        duration_months: 6,
        monthly_fee: 1800,
        yearly_fee: 18400,
        thumbnail_url: "/assets/images/group-study.webp"
      },
      {
        title: "Computer Courses (DCA, Tally Prime & Web)",
        slug: "computer-dca-tally",
        category: "Computer",
        class_range: "Students & Job Seekers",
        board: "Practical Certification",
        description: "Hands-on training in MS Office, Tally Prime with GST, CCC, HTML/CSS, and practical computer lab sessions.",
        duration_months: 6,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/computer-class.webp"
      },
      {
        title: "AI Learning & Python Coding Lab",
        slug: "ai-learning-python",
        category: "AI Learning",
        class_range: "Class 6th to College",
        board: "Applied Tech Track",
        description: "Learn Python programming, AI prompt engineering, automation workflows, and real student mini-projects in our guided lab.",
        duration_months: 6,
        monthly_fee: 1500,
        yearly_fee: 15300,
        thumbnail_url: "/assets/images/coding-workshop.webp"
      },
      {
        title: "Spoken English & Communication Skills",
        slug: "spoken-english-fluency",
        category: "English Speaking",
        class_range: "All Age Groups",
        board: "Fluency & Confidence",
        description: "Daily speaking practice, grammar correction, pronunciation drills, group discussions, and interview readiness.",
        duration_months: 3,
        monthly_fee: 900,
        yearly_fee: 9200,
        thumbnail_url: "/assets/images/student-project-presentation.webp"
      }
    ];
    const insertCourse = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, thumbnail_url, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );
    for (const c of courses) {
      insertCourse.run(
        c.title,
        c.slug,
        c.category,
        c.class_range,
        c.board,
        c.description,
        c.duration_months,
        c.monthly_fee,
        c.yearly_fee,
        c.thumbnail_url,
        now
      );
    }
    const firstCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insLesson = db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, '', ?, 35, ?, 1, ?)`
    );
    for (const fc of firstCourses) {
      insLesson.run(fc.id, `Orientation & Syllabus Roadmap \u2014 ${fc.title}`, "text", "Complete chapter weightage, study calendar, and weekly test schedule.", 1, now);
      insLesson.run(fc.id, "Core Concepts & Formula Sheet (Module 1)", "pdf", "Structured concept notes and solved board-level practice questions.", 2, now);
    }
  }
  const subjCount = db.prepare("SELECT COUNT(*) as c FROM subjects").get().c;
  if (subjCount === 0) {
    const subjects = [
      ["Mathematics", "MATH-612", "Classes 6\u201312", "NCERT concept clarity, shortcut methods, and weekly chapter tests for CBSE, ICSE, and UP Board."],
      ["Science (Foundation)", "SCI-610", "Classes 6\u201310", "Integrated Physics, Chemistry, and Biology with visual demonstrations and diagram practice."],
      ["Physics", "PHY-1112", "Classes 11\u201312 / JEE / NEET", "Mechanics, Electrostatics, Optics, and numerical problem solving for Boards and competitive exams."],
      ["Chemistry", "CHEM-1112", "Classes 11\u201312 / JEE / NEET", "Physical, Organic, and Inorganic Chemistry with reaction mechanisms and NCERT line-by-line mastery."],
      ["Biology", "BIO-1112", "Classes 11\u201312 / NEET", "Botany & Zoology diagrams, NCERT assertion-reason drills, and NEET PYQ practice."],
      ["English & Spoken Communication", "ENG-ALL", "Classes 6\u201312 & Spoken", "Reading comprehension, board writing formats, grammar accuracy, and daily speaking fluency."],
      ["Computer Applications & DCA", "COMP-DCA", "Classes 6\u201312 & Skill Track", "MS Office, Tally Prime with GST, Internet tools, and fundamentals of computing."],
      ["AI Learning & Python Coding", "AI-PY", "Classes 6\u201312 & Tech", "Python syntax, logic building, responsible AI tools, and practical project creation."]
    ];
    const insSubj = db.prepare(
      "INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const s of subjects) insSubj.run(s[0], s[1], s[2], s[3], now);
  }
  const faqCount = db.prepare("SELECT COUNT(*) as c FROM faqs").get().c;
  if (faqCount === 0) {
    const faqs = [
      ["Where is Yuitor Smart Classes located?", "Our coaching centre is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India."],
      ["Which classes and boards do you teach?", "We offer coaching for Classes 5th to 12th across CBSE, UP Board, and ICSE, alongside JEE, NEET, CUET, Computer Courses, AI Learning, and Spoken English."],
      ["Can students attend a demo class before admission?", "Yes! You can book a free counselling and demo session by submitting the Admission form or calling +91 78-2728-9292."],
      ["How does portal registration and approval work?", "Students and teachers register online, verify their 6-digit mobile OTP, and then the Yuitor Team reviews and approves the account for portal access."],
      ["What is your refund policy?", "Yuitor offers a transparent 7-day refund policy subject to the published admission and refund terms on our website."]
    ];
    const insFaq = db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, ?, 1, ?)");
    faqs.forEach((f, idx) => insFaq.run(f[0], f[1], idx + 1, now));
  }
  const testCount = db.prepare("SELECT COUNT(*) as c FROM testimonials").get().c;
  if (testCount === 0) {
    const tests = [
      ["Aarav Verma", "Class 10 CBSE Student", "95.4% in Board Exams", "Weekly tests and personal doubt sessions at Yuitor Muradnagar made Mathematics and Science much easier to score high in."],
      ["Ananya Tyagi", "Class 12 Science Student", "94% in Physics & Chemistry", "Small batch sizes meant our teachers checked every answer sheet and guided us step by step before boards."],
      ["Mrs. Sunita Chaudhary", "Parent, Muradnagar", "Consistent Academic Growth", "Regular attendance updates and transparent fee tracking keep parents completely informed throughout the session."]
    ];
    const insTest = db.prepare(
      "INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const t of tests) insTest.run(t[0], t[1], t[2], t[3], now);
  }
  const couponCount = db.prepare("SELECT COUNT(*) as c FROM coupons").get().c;
  if (couponCount === 0) {
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES ('YUITOR10', 'percent', 10, 500, 0, 1, ?)"
    ).run(now);
  }
  const tmplCount = db.prepare("SELECT COUNT(*) as c FROM email_templates").get().c;
  if (tmplCount === 0) {
    const templates = [
      ["New Batch Admission Open", "Admission", "Admissions Open at Yuitor Smart Classes, Muradnagar!", "Limited seats for Classes 6th\u201312th, JEE, NEET & Skills.", "<p>Dear {{name}},</p><p>Admissions are now open for our upcoming batches at <strong>Yuitor Smart Classes, Muradnagar</strong> (Classes 6th\u201312th, JEE/NEET/CUET, Computer, AI Learning &amp; Spoken English).</p><p>Book your counselling or demo session today at Trimurti Vihar, Near Venus Academy.</p>"],
      ["Skill & AI Course Promotion", "Course Promotion", "Upgrade Your Skills: AI Learning, Coding & Spoken English", "Practical weekend & weekday batches in Muradnagar.", "<p>Dear {{name}},</p><p>Build future-ready skills with Yuitor Smart Classes! Join our hands-on batches for <strong>AI Learning &amp; Python Coding</strong>, <strong>DCA + Tally Prime</strong>, and <strong>Spoken English</strong>.</p>"],
      ["Monthly Fee Reminder", "Fee Reminder", "Friendly Fee Schedule Reminder \u2014 Yuitor Smart Classes", "Check your fee status and downloadable receipt in Student Portal.", "<p>Dear {{name}},</p><p>This is a gentle reminder to review your current fee schedule in your Student Portal or at the Muradnagar centre desk. Kindly ignore if already settled.</p>"],
      ["Unit & Board Exam Announcement", "Exam Announcement", "Upcoming Test Series & Exam Schedule \u2014 Yuitor Smart Classes", "Important dates and revision checklist inside.", "<p>Dear {{name}},</p><p>Our upcoming weekly evaluation and mock test schedule has been published. Please review your syllabus notes in the Student Portal and arrive 10 minutes early.</p>"],
      ["Student Important Notice", "Student Notice", "Important Student Notice \u2014 Yuitor Smart Classes", "Batch timing and study material update.", "<p>Dear {{name}},</p><p>Please check your Student Dashboard for the latest batch timing updates and newly uploaded PDF notes from your faculty.</p>"],
      ["Faculty & Teacher Notice", "Teacher Notice", "Faculty Coordination Notice \u2014 Yuitor Smart Classes", "Academic schedule and attendance update reminder.", "<p>Dear {{name}},</p><p>Kindly ensure daily batch attendance and weekly assignment grades are updated in the Teacher Portal before 7:00 PM.</p>"],
      ["Festive Wishes from Yuitor", "Festival", "Warm Festive Wishes from Yuitor Smart Classes!", "Wishing you and your family joy, health, and success.", "<p>Dear {{name}},</p><p>Yuitor Smart Classes wishes you and your family a joyful and prosperous celebration! Keep learning and shining.</p>"],
      ["Yuitor Monthly Newsletter", "Newsletter", "Yuitor Monthly Academic Digest & Study Tips", "Highlights, topper strategies, and upcoming workshops.", "<p>Dear {{name}},</p><p>Here is your monthly summary of upcoming workshops, board preparation strategies, and new study resources at Yuitor Smart Classes, Muradnagar.</p>"],
      ["Special Workshop & Occasion", "Special Occasion", "Special Career & Scholarship Seminar \u2014 Yuitor Muradnagar", "Reserve your seat for our weekend seminar.", "<p>Dear {{name}},</p><p>You are invited to our upcoming Career Guidance &amp; Scholarship Evaluation Session at Yuitor Smart Classes, Trimurti Vihar, Muradnagar.</p>"]
    ];
    const insTmpl = db.prepare(
      "INSERT INTO email_templates (name, category, subject, preview_text, html_body, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const t of templates) insTmpl.run(t[0], t[1], t[2], t[3], t[4], now);
  }
}
function verifyBackupIntegrity(backupPath) {
  let checkDb = null;
  try {
    checkDb = new DatabaseSync(backupPath, { readOnly: true });
    const row = checkDb.prepare("PRAGMA quick_check").get();
    const result = row ? Object.values(row)[0] : "";
    return { ok: result === "ok", detail: result || "unknown" };
  } catch (err) {
    return { ok: false, detail: err?.message || "Integrity check failed" };
  } finally {
    try {
      checkDb?.close();
    } catch {
    }
  }
}
function createDatabaseBackup(db, label = "manual") {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const safeLabel = label.replace(/[^a-z0-9_-]/gi, "").slice(0, 20) || "backup";
  const filename = `yuitor-${safeLabel}-${stamp}.db`;
  const dest = path.join(BACKUPS_DIR, filename);
  const escaped = dest.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}';`);
  const stat = fs.statSync(dest);
  const integrity = verifyBackupIntegrity(dest);
  return { filename, sizeBytes: stat.size, createdAt: nowIso(), integrityOk: integrity.ok };
}
function ensureStartupBackup(db) {
  try {
    const files = fs.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db"));
    if (files.length === 0) {
      createDatabaseBackup(db, "startup");
    }
  } catch (err) {
    console.warn("[Yuitor DB] Startup backup warning:", err);
  }
}

// server/mailer.ts
import nodemailer from "nodemailer";
import path2 from "node:path";
import fs2 from "node:fs";
var getSenderName = () => (process.env.MAIL_FROM_NAME || "").trim() || "Yuitor Smart Classes";
var getSenderEmail = () => (process.env.MAIL_FROM_EMAIL || "").trim() || "info@yuitor.com";
var getReplyToEmail = (department) => {
  if (department) {
    return getDepartmentEmails()[department];
  }
  return (process.env.REPLY_TO_EMAIL || "").trim() || getDepartmentEmails().inquiry || "inquiry@yuitor.com";
};
var getAdminNotifyEmail = () => (process.env.ADMIN_NOTIFY_EMAIL || "").trim() || getDepartmentEmails().admission || "admission@yuitor.com";
var SENDER_NAME = getSenderName();
var SENDER_EMAIL = getSenderEmail();
var REPLY_TO_EMAIL = getReplyToEmail();
var ADMIN_NOTIFY_EMAIL = getAdminNotifyEmail();
function isSmtpConfigured() {
  const host = (process.env.SMTP_HOST || "").trim();
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return Boolean(host && host !== "smtp.example.com" && user && pass && !pass.startsWith("replace-with"));
}
function getTransporter() {
  const host = (process.env.SMTP_HOST || "").trim();
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || "").toLowerCase() === "true" || port === 465;
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    connectionTimeout: 1e4,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}
function renderBrandedEmailHtml(opts) {
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const personalized = opts.htmlBody.replace(/\{\{\s*name\s*\}\}/gi, escapeHtml(opts.recipientName || "Student"));
  const ctaBlock = opts.ctaLabel && opts.ctaUrl ? `<p style="margin:24px 0;"><a href="${escapeHtml(opts.ctaUrl)}" style="display:inline-block;background:#1677ff;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:10px;">${escapeHtml(opts.ctaLabel)}</a></p>` : "";
  const unsubBlock = opts.unsubscribeUrl ? `<p style="margin-top:16px;font-size:12px;color:#64748b;">Prefer not to receive promotional updates? <a href="${escapeHtml(opts.unsubscribeUrl)}" style="color:#0f54c4;">Manage email preferences / Unsubscribe</a></p>` : "";
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(opts.subject)}</title></head>
<body style="margin:0;padding:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
  ${opts.previewText ? `<div style="display:none;max-height:0;overflow:hidden;">${escapeHtml(opts.previewText)}</div>` : ""}
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;">
        <tr><td style="background:#0f172a;padding:20px 24px;color:#ffffff;">
          <table role="presentation" width="100%"><tr>
            <td><strong style="font-size:18px;letter-spacing:-0.01em;">Yuitor Smart Classes</strong><div style="font-size:12px;color:#78d3d3;margin-top:2px;">Muradnagar, Ghaziabad \xB7 Classes 6th\u201312th, JEE, NEET &amp; Skills</div></td>
            <td align="right"><img src="${siteUrl}/yuitor-icon-192.png" alt="Yuitor Smart Classes" width="40" height="40" style="border-radius:8px;display:block;"></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:26px 24px;font-size:15px;line-height:1.65;">
          ${personalized}
          ${ctaBlock}
          <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
            <strong>Yuitor Smart Classes</strong><br>
            Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh<br>
            Call / WhatsApp: <a href="tel:+917827289292" style="color:#0f54c4;">+91 78-2728-9292</a> \xB7 Branch: +91 1232314337 \xB7 <a href="${siteUrl}/admission" style="color:#0f54c4;">Apply for Admission</a>
            ${unsubBlock}
          </div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
async function sendEmailDirect(opts) {
  if (!isSmtpConfigured()) {
    return { ok: false, error: "SMTP credentials (SMTP_HOST, SMTP_USER, SMTP_PASS) are not configured on the server." };
  }
  try {
    const transporter = getTransporter();
    const attachments = [];
    if (opts.attachmentUrl && opts.attachmentUrl.startsWith("/uploads/")) {
      const safeName = path2.basename(opts.attachmentUrl);
      const fullPath = path2.join(UPLOADS_DIR, safeName);
      if (fs2.existsSync(fullPath)) {
        attachments.push({ filename: safeName, path: fullPath });
      }
    }
    const info = await transporter.sendMail({
      from: `"${getSenderName()}" <${getSenderEmail()}>`,
      replyTo: opts.replyTo || getReplyToEmail(opts.department),
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text || opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
      attachments
    });
    return { ok: true, messageId: info.messageId || "sent" };
  } catch (err) {
    return { ok: false, error: err?.message || "SMTP delivery failed." };
  }
}
async function processCampaignQueue(db, campaignId, batchSize = 25) {
  const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(campaignId);
  if (!camp || ["paused", "cancelled", "draft"].includes(camp.status)) {
    return { sent: 0, failed: 0 };
  }
  db.prepare("UPDATE email_campaigns SET status = 'sending', updated_at = ? WHERE id = ?").run(nowIso(), campaignId);
  const pendingRows = db.prepare(
    `SELECT d.*, u.unsubscribe_token
       FROM email_deliveries d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.campaign_id = ? AND (d.status = 'pending' OR (d.status = 'failed' AND d.retry_count < 2))
       ORDER BY d.id ASC LIMIT ?`
  ).all(campaignId, batchSize);
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  let sent = 0;
  let failed = 0;
  for (const row of pendingRows) {
    const latest = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
    if (!latest || latest.status === "paused" || latest.status === "cancelled") break;
    const unsubUrl = row.unsubscribe_token ? `${siteUrl}/unsubscribe/${row.unsubscribe_token}` : void 0;
    const html = renderBrandedEmailHtml({
      subject: camp.subject,
      previewText: camp.preview_text,
      htmlBody: camp.html_body,
      recipientName: row.recipient_name,
      ctaLabel: camp.cta_label,
      ctaUrl: camp.cta_url,
      unsubscribeUrl: unsubUrl
    });
    const result = await sendEmailDirect({
      to: row.recipient_email,
      subject: camp.subject,
      html,
      attachmentUrl: camp.attachment_url
    });
    if (result.ok) {
      db.prepare(
        "UPDATE email_deliveries SET status = 'sent', provider_message_id = ?, error_message = '', sent_at = ? WHERE id = ?"
      ).run(result.messageId, nowIso(), row.id);
      sent++;
    } else {
      db.prepare(
        "UPDATE email_deliveries SET status = 'failed', error_message = ?, retry_count = retry_count + 1 WHERE id = ?"
      ).run(result.error, row.id);
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40));
  }
  const counts = db.prepare(
    `SELECT
         SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent_c,
         SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_c,
         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_c
       FROM email_deliveries WHERE campaign_id = ?`
  ).get(campaignId);
  const currentCamp = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
  let nextStatus = currentCamp?.status || "completed";
  if (nextStatus !== "paused" && nextStatus !== "cancelled") {
    nextStatus = Number(counts?.pending_c || 0) > 0 ? "queued" : Number(counts?.sent_c || 0) > 0 ? "completed" : "failed";
  }
  db.prepare(
    "UPDATE email_campaigns SET status = ?, sent_count = ?, failed_count = ?, updated_at = ? WHERE id = ?"
  ).run(nextStatus, Number(counts?.sent_c || 0), Number(counts?.failed_c || 0), nowIso(), campaignId);
  return { sent, failed };
}

// server/cron.ts
async function runScheduledTasks() {
  const db = getDb();
  const nowEpoch = Math.floor(Date.now() / 1e3);
  const nowStr = nowIso();
  const sessRes = db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(nowEpoch);
  const otpRes = db.prepare("DELETE FROM otp_tokens WHERE expires_at <= ?").run(nowEpoch);
  const rlRes = db.prepare("DELETE FROM rate_limits WHERE locked_until IS NOT NULL AND locked_until <= ? AND window_started <= ?").run(nowEpoch, nowEpoch - 3600);
  const due = db.prepare(
    `SELECT id FROM email_campaigns
       WHERE (status = 'queued' AND (scheduled_at IS NULL OR scheduled_at <= ?))
          OR (send_mode = 'scheduled' AND status = 'queued' AND scheduled_at <= ?)`
  ).all(nowStr, nowStr);
  let totalSent = 0;
  let totalFailed = 0;
  for (const camp of due) {
    const res = await processCampaignQueue(db, camp.id, 30);
    totalSent += res.sent;
    totalFailed += res.failed;
  }
  console.log(
    JSON.stringify({
      ok: true,
      ranAt: nowStr,
      cleaned: {
        expiredSessions: Number(sessRes.changes || 0),
        expiredOtps: Number(otpRes.changes || 0),
        staleRateLimits: Number(rlRes.changes || 0)
      },
      campaignsProcessed: due.length,
      emailsSent: totalSent,
      emailsFailed: totalFailed
    })
  );
  db.close();
}
runScheduledTasks().catch((err) => {
  console.error("[Yuitor Cron Error]", err?.message || err);
  process.exit(1);
});
