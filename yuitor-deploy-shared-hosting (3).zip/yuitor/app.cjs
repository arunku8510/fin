// CommonJS startup bridge for cPanel / LiteSpeed / Phusion Passenger Node.js selectors
// Set Startup File to either "server.js" or "app.cjs" inside your hosting panel.
const path = require("node:path");
if (process.cwd() !== __dirname) {
  try {
    process.chdir(__dirname);
  } catch {
    // Ignore chdir errors in restricted environments
  }
}
import(path.join(__dirname, "server.js").startsWith("/") ? `file://${path.join(__dirname, "server.js")}` : "./server.js").catch((err) => {
  console.error("[Yuitor] Failed to boot server.js:", err);
  process.exit(1);
});
