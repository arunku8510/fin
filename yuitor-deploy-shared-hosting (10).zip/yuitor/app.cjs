// CommonJS startup bridge for cPanel / CloudLinux Phusion Passenger / LiteSpeed lsnode / VPS
// Set Startup File to "app.cjs" inside cPanel -> Setup Node.js App.
const path = require("node:path");

if (process.cwd() !== __dirname) {
  try {
    process.chdir(__dirname);
  } catch {
    // Ignore chdir errors in restricted environments; server.cjs resolves APP_ROOT independently
  }
}

const { createApp, serverApp } = require(path.join(__dirname, "server.cjs"));

module.exports = serverApp;
module.exports.createApp = createApp;
module.exports.serverApp = serverApp;
