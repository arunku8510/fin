import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (process.cwd() !== __dirname) {
  try {
    process.chdir(__dirname);
  } catch {
    // Ignore chdir errors in restricted hosting environments
  }
}

const require = createRequire(import.meta.url);
const { createApp, serverApp } = require(path.join(__dirname, "server.cjs"));

export { createApp, serverApp };
export default serverApp;
