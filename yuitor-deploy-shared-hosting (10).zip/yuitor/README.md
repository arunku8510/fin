# Yuitor Smart Classes — Unified Portal, Website & AI Platform

Complete unified web application for **Yuitor Smart Classes** (`https://yuitor.com`), combining the public educational website, Role-Based Portals (**Super Admin / Admin**, **Teacher**, **Student**), **Shreya Smart AI Assistant**, **Email Marketing Engine**, **Course & Fee Payment Ledger**, and **SQLite Database Migration & Atomic Backups** inside a single Node.js + Express + SQLite runtime.

---

## Brand & Official Contact Details

- **Institute:** Yuitor Smart Classes
- **Website:** https://yuitor.com
- **Address:** Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India
- **Call / WhatsApp:** `+91 78-2728-9292`
- **Branch Phone:** `+91 1232314337`
- **Admission Email:** `admission@yuitor.com`
- **General Inquiry:** `inquiry@yuitor.com`
- **Marketing Sender / Reply-To:** `info@yuitor.com` (Reply-To: `inquiry@yuitor.com`)

---

## Key Features Implemented

### 1. Public Website & SEO Shells (`public/`)
- Full multi-page educational experience covering Classes 5th–12th (`CBSE`, `UP Board`, `ICSE`, `State Board`), competitive exams (`NEET`, `JEE`, `CUET`, `NDA`, `SSC`, `Banking`), **Computer Courses**, **AI Learning**, **Spoken English**, **Courses**, **Subjects**, **Teachers**, **Admission**, **Fee Calculator**, **Comparison**, **Scholarship**, **Gallery**, **Results**, **Blog**, **FAQs**, **Testimonials**, **Privacy Policy**, **Terms**, and **Refund Policy**.
- Pre-rendered static HTML route shells (`200 OK` without `301` trailing-slash redirects), synced CSS/Portal bundles across all 50 route shells, deferred `route-seo.js` + `route-metadata.json`, `sitemap.xml`, and `robots.txt` blocking private routes (`/student/`, `/teacher/`, `/login`, `/register`, `/erp/`, `/api/`, `/backups/`, `/data/`). The secret Admin Gate path is never listed in public navigation, `sitemap.xml`, or `robots.txt`.
- Automated header/footer link deduplication and mutation-safe updates (`site-customizations.js`), seasonal theme support (`festival-engine.js`, `festival-system.js` with cached header measurements and zero layout thrashing), real VP8 WebP compressed images (`~3.8 MB` total across all 27 gallery/faculty assets), zero-dependency `gzip` response compression, and route-aware `Cache-Control` headers (`server.ts`).
- Dedicated department email routing across UI & mailer (`admission@yuitor.com`, `support@yuitor.com`, `grievance@yuitor.com`, `fee@yuitor.com`, `career@yuitor.com`, `privacy@yuitor.com`, `refund@yuitor.com`, `inquiry@yuitor.com`, `complain@yuitor.com`).

### 2. Unified Auth, HMAC OTP & Yuitor Team Approval (`server/routes/auth.ts`, `server/security.ts`)
- **Hardened Pre-Install Setup (`/<ADMIN_PATH>/setup`):** Runs preflight diagnostics (`Node >= 22`, `node:sqlite`, writable `data/`, `backups/`, `uploads/`, `logs/`, `.env`, SQLite schema), reports plain-language step/reason/fix errors, logs sanitized diagnostics to `logs/install.log`, requires a 6-digit Email OTP sent to `ADMIN_OTP_EMAIL` (`arunku8510@gmail.com`), supports Step 1A inline SMTP setup when unconfigured, requires explicit confirmation before reusing non-empty DBs or overwriting `.env`, reveals the generated `yt-ctrl-XXXX-gate` URL once, and permanently locks after creating the first Super Admin.
- **Unified Registration (`/register/student`, `/register/teacher`):**
  - Bcrypt password hashing (`$2y$` legacy PHP compatibility included).
  - 6-digit HMAC-SHA256 hashed OTP with 10-minute expiry, attempt limit, 30-second resend cooldown, and IP/account rate limiting.
  - Mandatory **Yuitor Team Approval** state after mobile verification with exact pending notice:
    > *"Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience."*
  - Pending, suspended, or rejected accounts cannot enter Student/Teacher dashboards.
- **Password Recovery:** OTP-based password reset flow (`/api/auth/forgot-password`, `/api/auth/reset-password`).
- **Session Security:** Signed HttpOnly/SameSite/Secure `yu_session` cookies backed by the `sessions` table, CSRF same-origin enforcement on state-changing `/api/*` requests, `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`, `X-Robots-Tag: noindex, nofollow` on admin pages, and `Cache-Control: no-store`.

### 3. Hidden Admin Gate & Console (`/<ADMIN_PATH>/`, `server/admin-gate.ts`, `server/routes/admin.ts`)
- Secret dynamic slug format `yt-ctrl-XXXX-gate` persisted in `system_settings` and `.env` (`ADMIN_PATH`). Predictable `/admin*`, `/wp-admin`, `/login-admin`, `/api/admin*`, and `/api/marketing*` paths return standard `404`.
- Hardened 2-step gate authentication: verifies password + brute-force lockout + optional CIDR IP allow-list (`ADMIN_IP_ALLOWLIST`), then ALWAYS emails a fresh 6-digit verification OTP to `ADMIN_OTP_EMAIL` (`arunku8510@gmail.com`) on every admin sign-in before creating the regenerated session, recording every attempt in `admin_login_attempts`, and supporting password-confirmed slug rotation inside **Admin → Settings**.
- Live KPI overview (students, teachers, pending approvals, courses, admissions, inquiries, unresolved Shreya chats, collected & pending fees).
- Paginated & filterable user management (`super_admin`, `admin`, `teacher`, `student`), profile editing, approve/activate/suspend/reject actions, OTP summary, and activity audit logs.
- **Impersonation Support:** Logged support impersonation into any Student or Teacher portal (`POST /api/<ADMIN_PATH>/impersonate`, 30-minute TTL) with visible banner & one-click `Exit Impersonation` (`POST /api/auth/exit-impersonation`).
- Courses, Subjects, Coupons (`YUITOR10` seeded), Fee/Payment verification (`YTR-RCP-*` receipt generation), Refunds, Inquiries, CMS (Announcements, Banners, Blog, FAQs, Testimonials), Chatbot transcript review, and atomic `VACUUM INTO` database backups.

### 4. Student Portal (`/student/`, `/server/routes/student.ts`)
- Class/Board profile, enrolled courses, expiry enforcement, ordered lessons/videos/PDFs/notes, lesson completion tracking, and automatic `100%` completion certificate code (`YTR-CERT-*`).
- Assignments submission & grades, MCQ quiz attempts & scores, attendance logs, class schedules, fee invoices/receipts (`fee@yuitor.com` / `refund@yuitor.com`), refund request workflow, course reviews, support tickets (`support@yuitor.com` / `grievance@yuitor.com` / `complain@yuitor.com`), and notifications.

### 5. Teacher Portal (`/teacher/`, `/server/routes/teacher.ts`)
- Strict RBAC course scoping (teachers can manage only courses assigned to them; unauthorized course mutations return `403`).
- Course & lesson CRUD, drag/button reordering, visibility toggling, student attendance marking, class schedules, assignments & submission grading, MCQ quiz creation, announcements, and availability/vacation status.

### 6. Payments & Admissions (`/server/routes/payments.ts`)
- Coupon calculation, UPI/Cash pending-verification ledger, Admin verification -> active enrollment + fee record sync + receipt generation, and Razorpay HMAC-SHA256 signature verification when `RAZORPAY_KEY_SECRET` is configured.

### 7. Shreya Smart AI Assistant (`public/assets/chatbot-widget.js`, `server/chatbot.ts`)
- Server-side `@google/genai` integration (`gemini-2.5-flash`) grounded in live SQLite courses/subjects/FAQs + deterministic bilingual Hindi/English/Hinglish fallback when `GEMINI_API_KEY` is absent.
- Automatically redacts passwords and 4–8 digit OTPs before storing messages in `chatbot_messages`, supports star ratings/feedback, and flags unresolved/human requests for Admin escalation.

### 8. Email Marketing Module (Admin Gate Marketing Tab, `server/routes/marketing.ts`, `server/mailer.ts`)
- Branded responsive HTML emails from `info@yuitor.com` (department-aware `Reply-To`) with 9 pre-seeded templates, recipient segmentation & preview, draft/immediate/scheduled/pause/resume/cancel controls, batch delivery logs, test sends, suppression list, and one-click `/unsubscribe/:token` compliance.

---

## Requirements & Setup Guide

### Prerequisites
- **Node.js `22.x+`** (required for built-in `node:sqlite` `DatabaseSync`; tested on Node `v22.23.2`)
- **npm `10+`** (only on build machine; shared hosting ZIP includes runtime dependencies)

### Shared Hosting Deployment (`deploy-shared-hosting.zip`)
See [`DEPLOY-SHARED-HOSTING.md`](./DEPLOY-SHARED-HOSTING.md) for full cPanel step-by-step setup (Layout A `public_html/` + `yuitor_core/`, Layout B fallback, `.htaccess`, `755/644` permissions, `.env`, and cPanel cron).

Build the shared hosting archive locally with:
```bash
npm run build:shared
```
This outputs `dist-shared/deploy-shared-hosting.zip`.

### Local / VPS / PM2 Development
- **Development Mode:**
  ```bash
  npm run dev
  ```
- **Type Check & Unit Tests:**
  ```bash
  npm run lint
  npx --yes tsx --test server/*.test.ts
  ```
- **Production Build & Start:**
  ```bash
  npm run build
  npm start
  ```
- Server binds to `0.0.0.0:${PORT:-3000}`, auto-listens under Phusion Passenger/cPanel & standalone Node, and automatically creates `data/yuitor.db`, `backups/` (startup atomic snapshot), `logs/`, and `uploads/`.

---

## REST API Summary

- **Health & Public:** `GET /api/health`, `GET /api/public/bootstrap`, `POST /api/inquiries`, `POST /api/public/inquiries`, `GET|POST /api/public/unsubscribe/:token`, `POST /api/public/chatbot/session|message|feedback`, `GET /api/festival`, `POST /api/uploads`, `GET /api/download-release`
- **Auth (Student & Teacher):** `POST /api/auth/register`, `POST /api/auth/verify-otp`, `POST /api/auth/resend-otp`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`, `POST /api/auth/forgot-password`, `POST /api/auth/reset-password`, `PATCH /api/auth/avatar`, `POST /api/auth/exit-impersonation`
- **Secret Admin Gate (`/api/<ADMIN_PATH>/*`):** `installer/preflight`, `installer/send-otp`, `installer/run`, `auth/login`, `auth/verify-otp`, `auth/resend-otp`, `dashboard`, `users`, `users/:id`, `users/:id/status`, `impersonate`, `courses`, `subjects`, `payments`, `coupons`, `payments/:id/verify|refund`, `inquiries`, `cms/*`, `chatbot`, `notifications`, `backups`, `settings`, `admin-url`, `settings/admin-path`, `login-attempts`, `marketing/*`
- **Teacher (`/api/teacher/*`):** `dashboard`, `profile`, `announcements`, `courses/:courseId`, `courses/:courseId/lessons`, `lessons/:lessonId`, `attendance`, `schedules`, `assignments`, `assignments/:assignmentId/submissions`, `submissions/:submissionId/grade`, `quizzes`
- **Student (`/api/student/*`):** `dashboard`, `courses/:courseId/lessons`, `lessons/:lessonId/complete`, `assignments/:assignmentId/submit`, `quizzes/:quizId/attempt`, `reviews`, `support`, `notifications/read-all`
- **Payments (`/api/payments/*`):** `enroll`, `refund-request`

---

## Complete File Manifest (All 163 Files Included — Zero Missing Files)

Every single file included in `yuitor-smart-classes-final.zip` is listed below:

### Root Configuration & Entry Files (`10` files)
1. `.env.example`
2. `.gitignore`
3. `README.md`
4. `app.cjs`
5. `htaccess.example`
6. `metadata.json`
7. `package.json`
8. `server.js`
9. `server.ts`
10. `tsconfig.json`

### Database & Uploads (`2` files)
11. `database/migrations/001_unified_portal.sql`
12. `uploads/.gitkeep`

### Server Backend (`11` files)
13. `server/chatbot.ts`
14. `server/db.ts`
15. `server/mailer.ts`
16. `server/routes/admin.ts`
17. `server/routes/auth.ts`
18. `server/routes/marketing.ts`
19. `server/routes/payments.ts`
20. `server/routes/public.ts`
21. `server/routes/student.ts`
22. `server/routes/teacher.ts`
23. `server/security.ts`

### Public Root Assets, SEO, Logos & Route Config (`10` files, #24–#33)
24. `public/favicon.svg`
25. `public/index.html`
26. `public/logo.svg`
27. `public/manifest.json`
28. `public/opengraph-yuitor.jpg`
29. `public/robots.txt`
30. `public/sitemap.xml`
31. `public/yuitor-icon-192.png`
32. `public/yuitor-icon-512.png`
33. `public/yuitor-smart-classes-logo.png`

#### Frontend Bundles, Styles, Portals & SEO Scripts (`public/assets/` — `54` files, #34–#87)
34. `public/assets/About-DVSiWcDR.js`
35. `public/assets/Blog-DspM7SEC.js`
36. `public/assets/BlogPost-B8ATqp-o.js`
37. `public/assets/BoardPage-DLuihC32.js`
38. `public/assets/ClassPage-BQZD-JRi.js`
39. `public/assets/Comparison-C15Jrgga.js`
40. `public/assets/Contact-D_CBGA0z.js`
41. `public/assets/CoursePage-D9FHINXr.js`
42. `public/assets/ExamPage-BgioO1FT.js`
43. `public/assets/FeeCalculator-D-07_p4l.js`
44. `public/assets/Gallery-BE5b_DWH.js`
45. `public/assets/Home-DYyETV50.js`
46. `public/assets/Home-VdLXSkf3.css`
47. `public/assets/PageHero-BIWNEDVc.js`
48. `public/assets/PrivacyPolicy-BPyyiwkh.js`
49. `public/assets/RefundPolicy-CQbVw9Tb.js`
50. `public/assets/Results-DGxFL5fQ.js`
51. `public/assets/SEO-BhsBzmN2.js`
52. `public/assets/Scholarship-BUEv0y4-.js`
53. `public/assets/ScrollTrigger-BrDuEirF.js`
54. `public/assets/TermsOfUse-ByhXKxAB.js`
55. `public/assets/arrow-left-BmKjbtdA.js`
56. `public/assets/blogPosts-LByPJwXY.js`
57. `public/assets/book-open-D6EVD9s5.js`
58. `public/assets/brand-refinements.css`
59. `public/assets/calculator-CEx_8T1S.js`
60. `public/assets/calendar-g3h3VyfI.js`
61. `public/assets/chatbot-widget.js`
62. `public/assets/circle-check-big-BkO7lxfP.js`
63. `public/assets/circle-question-mark-qVsr5Z8E.js`
64. `public/assets/festival-engine.js`
65. `public/assets/festival-system.js`
66. `public/assets/festival-themes.css`
67. `public/assets/images-B1b-hXln.js`
68. `public/assets/index-B5Qt9EMX.js`
69. `public/assets/index-BXOcHfSn.js`
70. `public/assets/index-D4-8ALNT.js`
71. `public/assets/index-Dn8os23u.css`
72. `public/assets/lenis-CmVXbI3P.js`
73. `public/assets/light-theme.css`
74. `public/assets/not-found-Cxa4uswq.js`
75. `public/assets/portals.css`
76. `public/assets/portals.js`
77. `public/assets/rebrand.css`
78. `public/assets/route-metadata.json`
79. `public/assets/route-seo.js`
80. `public/assets/send-DE0GZzFF.js`
81. `public/assets/site-customizations.js`
82. `public/assets/site-palette.css`
83. `public/assets/tag-JcwmYT4g.js`
84. `public/assets/target-yeLuts22.js`
85. `public/assets/three.module-JTBAQdeu.js`
86. `public/assets/trending-up-BfHY5wmk.js`
87. `public/assets/yuitor-home.css`

#### Public Educational & Faculty Images (`public/assets/images/` — `27` files, #88–#114)
88. `public/assets/images/award-ceremony.webp`
89. `public/assets/images/biology-model.webp`
90. `public/assets/images/campus-exterior.webp`
91. `public/assets/images/campus-groups.webp`
92. `public/assets/images/coding-workshop.webp`
93. `public/assets/images/computer-class.webp`
94. `public/assets/images/computer-study.webp`
95. `public/assets/images/electronics-workshop.webp`
96. `public/assets/images/exam-writing.webp`
97. `public/assets/images/faculty-priya-illustrative.webp`
98. `public/assets/images/faculty-ramesh-illustrative.webp`
99. `public/assets/images/faculty-sunita-illustrative.webp`
100. `public/assets/images/faculty-vikas-illustrative.webp`
101. `public/assets/images/founder-owner.webp`
102. `public/assets/images/group-study.webp`
103. `public/assets/images/library-study.webp`
104. `public/assets/images/math-board.webp`
105. `public/assets/images/science-lab-guidance.webp`
106. `public/assets/images/science-lab.webp`
107. `public/assets/images/science-project.webp`
108. `public/assets/images/student-books.webp`
109. `public/assets/images/student-library.webp`
110. `public/assets/images/student-project-presentation.webp`
111. `public/assets/images/study-notes.webp`
112. `public/assets/images/teacher-classroom-guidance.webp`
113. `public/assets/images/teacher-led-class.webp`
114. `public/assets/images/teacher-small-group.webp`

#### Pre-Rendered Route HTML Shells (`49` files, #115–#163)
115. `public/about/index.html`
116. `public/admission/index.html`
117. `public/ai-learning/index.html`
118. `public/blog/board-preparation/index.html`
119. `public/blog/coding-career/index.html`
120. `public/blog/english-speaking/index.html`
121. `public/blog/index.html`
122. `public/blog/jee-preparation/index.html`
123. `public/blog/neet-tips/index.html`
124. `public/blog/study-tips/index.html`
125. `public/board/cbse/index.html`
126. `public/board/icse/index.html`
127. `public/board/state-board/index.html`
128. `public/board/up-board/index.html`
129. `public/class/10/index.html`
130. `public/class/11/index.html`
131. `public/class/12/index.html`
132. `public/class/5/index.html`
133. `public/class/6/index.html`
134. `public/class/7/index.html`
135. `public/class/8/index.html`
136. `public/class/9/index.html`
137. `public/comparison/index.html`
138. `public/computer-courses/index.html`
139. `public/contact/index.html`
140. `public/course/coding/index.html`
141. `public/course/computer/index.html`
142. `public/course/spoken-english/index.html`
143. `public/courses/index.html`
144. `public/english-speaking/index.html`
145. `public/exam/banking/index.html`
146. `public/exam/cuet/index.html`
147. `public/exam/jee/index.html`
148. `public/exam/nda/index.html`
149. `public/exam/neet/index.html`
150. `public/exam/ssc/index.html`
151. `public/faqs/index.html`
152. `public/fee-calculator/index.html`
153. `public/gallery/index.html`
154. `public/login/index.html`
155. `public/privacy/index.html`
156. `public/refund/index.html`
157. `public/register/index.html`
158. `public/results/index.html`
159. `public/scholarship/index.html`
160. `public/subjects/index.html`
161. `public/teachers/index.html`
162. `public/terms/index.html`
163. `public/testimonials/index.html`

---

## Intentionally Excluded Runtime / Sensitive Files (Not Included in ZIP)

- `node_modules/` — Reinstalled on target machine with `npm install`.
- `.env` — Contains deployment-specific API keys and passwords; create from `.env.example`.
- `data/*.db`, `data/legacy-portal.sqlite`, `backups/*.db`, `logs/*` — Runtime databases and existing user records excluded for security; created automatically on server startup (`001_unified_portal.sql`).
- `legacy-php/` & unused duplicate images (`public/opengraph.jpg`, `public/assets/yuitor-watermark.png`) — Excluded as unused by the active Node.js runtime.
