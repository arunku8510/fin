(() => {
  "use strict";

  const root = document.getElementById("root");
  if (!root) return;

  // The homepage orb is decorative. Skip its observer so its large WebGL module
  // is never fetched; all other IntersectionObserver users keep native behavior.
  if (window.IntersectionObserver) {
    const NativeIntersectionObserver = window.IntersectionObserver;
    window.IntersectionObserver = class extends NativeIntersectionObserver {
      observe(target) {
        if (
          target instanceof Element &&
          target.matches(".yu-home .yu-orbit canvas")
        ) {
          return;
        }
        return super.observe(target);
      }
    };
  }

  const formatRupees = (amount) =>
    `₹${Number(amount).toLocaleString("en-IN")}`;
  const annualWithDiscount = (monthly) =>
    Math.round((monthly * 12 * 0.85) / 100) * 100;

  const boardFees = {
    "5": {
      CBSE: { monthly: 1000, yearly: 10200 },
      "UP Board": { monthly: 900, yearly: 9200 },
      ICSE: { monthly: 1200, yearly: 12200 },
    },
    "6": {
      CBSE: { monthly: 1000, yearly: 10200 },
      "UP Board": { monthly: 900, yearly: 9200 },
      ICSE: { monthly: 1200, yearly: 12200 },
    },
    "7": {
      CBSE: { monthly: 1100, yearly: 11200 },
      "UP Board": { monthly: 1000, yearly: 10200 },
      ICSE: { monthly: 1300, yearly: 13300 },
    },
    "8": {
      CBSE: { monthly: 1100, yearly: 11200 },
      "UP Board": { monthly: 1000, yearly: 10200 },
      ICSE: { monthly: 1300, yearly: 13300 },
    },
    "9": {
      CBSE: { monthly: 1400, yearly: 14300 },
      "UP Board": { monthly: 1200, yearly: 12200 },
      ICSE: { monthly: 1500, yearly: 15300 },
    },
    "10": {
      CBSE: { monthly: 1400, yearly: 14300 },
      "UP Board": { monthly: 1200, yearly: 12200 },
      ICSE: { monthly: 1500, yearly: 15300 },
    },
    "11": {
      CBSE: { monthly: 1700, yearly: 17300 },
      "UP Board": { monthly: 1500, yearly: 15300 },
      ICSE: { monthly: 1800, yearly: 18300 },
    },
    "12": {
      CBSE: { monthly: 1700, yearly: 17300 },
      "UP Board": { monthly: 1500, yearly: 15300 },
      ICSE: { monthly: 1800, yearly: 18300 },
    },
  };

  const extraCourseFees = {
    NEET: {
      "Full Course": { monthly: 2400, yearly: 24500 },
      "Crash Course": { monthly: 3000, yearly: 30600 },
    },
    JEE: {
      "Full Course": { monthly: 2400, yearly: 24500 },
      "Crash Course": { monthly: 3000, yearly: 30600 },
    },
    Coding: {
      Basic: { monthly: 800, yearly: 8200 },
      Advanced: { monthly: 1200, yearly: 12200 },
    },
  };

  const examFees = {
    neet: { monthly: 2400, yearly: 24500 },
    jee: { monthly: 2400, yearly: 24500 },
    cuet: { monthly: 2000, yearly: 20400 },
    nda: { monthly: 2200, yearly: 22400 },
    ssc: { monthly: 1800, yearly: 18300 },
    banking: { monthly: 1800, yearly: 18300 },
  };

  const boardPageFees = {
    cbse: { "Class 9-10": 1400, "Class 11-12": 1700 },
    "up-board": { "Class 9-10": 1200, "Class 11-12": 1500 },
    icse: { "Class 9-10": 1500, "Class 11-12": 1800 },
    "state-board": { "Class 9-10": 1200, "Class 11-12": 1500 },
  };

  const courseTrackFees = {
    computer: {
      "Basic Computer Course": 1200,
      "Advanced Computer Course": 1800,
    },
    "spoken-english": {
      "Basic Spoken English": 1500,
      "Advanced Communication": 2200,
    },
    coding: {
      "Web Development Basics": 1700,
      "Python Programming": 2100,
      "Full Stack (React + Node)": 3000,
      "AI & Machine Learning Basics": 2500,
    },
  };

  const indiaNextBatch = () => {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "numeric",
    }).formatToParts(new Date());
    const year = Number(parts.find((part) => part.type === "year").value);
    const month = Number(parts.find((part) => part.type === "month").value);
    const firstOfNextMonth = new Date(Date.UTC(year, month, 1));
    return {
      date: new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        day: "numeric",
        month: "long",
        year: "numeric",
      }).format(firstOfNextMonth),
      month: new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        month: "long",
        year: "numeric",
      }).format(firstOfNextMonth),
      monthName: new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        month: "long",
      }).format(firstOfNextMonth),
      year: firstOfNextMonth.getUTCFullYear(),
    };
  };

  const setText = (element, value) => {
    if (element && element.textContent !== value) element.textContent = value;
  };
  const setAttr = (element, name, value) => {
    if (element && element.getAttribute(name) !== value) {
      element.setAttribute(name, value);
    }
  };
  const setDataset = (element, key, value) => {
    if (element && element.dataset[key] !== value) {
      element.dataset[key] = value;
    }
  };

  function updateBranding() {
    const activeFestival = document.documentElement.getAttribute("data-festival");
    if (!activeFestival || activeFestival === "none") {
      document
        .querySelectorAll('meta[name="theme-color"], meta[name="msapplication-TileColor"]')
        .forEach((meta) => setAttr(meta, "content", "#0F172A"));
    }

    const header = document.querySelector("header");
    if (header) {
      header.querySelectorAll("span, p").forEach((label) => {
        const trimmed = label.textContent.trim();
        if (trimmed === "Yuitor" || (trimmed === "Yuitor Smart Classes" && label.dataset.yuStyled !== "1")) {
          setText(label, "Yuitor Smart Classes");
          label.style.fontSize = "clamp(18px, 1.8vw, 23px)";
          label.style.fontWeight = "700";
          label.style.lineHeight = "1.1";
          label.style.whiteSpace = "nowrap";
          label.dataset.yuStyled = "1";
        }
      });
    }

    const mobileMenu = document.querySelector(".yu-mobile-menu");
    if (mobileMenu) {
      mobileMenu.querySelectorAll("p").forEach((label) => {
        const trimmed = label.textContent.trim();
        if (trimmed === "Yuitor" || (trimmed === "Yuitor Smart Classes" && label.dataset.yuStyled !== "1")) {
          setText(label, "Yuitor Smart Classes");
          label.style.fontSize = "20px";
          label.style.fontWeight = "700";
          label.style.whiteSpace = "nowrap";
          label.dataset.yuStyled = "1";
        }
      });
    }

    const footer = document.querySelector("footer");
    if (!footer) return;

    footer.querySelectorAll('a[href="https://yuitor.com"]').forEach((link) => {
      link.remove();
    });

    const footerPolicyParagraphs = Array.from(footer.querySelectorAll("p"));
    const admissionLine = footerPolicyParagraphs.find((paragraph) =>
      paragraph.textContent.includes("Aptitude-based"),
    );
    const refundLine = footerPolicyParagraphs.find((paragraph) =>
      paragraph.textContent.includes("100% fee refund within 7 days"),
    );
    if (admissionLine && refundLine) {
      let policyCard = admissionLine;
      while (policyCard && policyCard !== footer && !policyCard.contains(refundLine)) {
        policyCard = policyCard.parentElement;
      }
      if (policyCard && policyCard !== footer) policyCard.remove();
    }

    footer.querySelectorAll("p").forEach((paragraph) => {
      const text = paragraph.textContent.trim();
      if (text === "Yuitor" || (text === "Yuitor Smart Classes" && paragraph.dataset.yuStyled !== "1")) {
        setText(paragraph, "Yuitor Smart Classes");
        paragraph.style.fontSize = "clamp(18px, 2.2vw, 24px)";
        paragraph.style.whiteSpace = "nowrap";
        paragraph.dataset.yuStyled = "1";
      } else if (
        /^© \d{4} Yuitor(?: Smart Classes)?\. All rights reserved\./.test(text)
      ) {
        setText(
          paragraph,
          "© 2026 Yuitor Smart Classes. All rights reserved. Muradnagar, India.",
        );
      }
    });
  }

  const createScopedTextWalker = (container) =>
    document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (
          parent.closest(
            "#yu-festival-header-trim, #yu-festival-banner, #yu-festival-hero-ornaments, #yu-festival-footer-wish, #yu-ai-guide-root, .portal-workspace, script, style, svg",
          )
        ) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });

  function updateBatchDatesAndCopy() {
    const schedule = indiaNextBatch();
    const path = window.location.pathname;
    const walker = createScopedTextWalker(root);
    let node;

    while ((node = walker.nextNode())) {
      const original = node.nodeValue || "";
      if (!original.trim()) continue;
      let text = original;

      if (path === "/scholarship") {
        text = text.replace(
          /June (\d{1,2}), 2026/gi,
          (_match, day) => `${schedule.monthName} ${day}, ${schedule.year}`,
        );
      } else {
        text = text
          .replace(/June 1, 2026/gi, schedule.date)
          .replace(/June 1(?=\s+(?:for|!|—))/gi, schedule.date)
          .replace(/June 2026/gi, schedule.month);
      }

      if (/^\d+\s+seats currently open$/i.test(text.trim())) {
        text = text.replace(/^\d+\s+seats currently open$/i, "Seats Filling Fast!");
      }
      if (
        /^The next batch starts .+seat availability for your course\.$/i.test(
          text.trim(),
        )
      ) {
        text =
          `Secure your admission before batches become full. ` +
          `Limited seats available for ${schedule.month} batch.`;
      }

      if (text !== original) node.nodeValue = text;
    }
  }

  function updateHomeAndComparisonPrices() {
    const path = window.location.pathname;
    if (path === "/") {
      const ranges = new Map([
        ["₹1200–₹1500", "₹900–₹1,300"],
        ["₹1500–₹2000", "₹1,200–₹1,500"],
        ["₹2000–₹2500", "₹1,500–₹1,800"],
        ["₹3000+", "₹2,400+"],
      ]);
      const walker = createScopedTextWalker(root);
      let node;
      while ((node = walker.nextNode())) {
        const replacement = ranges.get((node.nodeValue || "").trim());
        if (replacement && node.nodeValue !== replacement) node.nodeValue = replacement;
      }
    }

    if (path === "/comparison") {
      const feeRow = Array.from(root.querySelectorAll("tr")).find((row) =>
        row.textContent.includes("Monthly Fee (Class 10)"),
      );
      const cells = feeRow ? feeRow.querySelectorAll("td") : [];
      if (cells.length > 1) setText(cells[1], "₹1,400/month");
    }
  }

  function updateFeeCalculator() {
    if (window.location.pathname !== "/fee-calculator") return;

    const course = root.querySelector('[data-testid="select-calculator-course"]');
    if (!course || !course.value) return;

    const selectedBoard = Array.from(
      root.querySelectorAll('button[data-testid^="button-board-"]'),
    ).find((button) => button.classList.contains("bg-primary/20"));
    if (!selectedBoard) return;

    const board = selectedBoard
      .getAttribute("data-testid")
      .replace("button-board-", "");
    const selectedYearly = root
      .querySelector('[data-testid="button-mode-yearly"]')
      ?.classList.contains("bg-primary");
    const fee =
      boardFees[course.value]?.[board] ||
      extraCourseFees[course.value]?.[board];
    if (!fee) return;

    const baseFee = selectedYearly ? fee.yearly : fee.monthly;
    const scholarship =
      root.querySelector('[data-testid="select-scholarship"]')?.value || "";
    const discount = Number((scholarship.match(/\d+/) || [0])[0]);
    const finalFee = Math.round(baseFee * (1 - discount / 100));
    const amount = root.querySelector("div.text-4xl.font-black");
    setText(amount, formatRupees(finalFee));

    const savings = root.querySelector("p.text-green-400");
    if (discount > 0) {
      setText(savings, `You save ${formatRupees(baseFee - finalFee)} with your scholarship!`);
    }

    root.querySelectorAll("p").forEach((paragraph) => {
      if (paragraph.textContent.includes("Registration fee ₹500")) {
        setText(
          paragraph,
          "Ask our admissions team about any applicable one-time charges before enrollment.",
        );
      }
    });
  }

  function updateClassPagePrices() {
    const match = window.location.pathname.match(/^\/class\/(\d+)\/?$/);
    if (!match) return;
    const grade = match[1];
    const fees = boardFees[grade];
    if (!fees) return;

    root.querySelectorAll("p").forEach((paragraph) => {
      if (!paragraph.textContent.trim().startsWith("Monthly: ₹")) return;
      const board = paragraph.previousElementSibling?.textContent.trim();
      const fee = fees[board];
      if (!fee) return;
      setText(
        paragraph,
        `Monthly: ${formatRupees(fee.monthly)} | Yearly: ${formatRupees(fee.yearly)}`,
      );
    });
  }

  function updateBoardPagePrices() {
    const slug = window.location.pathname.match(/^\/board\/([^/]+)\/?$/)?.[1];
    const fees = slug ? boardPageFees[slug] : null;
    if (!fees) return;

    root.querySelectorAll("p").forEach((paragraph) => {
      const text = paragraph.textContent.trim();
      if (!/^₹[\d,]+\/month$/.test(text)) return;
      const row = paragraph.parentElement;
      const grade = Array.from(row.querySelectorAll("p"))
        .find((item) => item !== paragraph)
        ?.textContent.trim();
      if (fees[grade]) setText(paragraph, `${formatRupees(fees[grade])}/month`);
    });
  }

  function updateExamPagePrices() {
    const slug = window.location.pathname.match(/^\/exam\/([^/]+)\/?$/)?.[1];
    const fees = slug ? examFees[slug] : null;
    if (!fees) return;

    root.querySelectorAll("p").forEach((paragraph) => {
      const text = paragraph.textContent.trim();
      if (text.includes("₹") && text.includes("/month")) {
        setText(
          paragraph,
          text.replace(/₹[\d,]+\/month/, `${formatRupees(fees.monthly)}/month`),
        );
        return;
      }

      const label = paragraph.previousElementSibling?.textContent.trim().toLowerCase();
      if (label === "monthly fee") setText(paragraph, formatRupees(fees.monthly));
      if (label && label.startsWith("yearly fee")) {
        setText(paragraph, formatRupees(fees.yearly));
      }
    });
  }

  function updateCoursePagePrices() {
    const slug = window.location.pathname.match(/^\/course\/([^/]+)\/?$/)?.[1];
    const fees = slug ? courseTrackFees[slug] : null;
    if (!fees) return;

    root.querySelectorAll('[data-testid^="card-track-"]').forEach((card) => {
      const name = card.querySelector("h3")?.textContent.trim();
      const amount = card.querySelector("p.text-xl.font-black.text-primary");
      if (name && amount && fees[name] !== undefined) {
        setText(amount, formatRupees(fees[name]));
      }
    });
  }

  function isAdminGateActive() {
    return Boolean(window.__YU_ADMIN_GATE__);
  }

  function updateFeeEnrollmentAndPolicy() {
    if (isAdminGateActive()) {
      root.querySelectorAll("[data-yu-fee-link], [data-yu-mobile-fee-link]").forEach((el) => el.remove());
      return;
    }
    const path = window.location.pathname.replace(/\/+$/, "") || "/";
    const makeFeeLink = () => {
      const link = document.createElement("a");
      link.href = "/fee-calculator";
      link.className = "yu-injected-fee-link";
      link.dataset.yuFeeLink = "true";
      link.dataset.testid = "link-fee-enrollment";
      link.textContent = "Fees & Admission";
      return link;
    };

    const homeNav = root.querySelector(".yu-home .yu-nav");
    if (homeNav && !homeNav.querySelector("[data-yu-fee-link]")) {
      const link = makeFeeLink();
      const cta = homeNav.querySelector(".yu-nav-cta");
      homeNav.insertBefore(link, cta || null);
    }

    const sharedNav = root.querySelector(".yu-shared-header nav");
    if (sharedNav && !sharedNav.querySelector("[data-yu-fee-link]")) {
      const link = makeFeeLink();
      const primaryCta = sharedNav.querySelector(
        '[data-testid="link-enquire"], [data-testid="link-call-now"]',
      );
      sharedNav.insertBefore(link, primaryCta || null);
    }

    const mobileHeaderButton = root.querySelector(
      '.yu-shared-header [data-testid="button-hamburger"]',
    );
    if (mobileHeaderButton && !root.querySelector("[data-yu-mobile-fee-link]")) {
      const link = makeFeeLink();
      link.dataset.yuMobileFeeLink = "true";
      link.classList.add("yu-mobile-fee-shortcut");
      link.textContent = "Fees";
      mobileHeaderButton.parentElement?.insertBefore(link, mobileHeaderButton);
    }

    const mobileMenu = root.querySelector(".yu-mobile-menu");
    if (mobileMenu && !mobileMenu.querySelector("[data-yu-fee-link]")) {
      mobileMenu.append(makeFeeLink());
    }

    if (path === "/") {
      const homePolicy = root.querySelector(".yu-home .yu-policy");
      if (homePolicy) {
        homePolicy.hidden = true;
        homePolicy.style.display = "none";
      }
      const policyFaq = Array.from(root.querySelectorAll(".yu-faq-item")).find(
        (item) =>
          item.textContent.toLowerCase().includes("what are the admission and fee policies?"),
      );
      if (policyFaq) {
        const question = policyFaq.querySelector("button strong");
        const answer = policyFaq.querySelector(".yu-faq-answer p");
        setText(question, "How can I check course fees?");
        if (answer) {
          setText(
            answer,
            "Use the Fee Calculator to review course options and estimate fees. Contact our team to confirm current pricing and enrolment details.",
          );
        }
      }

      const faqSectionIndex = root.querySelector(
        ".yu-home .yu-faq-heading .yu-section-index > span",
      );
      setText(faqSectionIndex, "06");

      document
        .querySelectorAll('script[type="application/ld+json"]')
        .forEach((script) => {
          try {
            const schema = JSON.parse(script.textContent);
            if (schema["@type"] !== "FAQPage" || !Array.isArray(schema.mainEntity)) {
              return;
            }
            const policyIndex = schema.mainEntity.findIndex(
              (item) =>
                item.name === "What are the admission and fee policies?",
            );
            if (policyIndex === -1) return;
            schema.mainEntity[policyIndex] = {
              "@type": "Question",
              name: "How can I check course fees?",
              acceptedAnswer: {
                "@type": "Answer",
                text: "Use the Fee Calculator to review course options and estimate fees. Contact our team to confirm current pricing and enrolment details.",
              },
            };
            script.textContent = JSON.stringify(schema);
          } catch {
            // Ignore unrelated or invalid JSON-LD scripts.
          }
        });
    }

    if (path !== "/fee-calculator") return;
    const calculatorSection = Array.from(root.querySelectorAll("section")).find(
      (section) =>
        section.querySelector('[data-testid="select-calculator-course"]'),
    );
    if (!calculatorSection || calculatorSection.querySelector("[data-yu-fee-policy]")) {
      return;
    }

    const policy = document.createElement("aside");
    policy.className = "yu-fee-policy-note";
    policy.dataset.yuFeePolicy = "true";
    policy.setAttribute("aria-label", "Admission and refund information");
    const heading = document.createElement("h2");
    heading.textContent = "Fees, admission and refunds";
    policy.append(heading);

    const admission = document.createElement("p");
    const admissionLabel = document.createElement("strong");
    admissionLabel.textContent = "Admissions: ";
    admission.append(admissionLabel, "Aptitude-based admission.");
    policy.append(admission);

    const refund = document.createElement("p");
    const refundLabel = document.createElement("strong");
    refundLabel.textContent = "Refund: ";
    refund.append(
      refundLabel,
      "100% fee refund within 7 days, subject to the published admission terms.",
    );
    policy.append(refund);

    calculatorSection.prepend(policy);
  }

  function updateStudentPerformanceChart() {
    const match = window.location.pathname.match(/^\/class\/(\d+)\/?$/);
    if (!match) return;

    const chart = Array.from(root.querySelectorAll("div")).find((element) =>
      element.classList.contains("h-40") &&
      element.classList.contains("items-end") &&
      element.querySelector(":scope > .flex-1 > div.w-full"),
    );
    if (!chart) return;

    chart.setAttribute("role", "img");
    chart.setAttribute(
      "aria-label",
      `Illustrative monthly test-score trend for Class ${match[1]}, July to December`,
    );

    const description = chart.parentElement?.querySelector("p");
    if (description) {
      setText(
        description,
        `Illustrative average test-score trend for Class ${match[1]} over the session (Jul–Dec)`,
      );
    }
  }

  function printClassSyllabus(event) {
    const button = event.target.closest("button");
    if (!button || button.textContent.trim() !== "Download Full Syllabus PDF") return;

    event.preventDefault();
    const card = button.closest(".bg-white.border.border-border");
    if (!card) return;

    const title = root.querySelector("main h1")?.textContent.trim() || "Class syllabus";
    const topics = Array.from(card.querySelectorAll("div.grid > div"))
      .map((item) => item.textContent.trim())
      .filter(Boolean);
    if (!topics.length) return;

    const escapeHtml = (value) =>
      String(value).replace(/[&<>"']/g, (character) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      })[character]);
    const syllabusHtml =
      `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} syllabus</title><style>body{max-width:760px;margin:48px auto;padding:0 24px;color:#281a38;font:16px/1.6 Arial,sans-serif}h1{font-size:28px}h2{margin-top:32px;font-size:18px}li{margin:8px 0}.note{margin-top:36px;color:#665b70;font-size:12px}@media print{body{margin:20mm auto}}</style></head><body><h1>${escapeHtml(title)}</h1><h2>Key topics covered</h2><ul>${topics.map((topic) => `<li>${escapeHtml(topic)}</li>`).join("")}</ul><p class="note">Yuitor Smart Classes · Syllabus topics shown on the website at the time of printing.</p></body></html>`;

    try {
      const frame = document.createElement("iframe");
      frame.setAttribute("aria-hidden", "true");
      frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;";
      frame.srcdoc = syllabusHtml;
      document.body.appendChild(frame);
      frame.addEventListener("load", () => {
        try {
          frame.contentWindow?.focus();
          frame.contentWindow?.print();
        } finally {
          window.setTimeout(() => frame.remove(), 1500);
        }
      }, { once: true });
    } catch {
      const text = [title, "Key topics covered", "", ...topics.map((topic) => `• ${topic}`)].join("\n");
      const file = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
      const link = document.createElement("a");
      link.href = file;
      link.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-syllabus.txt`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(file), 1000);
    }
  }

  function updateAboutImages() {
    if (!/^\/about\/?$/.test(window.location.pathname)) return;

    const imageByAlt = {
      "Founder of Yuitor": "/assets/images/founder-owner.webp",
      "Dr. Ramesh Sharma": "/assets/images/faculty-ramesh-illustrative.webp",
      "Ms. Priya Agarwal": "/assets/images/faculty-priya-illustrative.webp",
      "Mr. Vikas Gupta": "/assets/images/faculty-vikas-illustrative.webp",
      "Ms. Sunita Yadav": "/assets/images/faculty-sunita-illustrative.webp",
    };

    root.querySelectorAll("img[alt]").forEach((image) => {
      const nextSrc = imageByAlt[image.alt];
      if (nextSrc && !image.getAttribute("src")?.endsWith(nextSrc)) {
        image.src = nextSrc;
      }

      if (nextSrc?.includes("-illustrative.webp")) {
        image.setAttribute(
          "aria-description",
          "AI-generated illustrative portrait; not a verified likeness of this staff member.",
        );
        const card = image.parentElement;
        if (card && !card.querySelector(":scope > .yu-illustrative-label")) {
          const badge = document.createElement("span");
          badge.className = "yu-illustrative-label";
          badge.textContent = "Illustrative image";
          card.appendChild(badge);
        }
      }
    });
  }

  function updateHomepageImageDescriptions() {
    if (window.location.pathname !== "/") return;

    const heroImage = root.querySelector(".yuitor-home .yh-hero-visual img");
    if (heroImage) {
      setAttr(heroImage, "alt", "A teacher guiding a small group of students in a classroom");
    }

    const classroomImage = root.querySelector(".yuitor-home .yh-classroom-image img");
    if (classroomImage) {
      setAttr(classroomImage, "alt", "A teacher leading a classroom lesson with students");
    }
  }

  const ROUTES = Object.freeze({
    home: "/",
    courses: "/courses",
    comparison: "/comparison",
    contact: "/contact",
    admission: "/admission",
    "student.login": "/login",
    "student.register": "/register/student",
    "teacher.login": "/login",
    "teacher.register": "/register/teacher",
    "student.portal": "/student/",
    "teacher.portal": "/teacher/",
  });

  function route(name, params = {}) {
    if (name === "admin.gate") {
      const slug =
        (params.slug || cachedAuthState?.adminGatePath || window.__YU_ADMIN_GATE__?.basePath || "")
          .replace(/^\/+|\/+$/g, "");
      return slug ? `/${slug}/` : "";
    }
    return ROUTES[name] || "/";
  }

  let cachedPublicBootstrap = null;
  let bootstrapRequested = false;
  function fetchPublicBootstrapOnce() {
    if (bootstrapRequested) return;
    bootstrapRequested = true;
    fetch("/api/public/bootstrap", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data) {
          cachedPublicBootstrap = data;
          window.__yuPublicBootstrap = data;
          scheduleUpdate();
        }
      })
      .catch(() => {});
  }

  function updatePortalEntryLinks() {
    if (!/^\/contact\/?$/.test(window.location.pathname)) return;
    const contactForm = root.querySelector("main form");
    if (!contactForm || root.querySelector("[data-yu-portal-entry]")) return;

    const panel = document.createElement("div");
    panel.className = "yu-contact-portal-links";
    panel.dataset.yuPortalEntry = "true";
    const note = document.createElement("span");
    note.textContent = "Already enrolled, or ready to join?";
    const login = document.createElement("a");
    login.href = route("student.login");
    login.textContent = "Student login";
    const register = document.createElement("a");
    register.href = route("student.register");
    register.textContent = "New student registration";
    panel.append(note, login, register);
    contactForm.insertAdjacentElement("afterend", panel);
  }

  let cachedAuthState = null;
  let authChecked = false;
  function checkAuthOnce() {
    if (authChecked) return;
    authChecked = true;
    fetch("/api/auth/me", { credentials: "same-origin", cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        cachedAuthState = data;
        window.__yuAuthState = data;
        scheduleUpdate();
      })
      .catch(() => {});
  }

  function normalizeBrokenLegacyLinks() {
    const legacyHrefMap = {
      "/student/login.php": route("student.login"),
      "/student/register.php": route("student.register"),
      "/teacher/login.php": route("teacher.login"),
      "/teacher/register.php": route("teacher.register"),
      "/teacher-apply.php": route("teacher.register"),
      "/login.php": route("student.login"),
      "/register.php": route("student.register"),
    };
    root.querySelectorAll("a[href]").forEach((a) => {
      const raw = (a.getAttribute("href") || "").trim();
      const base = raw.split(/[?#]/)[0].replace(/\/+$/, "") || "/";
      if (raw.includes("/erp/index.php?role=student")) {
        setAttr(a, "href", route("student.portal"));
      } else if (raw.includes("/erp/index.php?role=teacher")) {
        setAttr(a, "href", route("teacher.portal"));
      } else if (legacyHrefMap[base]) {
        setAttr(a, "href", legacyHrefMap[base]);
      }
    });
  }

  function syncDepartmentEmails() {
    const depts = cachedPublicBootstrap?.departmentEmails;
    if (!depts) return;
    root.querySelectorAll("a[data-dept-email]").forEach((a) => {
      const key = a.getAttribute("data-dept-email");
      const addr = depts[key];
      if (!addr) return;
      setAttr(a, "href", `mailto:${addr}`);
      if (key === "complain") {
        setText(a, `Complaints: ${addr}`);
      } else {
        setText(a, addr);
      }
    });
  }

  function ensurePortalNavigationLinks() {
    checkAuthOnce();
    fetchPublicBootstrapOnce();
    normalizeBrokenLegacyLinks();

    const user = cachedAuthState?.authenticated ? cachedAuthState.user : null;
    const gateHref = route("admin.gate");
    const dashboardHref =
      user?.role === "super_admin" || user?.role === "admin"
        ? gateHref || route("student.portal")
        : user?.role === "teacher"
          ? route("teacher.portal")
          : route("student.portal");

    const header = root.querySelector("header");
    const headerHrefs = new Set();

    if (isAdminGateActive()) {
      if (header) {
        const headerActions = header.querySelector(".hidden.lg\\:flex.items-center.gap-2");
        if (headerActions) {
          headerActions.querySelectorAll("a, button").forEach((el) => el.remove());
        }
      }
      return;
    }

    if (header) {
      header.querySelectorAll("nav a[href]").forEach((a) => {
        const href = (a.getAttribute("href") || "").replace(/\/+$/, "") || "/";
        headerHrefs.add(href);
      });

      const headerActions = header.querySelector(".hidden.lg\\:flex.items-center.gap-2");
      if (headerActions) {
        headerActions.querySelectorAll("a").forEach((el) => {
          if (el.textContent.trim() === "Admissions" && el.getAttribute("href") === "/contact") {
            el.remove();
          }
        });

        const existingLoginLinks = Array.from(headerActions.querySelectorAll("a")).filter(
          (el) =>
            (el.getAttribute("href") || "").includes("/student/login") ||
            (el.getAttribute("href") || "").includes("/login") ||
            (el.getAttribute("href") || "").includes("/student/") ||
            (el.getAttribute("href") || "").includes("/teacher/") ||
            (el.getAttribute("href") || "").includes("role=student") ||
            el.dataset.testid === "link-student-login" ||
            el.dataset.testid === "link-portal-login" ||
            el.dataset.testid === "link-portal-dashboard",
        );
        if (existingLoginLinks.length > 1) {
          existingLoginLinks.slice(1).forEach((dup) => dup.remove());
        }

        const primaryLoginEl = existingLoginLinks[0];
        let signOutBtn = headerActions.querySelector('[data-testid="button-header-signout"]');

        if (user) {
          if (primaryLoginEl) {
            setAttr(primaryLoginEl, "href", dashboardHref);
            setText(primaryLoginEl, "Dashboard");
            setDataset(primaryLoginEl, "testid", "link-portal-dashboard");
          }
          if (!signOutBtn) {
            signOutBtn = document.createElement("button");
            signOutBtn.type = "button";
            signOutBtn.dataset.testid = "button-header-signout";
            signOutBtn.className =
              "text-sm font-semibold text-red-600 hover:bg-red-50 px-3 py-2 rounded-lg transition-colors whitespace-nowrap";
            signOutBtn.textContent = "Sign Out";
            signOutBtn.addEventListener("click", async () => {
              try {
                await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
              } catch {
                // Proceed to login screen even if network already cleared session
              }
              cachedAuthState = { authenticated: false, user: null };
              scheduleUpdate();
              window.location.assign(route("student.login"));
            });
            headerActions.insertBefore(signOutBtn, primaryLoginEl?.nextSibling || null);
          }
        } else {
          if (signOutBtn) signOutBtn.remove();
          if (primaryLoginEl) {
            setAttr(primaryLoginEl, "href", route("student.login"));
            setText(primaryLoginEl, "Portal Login");
            setDataset(primaryLoginEl, "testid", "link-portal-login");
          } else {
            const a = document.createElement("a");
            a.href = route("student.login");
            a.dataset.testid = "link-portal-login";
            a.className =
              "text-sm font-semibold text-primary hover:bg-primary/8 px-3 py-2 rounded-lg transition-colors whitespace-nowrap";
            a.textContent = "Portal Login";
            headerActions.prepend(a);
          }
        }
      }
    }

    const mobileMenu = root.querySelector(".yu-mobile-menu");
    if (mobileMenu) {
      const mobLogin = mobileMenu.querySelector('[data-testid="link-mobile-student-login"], [data-testid="link-mobile-portal-login"], [data-testid="link-mobile-portal-dashboard"]');
      let mobReg = mobileMenu.querySelector('[data-testid="link-mobile-portal-register"]');
      let mobSignOut = mobileMenu.querySelector('[data-testid="button-mobile-signout"]');
      if (user) {
        if (mobReg) mobReg.remove();
        if (mobLogin) {
          setAttr(mobLogin, "href", dashboardHref);
          setText(mobLogin, "Dashboard");
          setDataset(mobLogin, "testid", "link-mobile-portal-dashboard");
        }
        if (!mobSignOut && mobLogin?.parentElement) {
          mobSignOut = document.createElement("button");
          mobSignOut.type = "button";
          mobSignOut.dataset.testid = "button-mobile-signout";
          mobSignOut.className = "flex items-center justify-center w-full border-2 border-red-200 bg-red-50 text-red-700 py-3 rounded-xl font-bold text-sm hover:bg-red-100 transition-colors";
          mobSignOut.textContent = "Sign Out";
          mobSignOut.addEventListener("click", async () => {
            try {
              await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
            } catch {}
            cachedAuthState = { authenticated: false, user: null };
            scheduleUpdate();
            window.location.assign(route("student.login"));
          });
          mobLogin.insertAdjacentElement("afterend", mobSignOut);
        }
      } else {
        if (mobSignOut) mobSignOut.remove();
        if (mobLogin) {
          setAttr(mobLogin, "href", route("student.login"));
          setText(mobLogin, "Portal Login");
          setDataset(mobLogin, "testid", "link-mobile-portal-login");
          if (!mobReg && mobLogin.parentElement) {
            mobReg = document.createElement("a");
            mobReg.href = route("student.register");
            mobReg.dataset.testid = "link-mobile-portal-register";
            mobReg.className = "yu-mobile-reg-btn flex items-center justify-center w-full py-3 rounded-xl font-bold text-sm transition-colors";
            mobReg.textContent = "Student & Teacher Register";
            mobLogin.insertAdjacentElement("afterend", mobReg);
          }
        }
      }
    }

    const footer = root.querySelector("footer");
    if (footer) {
      // Locate the "Our Courses" list and preserve/populate it with real courses
      const coursesCol = Array.from(footer.querySelectorAll("div")).find((div) => {
        const p = div.querySelector(":scope > div > p, :scope > p");
        return p && p.textContent.trim() === "Our Courses" && div.querySelector(":scope > ul");
      });
      const coursesList = coursesCol?.querySelector("ul") || null;

      // Remove header duplicate links ONLY outside "Our Courses"
      footer.querySelectorAll("ul li a[href]").forEach((a) => {
        if (coursesList && coursesList.contains(a)) return;
        const href = (a.getAttribute("href") || "").replace(/\/+$/, "") || "/";
        if (headerHrefs.has(href) && href !== "/") {
          a.closest("li")?.remove();
        }
      });

      // Populate "Our Courses" with real route-backed courses + View all courses
      if (coursesList) {
        const realCourseItems = [
          ["/class/7", "Class 5 – 8 Coaching"],
          ["/class/9", "Class 9 & 10 Coaching"],
          ["/class/11", "Class 11 & 12 Coaching"],
          ["/exam/neet", "NEET Coaching"],
          ["/exam/jee", "JEE Coaching"],
          ["/exam/cuet", "CUET Coaching"],
          ["/course/computer", "Computer & AI Courses"],
          ["/course/coding", "Coding Classes"],
          ["/course/spoken-english", "Spoken English"],
          [route("courses"), "View all courses"],
        ];
        const existingCourseHrefs = new Set(
          Array.from(coursesList.querySelectorAll("a[href]")).map((el) =>
            (el.getAttribute("href") || "").replace(/\/+$/, ""),
          ),
        );
        for (const [href, label] of realCourseItems) {
          const normalized = href.replace(/\/+$/, "");
          if (!existingCourseHrefs.has(normalized)) {
            existingCourseHrefs.add(normalized);
            const li = document.createElement("li");
            const a = document.createElement("a");
            a.href = href;
            a.className = "text-sm text-white/60 hover:text-[#7BB5FF] transition-colors flex items-center gap-1.5 group";
            if (href === route("courses")) {
              a.dataset.testid = "link-footer-all-courses";
            }
            a.textContent = label;
            li.appendChild(a);
            coursesList.appendChild(li);
          }
        }
      }

      // Remove Teacher & Student & Teacher items from Footer only (keep login pages intact)
      footer.querySelectorAll("ul li").forEach((li) => {
        const a = li.querySelector("a");
        if (!a) return;
        const href = (a.getAttribute("href") || "").trim().toLowerCase();
        const text = a.textContent.trim().toLowerCase();
        if (
          href.includes("/teacher") ||
          text.includes("teacher portal") ||
          text.includes("teacher login") ||
          text.includes("student & teacher") ||
          text === "teacher" ||
          text === "teachers" ||
          text.includes("faculty & teachers")
        ) {
          li.remove();
        }
      });

      const quickList = Array.from(footer.querySelectorAll("ul")).find((ul) =>
        ul !== coursesList &&
        ul.querySelector('a[href="/comparison"], a[href="/fee-calculator"], a[href="/gallery"]'),
      );
      if (quickList) {
        const extraLinks = [
          [route("admission"), "Admission Form"],
          ["/subjects", "Subjects Directory"],
          ["/ai-learning", "AI Learning Lab"],
          ["/faqs", "FAQs"],
          ["/testimonials", "Testimonials"],
        ];
        const existingHrefs = new Set(
          Array.from(footer.querySelectorAll("a")).map((el) =>
            (el.getAttribute("href") || "").replace(/\/+$/, ""),
          ),
        );
        for (const [href, label] of extraLinks) {
          const normalized = href.replace(/\/+$/, "");
          if (!existingHrefs.has(normalized)) {
            existingHrefs.add(normalized);
            const li = document.createElement("li");
            const a = document.createElement("a");
            a.href = href;
            a.className = "text-sm text-white/60 hover:text-[#7BB5FF] transition-colors flex items-center gap-1.5 group";
            a.textContent = label;
            li.appendChild(a);
            quickList.appendChild(li);
          }
        }
      }

      syncDepartmentEmails();
    }
  }

  let isUpdating = false;
  let updateRaf = 0;

  function updateAll() {
    ensurePortalNavigationLinks();
    updateHomepageImageDescriptions();
    updateAboutImages();
    updatePortalEntryLinks();
    updateBranding();
    updateBatchDatesAndCopy();
    updateHomeAndComparisonPrices();
    updateFeeCalculator();
    updateStudentPerformanceChart();
    updateClassPagePrices();
    updateBoardPagePrices();
    updateExamPagePrices();
    updateCoursePagePrices();
    updateFeeEnrollmentAndPolicy();
  }

  const observerConfig = { childList: true, subtree: true };
  const observer = new MutationObserver((mutations) => {
    const hasRelevantChange = mutations.some((m) => {
      const targetEl = m.target instanceof Element ? m.target : m.target?.parentElement;
      if (!targetEl) return false;
      return !targetEl.closest(
        "#yu-festival-header-trim, #yu-festival-banner, #yu-festival-hero-ornaments, #yu-festival-footer-wish, #yu-ai-guide-root, [data-yu-admin-topnav], [data-yu-admin-header-right]",
      );
    });
    if (hasRelevantChange) scheduleUpdate();
  });

  function runSafeUpdate() {
    if (isUpdating) return;
    isUpdating = true;
    observer.disconnect();
    try {
      updateAll();
    } finally {
      observer.observe(root, observerConfig);
      isUpdating = false;
    }
  }

  function scheduleUpdate() {
    if (isUpdating || updateRaf) return;
    updateRaf = window.requestAnimationFrame(() => {
      updateRaf = 0;
      runSafeUpdate();
    });
  }

  root.addEventListener("click", printClassSyllabus);
  window.addEventListener("popstate", scheduleUpdate);
  runSafeUpdate();
})();
