(() => {
  "use strict";
  const root = document.getElementById("root");
  if (!root) return;

  const BRAND_PENDING_MSG =
    "Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience.";
  const TEACHER_MISSING_RESUME_MSG =
    "Please upload your resume to complete teacher registration. Without submitting your resume, you cannot access the Teacher Dashboard.";
  const TEACHER_REJECTED_RESUME_MSG =
    "Your previous resume requires an update before Teacher Dashboard access can be restored. Please upload a revised PDF, DOC, or DOCX resume below.";
  const STUDENT_PENDING_MSG =
    "Congratulations on beginning your learning journey with Yuitor! Your mobile number is verified and your student application is with our academic admissions team for quick activation.";
  const TEACHER_PENDING_MSG =
    "Welcome to the Yuitor Teaching Community! Your mobile number and resume have been received. Our academic review team will verify your credentials and reach out to you soon.";

  const escapeHtml = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const escAttr = (v) => escapeHtml(v);

  const ADMIN_GATE =
    window.__YU_ADMIN_GATE__ && typeof window.__YU_ADMIN_GATE__ === "object" ? window.__YU_ADMIN_GATE__ : null;
  const GATE_BASE = ADMIN_GATE?.basePath ? String(ADMIN_GATE.basePath).replace(/\/+$/, "") : "";
  const ADMIN_API_BASE = ADMIN_GATE?.apiBase ? String(ADMIN_GATE.apiBase).replace(/\/+$/, "") : "";
  const adminApiUrl = (suffix) => `${ADMIN_API_BASE}${String(suffix || "").startsWith("/") ? suffix : "/" + suffix}`;

  const safeHref = (url, fallback = "") => {
    const raw = String(url ?? "").trim();
    if (!raw) return fallback;
    if (raw.startsWith("/") && !raw.startsWith("//")) return raw;
    try {
      const u = new URL(raw);
      return ["http:", "https:", "mailto:", "tel:"].includes(u.protocol) ? raw : fallback;
    } catch {
      return fallback;
    }
  };

  const ICONS = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    book: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
    wallet: '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
    megaphone: '<path d="m3 11 18-5v12L3 13v-2z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    bot: '<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
    mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
    sidebar: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
    user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    arrowUp: '<path d="m18 15-6-6-6 6"/>',
    arrowDown: '<path d="m6 9 6 6 6-6"/>',
    award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>',
  };

  function icon(name, cls = "portal-icon-svg") {
    return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.dashboard}</svg>`;
  }

  async function api(url, options = {}) {
    const headers = { Accept: "application/json", ...(options.headers || {}) };
    const opts = { credentials: "same-origin", cache: "no-store", ...options, headers };
    if (options.body && !(options.body instanceof FormData) && typeof options.body !== "string") {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(options.body);
    }
    const res = await fetch(url, opts);
    let data = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function uploadFile(file) {
    const fd = new FormData();
    fd.append("file", file);
    return api("/api/uploads", { method: "POST", body: fd });
  }

  function getMain() {
    return root.querySelector("main");
  }

  function applyThemePreference(main) {
    const dark = localStorage.getItem("yuitor_portal_dark") === "1";
    if (main) main.classList.toggle("portal-dark", dark);
    document.documentElement.classList.toggle("yu-portal-dark", dark);
    if (ADMIN_GATE) {
      document.documentElement.setAttribute("data-yu-admin-gate", "1");
    } else {
      document.documentElement.removeAttribute("data-yu-admin-gate");
    }
    return dark;
  }

  function getDefaultAvatarSrc(fullName, role) {
    const raw = String(fullName || role || "Y").trim();
    const parts = raw.split(/\s+/).filter(Boolean);
    const initials = parts.length >= 2
      ? `${parts[0][0] || ""}${parts[parts.length - 1][0] || ""}`.toUpperCase()
      : raw.slice(0, 2).toUpperCase() || "YT";
    const bgA = role === "super_admin" || role === "admin" ? "#4F46E5" : role === "teacher" ? "#6366F1" : "#4F46E5";
    const bgB = "#8B5CF6";
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${bgA}"/><stop offset="100%" stop-color="${bgB}"/></linearGradient></defs><rect width="96" height="96" rx="22" fill="url(#g)"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="#FFFFFF" font-family="Inter,Segoe UI,Arial,sans-serif" font-size="34" font-weight="800" letter-spacing="1">${initials.replace(/[<>&"']/g, "")}</text></svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  function getUserAvatarSrc(user) {
    const custom = safeHref(user?.avatar_url, "");
    if (custom) return custom;
    return getDefaultAvatarSrc(user?.full_name, user?.role);
  }

  function syncUserAvatarElements(user) {
    const nextSrc = getUserAvatarSrc(user);
    document.querySelectorAll("[data-user-avatar-img]").forEach((img) => {
      img.setAttribute("src", nextSrc);
    });
  }

  function renderProfilePhotoCard(user) {
    const hasCustom = Boolean(safeHref(user?.avatar_url, ""));
    const avatarSrc = getUserAvatarSrc(user);
    return `
      <div class="portal-card portal-profile" style="margin-bottom:16px;" data-profile-photo-card>
        <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:12px;">
          <div>
            <h3 class="portal-section-title" style="margin:0 0 4px;">Profile Photo</h3>
            <p class="portal-hint" style="margin:0;">Upload, preview, change, or remove your profile photo. Supports JPG, JPEG, PNG, and WEBP (max 5 MB).</p>
          </div>
          <span class="portal-status ${hasCustom ? "portal-status--paid" : ""}" data-avatar-status>${hasCustom ? "Custom Photo Active" : "Default Avatar"}</span>
        </div>
        <form class="portal-form" data-avatar-manager-form>
          <div class="portal-avatar-manager">
            <img src="${escAttr(avatarSrc)}" alt="${escAttr(user?.full_name || "Profile Photo")}" class="portal-avatar portal-avatar--lg" data-avatar-preview-img data-user-avatar-img>
            <div class="portal-avatar-controls">
              <div class="portal-actions">
                <input type="file" name="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" data-avatar-file-input>
                <button type="submit" class="portal-button portal-button--small" data-avatar-save-btn>${icon("upload")} <span>${hasCustom ? "Change Photo" : "Upload Photo"}</span></button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-avatar-cancel-btn hidden>Cancel Preview</button>
                ${hasCustom ? `<button type="button" class="portal-button portal-button--small portal-button--danger" data-avatar-remove-btn>${icon("trash")} <span>Remove Photo</span></button>` : ""}
              </div>
              <div class="portal-message" data-avatar-inline-msg hidden style="margin:8px 0 0;"></div>
            </div>
          </div>
        </form>
      </div>`;
  }

  function bindProfilePhotoCard(container, { session, onNotice, onRefresh }) {
    const card = container?.querySelector("[data-profile-photo-card]");
    if (!card || !session?.user) return;
    const form = card.querySelector("[data-avatar-manager-form]");
    const fileInput = card.querySelector("[data-avatar-file-input]");
    const previewImg = card.querySelector("[data-avatar-preview-img]");
    const statusEl = card.querySelector("[data-avatar-status]");
    const saveBtn = card.querySelector("[data-avatar-save-btn]");
    const cancelBtn = card.querySelector("[data-avatar-cancel-btn]");
    const removeBtn = card.querySelector("[data-avatar-remove-btn]");
    const msgBox = card.querySelector("[data-avatar-inline-msg]");
    const allowedExt = new Set(["jpg", "jpeg", "png", "webp"]);
    let stagedFile = null;

    const showInline = (type, text) => {
      if (!msgBox) return;
      msgBox.className = `portal-message portal-message--${type === "error" ? "error" : "success"}`;
      msgBox.textContent = text;
      msgBox.hidden = false;
    };

    const resetPreview = () => {
      stagedFile = null;
      if (fileInput) fileInput.value = "";
      if (previewImg) previewImg.src = getUserAvatarSrc(session.user);
      if (cancelBtn) cancelBtn.hidden = true;
      const hasCustom = Boolean(safeHref(session.user.avatar_url, ""));
      if (statusEl) {
        statusEl.className = `portal-status ${hasCustom ? "portal-status--paid" : ""}`;
        statusEl.textContent = hasCustom ? "Custom Photo Active" : "Default Avatar";
      }
      if (saveBtn) {
        const span = saveBtn.querySelector("span");
        if (span) span.textContent = hasCustom ? "Change Photo" : "Upload Photo";
      }
    };

    fileInput?.addEventListener("change", () => {
      const f = fileInput.files && fileInput.files[0];
      if (!f) {
        resetPreview();
        return;
      }
      const ext = String(f.name || "").split(".").pop().toLowerCase();
      if (!allowedExt.has(ext)) {
        resetPreview();
        showInline("error", "Unsupported file format. Choose a JPG, JPEG, PNG, or WEBP image.");
        return;
      }
      if (f.size > 5 * 1024 * 1024) {
        resetPreview();
        showInline("error", "Profile photo exceeds the 5 MB size limit.");
        return;
      }
      stagedFile = f;
      const reader = new FileReader();
      reader.onload = () => {
        if (previewImg && typeof reader.result === "string") {
          previewImg.src = reader.result;
        }
      };
      reader.readAsDataURL(f);
      if (cancelBtn) cancelBtn.hidden = false;
      if (statusEl) {
        statusEl.className = "portal-status portal-status--pending";
        statusEl.textContent = "Preview Ready (Unsaved)";
      }
      if (saveBtn) {
        const span = saveBtn.querySelector("span");
        if (span) span.textContent = "Save Selected Photo";
      }
      showInline("success", "Preview ready — click Save Selected Photo to update your profile.");
    });

    cancelBtn?.addEventListener("click", () => {
      resetPreview();
      if (msgBox) msgBox.hidden = true;
    });

    form?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = stagedFile || (fileInput?.files && fileInput.files[0]);
      if (!(f instanceof File) || f.size <= 0) {
        showInline("error", "Please select a JPG, JPEG, PNG, or WEBP photo first.");
        return;
      }
      if (saveBtn) saveBtn.disabled = true;
      try {
        const up = await uploadFile(f);
        await api("/api/auth/avatar", { method: "PATCH", body: { avatarUrl: up.url } });
        session.user.avatar_url = up.url;
        syncUserAvatarElements(session.user);
        if (onNotice) onNotice("success", "Profile photo updated.");
        if (onRefresh) onRefresh();
      } catch (err) {
        showInline("error", err?.message || "Unable to upload profile photo.");
        if (onNotice) onNotice("error", err?.message || "Unable to upload profile photo.");
      } finally {
        if (saveBtn) saveBtn.disabled = false;
      }
    });

    removeBtn?.addEventListener("click", async () => {
      removeBtn.disabled = true;
      try {
        await api("/api/auth/avatar", { method: "DELETE" });
        session.user.avatar_url = "";
        syncUserAvatarElements(session.user);
        if (onNotice) onNotice("success", "Profile photo removed.");
        if (onRefresh) onRefresh();
      } catch (err) {
        showInline("error", err?.message || "Unable to remove profile photo.");
        if (onNotice) onNotice("error", err?.message || "Unable to remove profile photo.");
      } finally {
        removeBtn.disabled = false;
      }
    });
  }

  function syncAdminHeaderNav({
    navGroups = null,
    activeItemId = "",
    activeTab = "",
    onSelectItem = null,
    onOpenProfile = null,
    isGateOnly = false,
    session = null,
    notifications = [],
    isDark = false,
    onReadNotifs = null,
    onReadSingleNotif = null,
  } = {}) {
    if (!ADMIN_GATE) return;
    document.documentElement.setAttribute("data-yu-admin-gate", "1");
    const header = root.querySelector(".yu-shared-header");
    if (!header) return;

    const logoLink = header.querySelector('[data-testid="link-logo"]');
    if (logoLink) {
      logoLink.setAttribute("href", GATE_BASE ? `${GATE_BASE}/` : "/");
      const subLabel = logoLink.querySelector("span:last-of-type, p:last-of-type");
      if (subLabel) subLabel.textContent = "ADMIN CONSOLE";
    }

    const rightActions = header.querySelector(".hidden.lg\\:flex.items-center.gap-2");
    if (rightActions) {
      rightActions.innerHTML = "";
    }

    const headerRow = header.querySelector(":scope > div:nth-child(2) > div");
    const nav = header.querySelector("nav");
    if (!nav) return;

    let adminRightHost = header.querySelector("[data-yu-admin-header-right]");
    if (!adminRightHost && headerRow) {
      adminRightHost = document.createElement("div");
      adminRightHost.className = "yu-admin-header-right";
      adminRightHost.setAttribute("data-yu-admin-header-right", "true");
      headerRow.appendChild(adminRightHost);
    }

    const getOrCreateMobileDrawer = () => {
      let drawer = header.querySelector("[data-admin-mobile-drawer]");
      if (!drawer) {
        drawer = document.createElement("div");
        drawer.className = "yu-admin-mobile-drawer";
        drawer.setAttribute("data-admin-mobile-drawer", "true");
        drawer.hidden = true;
        header.appendChild(drawer);
      }
      return drawer;
    };

    const bindHeaderThemeBtn = (container) => {
      container?.querySelectorAll("[data-header-theme-toggle]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const mainEl = getMain();
          const next = !(mainEl?.classList.contains("portal-dark") || document.documentElement.classList.contains("yu-portal-dark"));
          localStorage.setItem("yuitor_portal_dark", next ? "1" : "0");
          if (mainEl) mainEl.classList.toggle("portal-dark", next);
          document.documentElement.classList.toggle("yu-portal-dark", next);
          document.querySelectorAll("[data-header-theme-toggle], [data-theme-toggle], [data-shell-theme-toggle]").forEach((tb) => {
            tb.innerHTML = `${icon(next ? "sun" : "moon")}<span class="yu-theme-label">${next ? "Light Mode" : "Dark Mode"}</span>`;
          });
        });
      });
    };

    if (isGateOnly || !Array.isArray(navGroups) || !navGroups.length) {
      nav.innerHTML = `<div class="yu-admin-topnav" data-yu-admin-topnav><span class="yu-admin-gate-pill">Protected Admin Security Gate</span></div>`;
      const drawer = header.querySelector("[data-admin-mobile-drawer]");
      if (drawer) {
        drawer.hidden = true;
        drawer.innerHTML = "";
      }
      if (adminRightHost) {
        adminRightHost.innerHTML = `
          <button type="button" class="portal-icon-btn yu-header-theme-btn" title="Toggle Light/Dark theme" data-header-theme-toggle>
            ${icon(isDark ? "sun" : "moon")}
            <span class="yu-theme-label">${isDark ? "Light Mode" : "Dark Mode"}</span>
          </button>`;
        bindHeaderThemeBtn(adminRightHost);
      }
      return;
    }

    nav.innerHTML = `
      <div class="yu-admin-topnav" data-yu-admin-topnav>
        ${navGroups
          .map((entry) => {
            if (!entry.children) {
              const isAct = activeTab === entry.tab;
              return `<button type="button" class="yu-admin-top-btn ${isAct ? "is-active" : ""}" data-top-nav-item="${escAttr(entry.id)}">${icon(entry.icon)}<span>${escapeHtml(entry.label)}</span></button>`;
            }
            const groupAct = entry.children.some((c) => (activeItemId ? c.id === activeItemId : c.tab === activeTab));
            return `
              <div class="yu-admin-top-dropdown" data-top-dd="${escAttr(entry.groupId)}">
                <button type="button" class="yu-admin-top-btn ${groupAct ? "is-active" : ""}" data-top-dd-btn="${escAttr(entry.groupId)}" aria-expanded="false">
                  ${icon(entry.icon)}
                  <span>${escapeHtml(entry.label)}</span>
                  ${icon("chevronDown", "portal-icon-svg yu-chevron-sm")}
                </button>
                <div class="yu-admin-top-menu" data-top-dd-menu="${escAttr(entry.groupId)}" hidden>
                  ${entry.children
                    .map((child) => {
                      const childAct = activeItemId ? activeItemId === child.id : activeTab === child.tab;
                      return `<button type="button" class="yu-admin-top-menu-item ${childAct ? "is-active" : ""}" data-top-nav-item="${escAttr(child.id)}">${icon(child.icon)}<span>${escapeHtml(child.label)}</span></button>`;
                    })
                    .join("")}
                </div>
              </div>`;
          })
          .join("")}
      </div>`;

    const mobileDrawer = getOrCreateMobileDrawer();
    mobileDrawer.hidden = true;

    if (adminRightHost && session?.user) {
      const unreadCount = notifications.filter((n) => !n.is_read).length;
      const shownNotifs = notifications.slice(0, 15);
      const avatarSrc = getUserAvatarSrc(session.user);
      adminRightHost.innerHTML = `
        <button type="button" class="portal-icon-btn yu-header-theme-btn" title="Toggle Light/Dark theme" data-header-theme-toggle>
          ${icon(isDark ? "sun" : "moon")}
          <span class="yu-theme-label">${isDark ? "Light Mode" : "Dark Mode"}</span>
        </button>
        <div class="portal-notif-wrap">
          <button type="button" class="portal-icon-btn" title="Notifications" data-notif-toggle>
            ${icon("bell")}
            ${unreadCount > 0 ? `<span class="portal-notif-dot" data-notif-badge>${unreadCount}</span>` : ""}
          </button>
          <div class="portal-notif-dropdown" data-notif-menu hidden>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:8px;">
              <strong style="font-size:12px;">Notifications (${notifications.length})</strong>
              ${onReadNotifs ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-ws-read-notifs>Mark All Read</button>` : ""}
            </div>
            ${
              shownNotifs
                .map(
                  (n, idx) => `
              <button type="button" class="portal-notif-item ${n.is_read ? "" : "is-unread"}" data-notif-item="${idx}">
                <div class="portal-notif-item-meta">
                  <span>${escapeHtml(n.created_at)}</span>
                  <span class="portal-notif-state">${n.is_read ? "Read" : "New"}</span>
                </div>
                <strong>${escapeHtml(n.title)}</strong>
                <div class="portal-notif-item-preview">${escapeHtml(n.message)}</div>
                <div class="portal-notif-item-cta">Click to read full message →</div>
              </button>`
                )
                .join("") || `<p class="portal-hint">No notifications right now.</p>`
            }
          </div>
        </div>
        <div class="portal-user-wrap">
          <button type="button" class="portal-user-btn" data-user-menu-toggle aria-expanded="false" title="Account menu">
            <img src="${escAttr(avatarSrc)}" alt="" class="portal-avatar" data-user-avatar-img>
            <div class="portal-user-meta">
              <strong>${escapeHtml(session.user.full_name)}</strong>
              <span>${escapeHtml(session.user.role)}</span>
            </div>
            ${icon("chevronDown", "portal-icon-svg yu-chevron-sm")}
          </button>
          <div class="portal-user-dropdown" data-user-menu hidden>
            <div class="portal-user-dropdown-head">
              <span class="yu-user-signed-label">Signed in as</span>
              <span class="yu-user-role-line">${escapeHtml(session.user.role)}</span>
              ${session.user.email ? `<span>${escapeHtml(session.user.email)}</span>` : ""}
            </div>
            <button type="button" class="portal-user-dropdown-item" data-admin-open-profile>
              ${icon("user")}
              <span>Profile &amp; Photo</span>
            </button>
            <button type="button" class="portal-user-dropdown-item is-danger" data-portal-logout>
              ${icon("logout")}
              <span>Logout</span>
            </button>
          </div>
        </div>
        <button type="button" class="portal-icon-btn yu-admin-mobile-toggle" title="Open Admin Menu" aria-label="Open Admin Menu" aria-expanded="false" data-admin-mobile-toggle>
          ${icon("menu")}
        </button>`;

      mobileDrawer.innerHTML = `
        <div class="yu-admin-mobile-drawer-inner">
          <div class="yu-admin-mobile-user-bar">
            <div style="display:flex;align-items:center;gap:10px;min-width:0;">
              <img src="${escAttr(avatarSrc)}" alt="" class="portal-avatar" data-user-avatar-img style="width:36px;height:36px;border-radius:10px;object-fit:cover;flex-shrink:0;">
              <div style="min-width:0;">
                <strong style="display:block;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(session.user.full_name)}</strong>
                <span style="display:block;font-size:11px;opacity:.78;">${escapeHtml(session.user.role)}</span>
              </div>
            </div>
            <button type="button" class="portal-icon-btn" title="Toggle Light/Dark theme" data-header-theme-toggle>
              ${icon(isDark ? "sun" : "moon")}
              <span class="yu-theme-label">${isDark ? "Light Mode" : "Dark Mode"}</span>
            </button>
          </div>
          <div class="yu-admin-mobile-groups">
            ${navGroups
              .map((entry) => {
                if (!entry.children) {
                  const isAct = activeTab === entry.tab;
                  return `<button type="button" class="yu-admin-mobile-item ${isAct ? "is-active" : ""}" data-mobile-nav-item="${escAttr(entry.id)}">${icon(entry.icon)}<span>${escapeHtml(entry.label)}</span></button>`;
                }
                const groupAct = entry.children.some((c) => (activeItemId ? c.id === activeItemId : c.tab === activeTab));
                return `
                  <div class="yu-admin-mobile-group ${groupAct ? "is-open" : ""}" data-mobile-group="${escAttr(entry.groupId)}">
                    <button type="button" class="yu-admin-mobile-group-btn ${groupAct ? "is-active" : ""}" data-mobile-group-btn="${escAttr(entry.groupId)}" aria-expanded="${groupAct ? "true" : "false"}">
                      <span style="display:inline-flex;align-items:center;gap:9px;">${icon(entry.icon)}<span>${escapeHtml(entry.label)}</span></span>
                      ${icon("chevronDown", "portal-icon-svg yu-chevron-sm")}
                    </button>
                    <div class="yu-admin-mobile-sublist" data-mobile-group-list="${escAttr(entry.groupId)}" ${groupAct ? "" : "hidden"}>
                      ${entry.children
                        .map((child) => {
                          const childAct = activeItemId ? activeItemId === child.id : activeTab === child.tab;
                          return `<button type="button" class="yu-admin-mobile-subitem ${childAct ? "is-active" : ""}" data-mobile-nav-item="${escAttr(child.id)}">${icon(child.icon)}<span>${escapeHtml(child.label)}</span></button>`;
                        })
                        .join("")}
                    </div>
                  </div>`;
              })
              .join("")}
          </div>
          <div class="yu-admin-mobile-actions">
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-admin-open-profile>${icon("user")}<span>Profile &amp; Photo</span></button>
            <button type="button" class="portal-button portal-button--danger portal-button--small" data-portal-logout>${icon("logout")}<span>Logout</span></button>
          </div>
        </div>`;

      bindHeaderThemeBtn(adminRightHost);
      bindHeaderThemeBtn(mobileDrawer);

      const notifMenu = adminRightHost.querySelector("[data-notif-menu]");
      const userMenu = adminRightHost.querySelector("[data-user-menu]");
      const userMenuBtn = adminRightHost.querySelector("[data-user-menu-toggle]");
      const mobileToggleBtn = adminRightHost.querySelector("[data-admin-mobile-toggle]");

      const closeMobileDrawer = () => {
        mobileDrawer.hidden = true;
        mobileToggleBtn?.setAttribute("aria-expanded", "false");
      };

      mobileToggleBtn?.addEventListener("click", (e) => {
        e.stopPropagation();
        closeAllMenus();
        if (notifMenu) notifMenu.hidden = true;
        if (userMenu) userMenu.hidden = true;
        userMenuBtn?.setAttribute("aria-expanded", "false");
        const willOpen = mobileDrawer.hidden;
        mobileDrawer.hidden = !willOpen;
        mobileToggleBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
      });

      mobileDrawer.querySelectorAll("[data-mobile-group-btn]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const gid = btn.getAttribute("data-mobile-group-btn");
          const list = mobileDrawer.querySelector(`[data-mobile-group-list="${CSS.escape(gid || "")}"]`);
          const groupBox = mobileDrawer.querySelector(`[data-mobile-group="${CSS.escape(gid || "")}"]`);
          if (!list) return;
          const willOpen = list.hidden;
          list.hidden = !willOpen;
          btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
          groupBox?.classList.toggle("is-open", willOpen);
        });
      });

      mobileDrawer.querySelectorAll("[data-mobile-nav-item]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const itemId = btn.getAttribute("data-mobile-nav-item");
          closeMobileDrawer();
          if (onSelectItem && itemId) onSelectItem(itemId);
        });
      });

      adminRightHost.querySelector("[data-notif-toggle]")?.addEventListener("click", (e) => {
        e.stopPropagation();
        closeAllMenus();
        closeMobileDrawer();
        if (userMenu) userMenu.hidden = true;
        userMenuBtn?.setAttribute("aria-expanded", "false");
        if (notifMenu) notifMenu.hidden = !notifMenu.hidden;
      });

      userMenuBtn?.addEventListener("click", (e) => {
        e.stopPropagation();
        closeAllMenus();
        closeMobileDrawer();
        if (notifMenu) notifMenu.hidden = true;
        const willOpen = userMenu ? userMenu.hidden : false;
        if (userMenu) userMenu.hidden = !willOpen;
        userMenuBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
      });

      adminRightHost.querySelectorAll("[data-notif-item]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const idx = Number(btn.getAttribute("data-notif-item"));
          const notif = shownNotifs[idx];
          if (!notif) return;
          if (notifMenu) notifMenu.hidden = true;
          openNotificationModal(notif, async (item) => {
            if (onReadSingleNotif) {
              await onReadSingleNotif(item);
            } else if (onReadNotifs) {
              await onReadNotifs();
            }
            btn.classList.remove("is-unread");
            const stateEl = btn.querySelector(".portal-notif-state");
            if (stateEl) stateEl.textContent = "Read";
            const nextUnread = notifications.filter((x) => !x.is_read).length;
            const badge = adminRightHost.querySelector("[data-notif-badge]");
            if (badge) {
              if (nextUnread > 0) badge.textContent = String(nextUnread);
              else badge.remove();
            }
          });
        });
      });

      adminRightHost.querySelector("[data-ws-read-notifs]")?.addEventListener("click", async () => {
        if (onReadNotifs) await onReadNotifs();
      });

      header.querySelectorAll("[data-admin-open-profile]").forEach((btn) => {
        btn.addEventListener("click", () => {
          if (userMenu) userMenu.hidden = true;
          userMenuBtn?.setAttribute("aria-expanded", "false");
          closeMobileDrawer();
          if (onOpenProfile) onOpenProfile();
        });
      });

      header.querySelectorAll("[data-portal-logout]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          try {
            await api("/api/auth/logout", { method: "POST" });
          } catch {
            // ignore network hiccup on logout redirect
          }
          window.location.assign(GATE_BASE ? `${GATE_BASE}/` : "/login");
        });
      });
    }

    function closeAllMenus() {
      nav.querySelectorAll("[data-top-dd-menu]").forEach((m) => {
        m.hidden = true;
      });
      nav.querySelectorAll("[data-top-dd-btn]").forEach((b) => {
        b.setAttribute("aria-expanded", "false");
      });
    }

    nav.querySelectorAll("[data-top-dd-btn]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        adminRightHost?.querySelectorAll("[data-notif-menu], [data-user-menu]").forEach((m) => {
          m.hidden = true;
        });
        adminRightHost?.querySelectorAll("[data-user-menu-toggle]").forEach((b) => {
          b.setAttribute("aria-expanded", "false");
        });
        mobileDrawer.hidden = true;
        adminRightHost?.querySelector("[data-admin-mobile-toggle]")?.setAttribute("aria-expanded", "false");
        const gid = btn.getAttribute("data-top-dd-btn");
        const menu = nav.querySelector(`[data-top-dd-menu="${CSS.escape(gid || "")}"]`);
        const willOpen = menu ? menu.hidden : false;
        closeAllMenus();
        if (menu && willOpen) {
          menu.hidden = false;
          btn.setAttribute("aria-expanded", "true");
        }
      });
    });

    nav.querySelectorAll("[data-top-nav-item]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const itemId = btn.getAttribute("data-top-nav-item");
        closeAllMenus();
        if (onSelectItem && itemId) onSelectItem(itemId);
      });
    });

    if (!window.__yuAdminTopNavDocBound) {
      window.__yuAdminTopNavDocBound = true;
      document.addEventListener("click", (ev) => {
        if (!ev.target?.closest?.("[data-yu-admin-topnav]")) {
          document.querySelectorAll("[data-yu-admin-topnav] [data-top-dd-menu]").forEach((m) => {
            m.hidden = true;
          });
          document.querySelectorAll("[data-yu-admin-topnav] [data-top-dd-btn]").forEach((b) => {
            b.setAttribute("aria-expanded", "false");
          });
        }
        if (!ev.target?.closest?.(".portal-notif-wrap")) {
          document.querySelectorAll("[data-notif-menu]").forEach((m) => {
            m.hidden = true;
          });
        }
        if (!ev.target?.closest?.(".portal-user-wrap")) {
          document.querySelectorAll("[data-user-menu]").forEach((m) => {
            m.hidden = true;
          });
          document.querySelectorAll("[data-user-menu-toggle]").forEach((b) => {
            b.setAttribute("aria-expanded", "false");
          });
        }
        if (!ev.target?.closest?.("[data-admin-mobile-drawer]") && !ev.target?.closest?.("[data-admin-mobile-toggle]")) {
          document.querySelectorAll("[data-admin-mobile-drawer]").forEach((d) => {
            d.hidden = true;
          });
          document.querySelectorAll("[data-admin-mobile-toggle]").forEach((b) => {
            b.setAttribute("aria-expanded", "false");
          });
        }
      });
      document.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") {
          document.querySelectorAll("[data-yu-admin-topnav] [data-top-dd-menu], [data-notif-menu], [data-user-menu], [data-admin-mobile-drawer]").forEach((m) => {
            m.hidden = true;
          });
          document.querySelectorAll("[data-top-dd-btn], [data-user-menu-toggle], [data-admin-mobile-toggle]").forEach((b) => {
            b.setAttribute("aria-expanded", "false");
          });
        }
      });
    }
  }

  function getPortalHost(main) {
    if (!main) return null;
    let host = main.querySelector("[data-yu-portal-host]");
    if (!host) {
      host = document.createElement("div");
      host.setAttribute("data-yu-portal-host", "true");
      host.className = "min-h-[70vh]";
      main.appendChild(host);
    }
    return host;
  }

  function mountShell(html, options = {}) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    const isDark = applyThemePreference(main);
    if (ADMIN_GATE) {
      syncAdminHeaderNav({ isGateOnly: true, isDark });
    }
    main.dataset.yuPortalMounted = "true";
    const host = getPortalHost(main);
    const themeBarHtml =
      options.hideThemeToggle || ADMIN_GATE
        ? ""
        : `<div class="portal-shell-bar">
           <button type="button" class="portal-icon-btn" title="Toggle Light/Dark theme" data-shell-theme-toggle>
             ${icon(isDark ? "sun" : "moon")}
             <span>${isDark ? "Light Mode" : "Dark Mode"}</span>
           </button>
         </div>`;
    host.innerHTML = `<div class="portal-shell">${themeBarHtml}${html}</div>`;
    const shellToggleBtn = host.querySelector("[data-shell-theme-toggle]");
    if (shellToggleBtn) {
      shellToggleBtn.addEventListener("click", () => {
        const next = !main.classList.contains("portal-dark");
        localStorage.setItem("yuitor_portal_dark", next ? "1" : "0");
        main.classList.toggle("portal-dark", next);
        document.documentElement.classList.toggle("yu-portal-dark", next);
        shellToggleBtn.innerHTML = `${icon(next ? "sun" : "moon")}<span>${next ? "Light Mode" : "Dark Mode"}</span>`;
      });
    }
    return main;
  }

  function statusBadge(st) {
    const s = String(st || "").toLowerCase();
    let mod = "pending";
    if (["approved", "active", "verified", "paid", "completed", "resolved", "present", "graded", "available", "sent"].includes(s)) {
      mod = "paid";
    } else if (["rejected", "suspended", "inactive", "failed", "absent", "refunded", "cancelled", "closed"].includes(s)) {
      mod = "overdue";
    }
    return `<span class="portal-status portal-status--${mod}">${escapeHtml(s.replace(/_/g, " "))}</span>`;
  }

  function impersonationBanner(session) {
    if (!session?.impersonation?.active) return "";
    return `
      <div class="portal-alert">
        <div>
          <strong>Admin viewing as user: ${escapeHtml(session.user.full_name)} (${escapeHtml(session.user.role)})</strong>
          · Reason: ${escapeHtml(session.impersonation.reason)}
        </div>
        <button type="button" class="portal-button portal-button--small" data-exit-impersonation>Exit Impersonation</button>
      </div>`;
  }

  function bindGlobalImpersonationExit(container) {
    const btn = container.querySelector("[data-exit-impersonation]");
    if (!btn) return;
    btn.addEventListener("click", async () => {
      try {
        const res = await api("/api/auth/exit-impersonation", { method: "POST" });
        window.location.assign(res.redirectTo || (GATE_BASE ? `${GATE_BASE}/` : "/"));
      } catch (err) {
        btn.textContent = err.message || "Exit failed";
      }
    });
  }

  function openPromptModal({ title, label, placeholder = "", defaultValue = "", minLength = 1 }) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.className = "yu-festival-popup-overlay";
      overlay.style.cssText =
        "position:fixed;inset:0;z-index:10050;background:rgba(15,23,42,.56);display:flex;align-items:center;justify-content:center;padding:16px;";
      overlay.innerHTML = `
        <div class="portal-card portal-profile" role="dialog" aria-modal="true" style="max-width:440px;width:100%;margin:0;">
          <h3 class="portal-section-title" style="margin-bottom:8px;">${escapeHtml(title)}</h3>
          <form class="portal-form" data-modal-prompt-form>
            <div class="portal-field">
              <label>${escapeHtml(label)}</label>
              <input name="value" value="${escAttr(defaultValue)}" placeholder="${escAttr(placeholder)}" minlength="${minLength}" required>
            </div>
            <div class="portal-actions" style="justify-content:flex-end;margin-top:12px;">
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-modal-cancel>Cancel</button>
              <button type="submit" class="portal-button portal-button--small">Confirm</button>
            </div>
          </form>
        </div>`;
      const cleanup = (val) => {
        overlay.remove();
        resolve(val);
      };
      overlay.querySelector("[data-modal-cancel]")?.addEventListener("click", () => cleanup(""));
      overlay.addEventListener("click", (ev) => {
        if (ev.target === overlay) cleanup("");
      });
      overlay.querySelector("[data-modal-prompt-form]")?.addEventListener("submit", (ev) => {
        ev.preventDefault();
        const val = String(new FormData(ev.currentTarget).get("value") || "").trim();
        if (val.length < minLength) return;
        cleanup(val);
      });
      document.body.appendChild(overlay);
      overlay.querySelector('input[name="value"]')?.focus();
    });
  }

  function formatINR(n) {
    return `₹${Number(n || 0).toLocaleString("en-IN")}`;
  }

  function passwordFieldHtml(name, attrs = "") {
    return `<div class="portal-pw-wrap"><input name="${escAttr(name)}" type="password" ${attrs}><button type="button" class="portal-pw-toggle" data-toggle-pw="${escAttr(name)}" aria-label="Show password">Show</button></div>`;
  }

  function bindPasswordToggles(container) {
    if (!container) return;
    container.querySelectorAll("[data-toggle-pw]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const fieldName = btn.getAttribute("data-toggle-pw");
        const input = btn.closest(".portal-pw-wrap")?.querySelector(`input[name="${CSS.escape(fieldName || "")}"]`);
        if (!input) return;
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        btn.textContent = show ? "Hide" : "Show";
        btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
      });
    });
  }

  let rzpScriptPromise = null;
  function loadRazorpayCheckout() {
    if (window.Razorpay) return Promise.resolve(window.Razorpay);
    if (!rzpScriptPromise) {
      rzpScriptPromise = new Promise((resolve, reject) => {
        const sc = document.createElement("script");
        sc.src = "https://checkout.razorpay.com/v1/checkout.js";
        sc.async = true;
        sc.onload = () => (window.Razorpay ? resolve(window.Razorpay) : reject(new Error("Razorpay Checkout unavailable.")));
        sc.onerror = () => reject(new Error("Could not load Razorpay Checkout script. Check internet connection or pay via UPI/Desk."));
        document.head.appendChild(sc);
      });
    }
    return rzpScriptPromise;
  }

  function openNotificationModal(notif, onMarkedRead) {
    if (!notif) return;
    document.querySelector(".yu-notif-modal-overlay")?.remove();
    const main = getMain();
    const isDark = Boolean(main?.classList.contains("portal-dark")) || localStorage.getItem("yuitor_portal_dark") === "1";
    const overlay = document.createElement("div");
    overlay.className = `yu-notif-modal-overlay ${isDark ? "portal-dark-modal" : ""}`;
    overlay.innerHTML = `
      <div class="portal-card portal-profile yu-notif-modal-card" role="dialog" aria-modal="true" aria-labelledby="yu-notif-modal-title">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:10px;">
          <div>
            <p class="portal-kicker" style="margin-bottom:4px;">Notification Details</p>
            <h3 id="yu-notif-modal-title" style="margin:0;font-size:18px;font-weight:800;">${escapeHtml(notif.title || "Notification")}</h3>
          </div>
          <span class="portal-status ${notif.is_read ? "" : "portal-status--new"}" data-notif-modal-status>${notif.is_read ? "Read" : "New"}</span>
        </div>
        <p class="portal-hint" style="margin-bottom:14px;">Received: ${escapeHtml(notif.created_at || "Just now")}</p>
        <div class="portal-detail" style="margin-bottom:16px;padding:14px 16px;">
          <div style="white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;line-height:1.65;">${escapeHtml(notif.message || "")}</div>
        </div>
        <div class="portal-actions" style="justify-content:flex-end;">
          <button type="button" class="portal-button portal-button--small" data-notif-modal-close>Close</button>
        </div>
      </div>`;
    const close = () => overlay.remove();
    overlay.querySelector("[data-notif-modal-close]")?.addEventListener("click", close);
    overlay.addEventListener("click", (ev) => {
      if (ev.target === overlay) close();
    });
    document.body.appendChild(overlay);

    if (!notif.is_read && onMarkedRead) {
      notif.is_read = 1;
      Promise.resolve(onMarkedRead(notif))
        .then(() => {
          const st = overlay.querySelector("[data-notif-modal-status]");
          if (st) {
            st.className = "portal-status";
            st.textContent = "Read";
          }
        })
        .catch(() => {});
    }
  }

  function renderWorkspace({
    session,
    portalTitle,
    navItems = [],
    navGroups = null,
    openNavGroups = null,
    activeNavItemId = "",
    activeTab,
    onTabChange,
    onSelectNavItem = null,
    onToggleNavGroup = null,
    notifications = [],
    onReadNotifs,
    onReadSingleNotif = null,
    isAdmin = false,
    hideSidebar = false,
    bodyHtml,
  }) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    const isDark = applyThemePreference(main);
    const shouldHideSidebar = Boolean(hideSidebar || isAdmin);
    const isCollapsed = localStorage.getItem("yuitor_portal_collapsed") === "1";
    main.dataset.yuPortalMounted = "true";

    const flatItems = [];
    if (Array.isArray(navGroups) && navGroups.length) {
      navGroups.forEach((g) => {
        if (g.children) {
          g.children.forEach((c) => flatItems.push([c.tab, c.label, c.icon, c.id]));
        } else {
          flatItems.push([g.tab, g.label, g.icon, g.id]);
        }
      });
    } else {
      navItems.forEach((n) => flatItems.push([n[0], n[1], n[2], n[0]]));
    }

    const activeEntry =
      flatItems.find((n) => activeNavItemId && n[3] === activeNavItemId) ||
      flatItems.find((n) => n[0] === activeTab) ||
      (activeTab === "profile" ? ["profile", "Profile & Photo", "user", "profile"] : flatItems[0]) ||
      [activeTab, portalTitle];
    const activeLabel = activeEntry[1];
    const unreadCount = notifications.filter((n) => !n.is_read).length;
    const avatarSrc = getUserAvatarSrc(session.user);

    if (isAdmin && Array.isArray(navGroups)) {
      syncAdminHeaderNav({
        navGroups,
        activeItemId: activeNavItemId,
        activeTab,
        onSelectItem: onSelectNavItem,
        onOpenProfile: () => onTabChange("profile"),
        session,
        notifications,
        isDark,
        onReadNotifs,
        onReadSingleNotif,
      });
    }

    const sidebarNavHtml =
      Array.isArray(navGroups) && navGroups.length
        ? navGroups
            .map((entry) => {
              if (!entry.children) {
                const isAct = activeTab === entry.tab;
                return `
                  <button type="button" class="portal-nav-item" aria-current="${isAct ? "page" : "false"}" data-ws-nav-item="${escAttr(entry.id)}">
                    ${icon(entry.icon)}
                    <span class="portal-nav-label">${escapeHtml(entry.label)}</span>
                  </button>`;
              }
              const groupHasActive = entry.children.some((c) => (activeNavItemId ? c.id === activeNavItemId : c.tab === activeTab));
              const isOpen = openNavGroups ? openNavGroups.has(entry.groupId) : groupHasActive;
              return `
                <div class="portal-nav-group ${isOpen ? "is-open" : ""}" data-nav-group-box="${escAttr(entry.groupId)}">
                  <button type="button" class="portal-nav-item portal-nav-group-btn ${groupHasActive ? "is-group-active" : ""}" aria-expanded="${isOpen ? "true" : "false"}" data-ws-group-toggle="${escAttr(entry.groupId)}">
                    ${icon(entry.icon)}
                    <span class="portal-nav-label">${escapeHtml(entry.label)}</span>
                    <span class="portal-nav-chevron">${icon(isOpen ? "chevronDown" : "chevronRight")}</span>
                  </button>
                  <div class="portal-nav-sublist" ${isOpen ? "" : "hidden"}>
                    ${entry.children
                      .map((child) => {
                        const childAct = activeNavItemId ? activeNavItemId === child.id : activeTab === child.tab;
                        return `
                          <button type="button" class="portal-nav-subitem" aria-current="${childAct ? "page" : "false"}" data-ws-nav-item="${escAttr(child.id)}">
                            ${icon(child.icon)}
                            <span class="portal-nav-label">${escapeHtml(child.label)}</span>
                          </button>`;
                      })
                      .join("")}
                  </div>
                </div>`;
            })
            .join("")
        : navItems
            .map(
              ([id, label, iconName]) => `
            <button type="button" class="portal-nav-item" aria-current="${activeTab === id ? "page" : "false"}" data-ws-tab="${escAttr(id)}">
              ${icon(iconName)}
              <span class="portal-nav-label">${escapeHtml(label)}</span>
            </button>`
            )
            .join("");

    const shownNotifs = notifications.slice(0, 15);
    const host = getPortalHost(main);
    const sidebarMarkup = shouldHideSidebar
      ? ""
      : `
        <div class="portal-sidebar-backdrop" data-sb-close></div>
        <aside class="portal-sidebar" aria-label="Portal Navigation">
          <div class="portal-sidebar-head">
            <div class="portal-sidebar-brand">
              <img src="/yuitor-icon-192.png" alt="Yuitor Smart Classes logo">
              <div>
                <strong>Yuitor Portal</strong>
                <span>${escapeHtml(portalTitle)}</span>
              </div>
            </div>
            <button type="button" class="portal-icon-btn portal-collapse-btn" title="Toggle sidebar" data-sb-collapse>
              ${icon("sidebar")}
            </button>
          </div>
          <nav class="portal-nav-list">
            ${sidebarNavHtml}
          </nav>
          <div style="margin-top:auto;padding-top:10px;border-top:1px solid var(--pt-border);">
            <button type="button" class="portal-nav-item" data-portal-logout>
              ${icon("logout")}
              <span class="portal-nav-label">Sign Out</span>
            </button>
          </div>
        </aside>`;

    host.innerHTML = `
      <div class="portal-workspace ${shouldHideSidebar ? "is-no-sidebar" : isCollapsed ? "is-collapsed" : ""}" data-portal-ws>
        ${sidebarMarkup}

        <div class="portal-main-area">
          ${impersonationBanner(session)}
          <div class="portal-topbar">
            <div class="portal-topbar-left">
              ${
                shouldHideSidebar
                  ? ""
                  : `<button type="button" class="portal-icon-btn portal-mobile-menu-btn" title="Open navigation" data-sb-mobile>
                ${icon("menu")}
              </button>`
              }
              <div class="portal-breadcrumb">
                <span>${escapeHtml(portalTitle)}</span>
                <span>/</span>
                <strong>${escapeHtml(activeLabel)}</strong>
              </div>
            </div>
            ${
              isAdmin
                ? ""
                : `<div class="portal-topbar-right">
              <button type="button" class="portal-icon-btn" title="Toggle Light/Dark theme" data-theme-toggle>
                ${icon(isDark ? "sun" : "moon")}
                <span>${isDark ? "Light Mode" : "Dark Mode"}</span>
              </button>
              <div class="portal-notif-wrap">
                <button type="button" class="portal-icon-btn" title="Notifications" data-notif-toggle>
                  ${icon("bell")}
                  ${unreadCount > 0 ? `<span class="portal-notif-dot" data-notif-badge>${unreadCount}</span>` : ""}
                </button>
                <div class="portal-notif-dropdown" data-notif-menu hidden>
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:8px;">
                    <strong style="font-size:12px;">Notifications (${notifications.length})</strong>
                    ${onReadNotifs ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-ws-read-notifs>Mark All Read</button>` : ""}
                  </div>
                  ${
                    shownNotifs
                      .map(
                        (n, idx) => `
                    <button type="button" class="portal-notif-item ${n.is_read ? "" : "is-unread"}" data-notif-item="${idx}">
                      <div class="portal-notif-item-meta">
                        <span>${escapeHtml(n.created_at)}</span>
                        <span class="portal-notif-state">${n.is_read ? "Read" : "New"}</span>
                      </div>
                      <strong>${escapeHtml(n.title)}</strong>
                      <div class="portal-notif-item-preview">${escapeHtml(n.message)}</div>
                      <div class="portal-notif-item-cta">Click to read full message →</div>
                    </button>`
                      )
                      .join("") || `<p class="portal-hint">No notifications right now.</p>`
                  }
                </div>
              </div>
              <div class="portal-user-wrap">
                <button type="button" class="portal-user-btn" data-user-menu-toggle aria-expanded="false" title="Account menu">
                  <img src="${escAttr(avatarSrc)}" alt="" class="portal-avatar" data-user-avatar-img>
                  <div class="portal-user-meta">
                    <strong>${escapeHtml(session.user.full_name)}</strong>
                    <span>${escapeHtml(session.user.role)}</span>
                  </div>
                  ${icon("chevronDown", "portal-icon-svg yu-chevron-sm")}
                </button>
                <div class="portal-user-dropdown" data-user-menu hidden>
                  <div class="portal-user-dropdown-head">
                    <span class="yu-user-signed-label">Signed in as</span>
                    <span class="yu-user-role-line">${escapeHtml(session.user.role)}</span>
                    ${session.user.email ? `<span>${escapeHtml(session.user.email)}</span>` : ""}
                  </div>
                  ${
                    navItems.some((n) => n[0] === "profile" || n[0] === "support")
                      ? `<button type="button" class="portal-user-dropdown-item" data-ws-open-profile>
                    ${icon("user")}
                    <span>Profile &amp; Photo</span>
                  </button>`
                      : ""
                  }
                  <button type="button" class="portal-user-dropdown-item is-danger" data-portal-logout>
                    ${icon("logout")}
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>`
            }
          </div>

          <div data-ws-body>${bodyHtml}</div>
        </div>
      </div>`;

    const ws = main.querySelector("[data-portal-ws]");
    bindGlobalImpersonationExit(main);

    main.querySelector("[data-sb-collapse]")?.addEventListener("click", () => {
      const next = !ws.classList.contains("is-collapsed");
      ws.classList.toggle("is-collapsed", next);
      localStorage.setItem("yuitor_portal_collapsed", next ? "1" : "0");
    });

    main.querySelector("[data-sb-mobile]")?.addEventListener("click", () => {
      ws.classList.add("is-mobile-open");
    });

    main.querySelector("[data-sb-close]")?.addEventListener("click", () => {
      ws.classList.remove("is-mobile-open");
    });

    main.querySelector("[data-theme-toggle]")?.addEventListener("click", () => {
      const next = !main.classList.contains("portal-dark");
      localStorage.setItem("yuitor_portal_dark", next ? "1" : "0");
      main.classList.toggle("portal-dark", next);
      document.documentElement.classList.toggle("yu-portal-dark", next);
      const toggleBtn = main.querySelector("[data-theme-toggle]");
      if (toggleBtn) {
        toggleBtn.innerHTML = `${icon(next ? "sun" : "moon")}<span>${next ? "Light Mode" : "Dark Mode"}</span>`;
      }
    });

    const notifMenu = main.querySelector("[data-notif-menu]");
    const userMenu = main.querySelector("[data-user-menu]");
    const userMenuBtn = main.querySelector("[data-user-menu-toggle]");

    main.querySelector("[data-notif-toggle]")?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (userMenu) userMenu.hidden = true;
      userMenuBtn?.setAttribute("aria-expanded", "false");
      if (notifMenu) notifMenu.hidden = !notifMenu.hidden;
    });

    userMenuBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (notifMenu) notifMenu.hidden = true;
      const willOpen = userMenu ? userMenu.hidden : false;
      if (userMenu) userMenu.hidden = !willOpen;
      userMenuBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    });

    if (!window.__yuPortalMenusDocBound) {
      window.__yuPortalMenusDocBound = true;
      document.addEventListener("click", (ev) => {
        if (!ev.target?.closest?.(".portal-notif-wrap")) {
          document.querySelectorAll("[data-notif-menu]").forEach((m) => {
            m.hidden = true;
          });
        }
        if (!ev.target?.closest?.(".portal-user-wrap")) {
          document.querySelectorAll("[data-user-menu]").forEach((m) => {
            m.hidden = true;
          });
          document.querySelectorAll("[data-user-menu-toggle]").forEach((b) => {
            b.setAttribute("aria-expanded", "false");
          });
        }
      });
    }

    main.querySelectorAll("[data-notif-item]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = Number(btn.getAttribute("data-notif-item"));
        const notif = shownNotifs[idx];
        if (!notif) return;
        if (notifMenu) notifMenu.hidden = true;
        openNotificationModal(notif, async (item) => {
          if (onReadSingleNotif) {
            await onReadSingleNotif(item);
          } else if (onReadNotifs) {
            await onReadNotifs();
          }
          btn.classList.remove("is-unread");
          const stateEl = btn.querySelector(".portal-notif-state");
          if (stateEl) stateEl.textContent = "Read";
          const nextUnread = notifications.filter((x) => !x.is_read).length;
          const badge = main.querySelector("[data-notif-badge]");
          if (badge) {
            if (nextUnread > 0) badge.textContent = String(nextUnread);
            else badge.remove();
          }
        });
      });
    });

    main.querySelector("[data-ws-read-notifs]")?.addEventListener("click", async () => {
      if (onReadNotifs) await onReadNotifs();
    });

    main.querySelectorAll("[data-ws-group-toggle]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const gid = btn.getAttribute("data-ws-group-toggle");
        if (!gid) return;
        const box = btn.closest("[data-nav-group-box]");
        const sublist = box?.querySelector(".portal-nav-sublist");
        const willOpen = sublist ? sublist.hidden : false;
        if (sublist) sublist.hidden = !willOpen;
        box?.classList.toggle("is-open", willOpen);
        btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
        const chev = btn.querySelector(".portal-nav-chevron");
        if (chev) chev.innerHTML = icon(willOpen ? "chevronDown" : "chevronRight");
        if (onToggleNavGroup) onToggleNavGroup(gid, willOpen);
      });
    });

    main.querySelectorAll("[data-ws-nav-item]").forEach((b) => {
      b.addEventListener("click", () => {
        ws.classList.remove("is-mobile-open");
        const itemId = b.getAttribute("data-ws-nav-item");
        if (onSelectNavItem && itemId) onSelectNavItem(itemId);
      });
    });

    main.querySelectorAll("[data-ws-tab]").forEach((b) => {
      b.addEventListener("click", () => {
        ws.classList.remove("is-mobile-open");
        onTabChange(b.getAttribute("data-ws-tab"));
      });
    });

    main.querySelector("[data-ws-open-profile]")?.addEventListener("click", () => {
      if (userMenu) userMenu.hidden = true;
      userMenuBtn?.setAttribute("aria-expanded", "false");
      const targetTab = navItems.find((n) => n[0] === "profile" || n[0] === "support")?.[0];
      if (targetTab) onTabChange(targetTab);
    });

    main.querySelectorAll("[data-portal-logout]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await api("/api/auth/logout", { method: "POST" });
        } catch {
          // ignore network hiccup on logout redirect
        }
        window.location.assign(isAdmin && GATE_BASE ? `${GATE_BASE}/` : "/login");
      });
    });

    return main;
  }

  // ==================== PUBLIC COMPLEMENTARY PAGES ====================
  async function renderPublicExtension(path) {
    if (path.startsWith("/unsubscribe/")) {
      const token = path.split("/unsubscribe/")[1].split("/")[0];
      mountShell(`<div class="portal-card portal-login-card"><p class="portal-kicker">Email Preferences</p><div class="portal-heading"><h1>Loading preferences…</h1></div></div>`);
      try {
        const info = await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`);
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Yuitor Email Preferences</p>
            <div class="portal-heading"><h1>Manage Email Subscription</h1></div>
            <p class="portal-subtitle">Email: <strong>${escapeHtml(info.email)}</strong> · Current status: <strong>${escapeHtml(info.reason)}</strong></p>
            <div class="portal-actions" style="margin-top:20px;">
              <button type="button" class="portal-button" data-unsub-opt="false">Unsubscribe from Marketing Emails</button>
              <button type="button" class="portal-button portal-button--quiet" data-unsub-opt="true">Re-subscribe</button>
            </div>
            <div class="portal-message" data-unsub-fb hidden style="margin-top:16px;"></div>
          </div>`);
        main.querySelectorAll("[data-unsub-opt]").forEach((b) => {
          b.addEventListener("click", async () => {
            const opt = b.getAttribute("data-unsub-opt") === "true";
            const fb = main.querySelector("[data-unsub-fb]");
            try {
              await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`, {
                method: "POST",
                body: { marketingOptIn: opt },
              });
              fb.className = "portal-message portal-message--success";
              fb.textContent = opt ? "Subscribed to Yuitor updates." : "You have been unsubscribed from Yuitor marketing emails.";
              fb.hidden = false;
            } catch (err) {
              fb.className = "portal-message portal-message--error";
              fb.textContent = err.message;
              fb.hidden = false;
            }
          });
        });
      } catch (err) {
        mountShell(`<div class="portal-card portal-login-card"><div class="portal-message portal-message--error">${escapeHtml(err.message)}</div></div>`);
      }
      return;
    }

    const boot = await api("/api/public/bootstrap");
    const courses = boot.courses || [];
    const subjects = boot.subjects || [];
    const teachers = boot.teachers || [];
    const faqs = boot.faqs || [];
    const testimonials = boot.testimonials || [];

    if (path === "/admission") {
      const admEmail = boot.departmentEmails?.admission || "admission@yuitor.com";
      const main = mountShell(`
        <p class="portal-kicker">Admissions Open · Muradnagar</p>
        <div class="portal-heading">
          <div>
            <h1>Apply for Admission</h1>
            <p class="portal-subtitle">Yuitor Smart Classes · Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · Call/WhatsApp +91 78-2728-9292 · <a class="portal-text-link" href="mailto:${escAttr(admEmail)}">${escapeHtml(admEmail)}</a></p>
          </div>
          <a href="/register/student" class="portal-button portal-button--quiet">Student Portal Registration</a>
        </div>
        <div class="portal-card portal-profile">
          <form class="portal-form" data-adm-form>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Student Full Name *</label><input name="name" required placeholder="Full Name"></div>
              <div class="portal-field"><label>Mobile / WhatsApp Number *</label><input name="phone" required placeholder="10-digit number"></div>
              <div class="portal-field"><label>Email Address</label><input name="email" type="email" placeholder="student@example.com"></div>
              <div class="portal-field"><label>Class / Course *</label>
                <select name="class_or_course" required>
                  <option value="">Select Class or Course</option>
                  ${courses.map((c) => `<option value="${escAttr(c.title)}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="portal-field"><label>Notes / Demo Class Preference</label><textarea name="message" placeholder="Preferred batch timing or questions..."></textarea></div>
            <div class="portal-message" data-adm-fb hidden></div>
            <div class="portal-actions"><button type="submit" class="portal-button">Submit Admission Inquiry</button></div>
          </form>
        </div>`);
      const form = main.querySelector("[data-adm-form]");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        const fd = new FormData(form);
        const fb = main.querySelector("[data-adm-fb]");
        btn.disabled = true;
        try {
          const res = await api("/api/public/inquiries", {
            method: "POST",
            body: {
              name: fd.get("name"),
              phone: fd.get("phone"),
              email: fd.get("email"),
              class_or_course: fd.get("class_or_course"),
              message: fd.get("message"),
              source: "admission_form",
            },
          });
          fb.className = "portal-message portal-message--success";
          fb.textContent = res.message;
          fb.hidden = false;
          form.reset();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        } finally {
          btn.disabled = false;
        }
      });
      return;
    }

    if (path === "/subjects") {
      mountShell(`
        <p class="portal-kicker">Academic Directory</p>
        <div class="portal-heading"><h1>Subjects Offered (Classes 6th–12th &amp; Skills)</h1><a href="/admission" class="portal-button">Book Demo Class</a></div>
        <div class="portal-student-grid">
          ${subjects.map((s) => `<div class="portal-card portal-profile"><strong>${escapeHtml(s.name)}</strong><p class="portal-hint" style="margin-top:4px;">${escapeHtml(s.code)} · ${escapeHtml(s.class_level)}</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(s.description)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/ai-learning" || path === "/computer-courses" || path === "/english-speaking" || path === "/courses") {
      const initialCat =
        path === "/ai-learning"
          ? "AI Learning"
          : path === "/computer-courses"
            ? "Computer"
            : path === "/english-speaking"
              ? "English Speaking"
              : "All";
      let activeCat = initialCat;

      const drawCourses = () => {
        const list = activeCat === "All" ? courses : courses.filter((c) => c.category === activeCat);
        const heading = activeCat === "All" ? "All Courses & Fee Directory" : `${activeCat} Programmes`;
        const cats = ["All", "Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"];
        const main = mountShell(`
          <p class="portal-kicker">Yuitor Smart Classes Programmes</p>
          <div class="portal-heading"><h1>${escapeHtml(heading)}</h1><a href="/admission" class="portal-button">Apply for Admission</a></div>
          ${
            path === "/courses"
              ? `<div class="portal-actions" style="margin-bottom:18px;">
                  ${cats.map((c) => `<button type="button" class="portal-button portal-button--small ${activeCat === c ? "" : "portal-button--quiet"}" data-cat-pick="${escAttr(c)}">${escapeHtml(c)}</button>`).join("")}
                </div>`
              : ""
          }
          <div class="portal-form-grid">
            ${list
              .map(
                (c) => `
              <div class="portal-card portal-profile" style="overflow:hidden;">
                ${c.thumbnail_url ? `<img src="${escAttr(c.thumbnail_url)}" alt="${escAttr(c.title)} classroom at Yuitor Smart Classes" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:10px;margin-bottom:12px;">` : ""}
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
                  <span class="portal-status">${escapeHtml(c.category)}</span>
                  <span class="portal-hint">${c.duration_months} months · ${escapeHtml(c.board)}</span>
                </div>
                <h2 style="margin:0 0 8px;font-size:19px;">${escapeHtml(c.title)}</h2>
                <p class="portal-subtitle" style="font-size:13px;margin:0 0 12px;">${escapeHtml(c.description)}</p>
                <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--pt-border);padding-top:12px;">
                  <div><strong>${formatINR(c.monthly_fee)}/mo</strong> <span class="portal-hint">or ${formatINR(c.yearly_fee)}/yr</span></div>
                  <a href="/admission" class="portal-button portal-button--small">Enroll</a>
                </div>
              </div>`
              )
              .join("")}
          </div>`);
        main?.querySelectorAll("[data-cat-pick]").forEach((b) => {
          b.addEventListener("click", () => {
            activeCat = b.getAttribute("data-cat-pick");
            drawCourses();
          });
        });
      };
      drawCourses();
      return;
    }

    if (path === "/teachers") {
      const careerEmail = boot.departmentEmails?.career || "career@yuitor.com";
      mountShell(`
        <p class="portal-kicker">Faculty &amp; Mentors</p>
        <div class="portal-heading"><div><h1>Approved Faculty &amp; Teachers</h1><p class="portal-subtitle">Experienced educators teaching at Yuitor Smart Classes, Muradnagar. Hiring queries: <a class="portal-text-link" href="mailto:${escAttr(careerEmail)}">${escapeHtml(careerEmail)}</a></p></div><a href="/register/teacher" class="portal-button portal-button--quiet">Join as Teacher</a></div>
        <div class="portal-card portal-profile yu-teachers-showcase">
          <div>
            <h2 style="margin:0 0 8px;font-size:20px;">Mentorship-Driven Teaching in Muradnagar</h2>
            <p class="portal-subtitle" style="font-size:14px;margin:0 0 12px;">Every faculty application at Yuitor undergoes resume screening and academic verification before teaching Classes 5th–12th, JEE, NEET, CUET, Computer, and Spoken English batches.</p>
            <div class="portal-actions">
              <a href="/admission" class="portal-button portal-button--small">Book a Demo Class</a>
              <a href="/register/teacher" class="portal-button portal-button--small portal-button--quiet">Apply with Resume</a>
            </div>
          </div>
          <img src="/assets/images/teacher-classroom-guidance.webp" alt="Faculty mentoring students at Yuitor Smart Classes Muradnagar" loading="lazy">
        </div>
        ${
          teachers.length === 0
            ? `<div class="portal-card portal-empty">Verified faculty cards appear here automatically once teacher resumes and profiles are approved by the Yuitor Academic Team.</div>`
            : `<div class="portal-student-grid">
            ${teachers.map((t) => `<div class="portal-card portal-profile"><img src="${escAttr(t.avatar_url || "/assets/images/teacher-led-class.webp")}" alt="${escAttr(t.full_name)}" class="portal-avatar" style="margin-bottom:10px;object-fit:cover;"><h3 style="margin:0 0 4px;">${escapeHtml(t.full_name)}</h3><p class="portal-hint">${escapeHtml(t.qualification || "Faculty Member")} · ${Number(t.experience_years || 0)} yrs exp</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(t.bio || "")}</p></div>`).join("")}
          </div>`
        }`);
      return;
    }

    if (path === "/faqs") {
      mountShell(`
        <p class="portal-kicker">Questions &amp; Answers</p>
        <div class="portal-heading"><h1>Frequently Asked Questions</h1></div>
        <div class="portal-form">
          ${faqs.map((f) => `<div class="portal-card portal-profile"><h3 style="margin:0 0 6px;">${escapeHtml(f.question)}</h3><p class="portal-subtitle" style="font-size:14px;margin:0;">${escapeHtml(f.answer)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/testimonials") {
      mountShell(`
        <p class="portal-kicker">Student &amp; Parent Stories</p>
        <div class="portal-heading"><h1>Verified Reviews &amp; Testimonials</h1></div>
        <div class="portal-student-grid">
          ${testimonials.map((t) => `<div class="portal-card portal-profile"><p style="margin:0 0 12px;line-height:1.6;">“${escapeHtml(t.quote)}”</p><strong>${escapeHtml(t.author_name)}</strong><div class="portal-hint">${escapeHtml(t.author_role)}${t.outcome_metric ? " · " + escapeHtml(t.outcome_metric) : ""}</div></div>`).join("")}
        </div>`);
    }
  }

  // ==================== AUTHENTICATION, HARDENED INSTALLER & SECRET GATE ====================
  async function renderAdminSetup() {
    if (!GATE_BASE || !ADMIN_API_BASE) {
      return;
    }
    let formState = {
      fullName: "",
      email: "",
      phone: "+91 ",
      setupKey: "",
      otp: "",
      writeEnv: false,
      smtpHost: "",
      smtpPort: "587",
      smtpSecure: "false",
      smtpUser: "",
      smtpFrom: "",
    };
    let otpSentMsg = "";
    let needsDbConfirm = false;
    let needsEnvConfirm = false;
    let setupStructuredErr = null;
    let setupSuccess = null;
    let editSmtp = false;

    const renderStructuredErrorBox = (errObj) => {
      if (!errObj) return "";
      return `
        <div class="portal-error-box" data-testid="installer-structured-error">
          <h4>Step Failed: ${escapeHtml(errObj.step || "Installation")}</h4>
          <div><strong>What failed:</strong> ${escapeHtml(errObj.whatFailed || "Unexpected error")}</div>
          <div><strong>Why:</strong> ${escapeHtml(errObj.why || "")}</div>
          <div><strong>How to fix:</strong> ${escapeHtml(errObj.howToFix || "Check logs/install.log and retry.")}</div>
          <div style="margin-top:6px;font-size:11.5px;opacity:0.85;">Full technical trace (secrets redacted) recorded in <code>logs/install.log</code>.</div>
        </div>`;
    };

    async function loadPreflightAndDraw() {
      let pre = null;
      let preErr = null;
      try {
        pre = await api(adminApiUrl("/installer/preflight"));
      } catch (err) {
        preErr = err?.data?.error || {
          step: "Preflight Check",
          whatFailed: err?.message || "Unable to inspect server prerequisites",
          why: "Server preflight endpoint returned an error.",
          howToFix: "Ensure Node.js 22+ is active and data/ and logs/ directories have 755 permissions.",
        };
      }

      if (setupSuccess) {
        const main = mountShell(`
          <div class="portal-card portal-login-card" style="width:min(620px,100%);">
            <p class="portal-kicker">Installation Complete · Installer Locked</p>
            <div class="portal-heading"><h1>Super Admin Initialized</h1></div>
            <p class="portal-subtitle">The installer is now permanently locked. Bookmark your Secret Admin Gate URL below — it is shown once for your records.</p>
            <div class="portal-gate-reveal" data-testid="installer-gate-reveal">
              <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#1d4ed8;margin-bottom:4px;">Your Secret Admin Gate URL</div>
              <strong style="font-size:15px;display:block;margin-bottom:8px;" data-gate-url-text>${escapeHtml(setupSuccess.fullAdminGateUrl || setupSuccess.adminGateUrl)}</strong>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-copy-gate-url>Copy URL</button>
                <a href="${escAttr(setupSuccess.adminGateUrl)}" class="portal-button portal-button--small" data-testid="link-enter-admin-gate">Enter Admin Console</a>
              </div>
            </div>
          </div>`);
        main?.querySelector("[data-copy-gate-url]")?.addEventListener("click", async () => {
          const text = setupSuccess.fullAdminGateUrl || setupSuccess.adminGateUrl;
          try {
            await navigator.clipboard.writeText(text);
            const btn = main.querySelector("[data-copy-gate-url]");
            if (btn) btn.textContent = "Copied!";
          } catch {}
        });
        return;
      }

      if (pre?.existingState && pre.existingState.adminCount > 0) {
        mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Installer Locked</p>
            <div class="portal-heading"><h1>Setup Already Completed</h1></div>
            <div class="portal-message portal-message--success">An administrator account already exists (${pre.existingState.adminCount} admin account${pre.existingState.adminCount === 1 ? "" : "s"}). This installer is automatically locked to prevent unauthorized overwrites.</div>
            <div class="portal-actions">
              <a href="${escAttr(GATE_BASE)}/" class="portal-button">Proceed to Admin Gate Login</a>
            </div>
          </div>`);
        return;
      }

      const maskedOtpEmail = pre?.existingState?.otpRecipientMasked || "ar******10@gmail.com";
      const smtpConfigured = Boolean(pre?.existingState?.smtpConfigured);

      const checksHtml = (pre?.checks || [])
        .map((c) => {
          const cls = c.ok ? "is-ok" : c.required ? "is-fail" : "is-warn";
          return `
            <div class="portal-preflight-item ${cls}">
              <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
                <strong>${c.ok ? "✓" : c.required ? "✕" : "!"} ${escapeHtml(c.label)}</strong>
                <span>${c.ok ? "Ready" : c.required ? "Required" : "Action Needed"}</span>
              </div>
              <div style="margin-top:3px;opacity:0.9;">${escapeHtml(c.detail)}</div>
              ${!c.ok && c.howToFix ? `<div style="margin-top:4px;"><strong>Fix:</strong> ${escapeHtml(c.howToFix)}</div>` : ""}
            </div>`;
        })
        .join("");

      const showSmtpBox = !smtpConfigured || editSmtp || (setupStructuredErr && /smtp|mail|otp delivery/i.test(String(setupStructuredErr.step || "") + " " + String(setupStructuredErr.whatFailed || "")));
      const smtpSetupBox = showSmtpBox
        ? `
          <div class="portal-card portal-profile" style="margin-top:14px;padding:14px 16px;" data-installer-smtp-box>
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px;">
              <h3 class="portal-section-title" style="margin:0;">Step 1A · Configure Mail Server (for OTP to ${escapeHtml(maskedOtpEmail)})</h3>
              ${smtpConfigured ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-smtp-edit>Hide SMTP Form</button>` : ""}
            </div>
            <p class="portal-hint" style="margin-bottom:10px;">Enter your cPanel mail (<code>mail.yourdomain.com</code>) or Gmail App Password SMTP details so the installer can email your verification OTP.</p>
            <div class="portal-form-grid">
              <div class="portal-field"><label>SMTP Host *</label><input name="smtpHost" value="${escAttr(formState.smtpHost)}" placeholder="mail.yourdomain.com or smtp.gmail.com"></div>
              <div class="portal-field"><label>SMTP Port *</label><input name="smtpPort" type="number" value="${escAttr(formState.smtpPort)}" placeholder="587 or 465"></div>
              <div class="portal-field"><label>SSL/TLS Mode</label><select name="smtpSecure"><option value="false" ${formState.smtpSecure === "false" ? "selected" : ""}>STARTTLS (Port 587)</option><option value="true" ${formState.smtpSecure === "true" ? "selected" : ""}>Direct SSL/TLS (Port 465)</option></select></div>
              <div class="portal-field"><label>SMTP Username *</label><input name="smtpUser" value="${escAttr(formState.smtpUser)}" placeholder="info@yourdomain.com"></div>
              <div class="portal-field"><label>SMTP Password / App Password *</label>${passwordFieldHtml("smtpPass", 'autocomplete="new-password"')}</div>
              <div class="portal-field"><label>Sender From Email</label><input name="smtpFrom" type="email" value="${escAttr(formState.smtpFrom)}" placeholder="info@yourdomain.com"></div>
            </div>
          </div>`
        : `<div style="margin-top:10px;text-align:right;"><button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-smtp-edit>Change SMTP Settings</button></div>`;

      const main = mountShell(`
        <div class="portal-card portal-login-card" style="width:min(700px,100%);">
          <p class="portal-kicker">Hardened Setup Wizard · OTP Protected Gate</p>
          <div class="portal-heading">
            <div>
              <h1>Yuitor Platform Installer</h1>
              <p class="portal-subtitle">Protected by mandatory 6-digit Email OTP to <strong>${escapeHtml(maskedOtpEmail)}</strong> so only the owner can install.</p>
            </div>
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-retry-preflight>Retry Checks</button>
          </div>
          ${renderStructuredErrorBox(preErr || pre?.error || setupStructuredErr)}
          <div class="portal-preflight-list" data-testid="installer-preflight-list">${checksHtml}</div>
          ${
            pre?.existingState?.userCount > 0
              ? `<div class="portal-message">Existing database records detected (${pre.existingState.userCount} user accounts, ${pre.existingState.courseCount} courses). Existing data will be preserved automatically.</div>`
              : ""
          }
          <form class="portal-form" data-setup-form style="margin-top:16px;">
            ${
              pre?.existingState?.requiresSetupKey
                ? `<div class="portal-field"><label>Server Setup Key (YU_ADMIN_SETUP_KEY) *</label><input name="setupKey" type="password" required value="${escAttr(formState.setupKey)}" placeholder="Enter server setup key"></div>`
                : ""
            }
            ${smtpSetupBox}
            <div class="portal-card portal-profile" style="margin-top:14px;padding:14px 16px;">
              <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
                <div>
                  <strong style="font-size:13.5px;">${smtpConfigured ? "Step 1" : "Step 1B"} · Request Installer OTP</strong>
                  <div class="portal-hint">OTP will be emailed to <strong>${escapeHtml(maskedOtpEmail)}</strong> (valid 10 minutes).</div>
                </div>
                <button type="button" class="portal-button portal-button--small" data-send-setup-otp data-testid="button-send-setup-otp">Send OTP to ${escapeHtml(maskedOtpEmail)}</button>
              </div>
              ${otpSentMsg ? `<div class="portal-message portal-message--success" style="margin-top:10px;" data-setup-otp-fb>${escapeHtml(otpSentMsg)}</div>` : `<div class="portal-message" style="margin-top:10px;" data-setup-otp-fb hidden></div>`}
            </div>
            <div class="portal-form-grid" style="margin-top:14px;">
              <div class="portal-field"><label>Full Name *</label><input name="fullName" required value="${escAttr(formState.fullName)}" placeholder="Administrator Name"></div>
              <div class="portal-field"><label>Admin Login Email *</label><input name="email" type="email" required value="${escAttr(formState.email)}" placeholder="arunku8510@gmail.com"></div>
              <div class="portal-field"><label>Mobile Number *</label><input name="phone" required value="${escAttr(formState.phone)}" placeholder="+91 78-2728-9292"></div>
              <div class="portal-field"><label>Admin Password (min 8 chars) *</label>${passwordFieldHtml("password", 'minlength="8" required')}</div>
              <div class="portal-field"><label>6-Digit Email OTP (from ${escapeHtml(maskedOtpEmail)}) *</label><input name="otp" required maxlength="6" inputmode="numeric" pattern="\\d{6}" value="${escAttr(formState.otp)}" placeholder="Enter 6-digit Email OTP" data-testid="input-setup-otp"></div>
            </div>
            ${
              pre?.existingState?.hasEnvFile
                ? `<label class="portal-clear-check"><input type="checkbox" name="writeEnv" value="1" ${formState.writeEnv ? "checked" : ""}> Also sync ADMIN_PATH slug to server <code>.env</code> file</label>`
                : ""
            }
            ${
              pre?.existingState?.userCount > 0 || needsDbConfirm
                ? `<label class="portal-clear-check"><input type="checkbox" name="confirmExistingDb" value="1" required> Confirm adding Super Admin into the existing database without overwriting existing records</label>`
                : ""
            }
            ${
              needsEnvConfirm
                ? `<label class="portal-clear-check"><input type="checkbox" name="confirmOverwriteEnv" value="1" required> Confirm updating existing <code>.env</code> file with ADMIN_PATH</label>`
                : ""
            }
            <div class="portal-message" data-setup-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button" ${pre && !pre.ok ? "disabled" : ""} data-testid="button-run-installer">Verify OTP &amp; Complete Setup</button>
            </div>
          </form>
        </div>`);

      bindPasswordToggles(main);
      const form = main?.querySelector("[data-setup-form]");
      const captureFormFields = () => {
        if (!form) return;
        const fd = new FormData(form);
        formState = {
          fullName: String(fd.get("fullName") || ""),
          email: String(fd.get("email") || ""),
          phone: String(fd.get("phone") || ""),
          setupKey: String(fd.get("setupKey") || ""),
          otp: String(fd.get("otp") || ""),
          writeEnv: fd.get("writeEnv") === "1",
          smtpHost: String(fd.get("smtpHost") ?? formState.smtpHost),
          smtpPort: String(fd.get("smtpPort") ?? formState.smtpPort),
          smtpSecure: String(fd.get("smtpSecure") ?? formState.smtpSecure),
          smtpUser: String(fd.get("smtpUser") ?? formState.smtpUser),
          smtpFrom: String(fd.get("smtpFrom") ?? formState.smtpFrom),
        };
      };

      main?.querySelector("[data-toggle-smtp-edit]")?.addEventListener("click", () => {
        captureFormFields();
        editSmtp = !showSmtpBox;
        loadPreflightAndDraw();
      });

      main?.querySelector("[data-retry-preflight]")?.addEventListener("click", () => {
        captureFormFields();
        setupStructuredErr = null;
        loadPreflightAndDraw();
      });

      main?.querySelector("[data-send-setup-otp]")?.addEventListener("click", async () => {
        captureFormFields();
        const sendBtn = main.querySelector("[data-send-setup-otp]");
        const otpFb = main.querySelector("[data-setup-otp-fb]");
        if (sendBtn) sendBtn.disabled = true;
        setupStructuredErr = null;
        try {
          const bodyPayload = {
            setupKey: formState.setupKey,
          };
          if (form) {
            const fd = new FormData(form);
            const host = String(fd.get("smtpHost") || "").trim();
            const user = String(fd.get("smtpUser") || "").trim();
            const pass = String(fd.get("smtpPass") || "").trim();
            if (host || user || pass) {
              bodyPayload.smtp = {
                host,
                port: Number(fd.get("smtpPort") || 587),
                secure: String(fd.get("smtpSecure") || "false"),
                user,
                pass,
                fromEmail: String(fd.get("smtpFrom") || "").trim(),
              };
            }
          }
          const res = await api(adminApiUrl("/installer/send-otp"), {
            method: "POST",
            body: bodyPayload,
          });
          otpSentMsg = res.message || `6-digit OTP sent to ${maskedOtpEmail}.`;
          if (otpFb) {
            otpFb.className = "portal-message portal-message--success";
            otpFb.textContent = otpSentMsg;
            otpFb.hidden = false;
          }
          if (!smtpConfigured) {
            await loadPreflightAndDraw();
          }
        } catch (err) {
          if (err?.data?.structuredError) {
            setupStructuredErr = err.data.structuredError;
            await loadPreflightAndDraw();
            return;
          }
          if (otpFb) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Failed to send Installer OTP.";
            otpFb.hidden = false;
          }
        } finally {
          if (sendBtn) sendBtn.disabled = false;
        }
      });

      form?.addEventListener("submit", async (e) => {
        e.preventDefault();
        captureFormFields();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-setup-fb]");
        const btn = form.querySelector("[data-testid='button-run-installer']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/installer/run"), {
            method: "POST",
            body: {
              fullName: formState.fullName,
              email: formState.email,
              phone: formState.phone,
              password: String(fd.get("password") || ""),
              otp: formState.otp,
              setupKey: formState.setupKey,
              writeEnv: formState.writeEnv,
              confirmExistingDb: fd.get("confirmExistingDb") === "1",
              confirmOverwriteEnv: fd.get("confirmOverwriteEnv") === "1",
            },
          });
          setupSuccess = res;
          await loadPreflightAndDraw();
        } catch (err) {
          if (err?.data?.requiresConfirmation) {
            if (err.data.confirmationType === "existing_db") needsDbConfirm = true;
            if (err.data.confirmationType === "overwrite_env") needsEnvConfirm = true;
            setupStructuredErr = {
              step: "Confirmation Required",
              whatFailed: err.message,
              why: "Installer requires explicit confirmation before continuing.",
              howToFix: "Tick the confirmation checkbox below and click Verify OTP & Complete Setup again.",
            };
            await loadPreflightAndDraw();
            return;
          }
          if (err?.data?.structuredError) {
            setupStructuredErr = err.data.structuredError;
            await loadPreflightAndDraw();
            return;
          }
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
    }

    await loadPreflightAndDraw();
  }

  function renderAdminGateLogin(initialError = "") {
    let challengeToken = "";
    let recipientMasked = "";
    let stepMsg = "";

    function drawLogin() {
      if (challengeToken) {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 · Mandatory Email Verification</p>
            <div class="portal-heading"><h1>Enter Admin Sign-In OTP</h1></div>
            <p class="portal-subtitle">Enter the 6-digit verification code emailed to <strong>${escapeHtml(recipientMasked || "ar******10@gmail.com")}</strong> (valid for 10 minutes).</p>
            ${stepMsg ? `<div class="portal-message portal-message--success" style="margin-top:10px;">${escapeHtml(stepMsg)}</div>` : ""}
            <form class="portal-form" data-admin-gate-otp-form style="margin-top:14px;">
              <div class="portal-field"><label>6-Digit Email OTP *</label><input name="otp" required maxlength="6" inputmode="numeric" pattern="\\d{6}" autocomplete="one-time-code" placeholder="Enter 6-digit OTP" data-testid="input-admin-otp"></div>
              <div class="portal-message" data-gate-otp-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button" data-testid="button-admin-verify-otp">Verify OTP &amp; Enter Console</button>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-resend-admin-otp data-testid="button-admin-resend-otp">Resend OTP</button>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-admin-pw data-testid="button-admin-back-pw">Back</button>
              </div>
            </form>
          </div>`);

        const otpForm = main?.querySelector("[data-admin-gate-otp-form]");
        const otpFb = main?.querySelector("[data-gate-otp-fb]");
        otpForm?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(otpForm);
          const btn = otpForm.querySelector("[data-testid='button-admin-verify-otp']");
          if (btn) btn.disabled = true;
          try {
            await api(adminApiUrl("/auth/verify-otp"), {
              method: "POST",
              body: {
                challengeToken,
                otp: String(fd.get("otp") || ""),
              },
            });
            window.location.assign(`${GATE_BASE}/`);
          } catch (err) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Invalid or expired OTP.";
            otpFb.hidden = false;
            if (btn) btn.disabled = false;
          }
        });

        main?.querySelector("[data-resend-admin-otp]")?.addEventListener("click", async () => {
          const btn = main.querySelector("[data-resend-admin-otp]");
          if (btn) btn.disabled = true;
          try {
            const res = await api(adminApiUrl("/auth/resend-otp"), {
              method: "POST",
              body: { challengeToken },
            });
            otpFb.className = "portal-message portal-message--success";
            otpFb.textContent = res.message || `Fresh OTP sent to ${recipientMasked}.`;
            otpFb.hidden = false;
          } catch (err) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Failed to resend OTP.";
            otpFb.hidden = false;
          } finally {
            if (btn) btn.disabled = false;
          }
        });

        main?.querySelector("[data-back-admin-pw]")?.addEventListener("click", () => {
          challengeToken = "";
          stepMsg = "";
          drawLogin();
        });
        return;
      }

      const main = mountShell(`
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Restricted Console · 2FA Secret Gate</p>
          <div class="portal-heading"><h1>Administrator Sign In</h1></div>
          <p class="portal-subtitle">Authorized administrators only. Every sign-in verifies both your password and a 6-digit Email OTP.</p>
          ${initialError ? `<div class="portal-message portal-message--error">${escapeHtml(initialError)}</div>` : ""}
          <form class="portal-form" data-admin-gate-login-form style="margin-top:14px;">
            <div class="portal-field"><label>Administrator Email or Mobile</label><input name="identifier" required autocomplete="username" placeholder="admin@yuitor.com"></div>
            <div class="portal-field"><label>Password</label>${passwordFieldHtml("password", 'required autocomplete="current-password"')}</div>
            <div class="portal-message" data-gate-login-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button" data-testid="button-admin-signin">Continue &amp; Send Email OTP</button>
            </div>
          </form>
        </div>`);
      bindPasswordToggles(main);
      const form = main?.querySelector("[data-admin-gate-login-form]");
      form?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-gate-login-fb]");
        const btn = form.querySelector("[data-testid='button-admin-signin']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/auth/login"), {
            method: "POST",
            body: {
              identifier: String(fd.get("identifier") || ""),
              password: String(fd.get("password") || ""),
            },
          });
          if (res?.otpRequired && res?.challengeToken) {
            challengeToken = res.challengeToken;
            recipientMasked = res.recipientMasked || "ar******10@gmail.com";
            stepMsg = res.message || `6-digit OTP sent to ${recipientMasked}.`;
            drawLogin();
            return;
          }
          window.location.assign(`${GATE_BASE}/`);
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message || "Administrator login failed.";
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
    }

    drawLogin();
  }

  function renderLogin(defaultRole = "student", initialError = "") {
    let mode = "login"; // 'login' | 'forgot' | 'reset'
    let resetIdentifier = "";
    let resetNote = "";

    function draw() {
      const titleMap = { teacher: "Teacher Login", student: "Student & Teacher Sign In" };

      if (mode === "forgot") {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Account Recovery</p>
            <div class="portal-heading"><h1>Reset Password</h1></div>
            <p class="portal-subtitle">Enter your registered email or mobile number to request a 6-digit reset OTP.</p>
            <form class="portal-form" data-forgot-form style="margin-top:14px;">
              <div class="portal-field"><label>Registered Email or Mobile</label><input name="identifier" required placeholder="email@example.com or 10-digit mobile"></div>
              <div class="portal-message" data-forgot-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Request Reset OTP</button>
                <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
              </div>
            </form>
          </div>`);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          mode = "login";
          draw();
        });
        main.querySelector("[data-forgot-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const identifier = String(new FormData(e.target).get("identifier") || "").trim();
          const fb = main.querySelector("[data-forgot-fb]");
          try {
            const res = await api("/api/auth/forgot-password", { method: "POST", body: { identifier } });
            resetIdentifier = identifier;
            resetNote = res.limitationNote || res.message || "";
            mode = "reset";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      if (mode === "reset") {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 · Verify Reset OTP</p>
            <div class="portal-heading"><h1>Choose New Password</h1></div>
            <p class="portal-subtitle">Account: <strong>${escapeHtml(resetIdentifier)}</strong></p>
            ${resetNote ? `<div class="portal-message" style="margin-top:12px;">${escapeHtml(resetNote)}</div>` : ""}
            <form class="portal-form" data-reset-form style="margin-top:14px;">
              <div class="portal-field"><label>6-Digit Reset OTP</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP"></div>
              <div class="portal-field"><label>New Password (min 8 chars)</label>${passwordFieldHtml("newPassword", 'minlength="8" required')}</div>
              <div class="portal-message" data-reset-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Update Password</button>
                <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
              </div>
            </form>
          </div>`);
        bindPasswordToggles(main);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          mode = "login";
          draw();
        });
        main.querySelector("[data-reset-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const fb = main.querySelector("[data-reset-fb]");
          try {
            const res = await api("/api/auth/reset-password", {
              method: "POST",
              body: { identifier: resetIdentifier, otp: fd.get("otp"), newPassword: fd.get("newPassword") },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.message;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      const main = mountShell(`
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Yuitor Smart Classes Portal</p>
          <div class="portal-heading"><h1>${titleMap[defaultRole] || "Student & Teacher Sign In"}</h1></div>
          ${initialError ? `<div class="portal-message portal-message--error">${escapeHtml(initialError)}</div>` : ""}
          <form class="portal-form" data-login-form>
            <div class="portal-field"><label>Registered Email or Mobile</label><input name="identifier" required placeholder="email@example.com or mobile number"></div>
            <div class="portal-field"><label>Password</label>${passwordFieldHtml("password", "required")}</div>
            <div class="portal-message" data-login-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button">Sign In</button>
              <button type="button" class="portal-button portal-button--quiet portal-button--small" data-go-forgot>Forgot Password?</button>
            </div>
          </form>
          <div data-pending-resume-box hidden style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
            <h3 class="portal-section-title" style="margin-bottom:6px;">Upload / Update Teacher Resume</h3>
            <p class="portal-hint" style="margin-bottom:10px;">Attach a valid PDF, DOC, or DOCX resume (max 5 MB) so the Yuitor Academic Team can review and approve your teacher account.</p>
            <form class="portal-form" data-login-resume-form>
              <div class="yu-resume-dropzone">
                <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
              </div>
              <div class="portal-message" data-login-resume-fb hidden></div>
              <button type="submit" class="portal-button portal-button--small">Upload Resume for Verification</button>
            </form>
          </div>
          <div class="portal-inline-links">
            <a href="/register/student">Student Registration</a>
            <a href="/register/teacher">Teacher Registration</a>
            <a href="mailto:support@yuitor.com">Support: support@yuitor.com</a>
          </div>
        </div>`);

      bindPasswordToggles(main);
      main.querySelector("[data-go-forgot]")?.addEventListener("click", () => {
        mode = "forgot";
        draw();
      });

      let lastCredentials = { identifier: "", password: "" };
      const form = main.querySelector("[data-login-form]");
      const pendingResumeBox = main.querySelector("[data-pending-resume-box]");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-login-fb]");
        const identifier = String(fd.get("identifier") || "");
        const password = String(fd.get("password") || "");
        lastCredentials = { identifier, password };
        if (pendingResumeBox) pendingResumeBox.hidden = true;
        try {
          const res = await api("/api/auth/login", {
            method: "POST",
            body: { identifier, password },
          });
          if (res.verificationStatus === "pending_otp") {
            fb.className = "portal-message portal-message--error";
            fb.textContent = "Please complete mobile OTP verification before continuing.";
            fb.hidden = false;
            return;
          }
          if (res.verificationStatus === "pending_approval" || res.verificationStatus === "otp_verified") {
            const missingTeacherResume = res.role === "teacher" && res.teacherResume && !res.teacherResume.hasResume;
            fb.className = missingTeacherResume ? "portal-message portal-message--error" : "portal-message portal-message--success";
            fb.textContent = missingTeacherResume
              ? (res.teacherResume.resumeStatus === "rejected"
                  ? TEACHER_REJECTED_RESUME_MSG
                  : (res.teacherResume.missingResumeMessage || TEACHER_MISSING_RESUME_MSG))
              : (res.pendingMessage || BRAND_PENDING_MSG);
            fb.hidden = false;
            if (missingTeacherResume && pendingResumeBox) {
              pendingResumeBox.hidden = false;
            }
            return;
          }
          if (res.role === "super_admin" || res.role === "admin") {
            fb.className = "portal-message portal-message--error";
            fb.textContent = "Administrator login is not permitted on the public Student/Teacher portal.";
            fb.hidden = false;
            return;
          }
          const dest = res.role === "teacher" ? "/teacher/" : "/student/";
          window.location.assign(dest);
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        }
      });

      main.querySelector("[data-login-resume-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const rForm = e.target;
        const rFd = new FormData(rForm);
        const rFb = main.querySelector("[data-login-resume-fb]");
        const file = rFd.get("resume");
        if (!(file instanceof File) || file.size === 0) {
          rFb.className = "portal-message portal-message--error";
          rFb.textContent = TEACHER_MISSING_RESUME_MSG;
          rFb.hidden = false;
          return;
        }
        rFd.append("identifier", lastCredentials.identifier || String(form.querySelector('[name="identifier"]')?.value || ""));
        rFd.append("password", lastCredentials.password || String(form.querySelector('[name="password"]')?.value || ""));
        const btn = rForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        try {
          const upRes = await api("/api/auth/teacher-resume", { method: "POST", body: rFd });
          rFb.className = "portal-message portal-message--success";
          rFb.textContent = `Resume (${upRes.resumeFilename || "uploaded"}) submitted! Our academic team will review your profile shortly.`;
          rFb.hidden = false;
        } catch (err) {
          rFb.className = "portal-message portal-message--error";
          rFb.textContent = err.message || "Could not upload resume.";
          rFb.hidden = false;
        } finally {
          if (btn) btn.disabled = false;
        }
      });
    }
    draw();
  }

  function renderRegister(defaultRole = "student") {
    let role = defaultRole === "teacher" ? "teacher" : "student";
    let step = "form";
    let registeredPhone = "";
    let registeredName = "";
    let registeredRole = role;
    let limitationMsg = "";
    let pendingCustomMsg = "";
    let selectedResumeFile = null;
    let otpCooldownSec = 0;
    let otpTimerId = null;

    function stopOtpTimer() {
      if (otpTimerId) {
        window.clearInterval(otpTimerId);
        otpTimerId = null;
      }
    }

    function startOtpCooldown(seconds = 30) {
      stopOtpTimer();
      otpCooldownSec = Math.max(0, Number(seconds) || 0);
      const syncBtn = () => {
        const btn = root.querySelector("[data-resend-otp]");
        if (!btn) {
          stopOtpTimer();
          return;
        }
        if (otpCooldownSec > 0) {
          btn.disabled = true;
          btn.textContent = `Resend OTP (${otpCooldownSec}s)`;
        } else {
          btn.disabled = false;
          btn.textContent = "Resend OTP";
          stopOtpTimer();
        }
      };
      syncBtn();
      if (otpCooldownSec > 0) {
        otpTimerId = window.setInterval(() => {
          otpCooldownSec = Math.max(0, otpCooldownSec - 1);
          syncBtn();
        }, 1000);
      }
    }

    function formatBytes(bytes) {
      const n = Number(bytes || 0);
      if (n < 1024) return `${n} B`;
      if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
      return `${(n / (1024 * 1024)).toFixed(2)} MB`;
    }

    function isValidResumeExtension(name) {
      return /\.(pdf|doc|docx)$/i.test(String(name || ""));
    }

    function draw() {
      if (step === "pending") {
        stopOtpTimer();
        const isTeacher = registeredRole === "teacher";
        const headingText = isTeacher
          ? "Welcome to the Yuitor Teaching Community!"
          : "Congratulations on Beginning Your Learning Journey with Yuitor!";
        const roleMessage = pendingCustomMsg || (isTeacher ? TEACHER_PENDING_MSG : STUDENT_PENDING_MSG);
        mountShell(`
          <div class="portal-card portal-profile yu-reg-card">
            <div class="yu-reg-hero">
              <p class="yu-reg-hero-kicker">${isTeacher ? "Teacher Application Submitted" : "Student Registration Confirmed"}</p>
              <h1>${headingText}</h1>
              <p>${registeredName ? `Thank you, ${escapeHtml(registeredName)}. ` : ""}Your registration and mobile verification are complete.</p>
            </div>
            <div class="portal-message portal-message--success" data-testid="registration-success-message">${escapeHtml(roleMessage)}</div>
            <p class="portal-hint" style="margin-top:8px;">${escapeHtml(BRAND_PENDING_MSG)}</p>
            <div class="portal-inline-links" style="margin-top:18px;">
              <a href="/login" class="portal-button portal-button--small">Go to ${isTeacher ? "Teacher" : "Student"} Sign In</a>
              <a href="/courses" class="portal-button portal-button--small portal-button--quiet">Explore Courses</a>
              <a href="/">Return Home</a>
            </div>
          </div>`);
        return;
      }

      if (step === "otp") {
        const isTeacher = registeredRole === "teacher";
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 of 2 · Mobile Verification</p>
            <div class="portal-heading"><h1>Verify Your Mobile Number</h1></div>
            <p class="portal-subtitle">
              ${isTeacher ? "Almost done with your Teacher application!" : "One quick verification before completing your student registration."}
              Enter the 6-digit OTP sent to <strong>${escapeHtml(registeredPhone)}</strong>.
            </p>
            ${limitationMsg ? `<div class="portal-message" style="margin-top:12px;">${escapeHtml(limitationMsg)}</div>` : ""}
            <form class="portal-form" data-otp-form style="margin-top:16px;">
              <div class="portal-field"><label>6-Digit OTP</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP" inputmode="numeric"></div>
              <div class="portal-message" data-otp-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Verify OTP &amp; Complete Registration</button>
                <button type="button" class="portal-button portal-button--quiet" data-resend-otp ${otpCooldownSec > 0 ? "disabled" : ""}>${otpCooldownSec > 0 ? `Resend OTP (${otpCooldownSec}s)` : "Resend OTP"}</button>
              </div>
            </form>
          </div>`);
        startOtpCooldown(otpCooldownSec || 30);
        main.querySelector("[data-otp-form]").addEventListener("submit", async (e) => {
          e.preventDefault();
          const btn = e.target.querySelector('button[type="submit"]');
          const otp = new FormData(e.target).get("otp");
          const fb = main.querySelector("[data-otp-fb]");
          btn.disabled = true;
          try {
            await api("/api/auth/verify-otp", { method: "POST", body: { phone: registeredPhone, otp } });
            pendingCustomMsg = "";
            step = "pending";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
            btn.disabled = false;
          }
        });
        main.querySelector("[data-resend-otp]").addEventListener("click", async () => {
          if (otpCooldownSec > 0) return;
          const fb = main.querySelector("[data-otp-fb]");
          try {
            const res = await api("/api/auth/resend-otp", { method: "POST", body: { phone: registeredPhone } });
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.limitationNote || res.message || "A fresh OTP has been dispatched.";
            fb.hidden = false;
            startOtpCooldown(Number(res.cooldownSeconds || 30));
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      const isTeacher = role === "teacher";
      const main = mountShell(`
        <div class="portal-card portal-profile yu-reg-card">
          <div class="yu-reg-hero">
            <p class="yu-reg-hero-kicker">Yuitor Smart Classes · Muradnagar</p>
            <h1>Congratulations on Taking Your First Step Towards Yuitor!</h1>
            <p>Whether you are joining to master your subjects or inspire learners as part of our faculty, we are excited to welcome you with a quick, guided registration.</p>
          </div>

          <div class="yu-reg-role-tabs" role="tablist" aria-label="Choose Registration Type">
            <button type="button" role="tab" aria-selected="${!isTeacher}" class="yu-reg-role-tab ${!isTeacher ? "is-active" : ""}" data-reg-role="student">
              <strong>Student Registration</strong>
              <span>Classes 6–12, JEE, NEET, CUET &amp; Skill Courses</span>
            </button>
            <button type="button" role="tab" aria-selected="${isTeacher}" class="yu-reg-role-tab ${isTeacher ? "is-active" : ""}" data-reg-role="teacher">
              <strong>Teacher Registration</strong>
              <span>Faculty Application · Resume Required</span>
            </button>
          </div>

          <div class="yu-reg-role-banner ${isTeacher ? "yu-reg-role-banner--teacher" : ""}">
            <h2>${isTeacher ? "Welcome to the Yuitor Teaching Community!" : "Congratulations on Beginning Your Learning Journey with Yuitor!"}</h2>
            <p>${
              isTeacher
                ? "Share your qualifications, subject strengths, and an updated resume (PDF, DOC, or DOCX) so our academic leadership team can review your profile before enabling Teacher Dashboard access."
                : "Get personalized mentorship, structured notes, attendance tracking, assignments, and smart AI support with Ask Shreya once your mobile number and enrolment are verified."
            }</p>
          </div>

          <form class="portal-form" data-reg-form novalidate>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Full Name *</label><input name="fullName" required placeholder="Enter your full name"></div>
              <div class="portal-field"><label>Email Address *</label><input name="email" type="email" required placeholder="you@example.com"></div>
              <div class="portal-field"><label>Mobile Number *</label><input name="phone" required placeholder="10-digit mobile number" inputmode="tel"></div>
              <div class="portal-field"><label>Password (min 8 chars) *</label>${passwordFieldHtml("password", 'minlength="8" required placeholder="Minimum 8 characters"')}</div>
              ${
                !isTeacher
                  ? `
                <div class="portal-field"><label>Class / Level *</label>
                  <select name="classLevel">${["Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12", "JEE / NEET / CUET", "Computer / AI", "Spoken English"].map((c) => `<option>${c}</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Board / Track *</label>
                  <select name="board"><option>CBSE</option><option>ICSE</option><option>UP Board</option><option>Skill / Competitive</option></select>
                </div>
                <div class="portal-field"><label>Interested Subjects (comma separated)</label><input name="subjects" value="Mathematics, Science" placeholder="Mathematics, Science"></div>
                <div class="portal-field"><label>Course Duration (months)</label><input name="courseDurationMonths" type="number" value="12" min="1" max="60"></div>
              `
                  : `
                <div class="portal-field"><label>Highest Qualification *</label><input name="qualification" required placeholder="e.g. M.Sc Physics, B.Ed"></div>
                <div class="portal-field"><label>Teaching Experience (Years)</label><input name="experienceYears" type="number" min="0" max="50" value="2"></div>
                <div class="portal-field"><label>Teaching Subjects (comma separated)</label><input name="subjects" placeholder="Physics, Mathematics"></div>
                <div class="portal-field"><label>Preferred Classes / Batches</label><input name="assignedClasses" placeholder="Class 9, Class 10"></div>
              `
              }
            </div>
            ${
              isTeacher
                ? `
              <div class="portal-field">
                <label>Upload Updated Resume / CV (Mandatory) *</label>
                <div class="yu-resume-dropzone">
                  <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required data-reg-resume>
                  <p class="portal-hint">Accepted formats: <strong>PDF, DOC, DOCX</strong> · Maximum file size: <strong>5 MB</strong>. Without a submitted resume, Teacher Dashboard access cannot be granted.</p>
                  <div data-resume-preview>
                    ${
                      selectedResumeFile
                        ? `<span class="yu-resume-file-pill">Selected: ${escapeHtml(selectedResumeFile.name)} (${escapeHtml(formatBytes(selectedResumeFile.size))})</span>`
                        : ""
                    }
                  </div>
                </div>
              </div>
            `
                : ""
            }
            <div class="portal-message" data-reg-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button">${isTeacher ? "Submit Teacher Application &amp; Request OTP" : "Complete Student Step &amp; Request OTP"}</button>
            </div>
          </form>
          <div class="portal-inline-links">
            <a href="/login">Already registered? Sign in</a>
            <a href="${isTeacher ? "mailto:career@yuitor.com" : "mailto:admission@yuitor.com"}">${isTeacher ? "Hiring Desk: career@yuitor.com" : "Admissions Desk: admission@yuitor.com"}</a>
            <a href="/contact">Need Guidance? Contact Team</a>
          </div>
        </div>`);

      bindPasswordToggles(main);
      main.querySelectorAll("[data-reg-role]").forEach((b) => {
        b.addEventListener("click", () => {
          role = b.getAttribute("data-reg-role") === "teacher" ? "teacher" : "student";
          selectedResumeFile = null;
          draw();
        });
      });

      const resumeInput = main.querySelector("[data-reg-resume]");
      if (resumeInput) {
        resumeInput.addEventListener("change", () => {
          const file = resumeInput.files && resumeInput.files[0];
          const preview = main.querySelector("[data-resume-preview]");
          selectedResumeFile = file || null;
          if (preview) {
            preview.innerHTML = file
              ? `<span class="yu-resume-file-pill">Selected: ${escapeHtml(file.name)} (${escapeHtml(formatBytes(file.size))})</span>`
              : "";
          }
        });
      }

      main.querySelector("[data-reg-form]").addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const btn = form.querySelector('button[type="submit"]');
        const fd = new FormData(form);
        const fb = main.querySelector("[data-reg-fb]");
        const showError = (msg) => {
          fb.className = "portal-message portal-message--error";
          fb.textContent = msg;
          fb.hidden = false;
        };

        const fullName = String(fd.get("fullName") || "").trim();
        const email = String(fd.get("email") || "").trim();
        const phone = String(fd.get("phone") || "").trim();
        const password = String(fd.get("password") || "");
        if (!fullName || !email || !phone || password.length < 8) {
          showError("Please fill in your full name, valid email, mobile number, and a password of at least 8 characters.");
          return;
        }

        if (role === "teacher") {
          const qualification = String(fd.get("qualification") || "").trim();
          if (!qualification) {
            showError("Please enter your highest teaching qualification.");
            return;
          }
          const resumeFile = fd.get("resume") instanceof File && fd.get("resume").size > 0 ? fd.get("resume") : selectedResumeFile;
          if (!resumeFile || resumeFile.size === 0) {
            showError(TEACHER_MISSING_RESUME_MSG);
            return;
          }
          if (!isValidResumeExtension(resumeFile.name)) {
            showError("Unsupported resume file type. Please upload a PDF, DOC, or DOCX resume.");
            return;
          }
          if (resumeFile.size > 5 * 1024 * 1024) {
            showError("Resume file is too large. Maximum allowed size is 5 MB.");
            return;
          }
        }

        btn.disabled = true;
        fb.hidden = true;
        try {
          const splitCsv = (v) => String(v || "").split(",").map((x) => x.trim()).filter(Boolean);
          let res;
          if (role === "teacher") {
            const bodyFd = new FormData();
            bodyFd.append("role", "teacher");
            bodyFd.append("fullName", fullName);
            bodyFd.append("email", email);
            bodyFd.append("phone", phone);
            bodyFd.append("password", password);
            bodyFd.append("qualification", String(fd.get("qualification") || "").trim());
            bodyFd.append("experienceYears", String(Number(fd.get("experienceYears") || 0)));
            bodyFd.append("subjects", JSON.stringify(splitCsv(fd.get("subjects"))));
            bodyFd.append("assignedClasses", JSON.stringify(splitCsv(fd.get("assignedClasses"))));
            const resumeFile = fd.get("resume") instanceof File && fd.get("resume").size > 0 ? fd.get("resume") : selectedResumeFile;
            bodyFd.append("resume", resumeFile);
            res = await api("/api/auth/register", { method: "POST", body: bodyFd });
          } else {
            const payload = {
              role: "student",
              fullName,
              email,
              phone,
              password,
              classLevel: fd.get("classLevel"),
              board: fd.get("board"),
              courseDurationMonths: Number(fd.get("courseDurationMonths") || 12),
              subjects: splitCsv(fd.get("subjects")),
            };
            res = await api("/api/auth/register", { method: "POST", body: payload });
          }
          registeredPhone = res.phone;
          registeredName = fullName;
          registeredRole = role;
          limitationMsg = res.limitationNote || "";
          pendingCustomMsg = "";
          step = "otp";
          draw();
        } catch (err) {
          showError(err.message);
          btn.disabled = false;
        }
      });
    }
    draw();
  }

  // ==================== ADMIN PANEL ====================
  async function renderAdminPanel(session) {
    let tab = "dashboard";
    let activeNavItemId = "dashboard";
    let userFilterStatus = "all";
    let userFilterRole = "all";
    let userSearch = "";
    let userPage = 1;
    let showCreateUser = false;
    let selectedUserDetail = null;
    let editingCourse = null;
    let paymentFilterStatus = "all";
    let paymentSection = "all";
    let chatFilterStatus = "all";
    let chatSearch = "";
    let chatMinRating = 0;
    let selectedChatDetail = null;
    let selectedCampaignDeliveries = null;
    let openNavGroups = new Set(["dashboard"]);
    let openSettingGroups = new Set();
    let pendingScrollSelector = "";
    let feedbackMsg = "";
    let feedbackError = "";

    const adminNavGroups = [
      {
        groupId: "dashboard",
        label: "Dashboard",
        icon: "dashboard",
        children: [
          {
            id: "dashboard",
            tab: "dashboard",
            label: "Overview",
            icon: "dashboard",
            apply: () => {},
          },
          {
            id: "dashboard-audit",
            tab: "dashboard",
            label: "Audit Logs",
            icon: "shield",
            apply: () => {
              pendingScrollSelector = "#admin-sec-audit";
            },
          },
        ],
      },
      {
        groupId: "users",
        label: "Users",
        icon: "users",
        children: [
          {
            id: "users",
            tab: "users",
            label: "All Users",
            icon: "users",
            apply: () => {
              userFilterRole = "all";
              userFilterStatus = "all";
              showCreateUser = false;
              userPage = 1;
            },
          },
          {
            id: "users-pending",
            tab: "users",
            label: "Pending",
            icon: "shield",
            apply: () => {
              userFilterRole = "all";
              userFilterStatus = "pending_approval";
              showCreateUser = false;
              userPage = 1;
            },
          },
          {
            id: "users-students",
            tab: "users",
            label: "Students",
            icon: "users",
            apply: () => {
              userFilterRole = "student";
              userFilterStatus = "all";
              showCreateUser = false;
              userPage = 1;
            },
          },
          {
            id: "users-teachers",
            tab: "users",
            label: "Teachers",
            icon: "user",
            apply: () => {
              userFilterRole = "teacher";
              userFilterStatus = "all";
              showCreateUser = false;
              userPage = 1;
            },
          },
          {
            id: "users-create",
            tab: "users",
            label: "Add User",
            icon: "user",
            apply: () => {
              userFilterRole = "all";
              userFilterStatus = "all";
              showCreateUser = true;
              userPage = 1;
            },
          },
          {
            id: "courses",
            tab: "courses",
            label: "Courses",
            icon: "book",
            apply: () => {
              pendingScrollSelector = "";
            },
          },
          {
            id: "courses-subjects",
            tab: "courses",
            label: "Subjects",
            icon: "book",
            apply: () => {
              pendingScrollSelector = "#admin-sec-subjects";
            },
          },
        ],
      },
      {
        groupId: "finance",
        label: "Finance",
        icon: "wallet",
        children: [
          {
            id: "payments-all",
            tab: "payments",
            label: "All Payments",
            icon: "wallet",
            apply: () => {
              paymentFilterStatus = "all";
              paymentSection = "all";
            },
          },
          {
            id: "payments-pending",
            tab: "payments",
            label: "Pending Fees",
            icon: "check",
            apply: () => {
              paymentFilterStatus = "pending_verification";
              paymentSection = "table";
            },
          },
          {
            id: "payments-verified",
            tab: "payments",
            label: "Receipts",
            icon: "award",
            apply: () => {
              paymentFilterStatus = "verified";
              paymentSection = "table";
            },
          },
          {
            id: "payments-refunded",
            tab: "payments",
            label: "Refunds & Failed",
            icon: "wallet",
            apply: () => {
              paymentFilterStatus = "refunded_failed";
              paymentSection = "table";
            },
          },
          {
            id: "payments-coupons",
            tab: "payments",
            label: "Coupons",
            icon: "award",
            apply: () => {
              paymentFilterStatus = "all";
              paymentSection = "coupons";
            },
          },
        ],
      },
      {
        groupId: "cms",
        label: "CMS",
        icon: "megaphone",
        children: [
          {
            id: "cms-inquiries",
            tab: "cms",
            label: "Leads",
            icon: "megaphone",
            apply: () => {
              pendingScrollSelector = "#admin-sec-inquiries";
            },
          },
          {
            id: "cms-announcements",
            tab: "cms",
            label: "Banners",
            icon: "bell",
            apply: () => {
              pendingScrollSelector = "#admin-sec-announcements";
            },
          },
          {
            id: "cms-blog",
            tab: "cms",
            label: "Blogs",
            icon: "book",
            apply: () => {
              pendingScrollSelector = "#admin-sec-blog";
            },
          },
          {
            id: "cms-faqs",
            tab: "cms",
            label: "FAQs & Reviews",
            icon: "award",
            apply: () => {
              pendingScrollSelector = "#admin-sec-faqs";
            },
          },
        ],
      },
      {
        groupId: "ai-marketing",
        label: "AI & Marketing",
        icon: "bot",
        children: [
          {
            id: "chatbot",
            tab: "chatbot",
            label: "AI Chats",
            icon: "bot",
            apply: () => {
              chatFilterStatus = "all";
              pendingScrollSelector = "";
            },
          },
          {
            id: "chatbot-unresolved",
            tab: "chatbot",
            label: "Escalated Chats",
            icon: "bot",
            apply: () => {
              chatFilterStatus = "unresolved_all";
              pendingScrollSelector = "";
            },
          },
          {
            id: "chatbot-knowledge",
            tab: "chatbot",
            label: "Knowledge Base",
            icon: "upload",
            apply: () => {
              chatFilterStatus = "all";
              pendingScrollSelector = "#admin-sec-knowledge";
            },
          },
          {
            id: "marketing-create",
            tab: "marketing",
            label: "New Campaign",
            icon: "mail",
            apply: () => {
              pendingScrollSelector = "#admin-sec-mkt-create";
            },
          },
          {
            id: "marketing-campaigns",
            tab: "marketing",
            label: "Campaign Logs",
            icon: "mail",
            apply: () => {
              pendingScrollSelector = "#admin-sec-mkt-list";
            },
          },
          {
            id: "marketing-suppressions",
            tab: "marketing",
            label: "Email Blocklist",
            icon: "shield",
            apply: () => {
              pendingScrollSelector = "#admin-sec-mkt-supp";
            },
          },
        ],
      },
      {
        groupId: "settings",
        label: "Settings",
        icon: "settings",
        children: [
          {
            id: "backups",
            tab: "backups",
            label: "Backups",
            icon: "database",
            apply: () => {
              pendingScrollSelector = "#admin-sec-backups";
            },
          },
          {
            id: "backups-zip",
            tab: "backups",
            label: "Export Project",
            icon: "download",
            apply: () => {
              pendingScrollSelector = "#admin-sec-backups-zip";
            },
          },
          {
            id: "settings-general",
            tab: "settings",
            label: "Domain & Keys",
            icon: "settings",
            apply: () => {
              openSettingGroups = new Set(["general"]);
              pendingScrollSelector = '[data-setting-card="general"]';
            },
          },
          {
            id: "settings-ai",
            tab: "settings",
            label: "AI Configuration",
            icon: "bot",
            apply: () => {
              openSettingGroups = new Set(["ai"]);
              pendingScrollSelector = '[data-setting-card="ai"]';
            },
          },
          {
            id: "settings-email",
            tab: "settings",
            label: "Email Settings",
            icon: "mail",
            apply: () => {
              openSettingGroups = new Set(["email"]);
              pendingScrollSelector = '[data-setting-card="email"]';
            },
          },
          {
            id: "settings-sms",
            tab: "settings",
            label: "SMS Settings",
            icon: "bell",
            apply: () => {
              openSettingGroups = new Set(["sms"]);
              pendingScrollSelector = '[data-setting-card="sms"]';
            },
          },
          {
            id: "settings-payments",
            tab: "settings",
            label: "Payment Settings",
            icon: "wallet",
            apply: () => {
              openSettingGroups = new Set(["payments"]);
              pendingScrollSelector = '[data-setting-card="payments"]';
            },
          },
          {
            id: "settings-gate",
            tab: "settings",
            label: "Admin URL",
            icon: "shield",
            apply: () => {
              openSettingGroups = new Set(["admin-gate"]);
              pendingScrollSelector = '[data-setting-card="admin-gate"]';
            },
          },
          {
            id: "settings-readiness",
            tab: "settings",
            label: "System Status",
            icon: "shield",
            apply: () => {
              openSettingGroups = new Set(["readiness"]);
              pendingScrollSelector = '[data-setting-card="readiness"]';
            },
          },
        ],
      },
    ];

    const findNavMeta = (itemId) => {
      for (const entry of adminNavGroups) {
        if (!entry.children && entry.id === itemId) return { item: entry, groupId: null };
        if (entry.children) {
          const match = entry.children.find((c) => c.id === itemId);
          if (match) return { item: match, groupId: entry.groupId };
        }
      }
      return null;
    };

    const navigateToAdminItem = (itemId, customApply = null) => {
      pendingScrollSelector = "";
      const found = findNavMeta(itemId);
      if (found) {
        tab = found.item.tab;
        activeNavItemId = found.item.id;
        if (found.groupId) openNavGroups.add(found.groupId);
        if (typeof found.item.apply === "function") found.item.apply();
      } else {
        tab = itemId;
        activeNavItemId = itemId;
      }
      if (typeof customApply === "function") customApply();
      selectedUserDetail = null;
      selectedChatDetail = null;
      editingCourse = null;
      loadAndDraw();
    };

    async function loadAndDraw() {
      const [dash, usersRes, coursesRes, paymentsRes, inquiriesRes, cmsRes, chatsRes, knowledgeRes, mktRes, notifsRes, backupsRes, settingsRes, adminUrlRes, loginAttemptsRes] = await Promise.all([
        api(adminApiUrl("/dashboard")),
        api(adminApiUrl(`/users?role=${encodeURIComponent(userFilterRole)}&status=${encodeURIComponent(userFilterStatus)}&search=${encodeURIComponent(userSearch)}&page=${userPage}&pageSize=12`)),
        api(adminApiUrl("/courses")),
        api(adminApiUrl("/payments")),
        api(adminApiUrl("/inquiries")),
        api(adminApiUrl("/cms")),
        api(adminApiUrl(`/chatbot?status=${encodeURIComponent(chatFilterStatus)}&search=${encodeURIComponent(chatSearch)}&minRating=${chatMinRating}`)),
        api(adminApiUrl("/knowledge-docs")).catch(() => ({ docs: [] })),
        api(adminApiUrl("/marketing/overview")),
        api(adminApiUrl("/notifications")),
        api(adminApiUrl("/backups")),
        api(adminApiUrl("/settings")),
        api(adminApiUrl("/admin-url")).catch(() => ({})),
        api(adminApiUrl("/login-attempts")).catch(() => ({ attempts: [] })),
      ]);

      let bodyHtml = "";
      if (feedbackError) {
        bodyHtml += `<div class="portal-message portal-message--error">${escapeHtml(feedbackError)}</div>`;
        feedbackError = "";
      }
      if (feedbackMsg) {
        bodyHtml += `<div class="portal-message portal-message--success">${escapeHtml(feedbackMsg)}</div>`;
        feedbackMsg = "";
      }

      if (tab === "dashboard") {
        const c = dash.counts;
        const f = dash.feeSummary;
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="students">
              <div><strong>${c.totalStudents}</strong><span>Total Students</span><em class="portal-stat-cta">View students →</em></div>
              <div class="portal-stat-icon">${icon("users")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="teachers">
              <div><strong>${c.totalTeachers}</strong><span>Total Teachers</span><em class="portal-stat-cta">View teachers →</em></div>
              <div class="portal-stat-icon">${icon("user")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="approvals">
              <div><strong>${c.pendingApprovals}</strong><span>Pending Approvals</span><em class="portal-stat-cta">Review approvals →</em></div>
              <div class="portal-stat-icon">${icon("shield")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="courses">
              <div><strong>${c.totalCourses}</strong><span>Active Courses</span><em class="portal-stat-cta">Manage courses →</em></div>
              <div class="portal-stat-icon">${icon("book")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="admissions">
              <div><strong>${c.totalAdmissions}</strong><span>Confirmed Admissions</span><em class="portal-stat-cta">View admissions →</em></div>
              <div class="portal-stat-icon">${icon("award")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="inquiries">
              <div><strong>${c.newInquiries}</strong><span>New Website Inquiries</span><em class="portal-stat-cta">View inquiries →</em></div>
              <div class="portal-stat-icon">${icon("megaphone")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="fees">
              <div><strong>${formatINR(f.totalCollected)}</strong><span>Verified Fees (${formatINR(f.totalPending)} pending)</span><em class="portal-stat-cta">View fee payments →</em></div>
              <div class="portal-stat-icon">${icon("wallet")}</div>
            </button>
            <button type="button" class="portal-stat portal-stat--link" data-dash-jump="chats">
              <div><strong>${c.unresolvedChats}</strong><span>Unresolved Shreya Chats</span><em class="portal-stat-cta">Open chats →</em></div>
              <div class="portal-stat-icon">${icon("bot")}</div>
            </button>
          </div>
          <div class="portal-card portal-table-card" id="admin-sec-audit">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Recent Audit Activity</div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>Details</th><th>Timestamp</th></tr></thead>
                <tbody>
                  ${(dash.recentActivities || []).map((a) => `<tr><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.actor_name || "-")}</td><td>${escapeHtml(a.target_name || "-")}</td><td>${escapeHtml(a.details || "")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No activity logs yet.</td></tr>`}
                </tbody>
              </table>
            </div>
          </div>`;
      } else if (tab === "users") {
        if (selectedUserDetail) {
          const u = selectedUserDetail.user;
          const sp = selectedUserDetail.studentProfile || {};
          const tp = selectedUserDetail.teacherProfile || {};
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>${escapeHtml(u.full_name)}</h2><p>${escapeHtml(u.role)} · ${escapeHtml(u.email)} · ${escapeHtml(u.phone)}</p></div>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-users>← Back to Users</button>
              </div>
              <div class="portal-personal-grid" style="margin-bottom:16px;">
                <div class="portal-detail"><span>Verification Status</span><strong>${statusBadge(u.verification_status)}</strong></div>
                <div class="portal-detail"><span>Mobile OTP Verified</span><strong>${u.mobile_verified ? "Yes" : "No"}</strong></div>
                <div class="portal-detail"><span>Account Active</span><strong>${u.is_active ? "Yes" : "Disabled"}</strong></div>
              </div>
              <div class="portal-actions" style="margin-bottom:20px;">
                <button type="button" class="portal-button portal-button--small" data-user-act="approve" data-uid="${u.id}">Approve</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-user-act="activate" data-uid="${u.id}">Activate</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-user-act="suspend" data-uid="${u.id}">Suspend</button>
                <button type="button" class="portal-button portal-button--small portal-button--danger" data-user-act="reject" data-uid="${u.id}">Reject</button>
                ${["student", "teacher"].includes(u.role) ? `<button type="button" class="portal-button portal-button--small" data-impersonate-uid="${u.id}">Impersonate Panel</button>` : ""}
              </div>
              ${
                u.role === "teacher"
                  ? `<div class="portal-detail" style="margin-bottom:20px;padding:14px 16px;">
                      <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
                        <div>
                          <span>Teacher Resume / CV Status</span>
                          <div style="display:flex;align-items:center;gap:8px;margin-top:4px;">
                            ${statusBadge(tp.resume_status || "missing")}
                            <strong>${escapeHtml(tp.resume_filename || "No resume uploaded yet")}</strong>
                          </div>
                        </div>
                        ${
                          tp.resume_url
                            ? `<a href="${escAttr(adminApiUrl(`/users/${u.id}/resume`))}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${icon("download")} View / Download Resume</a>`
                            : ""
                        }
                      </div>
                      ${tp.resume_uploaded_at ? `<p class="portal-hint" style="margin-bottom:8px;">Uploaded: ${escapeHtml(tp.resume_uploaded_at)}${tp.resume_notes ? ` · Notes: ${escapeHtml(tp.resume_notes)}` : ""}</p>` : ""}
                      ${
                        tp.resume_url
                          ? `<div class="portal-actions">
                              <input type="text" placeholder="Optional review note" value="${escAttr(tp.resume_notes || "")}" data-resume-note-input style="min-height:34px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;min-width:220px;">
                              <button type="button" class="portal-button portal-button--small" data-resume-review="verified" data-uid="${u.id}">Verify Resume</button>
                              <button type="button" class="portal-button portal-button--small portal-button--danger" data-resume-review="rejected" data-uid="${u.id}">Request Re-upload</button>
                            </div>`
                          : `<p class="portal-hint" style="color:#b91c1c;">This teacher has not uploaded a valid resume yet and cannot be approved for dashboard access.</p>`
                      }
                    </div>`
                  : ""
              }
              <h3 class="portal-section-title">Edit Account &amp; Profile</h3>
              <form class="portal-form" data-edit-user-form="${u.id}" style="margin-bottom:20px;">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(u.full_name)}" required></div>
                  <div class="portal-field"><label>Email</label><input name="email" type="email" value="${escAttr(u.email)}" required></div>
                  <div class="portal-field"><label>Phone</label><input name="phone" value="${escAttr(u.phone)}" required></div>
                  ${
                    u.role === "student"
                      ? `<div class="portal-field"><label>Class / Level</label><input name="classLevel" value="${escAttr(sp.class_level || "")}"></div>
                         <div class="portal-field"><label>Board</label><input name="board" value="${escAttr(sp.board || "CBSE")}"></div>
                         <div class="portal-field"><label>Duration (months)</label><input name="courseDurationMonths" type="number" value="${Number(sp.course_duration_months || 12)}"></div>`
                      : u.role === "teacher"
                        ? `<div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                           <div class="portal-field"><label>Experience (years)</label><input name="experienceYears" type="number" value="${Number(tp.experience_years || 0)}"></div>`
                        : ""
                  }
                </div>
                <div><button type="submit" class="portal-button portal-button--small">Save Profile Changes</button></div>
              </form>
              <h3 class="portal-section-title">OTP Summary</h3>
              <div class="portal-table-scroll" style="margin-bottom:20px;"><table class="portal-table"><thead><tr><th>Purpose</th><th>Attempts</th><th>Consumed</th><th>Created</th></tr></thead><tbody>
                ${(selectedUserDetail.otpSummary || []).map((o) => `<tr><td>${escapeHtml(o.purpose)}</td><td>${o.attempts}</td><td>${o.consumed_at ? "Yes" : "Pending"}</td><td>${new Date(Number(o.created_at) * 1000).toLocaleString()}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No OTP logs.</td></tr>`}
              </tbody></table></div>
              <h3 class="portal-section-title">Account Audit History</h3>
              <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Action</th><th>Details</th><th>IP</th><th>Date</th></tr></thead><tbody>
                ${(selectedUserDetail.history || []).map((h) => `<tr><td>${escapeHtml(h.action)}</td><td>${escapeHtml(h.details)}</td><td>${escapeHtml(h.ip_address)}</td><td>${escapeHtml(h.created_at)}</td></tr>`).join("")}
              </tbody></table></div>
            </div>`;
        } else {
          const totalPages = Math.max(1, Math.ceil((usersRes.total || 0) / (usersRes.pageSize || 12)));
          bodyHtml += `
            <div class="portal-toolbar">
              <input type="search" data-admin-usearch value="${escAttr(userSearch)}" placeholder="Search name, email, phone...">
              <div class="portal-toolbar-actions">
                <select data-admin-urole style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Roles"], ["student", "Students"], ["teacher", "Teachers"], ["admin", "Admins"], ["super_admin", "Super Admins"]].map(([k, l]) => `<option value="${k}"${userFilterRole === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <select data-admin-ustatus style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Statuses"], ["pending_approval", "Pending Approval"], ["pending_otp", "Pending OTP"], ["approved", "Approved"], ["suspended", "Suspended"], ["rejected", "Rejected"]].map(([k, l]) => `<option value="${k}"${userFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <button type="button" class="portal-button portal-button--small" data-toggle-new-user>${showCreateUser ? "Close Form" : "+ Create User"}</button>
              </div>
            </div>
            ${
              showCreateUser
                ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                    <h3 class="portal-section-title">Create Approved Account (Student / Teacher / Admin)</h3>
                    <form class="portal-form" data-admin-create-user>
                      <div class="portal-form-grid">
                        <div class="portal-field"><label>Role</label><select name="role"><option value="student">Student</option><option value="teacher">Teacher</option>${session.user.role === "super_admin" ? `<option value="admin">Admin</option>` : ""}</select></div>
                        <div class="portal-field"><label>Full Name *</label><input name="fullName" required></div>
                        <div class="portal-field"><label>Email *</label><input name="email" type="email" required></div>
                        <div class="portal-field"><label>Phone *</label><input name="phone" required></div>
                        <div class="portal-field"><label>Password (min 8 chars) *</label><input name="password" type="password" minlength="8" required></div>
                        <div class="portal-field"><label>Class / Qualification</label><input name="extra" placeholder="Class 10 or M.Sc"></div>
                      </div>
                      <p class="portal-hint" style="margin-bottom:10px;">Note: Admin-created teachers without a resume on file will be prompted to upload their PDF/DOC/DOCX resume on first sign-in before entering the Teacher Dashboard.</p>
                      <button type="submit" class="portal-button portal-button--small">Create Approved User</button>
                    </form>
                  </div>`
                : ""
            }
            <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Name</th><th>Contact</th><th>Role</th><th>OTP</th><th>Resume</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${(usersRes.users || []).map((u) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(u.full_name)}</span><span class="portal-cell-sub">${escapeHtml(u.class_level || u.qualification || "")}</span></td>
                  <td>${escapeHtml(u.email)}<span class="portal-cell-sub">${escapeHtml(u.phone)}</span></td>
                  <td>${escapeHtml(u.role)}</td>
                  <td>${u.mobile_verified ? "Verified" : "Unverified"}</td>
                  <td>${u.role === "teacher" ? (u.has_resume ? `${statusBadge(u.resume_status || "submitted")} <span class="portal-cell-sub">${escapeHtml(u.resume_filename || "")}</span>` : statusBadge("missing")) : `<span class="portal-hint">—</span>`}</td>
                  <td>${statusBadge(u.verification_status)}</td>
                  <td>
                    <div class="portal-actions">
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-view-uid="${u.id}">Manage</button>
                      ${u.verification_status !== "approved" && u.role !== "super_admin" ? `<button type="button" class="portal-button portal-button--small" data-user-act="approve" data-uid="${u.id}">Approve</button>` : ""}
                      ${u.role === "teacher" && u.has_resume ? `<a href="${escAttr(adminApiUrl(`/users/${u.id}/resume`))}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">Resume</a>` : ""}
                      ${["student", "teacher"].includes(u.role) ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-impersonate-uid="${u.id}">Impersonate</button>` : ""}
                    </div>
                  </td>
                </tr>`).join("") || `<tr><td colspan="7" class="portal-empty">No users match the filter.</td></tr>`}
              </tbody>
            </table></div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-top:1px solid var(--pt-border);font-size:12px;">
              <span>Showing page ${userPage} of ${totalPages} (${usersRes.total || 0} total)</span>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage - 1}" ${userPage <= 1 ? "disabled" : ""}>Prev</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage + 1}" ${userPage >= totalPages ? "disabled" : ""}>Next</button>
              </div>
            </div></div>`;
        }
      } else if (tab === "courses") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">${editingCourse ? `Edit Course: ${escapeHtml(editingCourse.title)}` : "Create Course"}</h3>
            <form class="portal-form" ${editingCourse ? `data-edit-course-form="${editingCourse.id}"` : "data-new-course-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Title *</label><input name="title" required value="${escAttr(editingCourse?.title || "")}"></div>
                <div class="portal-field"><label>Category</label><select name="category">${["Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"].map((cat) => `<option${editingCourse?.category === cat ? " selected" : ""}>${cat}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Class / Level</label><input name="classRange" value="${escAttr(editingCourse?.class_range || "Classes 9–10")}"></div>
                <div class="portal-field"><label>Board / Track</label><input name="board" value="${escAttr(editingCourse?.board || "CBSE / UP Board")}"></div>
                <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="60" value="${editingCourse?.duration_months ?? 12}"></div>
                <div class="portal-field"><label>Monthly Fee (₹)</label><input name="monthlyFee" type="number" value="${editingCourse?.monthly_fee ?? 1400}" required></div>
                <div class="portal-field"><label>Yearly Fee (₹)</label><input name="yearlyFee" type="number" value="${editingCourse?.yearly_fee ?? 14300}" required></div>
                <div class="portal-field"><label>Assign Teacher</label><select name="teacherId"><option value="">Unassigned</option>${(coursesRes.teachers || []).map((t) => `<option value="${t.id}"${Number(editingCourse?.teacher_id) === Number(t.id) ? " selected" : ""}>${escapeHtml(t.full_name)}</option>`).join("")}</select></div>
              </div>
              <div class="portal-field"><label>Description</label><textarea name="description" rows="2">${escapeHtml(editingCourse?.description || "")}</textarea></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editingCourse ? "Update Course" : "Create Course"}</button>
                ${editingCourse ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-course>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Course</th><th>Category</th><th>Teacher</th><th>Monthly / Yearly</th><th>Students</th><th>Actions</th></tr></thead>
            <tbody>
              ${(coursesRes.courses || []).map((c) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(c.title)}</span><span class="portal-cell-sub">${escapeHtml(c.class_range)}</span></td>
                <td>${escapeHtml(c.category)}</td>
                <td>${escapeHtml(c.teacher_name || "Unassigned")}</td>
                <td>${formatINR(c.monthly_fee)} / ${formatINR(c.yearly_fee)}</td>
                <td>${c.active_students}</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-course="${c.id}">Edit</button>
                  <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-course="${c.id}">Delete</button>
                </div></td>
              </tr>`).join("")}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-profile" id="admin-sec-subjects">
            <h3 class="portal-section-title">Manage Subjects (${(coursesRes.subjects || []).length})</h3>
            <form class="portal-form" data-new-subject-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Subject Name *</label><input name="name" required placeholder="e.g. Organic Chemistry"></div>
                <div class="portal-field"><label>Subject Code *</label><input name="code" required placeholder="CHEM-12"></div>
                <div class="portal-field"><label>Class Level</label><input name="classLevel" value="Classes 11–12"></div>
                <div class="portal-field"><label>Description</label><input name="description" placeholder="Short syllabus overview"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Subject</button></div>
            </form>
            <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Subject</th><th>Code</th><th>Class</th><th>Action</th></tr></thead><tbody>
              ${(coursesRes.subjects || []).map((s) => `<tr><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.code)}</td><td>${escapeHtml(s.class_level)}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-subject="${s.id}">Delete</button></td></tr>`).join("")}
            </tbody></table></div>
          </div>`;
      } else if (tab === "payments") {
        const allPayments = paymentsRes.payments || [];
        const filteredPayments =
          paymentFilterStatus === "all"
            ? allPayments
            : paymentFilterStatus === "refunded_failed"
              ? allPayments.filter((p) => ["refunded", "failed"].includes(String(p.verification_status || "")))
              : allPayments.filter((p) => String(p.verification_status || "") === paymentFilterStatus);
        const couponsCardHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Discount Coupons (${(paymentsRes.coupons || []).length})</h3>
            <form class="portal-form" data-coupon-form style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Code *</label><input name="code" required placeholder="YUITOR15"></div>
                <div class="portal-field"><label>Type</label><select name="discountType"><option value="percent">Percentage (%)</option><option value="flat">Flat (₹)</option></select></div>
                <div class="portal-field"><label>Value *</label><input name="discountValue" type="number" required value="10"></div>
                <div class="portal-field"><label>Max Uses</label><input name="maxUses" type="number" value="100"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Coupon</button></div>
            </form>
            ${(paymentsRes.coupons || []).map((cp) => `<span class="portal-status" style="margin-right:6px;">${escapeHtml(cp.code)} (${cp.discount_type === "percent" ? cp.discount_value + "%" : formatINR(cp.discount_value)} · ${cp.used_count}/${cp.max_uses})</span>`).join("")}
          </div>`;
        const paymentsTableHtml = `
          <div class="portal-toolbar" style="margin-bottom:12px;">
            <strong style="font-size:15px;">Fee Payments (${filteredPayments.length})</strong>
            <div class="portal-toolbar-actions">
              <select data-payment-status-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                ${[
                  ["all", "All Payment Statuses"],
                  ["pending_verification", "Pending Verification"],
                  ["verified", "Verified"],
                  ["refunded_failed", "Refunds & Failed"],
                  ["failed", "Rejected / Failed"],
                  ["refunded", "Refunded"],
                ]
                  .map(([k, l]) => `<option value="${k}"${paymentFilterStatus === k ? " selected" : ""}>${l}</option>`)
                  .join("")}
              </select>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Amount</th><th>Method / Ref</th><th>Status</th><th>Receipt</th><th>Actions</th></tr></thead>
            <tbody>
              ${filteredPayments.map((p) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(p.student_name)}</span><span class="portal-cell-sub">${escapeHtml(p.student_phone)}</span></td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)} ${p.gateway_payment_id ? "· " + escapeHtml(p.gateway_payment_id) : ""}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td>${escapeHtml(p.receipt_number || "-")}</td>
                <td><div class="portal-actions">
                  ${p.verification_status === "pending_verification" ? `<button type="button" class="portal-button portal-button--small" data-pay-verify="${p.id}" data-dec="verify">Verify</button><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-verify="${p.id}" data-dec="fail">Reject</button>` : ""}
                  ${p.verification_status === "verified" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-refund="${p.id}">Refund</button>` : ""}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="7" class="portal-empty">No payments match this filter.</td></tr>`}
            </tbody>
          </table></div></div>`;
        bodyHtml += paymentSection === "coupons" ? couponsCardHtml + paymentsTableHtml : paymentsTableHtml + couponsCardHtml;
      } else if (tab === "cms") {
        bodyHtml += `
          <div class="portal-card portal-table-card" id="admin-sec-inquiries" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Website Inquiries (${(inquiriesRes.inquiries || []).length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Name</th><th>Phone</th><th>Course</th><th>Message</th><th>Status</th><th>Update / Delete</th></tr></thead>
              <tbody>
                ${(inquiriesRes.inquiries || []).map((q) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(q.name)}</span><span class="portal-cell-sub">${escapeHtml(q.email)}</span></td>
                  <td>${escapeHtml(q.phone)}</td>
                  <td>${escapeHtml(q.class_or_course)}</td>
                  <td><span class="portal-cell-message">${escapeHtml(q.message)}</span></td>
                  <td>${statusBadge(q.status)}</td>
                  <td><div class="portal-actions">
                    <select data-inq-status="${q.id}" style="min-height:32px;border:1px solid var(--pt-border);border-radius:8px;padding:2px 6px;">
                      ${["new", "contacted", "admitted", "closed"].map((st) => `<option value="${st}"${q.status === st ? " selected" : ""}>${st}</option>`).join("")}
                    </select>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-inq="${q.id}">Delete</button>
                  </div></td>
                </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No inquiries yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>

          <div class="portal-form-grid" id="admin-sec-announcements" style="margin-bottom:16px;">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Publish Notice / Announcement</h3>
              <form class="portal-form" data-ann-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Audience</label><select name="audience"><option value="all">All Users</option><option value="students">Students</option><option value="teachers">Teachers</option><option value="public">Public</option></select></div>
                <div class="portal-field"><label>Message</label><textarea name="body" required></textarea></div>
                <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;font-weight:600;color:var(--pt-muted);cursor:pointer;">
                  <input type="checkbox" name="sendEmail" value="1">
                  <span>Also send announcement email to matching active members (when SMTP is configured)</span>
                </label>
                <button type="submit" class="portal-button portal-button--small">Publish Notice</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.announcements || []).map((a) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)}</strong><span>${escapeHtml(a.audience)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-ann="${a.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Homepage / Promo Banners</h3>
              <form class="portal-form" data-banner-form>
                <div class="portal-field"><label>Headline</label><input name="title" required></div>
                <div class="portal-field"><label>Subtitle</label><input name="subtitle"></div>
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Button Label</label><input name="ctaLabel" value="Apply for Admission"></div>
                  <div class="portal-field"><label>Link</label><input name="ctaHref" value="/admission"></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Add Banner</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.banners || []).map((b) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(b.title)}</strong><span>${escapeHtml(b.cta_href)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-banner="${b.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>

          <div class="portal-form-grid">
            <div class="portal-card portal-profile" id="admin-sec-blog">
              <h3 class="portal-section-title">Blog Posts (${(cmsRes.blogPosts || []).length})</h3>
              <form class="portal-form" data-blog-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Category</label><input name="category" value="Study Tips"></div>
                <div class="portal-field"><label>Excerpt</label><input name="excerpt"></div>
                <div class="portal-field"><label>Article Content</label><textarea name="content" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Publish Article</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.blogPosts || []).map((p) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(p.title)}</strong><span>${escapeHtml(p.category)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-blog="${p.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile" id="admin-sec-faqs">
              <h3 class="portal-section-title">FAQs &amp; Testimonials</h3>
              <form class="portal-form" data-faq-form style="margin-bottom:14px;">
                <div class="portal-field"><label>FAQ Question</label><input name="question" required></div>
                <div class="portal-field"><label>Answer</label><textarea name="answer" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add FAQ</button>
              </form>
              ${(cmsRes.faqs || []).map((f) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(f.question)}</strong></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-faq="${f.id}">Delete</button></div>`).join("")}
              <form class="portal-form" data-test-form style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Author Name</label><input name="authorName" required></div>
                  <div class="portal-field"><label>Role / Batch</label><input name="authorRole" required placeholder="Class 12 Student"></div>
                </div>
                <div class="portal-field"><label>Outcome Metric</label><input name="outcomeMetric" placeholder="95% in Boards"></div>
                <div class="portal-field"><label>Quote</label><textarea name="quote" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add Testimonial</button>
              </form>
              <div style="margin-top:10px;">
                ${(cmsRes.testimonials || []).map((t) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(t.author_name)}</strong><span>${escapeHtml(t.outcome_metric)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-test="${t.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>`;
      } else if (tab === "chatbot") {
        if (selectedChatDetail) {
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>Shreya Transcript</h2><p>${escapeHtml(selectedChatDetail.conversation.visitor_name || "Visitor")} · ${statusBadge(selectedChatDetail.conversation.status)}</p></div>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-back>← All Conversations</button>
              </div>
              <div style="display:grid;gap:10px;margin-bottom:16px;">
                ${(selectedChatDetail.messages || []).map((m) => `<div class="portal-detail"><span>${escapeHtml(m.sender)} · ${escapeHtml(m.created_at)}</span><strong style="font-weight:500;">${escapeHtml(m.message)}</strong></div>`).join("")}
              </div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="resolved">Mark Resolved</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="escalated">Escalate to Team</button>
              </div>
            </div>`;
        } else {
          bodyHtml += `
            <div class="portal-toolbar">
              <input type="search" data-chat-search value="${escAttr(chatSearch)}" placeholder="Search transcripts, visitor name/phone...">
              <div class="portal-toolbar-actions">
                <select data-chat-status-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Statuses"], ["unresolved_all", "Unresolved & Escalated"], ["active", "Active"], ["unresolved", "Unresolved Only"], ["escalated", "Escalated Only"], ["resolved", "Resolved"]].map(([k, l]) => `<option value="${k}"${chatFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <select data-chat-rating-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  <option value="0"${chatMinRating === 0 ? " selected" : ""}>Any Rating</option>
                  ${[1, 2, 3, 4, 5].map((r) => `<option value="${r}"${chatMinRating === r ? " selected" : ""}>${r}+ Stars</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Visitor</th><th>Last Message</th><th>Status</th><th>Rating</th><th>View</th></tr></thead>
              <tbody>
                ${(chatsRes.conversations || []).map((c) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(c.visitor_name || "Anonymous Visitor")}</span><span class="portal-cell-sub">${escapeHtml(c.visitor_phone || c.visitor_email || c.visitor_id)}</span></td>
                  <td><span class="portal-cell-message">${escapeHtml(c.last_message || "")}</span></td>
                  <td>${statusBadge(c.status)}</td>
                  <td>${c.rating ? `${c.rating}/5` : "-"}</td>
                  <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-open-chat="${escAttr(c.id)}">Transcript</button></td>
                </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No Shreya chatbot conversations match.</td></tr>`}
              </tbody>
            </table></div></div>
            <div class="portal-card portal-profile" id="admin-sec-knowledge">
              <h3 class="portal-section-title">Shreya AI Knowledge Base Documents (PDF / TXT / MD)</h3>
              <p class="portal-hint" style="margin-bottom:12px;">Upload course brochures, fee sheets, syllabus PDFs, or FAQ notes. Shreya automatically indexes extracted text to ground Gemini &amp; fallback responses.</p>
              <form class="portal-form" data-knowledge-upload-form style="margin-bottom:14px;">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Document Title *</label><input name="title" required placeholder="e.g. Class 10 Board Syllabus 2026"></div>
                  <div class="portal-field"><label>Document File (.pdf, .txt, .md · max 5 MB) *</label><input name="document" type="file" accept=".pdf,.txt,.md,application/pdf,text/plain,text/markdown" required></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload &amp; Index Document</button>
              </form>
              <div class="portal-table-scroll"><table class="portal-table">
                <thead><tr><th>Document Title</th><th>Filename</th><th>Indexed Text</th><th>Uploaded</th><th>Action</th></tr></thead>
                <tbody>
                  ${(knowledgeRes.docs || []).map((d) => `<tr><td><strong>${escapeHtml(d.title)}</strong></td><td>${escapeHtml(d.filename)}</td><td>${Number(d.char_count || 0).toLocaleString("en-IN")} chars</td><td>${escapeHtml(d.created_at)}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-kdoc="${d.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No knowledge documents indexed yet.</td></tr>`}
                </tbody>
              </table></div>
            </div>`;
        }
      } else if (tab === "marketing") {
        const mktSum = mktRes.summary || { totalCampaigns: 0, totalEligible: 0, totalSent: 0, totalFailed: 0 };
        const recipientsList = [...(mktRes.students || []).map((u) => ({ ...u, role: "Student" })), ...(mktRes.teachers || []).map((u) => ({ ...u, role: "Teacher" }))];
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${mktSum.totalCampaigns}</strong><span>Campaigns</span></div><div class="portal-stat-icon">${icon("mail")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalEligible}</strong><span>Queued Recipients</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalSent}</strong><span>Emails Sent</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalFailed}</strong><span>Failed / Pending SMTP</span></div><div class="portal-stat-icon">${icon("megaphone")}</div></div>
          </div>
          <div class="portal-message">Sender: <strong>${escapeHtml(mktRes.senderEmail)}</strong> · Reply-To: <strong>${escapeHtml(mktRes.replyToEmail)}</strong> · SMTP Status: <strong>${mktRes.smtpConfigured ? "Configured" : "Not Configured (configure SMTP_* in .env before sending live emails)"}</strong>${mktSum.openClickTrackingNote ? ` · ${escapeHtml(mktSum.openClickTrackingNote)}` : ""}</div>
          <div class="portal-card portal-profile" id="admin-sec-mkt-create" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create &amp; Send Email Campaign</h3>
            <form class="portal-form" data-mkt-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Campaign Name *</label><input name="name" required placeholder="e.g. Board Exam Batch Alert"></div>
                <div class="portal-field"><label>Load Reusable Template (${(mktRes.templates || []).length})</label>
                  <select data-mkt-tmpl><option value="">Custom Email</option>${(mktRes.templates || []).map((t) => `<option value="${t.id}">${escapeHtml(t.name)} (${escapeHtml(t.category)})</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Segment Audience</label>
                  <select name="audienceGroup">
                    <option value="all_students">All Eligible Students</option>
                    <option value="all_teachers">All Eligible Teachers</option>
                    <option value="all_opted_in">All Students &amp; Teachers</option>
                    <option value="recently_registered">Recently Registered (30 days)</option>
                  </select>
                </div>
                <div class="portal-field"><label>Account Status Filter</label>
                  <select name="accountStatus"><option value="all">Any</option><option value="approved">Approved Only</option><option value="pending_approval">Pending Approval</option></select>
                </div>
                <div class="portal-field"><label>Class Filter (Optional)</label><input name="classLevel" placeholder="e.g. Class 10"></div>
                <div class="portal-field"><label>Subject Keyword (Optional)</label><input name="subjectFilter" placeholder="e.g. Mathematics"></div>
                <div class="portal-field"><label>Course Filter</label><select name="courseId"><option value="">Any Course</option>${(mktRes.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Registered After</label><input name="registeredAfter" type="date"></div>
                <div class="portal-field"><label>Email Subject *</label><input name="subject" required></div>
                <div class="portal-field"><label>Preview Text (Optional)</label><input name="previewText" placeholder="Inbox snippet line..."></div>
                <div class="portal-field"><label>CTA Button Label (Optional)</label><input name="ctaLabel" placeholder="e.g. Apply for Admission"></div>
                <div class="portal-field"><label>CTA Link URL (Optional)</label><input name="ctaUrl" placeholder="https://yuitor.com/admission"></div>
                <div class="portal-field"><label>Send Mode</label><select name="sendMode"><option value="draft">Save Draft</option><option value="immediate">Send Immediately</option><option value="scheduled">Schedule</option></select></div>
                <div class="portal-field"><label>Schedule Date &amp; Time (if Scheduled)</label><input name="scheduledAt" type="datetime-local"></div>
                <div class="portal-field"><label>Optional Attachment (PDF / Image, max 5 MB)</label><input name="attachmentFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field">
                <label>Or Select Specific Recipients (Optional — leave unchecked to use segment filters)</label>
                <div class="portal-email-recipient-list">
                  ${recipientsList.map((u) => `<label class="portal-email-recipient"><input type="checkbox" name="selectedUid" value="${u.id}"><span><strong>${escapeHtml(u.full_name)}</strong> (${u.role})<br><span style="color:var(--pt-muted);">${escapeHtml(u.email)}</span></span></label>`).join("") || `<span class="portal-hint">No contacts found.</span>`}
                </div>
              </div>
              <div class="portal-field"><label>HTML Body (supports {{name}}) *</label><textarea name="htmlBody" rows="5" required><p>Dear {{name}},</p><p>Admissions are open at Yuitor Smart Classes, Muradnagar.</p></textarea></div>
              <div class="portal-message" data-mkt-preview hidden></div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-mkt-check>Preview Eligible Recipients</button>
                <button type="submit" class="portal-button portal-button--small">Create Campaign</button>
              </div>
            </form>
            <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
              <h4 style="margin:0 0 8px;font-size:13px;">Send Test Email</h4>
              <div class="portal-actions">
                <input type="email" data-test-email placeholder="recipient@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-test-send-btn>Send Test</button>
              </div>
              <div class="portal-message" data-test-fb hidden style="margin-top:8px;"></div>
            </div>
          </div>
          <div class="portal-card portal-table-card" id="admin-sec-mkt-list" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Campaign</th><th>Recipients</th><th>Sent / Failed</th><th>Status</th><th>Controls</th></tr></thead>
            <tbody>
              ${(mktRes.campaigns || []).map((cp) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(cp.name)}</span><span class="portal-cell-sub">${escapeHtml(cp.subject)}</span></td>
                <td>${cp.total_recipients} eligible (${cp.excluded_count} excluded)</td>
                <td>${cp.sent_count} sent / ${cp.failed_count} failed</td>
                <td>${statusBadge(cp.status)}</td>
                <td><div class="portal-actions">
                  ${cp.status !== "cancelled" && cp.status !== "completed" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-act="${cp.id}" data-act="pause">Pause</button><button type="button" class="portal-button portal-button--small" data-camp-act="${cp.id}" data-act="process_now">Process</button>` : ""}
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-deliveries="${cp.id}">Logs</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No campaigns yet.</td></tr>`}
            </tbody>
          </table></div></div>
          ${
            selectedCampaignDeliveries
              ? `<div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:12px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Delivery Logs</div><div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Recipient</th><th>Status</th><th>Error / ID</th><th>Timestamp</th></tr></thead><tbody>
                ${selectedCampaignDeliveries.map((d) => `<tr><td>${escapeHtml(d.recipient_name)} (${escapeHtml(d.recipient_email)})</td><td>${statusBadge(d.status)}</td><td>${escapeHtml(d.error_message || d.provider_message_id || "-")}</td><td>${escapeHtml(d.sent_at || d.created_at || "")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No deliveries queued.</td></tr>`}
              </tbody></table></div></div>`
              : ""
          }
          <div class="portal-card portal-profile" id="admin-sec-mkt-supp">
            <h3 class="portal-section-title">Email Suppression List (${(mktRes.suppressions || []).length})</h3>
            <form class="portal-form" data-supp-form style="margin-bottom:10px;">
              <div class="portal-actions">
                <input name="email" type="email" required placeholder="optout@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <select name="reason" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 8px;"><option value="unsubscribed">Unsubscribed</option><option value="bounced">Bounced</option><option value="complaint">Complaint</option></select>
                <button type="submit" class="portal-button portal-button--small portal-button--quiet">Add Suppression</button>
              </div>
            </form>
            <p class="portal-hint">${(mktRes.suppressions || []).map((s) => `${escapeHtml(s.email)} (${escapeHtml(s.reason)})`).join(" · ") || "No suppressed addresses."}</p>
          </div>`;
      } else if (tab === "backups") {
        bodyHtml += `
          <div class="portal-card portal-profile" id="admin-sec-backups" style="margin-bottom:16px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
            <div>
              <h3 class="portal-section-title" style="margin:0;">SQLite Database Backups</h3>
              <p class="portal-hint">Atomic VACUUM INTO snapshots stored safely inside private /backups (verified via PRAGMA quick_check).</p>
            </div>
            <div class="portal-actions" id="admin-sec-backups-zip">
              <a href="${escAttr(adminApiUrl("/project-zip"))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Final Project ZIP</a>
              <button type="button" class="portal-button portal-button--small" data-create-backup>${icon("database")} Create Backup Now</button>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Filename</th><th>Size</th><th>Integrity</th><th>Created</th><th>Download</th></tr></thead>
            <tbody>
              ${(backupsRes.backups || []).map((b) => `<tr><td><strong>${escapeHtml(b.filename)}</strong></td><td>${(b.sizeBytes / 1024).toFixed(1)} KB</td><td>${statusBadge(b.integrityOk ? "verified" : "failed")}</td><td>${escapeHtml(b.createdAt)}</td><td><a href="${escAttr(adminApiUrl(`/backups/${encodeURIComponent(b.filename)}`))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download .db</a></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No backups recorded yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Backup &amp; Recovery Procedure</h3>
            <div class="portal-personal-grid" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));">
              <div class="portal-detail"><span>1. Database Snapshot</span><strong>Atomic VACUUM INTO snapshots in /backups (non-public). Download verified .db archives off-server daily.</strong></div>
              <div class="portal-detail"><span>2. Uploaded Documents</span><strong>Archive /uploads/resumes and /uploads/knowledge alongside the DB backup (never served via public static root).</strong></div>
              <div class="portal-detail"><span>3. Configuration Backup</span><strong>Keep .env secrets backed up in your hosting secret manager; non-secret &amp; admin keys also persist in system_settings.</strong></div>
              <div class="portal-detail"><span>4. Recovery Steps</span><strong>Stop Node process, replace /data/yuitor.db with verified backup .db, restore /uploads, restart server, verify /api/health.</strong></div>
            </div>
          </div>`;
      } else if (tab === "profile") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:14px;">
              <div>
                <h3 class="portal-section-title" style="margin:0 0 4px;">Administrator Profile</h3>
                <p class="portal-hint" style="margin:0;">Manage your administrator account details and dashboard profile photo.</p>
              </div>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-admin-back-dash>← Back to Dashboard</button>
            </div>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Full Name</span><strong>${escapeHtml(session.user.full_name || "Administrator")}</strong></div>
              <div class="portal-detail"><span>Role</span><strong>${escapeHtml(session.user.role || "admin")}</strong></div>
              <div class="portal-detail"><span>Email Address</span><strong>${escapeHtml(session.user.email || "-")}</strong></div>
              <div class="portal-detail"><span>Mobile Number</span><strong>${escapeHtml(session.user.phone || "-")}</strong></div>
            </div>
          </div>
          ${renderProfilePhotoCard(session.user)}`;
      } else if (tab === "settings") {
        const sList = settingsRes.settings || [];
        const rdy = settingsRes.readiness || {};
        const intStatuses = settingsRes.integrationStatuses || {};
        const badgeForIntegration = (groupId, configured) => {
          const map = { ai: "gemini", email: "smtp", sms: "fast2sms", payments: "razorpay" };
          const key = map[groupId];
          if (!key) {
            return configured
              ? `<span class="portal-status portal-status--paid" data-group-status="${escAttr(groupId)}">Configured</span>`
              : `<span class="portal-status portal-status--pending" data-group-status="${escAttr(groupId)}">Default / Review</span>`;
          }
          if (!configured) {
            return `<span class="portal-status portal-status--pending" data-group-status="${escAttr(groupId)}">Not Configured</span>`;
          }
          const st = intStatuses[key];
          if (st?.tested && st.connected) {
            return `<span class="portal-status portal-status--paid" data-group-status="${escAttr(groupId)}">Connected</span>`;
          }
          if (st?.tested && !st.connected) {
            return `<span class="portal-status portal-status--overdue" data-group-status="${escAttr(groupId)}">Connection Failed</span>`;
          }
          return `<span class="portal-status portal-status--pending" data-group-status="${escAttr(groupId)}">Configured (Untested)</span>`;
        };
        const groups = [
          {
            id: "general",
            title: "Website Domain & Security Keys",
            subtitle: "APP_URL, SESSION_SECRET, IP allow-list, and installer setup key.",
            configured: Boolean(rdy.appUrl && rdy.sessionSecret),
          },
          {
            id: "ai",
            title: "Shreya AI Assistant (Gemini API)",
            subtitle: "GEMINI_API_KEY & model for live Gemini AI replies + knowledge grounding.",
            configured: Boolean(rdy.geminiAi),
          },
          {
            id: "email",
            title: "Email & SMTP Configuration",
            subtitle: "SMTP host, credentials, and department sender/reply-to emails.",
            configured: Boolean(rdy.smtpMail),
          },
          {
            id: "sms",
            title: "Mobile SMS OTP Gateway (Fast2SMS)",
            subtitle: "FAST2SMS_API_KEY and route settings for mobile OTP delivery.",
            configured: Boolean(rdy.fast2sms),
          },
          {
            id: "payments",
            title: `Online Payments (Razorpay${rdy.razorpayMode === "live" ? " · Live Mode" : rdy.razorpayMode === "sandbox" ? " · Sandbox Mode" : ""})`,
            subtitle: "Razorpay Key ID, Key Secret, and Webhook verification settings.",
            configured: Boolean(rdy.razorpay),
          },
        ];

        const renderSettingField = (item) => {
          const sourceLabel =
            item.source === "admin"
              ? "Saved in Admin"
              : item.source === "env"
                ? "From Server .env"
                : item.source === "default"
                  ? "Default"
                  : "Not Set";
          const sourceTone = item.isConfigured ? "approved" : "pending";
          const inputHtml =
            item.inputType === "boolean"
              ? `<select name="cfg__${escAttr(item.key)}">
                   <option value="false" ${String(item.value || "false") !== "true" ? "selected" : ""}>false (STARTTLS / Port 587)</option>
                   <option value="true" ${String(item.value) === "true" ? "selected" : ""}>true (SSL/TLS / Port 465)</option>
                 </select>`
              : item.key === "FAST2SMS_ROUTE"
                ? `<select name="cfg__FAST2SMS_ROUTE">
                     <option value="q" ${String(item.value || "q") === "q" ? "selected" : ""}>q (Quick SMS Route)</option>
                     <option value="otp" ${String(item.value || "q") === "otp" ? "selected" : ""}>otp (OTP Route)</option>
                     <option value="dlt" ${String(item.value || "q") === "dlt" ? "selected" : ""}>dlt (TRAI DLT Approved Route)</option>
                   </select>`
                : `<input
                     name="cfg__${escAttr(item.key)}"
                     type="${item.isSecret ? "password" : item.inputType === "number" ? "number" : item.inputType === "email" ? "email" : item.inputType === "url" ? "url" : "text"}"
                     value="${item.isSecret ? "" : escAttr(item.value || "")}"
                     ${item.key === "GEMINI_MODEL" ? 'list="gemini-model-presets"' : ""}
                     placeholder="${item.isSecret && item.isConfigured ? `Saved (${item.maskedValue}) — leave blank to keep` : escAttr(item.placeholder || "")}"
                     autocomplete="new-password"
                   >`;
          const secretToggleBtn = item.isSecret
            ? `<button type="button" class="portal-button portal-button--small portal-button--quiet portal-setting-toggle" data-toggle-secret="${escAttr(item.key)}" aria-label="Show ${escAttr(item.key)}">Show</button>`
            : "";
          const extraBtn =
            item.key === "SESSION_SECRET"
              ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-gen-secret>Generate 64-Char Secret</button>`
              : "";
          const clearBox = item.hasDbOverride
            ? `<label class="portal-clear-check"><input type="checkbox" name="clr__${escAttr(item.key)}" value="1"> Clear saved Admin override (revert to .env / unset)</label>`
            : "";
          return `
            <div class="portal-setting-row">
              <div class="portal-setting-head">
                <strong style="font-size:13px;color:var(--pt-text);">${escapeHtml(item.label)}</strong>
                <span class="portal-status portal-status--${sourceTone}">${escapeHtml(sourceLabel)}</span>
              </div>
              <p class="portal-hint" style="margin:0 0 8px;">${escapeHtml(item.description)}</p>
              <div class="portal-field" style="margin:0;">
                <div class="portal-setting-input-row">${inputHtml}${secretToggleBtn}${extraBtn}</div>
              </div>
              ${clearBox}
            </div>`;
        };

        const renderGroupTester = (groupId) => {
          if (groupId === "ai") {
            return `<div class="portal-setting-tester">
              <div class="portal-setting-input-row">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-gemini-test-btn>Verify / Test Saved Gemini AI</button>
              </div>
              <p class="portal-hint" style="margin:6px 0 0;">Save your GEMINI_API_KEY first, then click to test a live Gemini response.</p>
              <div class="portal-message" data-gemini-test-fb hidden style="margin-top:8px;"></div>
            </div>`;
          }
          if (groupId === "email") {
            return `<div class="portal-setting-tester">
              <div class="portal-setting-input-row">
                <input type="email" data-smtp-test-email placeholder="Optional test recipient email (e.g. you@example.com)">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-smtp-test-btn>Verify / Test Saved SMTP</button>
              </div>
              <p class="portal-hint" style="margin:6px 0 0;">Save your SMTP changes first, then click Verify / Test Saved SMTP to test live delivery.</p>
              <div class="portal-message" data-smtp-test-fb hidden style="margin-top:8px;"></div>
            </div>`;
          }
          if (groupId === "sms") {
            return `<div class="portal-setting-tester">
              <div class="portal-setting-input-row">
                <input type="tel" data-sms-test-phone placeholder="Optional 10-digit mobile for test OTP (blank = wallet check)">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-sms-test-btn>Verify / Test Saved Fast2SMS</button>
              </div>
              <p class="portal-hint" style="margin:6px 0 0;">Save your Fast2SMS API key first, then test key wallet verification or send a test OTP SMS.</p>
              <div class="portal-message" data-sms-test-fb hidden style="margin-top:8px;"></div>
            </div>`;
          }
          if (groupId === "payments") {
            return `<div class="portal-setting-tester">
              <div class="portal-setting-input-row">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-razorpay-test-btn>Verify Saved Razorpay Keys</button>
              </div>
              <p class="portal-hint" style="margin:6px 0 0;">Save your Razorpay Key ID &amp; Key Secret first, then verify live API connectivity.</p>
              <div class="portal-message" data-razorpay-test-fb hidden style="margin-top:8px;"></div>
            </div>`;
          }
          return "";
        };

        const gateOpen = openSettingGroups.has("admin-gate");
        const readinessOpen = openSettingGroups.has("readiness");
        const describeLiveStatus = (key, configured, defaultUnset) => {
          if (!configured) return defaultUnset;
          const st = intStatuses[key];
          if (st?.tested && st.connected) return `Connected (${st.testedAt ? st.testedAt.slice(0, 19).replace("T", " ") : "Verified"})`;
          if (st?.tested && !st.connected) return `Connection Failed: ${st.message || "Re-test"}`;
          return "Configured — Untested";
        };

        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title" style="margin-bottom:4px;">Settings &amp; API Configurations</h3>
            <p class="portal-hint">Click any setting or API integration name below to open and enter/update its configuration.</p>
          </div>
          <datalist id="gemini-model-presets">
            <option value="gemini-2.5-flash">
            <option value="gemini-2.5-pro">
            <option value="gemini-3.1-pro-preview">
          </datalist>
          <div class="portal-settings-accordion">
            ${groups
              .map((g) => {
                const items = sList.filter((it) => it.category === g.id);
                const isOpen = openSettingGroups.has(g.id);
                return `
                  <div class="portal-card portal-settings-group ${isOpen ? "is-open" : ""}" data-setting-card="${escAttr(g.id)}">
                    <button type="button" class="portal-settings-trigger" data-toggle-setting-card="${escAttr(g.id)}" aria-expanded="${isOpen ? "true" : "false"}">
                      <div class="portal-settings-trigger-title">
                        <strong>${escapeHtml(g.title)}</strong>
                        <span>${escapeHtml(g.subtitle)}</span>
                      </div>
                      <div class="portal-settings-trigger-meta">
                        ${badgeForIntegration(g.id, g.configured)}
                        <span class="portal-settings-chevron">${icon(isOpen ? "chevronDown" : "chevronRight")}</span>
                      </div>
                    </button>
                    <div class="portal-settings-panel" data-setting-panel="${escAttr(g.id)}" ${isOpen ? "" : "hidden"}>
                      <form class="portal-form" data-admin-group-settings-form="${escAttr(g.id)}">
                        <div class="portal-form-grid">
                          ${items.map(renderSettingField).join("")}
                        </div>
                        <div class="portal-actions" style="justify-content:space-between;align-items:center;margin-top:6px;">
                          <p class="portal-hint" style="margin:0;">Secrets are masked after saving and applied live without restarting Node.js.</p>
                          <button type="submit" class="portal-button portal-button--small" data-save-group-btn="${escAttr(g.id)}">Save Settings</button>
                        </div>
                      </form>
                      ${renderGroupTester(g.id)}
                    </div>
                  </div>`;
              })
              .join("")}

            <div class="portal-card portal-settings-group ${gateOpen ? "is-open" : ""}" data-setting-card="admin-gate">
              <button type="button" class="portal-settings-trigger" data-toggle-setting-card="admin-gate" aria-expanded="${gateOpen ? "true" : "false"}">
                <div class="portal-settings-trigger-title">
                  <strong>Secret Admin Gate URL &amp; Slug Rotation</strong>
                  <span>Manage hidden admin login URL path and IP allow-list access.</span>
                </div>
                <div class="portal-settings-trigger-meta">
                  <span class="portal-status portal-status--paid">Active</span>
                  <span class="portal-settings-chevron">${icon(gateOpen ? "chevronDown" : "chevronRight")}</span>
                </div>
              </button>
              <div class="portal-settings-panel" data-setting-panel="admin-gate" ${gateOpen ? "" : "hidden"}>
                <p class="portal-hint" style="margin-bottom:12px;">The admin panel is hidden at a secret gate path. Changing the slug immediately disables the old URL and redirects you to the new secret path.</p>
                <div class="portal-personal-grid" style="margin-bottom:16px;">
                  <div class="portal-detail"><span>Current Secret Admin URL</span><strong data-testid="current-admin-gate-url">${escapeHtml(adminUrlRes.fullAdminGateUrl || GATE_BASE + "/")}</strong></div>
                  <div class="portal-detail"><span>Current Slug</span><strong data-testid="current-admin-slug">${escapeHtml(adminUrlRes.adminPath || GATE_BASE.replace(/^\//, ""))}</strong></div>
                  <div class="portal-detail"><span>Admin IP Allow-List</span><strong>${escapeHtml(adminUrlRes.ipAllowlist || "Any IP (Unrestricted)")}</strong></div>
                </div>
                <form class="portal-form" data-change-admin-path-form>
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>New Secret Admin Slug *</label><input name="adminPath" required pattern="[a-z0-9][a-z0-9\\-]{7,62}[a-z0-9]" placeholder="e.g. yt-ctrl-88k4-gate" value="${escAttr(adminUrlRes.adminPath || "")}"></div>
                    <div class="portal-field"><label>Confirm Current Admin Password *</label>${passwordFieldHtml("currentPassword", "required")}</div>
                  </div>
                  <div class="portal-actions">
                    <button type="submit" class="portal-button portal-button--small" data-testid="button-rotate-admin-slug">Update Secret Admin URL</button>
                  </div>
                </form>
              </div>
            </div>

            <div class="portal-card portal-settings-group ${readinessOpen ? "is-open" : ""}" data-setting-card="readiness">
              <button type="button" class="portal-settings-trigger" data-toggle-setting-card="readiness" aria-expanded="${readinessOpen ? "true" : "false"}">
                <div class="portal-settings-trigger-title">
                  <strong>Security &amp; Integration Status Overview</strong>
                  <span>View live status of keys, integrations, and recent admin login security logs.</span>
                </div>
                <div class="portal-settings-trigger-meta">
                  <span class="portal-status">Overview</span>
                  <span class="portal-settings-chevron">${icon(readinessOpen ? "chevronDown" : "chevronRight")}</span>
                </div>
              </button>
              <div class="portal-settings-panel" data-setting-panel="readiness" ${readinessOpen ? "" : "hidden"}>
                <div class="portal-personal-grid" style="margin-bottom:16px;">
                  <div class="portal-detail"><span>Public Domain (APP_URL)</span><strong>${rdy.appUrl ? "Configured" : "Using Default"}</strong></div>
                  <div class="portal-detail"><span>Session Signing Secret</span><strong>${rdy.sessionSecret ? "Custom Secret Active" : "Auto-Derived Key"}</strong></div>
                  <div class="portal-detail"><span>Installer Setup Key</span><strong>${rdy.setupKeyProtected ? "Protected by YU_ADMIN_SETUP_KEY" : "Standard (Single-Run Lock)"}</strong></div>
                  <div class="portal-detail"><span>Shreya Gemini AI (${escapeHtml(rdy.geminiModel || "gemini-2.5-flash")})</span><strong>${escapeHtml(describeLiveStatus("gemini", rdy.geminiAi, "Not Configured"))}</strong></div>
                  <div class="portal-detail"><span>SMTP Mail Server</span><strong>${escapeHtml(describeLiveStatus("smtp", rdy.smtpMail, "Not Configured"))}</strong></div>
                  <div class="portal-detail"><span>Fast2SMS Mobile OTP</span><strong>${escapeHtml(describeLiveStatus("fast2sms", rdy.fast2sms, "Not Configured"))}</strong></div>
                  <div class="portal-detail"><span>Razorpay Checkout (${rdy.razorpayMode === "live" ? "Live Mode" : rdy.razorpayMode === "sandbox" ? "Sandbox Mode" : "Unconfigured"})</span><strong>${escapeHtml(describeLiveStatus("razorpay", rdy.razorpay, "Not Configured"))}</strong></div>
                  <div class="portal-detail"><span>Razorpay Webhook Secret</span><strong>${rdy.razorpayWebhook ? "Webhook Signature Verified" : "Not Configured (Optional)"}</strong></div>
                </div>
                <div class="portal-table-scroll"><table class="portal-table">
                  <thead><tr><th>Identifier</th><th>IP Address</th><th>Outcome</th><th>Reason</th><th>Timestamp</th></tr></thead>
                  <tbody>
                    ${(loginAttemptsRes.attempts || []).map((a) => `<tr><td>${escapeHtml(a.identifier || "-")}</td><td>${escapeHtml(a.ip_address)}</td><td>${statusBadge(a.outcome === "success" ? "approved" : "rejected")}</td><td>${escapeHtml(a.reason || "-")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No admin login attempts logged yet.</td></tr>`}
                  </tbody>
                </table></div>
              </div>
            </div>
          </div>`;
      }

      const main = renderWorkspace({
        session,
        portalTitle: "Admin Console",
        navGroups: adminNavGroups,
        openNavGroups,
        activeNavItemId,
        activeTab: tab,
        isAdmin: true,
        onTabChange: (next) => navigateToAdminItem(next),
        onSelectNavItem: (itemId) => navigateToAdminItem(itemId),
        onToggleNavGroup: (gid, isOpen) => {
          if (isOpen) openNavGroups.add(gid);
          else openNavGroups.delete(gid);
        },
        notifications: notifsRes.notifications || [],
        onReadNotifs: async () => {
          await api(adminApiUrl("/notifications/read-all"), { method: "POST" });
          loadAndDraw();
        },
        onReadSingleNotif: async (notif) => {
          await api(adminApiUrl(`/notifications/${encodeURIComponent(notif.id)}/read`), { method: "POST" });
        },
        bodyHtml,
      });

      if (pendingScrollSelector) {
        const scrollTarget = main.querySelector(pendingScrollSelector);
        pendingScrollSelector = "";
        if (scrollTarget) {
          requestAnimationFrame(() => {
            scrollTarget.scrollIntoView({ behavior: "smooth", block: "start" });
          });
        }
      }

      // Dashboard Overview clickable stat cards
      main.querySelectorAll("[data-dash-jump]").forEach((card) => {
        card.addEventListener("click", () => {
          const target = card.getAttribute("data-dash-jump");
          if (target === "students") {
            navigateToAdminItem("users-students");
          } else if (target === "teachers") {
            navigateToAdminItem("users-teachers");
          } else if (target === "approvals") {
            navigateToAdminItem("users-pending");
          } else if (target === "courses") {
            navigateToAdminItem("courses");
          } else if (target === "admissions") {
            navigateToAdminItem("users-students", () => {
              userFilterStatus = "approved";
              userPage = 1;
            });
          } else if (target === "inquiries") {
            navigateToAdminItem("cms-inquiries");
          } else if (target === "fees") {
            navigateToAdminItem("payments-verified");
          } else if (target === "chats") {
            navigateToAdminItem("chatbot-unresolved");
          }
        });
      });

      // Users handlers
      main.querySelector("[data-admin-usearch]")?.addEventListener("change", (e) => {
        userSearch = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-urole]")?.addEventListener("change", (e) => {
        userFilterRole = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-ustatus]")?.addEventListener("change", (e) => {
        userFilterStatus = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelectorAll("[data-upage]").forEach((b) => {
        b.addEventListener("click", () => {
          userPage = Math.max(1, Number(b.getAttribute("data-upage")));
          loadAndDraw();
        });
      });
      main.querySelector("[data-toggle-new-user]")?.addEventListener("click", () => {
        showCreateUser = !showCreateUser;
        loadAndDraw();
      });
      const runAdminAction = async (fn, successMsg = "") => {
        try {
          await fn();
          if (successMsg) feedbackMsg = successMsg;
        } catch (err) {
          feedbackError = err?.message || "Action failed. Please check inputs and try again.";
        }
        loadAndDraw();
      };

      main.querySelector("[data-admin-create-user]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const role = fd.get("role");
        await runAdminAction(async () => {
          await api(adminApiUrl("/users"), {
            method: "POST",
            body: {
              role,
              fullName: fd.get("fullName"),
              email: fd.get("email"),
              phone: fd.get("phone"),
              password: fd.get("password"),
              classLevel: role === "student" ? fd.get("extra") || "Class 10" : undefined,
              qualification: role === "teacher" ? fd.get("extra") || "" : undefined,
            },
          });
          showCreateUser = false;
        }, "User created & approved successfully.");
      });
      main.querySelectorAll("[data-view-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            selectedUserDetail = await api(adminApiUrl(`/users/${b.getAttribute("data-view-uid")}`));
          });
        });
      });
      main.querySelector("[data-back-users]")?.addEventListener("click", () => {
        selectedUserDetail = null;
        loadAndDraw();
      });
      main.querySelector("[data-edit-user-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const uid = e.target.getAttribute("data-edit-user-form");
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          await api(adminApiUrl(`/users/${uid}`), {
            method: "PATCH",
            body: {
              fullName: fd.get("fullName"),
              email: fd.get("email"),
              phone: fd.get("phone"),
              studentProfile: fd.has("classLevel")
                ? { classLevel: fd.get("classLevel"), board: fd.get("board"), courseDurationMonths: Number(fd.get("courseDurationMonths") || 12) }
                : undefined,
              teacherProfile: fd.has("qualification")
                ? { qualification: fd.get("qualification"), experienceYears: Number(fd.get("experienceYears") || 0) }
                : undefined,
            },
          });
          selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
        }, "Account changes saved.");
      });
      main.querySelectorAll("[data-user-act]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-uid");
          const action = b.getAttribute("data-user-act");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/users/${uid}/status`), { method: "POST", body: { action, reason: "" } });
            if (selectedUserDetail) selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
          }, `Account ${action}d successfully.`);
        });
      });
      main.querySelectorAll("[data-resume-review]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-uid");
          const status = b.getAttribute("data-resume-review");
          const notes = main.querySelector("[data-resume-note-input]")?.value || "";
          await runAdminAction(async () => {
            await api(adminApiUrl(`/users/${uid}/resume-review`), { method: "POST", body: { status, notes } });
            if (selectedUserDetail) selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
          }, status === "verified" ? "Teacher resume marked verified." : "Resume re-upload requested.");
        });
      });
      main.querySelectorAll("[data-impersonate-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = Number(b.getAttribute("data-impersonate-uid"));
          const reason = await openPromptModal({
            title: "Start Troubleshooting Session",
            label: "Reason for impersonation (min 4 characters)",
            defaultValue: "Support check",
            minLength: 4,
          });
          if (reason.trim().length < 4) return;
          try {
            const res = await api(adminApiUrl("/impersonate"), { method: "POST", body: { userId: uid, reason } });
            window.location.assign(res.redirectTo || "/student/");
          } catch (err) {
            feedbackError = err.message;
            loadAndDraw();
          }
        });
      });

      // Courses & Subjects
      main.querySelector("[data-new-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/courses"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Course created.");
      });
      main.querySelector("[data-edit-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        const cid = formEl.getAttribute("data-edit-course-form");
        await runAdminAction(async () => {
          await api(adminApiUrl(`/courses/${cid}`), { method: "PATCH", body: Object.fromEntries(new FormData(formEl).entries()) });
          editingCourse = null;
        }, "Course updated.");
      });
      main.querySelector("[data-cancel-edit-course]")?.addEventListener("click", () => {
        editingCourse = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-course]").forEach((b) => {
        b.addEventListener("click", () => {
          const cid = Number(b.getAttribute("data-edit-course"));
          editingCourse = (coursesRes.courses || []).find((c) => Number(c.id) === cid) || null;
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-del-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/courses/${b.getAttribute("data-del-course")}`), { method: "DELETE" });
          }, "Course deleted.");
        });
      });
      main.querySelector("[data-new-subject-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/subjects"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Subject added.");
      });
      main.querySelectorAll("[data-del-subject]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/subjects/${b.getAttribute("data-del-subject")}`), { method: "DELETE" });
          }, "Subject removed.");
        });
      });

      // Payments
      main.querySelector("[data-payment-status-filter]")?.addEventListener("change", (e) => {
        paymentFilterStatus = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-coupon-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/coupons"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Discount coupon created.");
      });
      main.querySelectorAll("[data-pay-verify]").forEach((b) => {
        b.addEventListener("click", async () => {
          const dec = b.getAttribute("data-dec");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/payments/${b.getAttribute("data-pay-verify")}/verify`), { method: "POST", body: { decision: dec } });
          }, dec === "verify" ? "Payment verified & receipt generated." : "Payment marked rejected.");
        });
      });
      main.querySelectorAll("[data-pay-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/payments/${b.getAttribute("data-pay-refund")}/refund`), { method: "POST" });
          }, "Payment refund processed.");
        });
      });

      // Inquiries & CMS
      main.querySelectorAll("[data-inq-status]").forEach((sel) => {
        sel.addEventListener("change", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/inquiries/${sel.getAttribute("data-inq-status")}`), { method: "PATCH", body: { status: sel.value } });
          }, "Inquiry status updated.");
        });
      });
      main.querySelectorAll("[data-del-inq]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/inquiries/${b.getAttribute("data-del-inq")}`), { method: "DELETE" });
          }, "Inquiry deleted.");
        });
      });
      main.querySelector("[data-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        const fd = new FormData(formEl);
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/cms/announcements"), {
            method: "POST",
            body: {
              title: fd.get("title"),
              audience: fd.get("audience"),
              body: fd.get("body"),
              sendEmail: Boolean(fd.get("sendEmail")),
            },
          });
          feedbackMsg = res.emailedCount > 0 ? `Notice published & emailed to ${res.emailedCount} member(s).` : "Notice published.";
        });
      });
      main.querySelectorAll("[data-del-ann]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/announcements/${b.getAttribute("data-del-ann")}`), { method: "DELETE" });
          }, "Notice removed.");
        });
      });
      main.querySelector("[data-banner-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/banners"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Banner added.");
      });
      main.querySelectorAll("[data-del-banner]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/banners/${b.getAttribute("data-del-banner")}`), { method: "DELETE" });
          }, "Banner removed.");
        });
      });
      main.querySelector("[data-blog-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/blog"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Blog article published.");
      });
      main.querySelectorAll("[data-del-blog]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/blog/${b.getAttribute("data-del-blog")}`), { method: "DELETE" });
          }, "Article removed.");
        });
      });
      main.querySelector("[data-faq-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/faqs"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "FAQ added.");
      });
      main.querySelectorAll("[data-del-faq]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/faqs/${b.getAttribute("data-del-faq")}`), { method: "DELETE" });
          }, "FAQ removed.");
        });
      });
      main.querySelector("[data-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/testimonials"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Testimonial added.");
      });
      main.querySelectorAll("[data-del-test]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/testimonials/${b.getAttribute("data-del-test")}`), { method: "DELETE" });
          }, "Testimonial removed.");
        });
      });

      // Chatbot handlers
      main.querySelector("[data-chat-search]")?.addEventListener("change", (e) => {
        chatSearch = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-status-filter]")?.addEventListener("change", (e) => {
        chatFilterStatus = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-rating-filter]")?.addEventListener("change", (e) => {
        chatMinRating = Number(e.target.value || 0);
        loadAndDraw();
      });
      main.querySelectorAll("[data-open-chat]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            selectedChatDetail = await api(adminApiUrl(`/chatbot/${encodeURIComponent(b.getAttribute("data-open-chat"))}`));
          });
        });
      });
      main.querySelector("[data-chat-back]")?.addEventListener("click", () => {
        selectedChatDetail = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-chat-status]").forEach((b) => {
        b.addEventListener("click", async () => {
          const cid = b.getAttribute("data-chat-status");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/chatbot/${encodeURIComponent(cid)}`), { method: "PATCH", body: { status: b.getAttribute("data-st") } });
            selectedChatDetail = await api(adminApiUrl(`/chatbot/${encodeURIComponent(cid)}`));
          }, "Conversation status updated.");
        });
      });
      main.querySelector("[data-knowledge-upload-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          const upRes = await api(adminApiUrl("/knowledge-docs"), { method: "POST", body: fd });
          feedbackMsg = `Document "${upRes.doc?.title || "Knowledge Doc"}" indexed (${upRes.doc?.char_count || 0} chars) for Shreya AI.`;
        });
      });
      main.querySelectorAll("[data-del-kdoc]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/knowledge-docs/${b.getAttribute("data-del-kdoc")}`), { method: "DELETE" });
          }, "Knowledge document removed.");
        });
      });

      // Marketing handlers
      const mktForm = main.querySelector("[data-mkt-form]");
      const buildMktFilters = () => {
        const fd = new FormData(mktForm);
        const selectedUserIds = Array.from(mktForm.querySelectorAll('input[name="selectedUid"]:checked')).map((el) => Number(el.value));
        return {
          audienceGroup: fd.get("audienceGroup"),
          accountStatus: fd.get("accountStatus"),
          classLevel: String(fd.get("classLevel") || "").trim() || undefined,
          subject: String(fd.get("subjectFilter") || "").trim() || undefined,
          courseId: fd.get("courseId") ? Number(fd.get("courseId")) : undefined,
          registeredAfter: fd.get("registeredAfter") || undefined,
          selectedUserIds: selectedUserIds.length ? selectedUserIds : undefined,
        };
      };
      if (mktForm) {
        main.querySelector("[data-mkt-tmpl]")?.addEventListener("change", (e) => {
          const t = (mktRes.templates || []).find((x) => String(x.id) === e.target.value);
          if (t) {
            mktForm.querySelector('[name="subject"]').value = t.subject;
            mktForm.querySelector('[name="previewText"]').value = t.preview_text || "";
            mktForm.querySelector('[name="htmlBody"]').value = t.html_body;
          }
        });
        main.querySelector("[data-mkt-check]")?.addEventListener("click", async () => {
          const box = main.querySelector("[data-mkt-preview]");
          try {
            const pv = await api(adminApiUrl("/marketing/preview-recipients"), { method: "POST", body: { filters: buildMktFilters() } });
            box.className = "portal-message portal-message--success";
            box.textContent = `Eligible recipients: ${pv.eligibleCount} · Excluded (opted-out/suppressed/unverified): ${pv.excludedCount}`;
            box.hidden = false;
          } catch (err) {
            box.className = "portal-message portal-message--error";
            box.textContent = err.message || "Unable to preview recipients.";
            box.hidden = false;
          }
        });
        mktForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(mktForm);
          await runAdminAction(async () => {
            let attachmentUrl = "";
            const attFile = fd.get("attachmentFile");
            if (attFile instanceof File && attFile.size > 0) {
              const up = await uploadFile(attFile);
              attachmentUrl = up.url;
            }
            await api(adminApiUrl("/marketing/campaigns"), {
              method: "POST",
              body: {
                name: fd.get("name"),
                templateId: main.querySelector("[data-mkt-tmpl]")?.value || undefined,
                subject: fd.get("subject"),
                previewText: fd.get("previewText"),
                ctaLabel: fd.get("ctaLabel"),
                ctaUrl: fd.get("ctaUrl"),
                scheduledAt: fd.get("scheduledAt") || undefined,
                attachmentUrl,
                htmlBody: fd.get("htmlBody"),
                sendMode: fd.get("sendMode"),
                filters: buildMktFilters(),
              },
            });
          }, "Campaign created.");
        });
        main.querySelector("[data-test-send-btn]")?.addEventListener("click", async () => {
          const to = main.querySelector("[data-test-email]")?.value || "";
          const fb = main.querySelector("[data-test-fb]");
          try {
            const res = await api(adminApiUrl("/marketing/test-send"), {
              method: "POST",
              body: {
                to,
                subject: mktForm.querySelector('[name="subject"]').value,
                previewText: mktForm.querySelector('[name="previewText"]').value,
                ctaLabel: mktForm.querySelector('[name="ctaLabel"]').value,
                ctaUrl: mktForm.querySelector('[name="ctaUrl"]').value,
                htmlBody: mktForm.querySelector('[name="htmlBody"]').value,
              },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = `Test email sent (ID: ${res.messageId || "ok"}).`;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        main.querySelectorAll("[data-camp-act]").forEach((b) => {
          b.addEventListener("click", async () => {
            await runAdminAction(async () => {
              await api(adminApiUrl(`/marketing/campaigns/${b.getAttribute("data-camp-act")}/action`), {
                method: "POST",
                body: { action: b.getAttribute("data-act") },
              });
            }, "Campaign updated.");
          });
        });
        main.querySelectorAll("[data-camp-deliveries]").forEach((b) => {
          b.addEventListener("click", async () => {
            await runAdminAction(async () => {
              const res = await api(adminApiUrl(`/marketing/campaigns/${b.getAttribute("data-camp-deliveries")}/deliveries`));
              selectedCampaignDeliveries = res.deliveries || [];
            });
          });
        });
        main.querySelector("[data-supp-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const formEl = e.target;
          await runAdminAction(async () => {
            await api(adminApiUrl("/marketing/suppressions"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
          }, "Email added to suppression list.");
        });
      }

      // Backups
      main.querySelector("[data-create-backup]")?.addEventListener("click", async () => {
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/backups"), { method: "POST" });
          feedbackMsg = `Backup created: ${res.backup?.filename}`;
        });
      });

      // Secret Admin Slug change (password-confirmed)
      bindPasswordToggles(main);
      main.querySelector("[data-change-admin-path-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const fd = new FormData(form);
        const btn = form.querySelector("[data-testid='button-rotate-admin-slug']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/settings/admin-path"), {
            method: "POST",
            body: {
              adminPath: String(fd.get("adminPath") || "").trim(),
              currentPassword: String(fd.get("currentPassword") || ""),
            },
          });
          window.location.assign(res.redirectTo || `/${res.adminPath}/`);
        } catch (err) {
          feedbackError = err?.message || "Unable to update Secret Admin Gate URL.";
          loadAndDraw();
        }
      });

      // Settings & API handlers (click name to expand & configure)
      main.querySelectorAll("[data-toggle-setting-card]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const gid = btn.getAttribute("data-toggle-setting-card");
          if (!gid) return;
          const card = main.querySelector(`[data-setting-card="${CSS.escape(gid)}"]`);
          const panel = main.querySelector(`[data-setting-panel="${CSS.escape(gid)}"]`);
          const willOpen = panel ? panel.hidden : !openSettingGroups.has(gid);
          if (willOpen) openSettingGroups.add(gid);
          else openSettingGroups.delete(gid);
          if (panel) panel.hidden = !willOpen;
          card?.classList.toggle("is-open", willOpen);
          btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
          const chev = btn.querySelector(".portal-settings-chevron");
          if (chev) chev.innerHTML = icon(willOpen ? "chevronDown" : "chevronRight");
        });
      });
      main.querySelectorAll("[data-toggle-secret]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const key = btn.getAttribute("data-toggle-secret");
          const input = main.querySelector(`input[name="cfg__${CSS.escape(key || "")}"]`);
          if (!input) return;
          const reveal = input.type === "password";
          input.type = reveal ? "text" : "password";
          btn.textContent = reveal ? "Hide" : "Show";
          btn.setAttribute("aria-label", `${reveal ? "Hide" : "Show"} ${key}`);
        });
      });
      main.querySelector("[data-gen-secret]")?.addEventListener("click", () => {
        const input = main.querySelector('input[name="cfg__SESSION_SECRET"]');
        if (!input) return;
        const bytes = new Uint8Array(32);
        crypto.getRandomValues(bytes);
        const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
        input.type = "text";
        input.value = hex;
        const toggleBtn = main.querySelector('[data-toggle-secret="SESSION_SECRET"]');
        if (toggleBtn) toggleBtn.textContent = "Hide";
      });
      main.querySelectorAll("[data-admin-group-settings-form]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const gid = form.getAttribute("data-admin-group-settings-form");
          const btn = form.querySelector("[data-save-group-btn]");
          const values = {};
          const clearKeys = [];
          const fd = new FormData(form);
          for (const [name, val] of fd.entries()) {
            if (name.startsWith("cfg__")) {
              values[name.slice(5)] = String(val);
            } else if (name.startsWith("clr__")) {
              clearKeys.push(name.slice(5));
            }
          }
          if (btn) btn.disabled = true;
          if (gid) openSettingGroups.add(gid);
          try {
            const res = await api(adminApiUrl("/settings"), { method: "PUT", body: { values, clearKeys } });
            const count = (res.updatedKeys?.length || 0) + (res.clearedKeys?.length || 0);
            feedbackMsg = count
              ? `Settings saved cleanly (${count} change${count === 1 ? "" : "s"} applied live).`
              : "No changes detected — existing settings preserved.";
            loadAndDraw();
          } catch (err) {
            feedbackError = err.message || "Unable to save API settings.";
            loadAndDraw();
          }
        });
      });

      const updateGroupBadge = (groupId, intKey, ok) => {
        const badge = main.querySelector(`[data-group-status="${CSS.escape(groupId)}"]`);
        if (!badge) return;
        badge.className = `portal-status portal-status--${ok ? "paid" : "overdue"}`;
        badge.textContent = ok ? "Connected" : "Connection Failed";
        if (settingsRes.integrationStatuses && intKey) {
          settingsRes.integrationStatuses[intKey] = {
            tested: true,
            connected: ok,
            message: "",
            testedAt: new Date().toISOString(),
          };
        }
      };

      const wireTester = (btnSel, fbSel, endpoint, bodyBuilder, defaultOk, groupId, intKey) => {
        main.querySelector(btnSel)?.addEventListener("click", async () => {
          const fb = main.querySelector(fbSel);
          const btn = main.querySelector(btnSel);
          if (btn) btn.disabled = true;
          if (fb) fb.hidden = true;
          try {
            const res = await api(endpoint, { method: "POST", body: bodyBuilder ? bodyBuilder() : {} });
            updateGroupBadge(groupId, intKey, true);
            if (res.integrationStatuses) settingsRes.integrationStatuses = res.integrationStatuses;
            if (fb) {
              fb.className = "portal-message portal-message--success";
              fb.textContent = res.message || defaultOk;
              fb.hidden = false;
            }
          } catch (err) {
            updateGroupBadge(groupId, intKey, false);
            if (err?.data?.integrationStatuses) settingsRes.integrationStatuses = err.data.integrationStatuses;
            if (fb) {
              fb.className = "portal-message portal-message--error";
              fb.textContent = err.message || "Verification failed.";
              fb.hidden = false;
            }
          } finally {
            if (btn) btn.disabled = false;
          }
        });
      };

      wireTester(
        "[data-smtp-test-btn]",
        "[data-smtp-test-fb]",
        adminApiUrl("/settings/test-smtp"),
        () => ({ testRecipient: main.querySelector("[data-smtp-test-email]")?.value || "" }),
        "SMTP verified.",
        "email",
        "smtp"
      );
      wireTester(
        "[data-gemini-test-btn]",
        "[data-gemini-test-fb]",
        adminApiUrl("/settings/test-gemini"),
        null,
        "Gemini AI verified.",
        "ai",
        "gemini"
      );
      wireTester(
        "[data-sms-test-btn]",
        "[data-sms-test-fb]",
        adminApiUrl("/settings/test-sms"),
        () => ({ testPhone: main.querySelector("[data-sms-test-phone]")?.value || "" }),
        "Fast2SMS verified.",
        "sms",
        "fast2sms"
      );
      wireTester(
        "[data-razorpay-test-btn]",
        "[data-razorpay-test-fb]",
        adminApiUrl("/settings/test-razorpay"),
        null,
        "Razorpay credentials verified.",
        "payments",
        "razorpay"
      );

      main.querySelector("[data-admin-back-dash]")?.addEventListener("click", () => {
        navigateToAdminItem("dashboard");
      });
      bindProfilePhotoCard(main, {
        session,
        onNotice: (type, msg) => {
          if (type === "error") feedbackError = msg;
          else feedbackMsg = msg;
        },
        onRefresh: loadAndDraw,
      });
    }
    await loadAndDraw();
  }

  // ==================== STUDENT PANEL ====================
  async function renderStudentPanel(session) {
    if (session.user.verification_status !== "approved") {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Account Status</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let activeLessons = null;
    let studentNotice = "";
    let studentNoticeType = "success";

    async function loadAndDraw() {
      const [dash, boot, payCfg] = await Promise.all([
        api("/api/student/dashboard"),
        api("/api/public/bootstrap"),
        api("/api/payments/config").catch(() => ({ razorpayEnabled: false, keyId: "" })),
      ]);
      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["courses", "Courses & Learning", "book"],
        ["fees", "Fees & Receipts", "wallet"],
        ["assignments", "Assignments & Quizzes", "award"],
        ["attendance", "Attendance Record", "calendar"],
        ["support", "Profile & Support", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        const p = dash.profile || {};
        const totalLearningMins = (dash.enrollments || []).reduce((acc, e) => acc + Number(e.learning_minutes || 0), 0);
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${(dash.enrollments || []).length}</strong><span>Enrolled Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.assignments || []).length}</strong><span>Assignments</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.attendance || []).filter((a) => a.status === "present").length}</strong><span>Present Days</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${totalLearningMins} min</strong><span>Learning Time</span></div><div class="portal-stat-icon">${icon("dashboard")}</div></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Student Profile</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Class &amp; Board</span><strong>${escapeHtml(p.class_level || "Student")} · ${escapeHtml(p.board || "CBSE")}</strong></div>
              <div class="portal-detail"><span>Admission Date</span><strong>${escapeHtml(p.admission_date || "Pending assignment")}</strong></div>
              <div class="portal-detail"><span>Course Duration</span><strong>${Number(p.course_duration_months || 12)} months</strong></div>
              <div class="portal-detail"><span>Enrollment Status</span><strong>${statusBadge(p.enrollment_status || "active")}</strong></div>
            </div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Upcoming Classes</h3>
            ${(dash.upcomingClasses || []).map((c) => { const mUrl = safeHref(c.meeting_link); return `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(c.scheduled_date)} · ${escapeHtml(c.start_time)}–${escapeHtml(c.end_time)} (${escapeHtml(c.mode)})</span><strong>${escapeHtml(c.title)} · ${escapeHtml(c.course_title)}</strong>${mUrl ? `<div><a href="${escAttr(mUrl)}" target="_blank" rel="noopener noreferrer">Join Online Class</a></div>` : ""}</div>`; }).join("") || `<p class="portal-hint">No upcoming classes scheduled right now.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Announcements</h3>
            ${(dash.announcements || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(a.created_at)}</span><strong>${escapeHtml(a.title)}</strong><div>${escapeHtml(a.body)}</div></div>`).join("") || `<p class="portal-hint">No recent announcements.</p>`}
          </div>`;
      } else if (tab === "courses") {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">My Enrolled Courses</h3>
            ${(dash.enrollments || []).map((e) => `
              <div class="portal-detail" style="margin-bottom:10px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
                <div>
                  <strong>${escapeHtml(e.title)} (${e.progress_percent || 0}% complete)</strong>
                  <span>Status: ${escapeHtml(e.is_expired ? "expired" : e.status)}${e.expires_at ? " · Valid until " + escapeHtml(e.expires_at) : ""}${e.certificate_code ? " · Certificate: " + escapeHtml(e.certificate_code) : ""}</span>
                </div>
                <div class="portal-actions">
                  ${["active", "completed"].includes(e.status) && !e.is_expired ? `<button type="button" class="portal-button portal-button--small" data-open-course="${e.course_id}">Open Lessons</button>` : statusBadge(e.is_expired ? "expired" : e.status)}
                  ${e.certificate_code ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-cert="${escAttr(JSON.stringify({ code: e.certificate_code, student: session.user.full_name, course: e.title }))}">Certificate</button>` : ""}
                </div>
              </div>`).join("") || `<p class="portal-hint">No enrolled courses yet. Enroll below.</p>`}
          </div>
          ${
            activeLessons
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
              <h3 class="portal-section-title">Course Lessons</h3>
              ${(activeLessons.lessons || []).map((l) => { const matUrl = safeHref(l.material_url); return `
                <div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.duration_minutes} mins · ${escapeHtml(l.content)}</span>${matUrl ? `<div><a href="${escAttr(matUrl)}" target="_blank" rel="noopener noreferrer">Open Study Material</a></div>` : ""}</div>
                  ${l.completed ? statusBadge("completed") : `<button type="button" class="portal-button portal-button--small" data-complete-lesson="${l.id}">Mark Complete</button>`}
                </div>`; }).join("")}
            </div>`
              : ""
          }
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Enroll in a Course</h3>
            <form class="portal-form" data-enroll-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Plan</label><select name="plan"><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div>
                <div class="portal-field"><label>Payment Method</label><select name="paymentMethod"><option value="upi">UPI / Desk Transfer</option><option value="cash">Centre Cash Desk</option><option value="gateway">${payCfg.razorpayEnabled ? "Online Gateway (Razorpay Instant)" : "Online Gateway (Desk Fallback)"}</option></select></div>
                <div class="portal-field"><label>UTR / Reference No.</label><input name="utrReference" placeholder="UTR or desk receipt ref"></div>
                <div class="portal-field"><label>Coupon Code (Optional)</label><input name="couponCode" placeholder="e.g. YUITOR10"></div>
              </div>
              <p class="portal-hint" data-enroll-mode-hint style="margin-bottom:8px;">${payCfg.razorpayEnabled ? "Razorpay Online Gateway is active for instant receipt generation, or choose UPI/Cash Desk." : "Gateway keys are not set yet — enrollments save cleanly as Pending Verification for desk confirmation."}</p>
              <div class="portal-message" data-enroll-fb hidden></div>
              <button type="submit" class="portal-button portal-button--small">Submit Enrollment</button>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Rate an Enrolled Course</h3>
            <form class="portal-form" data-review-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Rating</label><select name="rating"><option value="5">5 - Excellent</option><option value="4">4 - Good</option><option value="3">3 - Average</option><option value="2">2 - Fair</option><option value="1">1 - Needs Improvement</option></select></div>
              </div>
              <div class="portal-field"><label>Review</label><textarea name="comment" required placeholder="Share your learning experience..."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Submit Review</button>
            </form>
          </div>`;
      } else if (tab === "fees") {
        const totalNetFee = (dash.feeRecords || []).reduce((acc, f) => acc + Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0)), 0);
        const totalPaidFee = (dash.feeRecords || []).reduce((acc, f) => acc + Number(f.paid_amount || 0), 0);
        const pendingFee = Math.max(0, totalNetFee - totalPaidFee);
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${formatINR(totalNetFee)}</strong><span>Total Net Fee</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(totalPaidFee)}</strong><span>Paid Amount</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(pendingFee)}</strong><span>Pending Balance</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Invoice</th><th>Course</th><th>Total</th><th>Paid</th><th>Due Date</th><th>Status</th></tr></thead>
            <tbody>
              ${(dash.feeRecords || []).map((f) => `<tr><td>${escapeHtml(f.invoice_number)}</td><td>${escapeHtml(f.course_title)}</td><td>${formatINR(f.total_amount - f.discount_amount)}</td><td>${formatINR(f.paid_amount)}</td><td>${escapeHtml(f.due_date || "-")}</td><td>${statusBadge(f.status)}</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No fee records yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Payment Receipts &amp; Refunds</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Receipt #</th><th>Course</th><th>Amount</th><th>Method</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              ${(dash.payments || []).map((p) => `<tr>
                <td>${escapeHtml(p.receipt_number || "Pending")}</td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td><div class="portal-actions">
                  ${p.receipt_number ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-receipt="${escAttr(JSON.stringify({ receipt: p.receipt_number, student: session.user.full_name, course: p.course_title, amount: p.amount, date: p.paid_at || p.created_at, invoice: p.invoice_number }))}">Print Receipt</button>` : ""}
                  ${p.verification_status === "verified" && p.refund_status === "none" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-req-refund="${p.id}">Request Refund</button>` : escapeHtml(p.refund_status !== "none" ? `Refund: ${p.refund_status}` : "")}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No payment transactions yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-dept-strip" style="margin-top:14px;">
            <span>Fee Billing &amp; Receipts: <a href="mailto:${escAttr(boot.departmentEmails?.fee || "fee@yuitor.com")}">${escapeHtml(boot.departmentEmails?.fee || "fee@yuitor.com")}</a></span>
            <span>Fee Refunds: <a href="mailto:${escAttr(boot.departmentEmails?.refund || "refund@yuitor.com")}">${escapeHtml(boot.departmentEmails?.refund || "refund@yuitor.com")}</a></span>
          </div>`;
      } else if (tab === "assignments") {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Assignments</h3>
            ${(dash.assignments || []).map((a) => `
              <div class="portal-detail" style="margin-bottom:10px;">
                <strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong>
                <span>Due: ${escapeHtml(a.due_date)} · Status: ${escapeHtml(a.submission_status || "Pending")} ${a.marks_obtained !== null ? "· Score: " + a.marks_obtained + "/" + a.max_marks : ""}</span>
                <form class="portal-form" data-sub-assign="${a.id}" style="margin-top:8px;">
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>Answer Text</label><input name="submissionText" placeholder="Write answer or notes..."></div>
                    <div class="portal-field"><label>Upload File (PDF / Image, max 5 MB)</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
                  </div>
                  <button type="submit" class="portal-button portal-button--small">Submit Assignment</button>
                </form>
              </div>`).join("") || `<p class="portal-hint">No pending assignments.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quizzes &amp; Tests</h3>
            ${(dash.quizzes || []).map((q) => {
              let qs = [];
              try { qs = JSON.parse(q.questions_json || "[]"); } catch { qs = []; }
              return `<div class="portal-detail" style="margin-bottom:12px;">
                <strong>${escapeHtml(q.title)} (${escapeHtml(q.course_title)})</strong>
                <span>${q.duration_minutes} mins · Max ${q.max_marks} marks ${q.score !== null && q.score !== undefined ? "· Last Score: " + q.score + "/" + q.max_marks : ""}</span>
                ${qs.length ? `<form class="portal-form" data-quiz-form="${q.id}" style="margin-top:10px;">
                  ${qs.map((item, idx) => `<div style="margin-bottom:8px;"><div><strong>Q${idx + 1}:</strong> ${escapeHtml(item.question)}</div><select name="q_${idx}">${(item.options || []).map((opt, oi) => `<option value="${oi}">${escapeHtml(opt)}</option>`).join("")}</select></div>`).join("")}
                  <button type="submit" class="portal-button portal-button--small">Submit Quiz</button>
                </form>` : ""}
              </div>`;
            }).join("") || `<p class="portal-hint">No quizzes published for your enrolled courses yet.</p>`}
          </div>`;
      } else if (tab === "attendance") {
        const present = (dash.attendance || []).filter((a) => a.status === "present").length;
        const absent = (dash.attendance || []).filter((a) => a.status === "absent").length;
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${present}</strong><span>Present Sessions</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${absent}</strong><span>Absent Sessions</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Date</th><th>Course</th><th>Status</th><th>Remarks</th></tr></thead>
            <tbody>
              ${(dash.attendance || []).map((a) => `<tr><td>${escapeHtml(a.att_date)}</td><td>${escapeHtml(a.course_title)}</td><td>${statusBadge(a.status)}</td><td>${escapeHtml(a.remarks || "-")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No attendance marked yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else {
        const sp = dash.profile || {};
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Student Profile</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Full Name</span><strong>${escapeHtml(session.user.full_name || "Student")}</strong></div>
              <div class="portal-detail"><span>Email Address</span><strong>${escapeHtml(session.user.email || "-")}</strong></div>
              <div class="portal-detail"><span>Mobile Number</span><strong>${escapeHtml(session.user.phone || "-")}</strong></div>
              <div class="portal-detail"><span>Class &amp; Board</span><strong>${escapeHtml([sp.class_level, sp.board].filter(Boolean).join(" · ") || "Active Student")}</strong></div>
            </div>
          </div>
          ${renderProfilePhotoCard(session.user)}
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Contact Yuitor Support</h3>
            <form class="portal-form" data-support-form>
              <div class="portal-field"><label>Subject</label><input name="subject" required></div>
              <div class="portal-field"><label>Message</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Send Message</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Recent Support Thread</h3>
            ${(dash.supportMessages || []).map((m) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(m.created_at)}</span><strong>${escapeHtml(m.subject)}</strong><div>${escapeHtml(m.body)}</div></div>`).join("") || `<p class="portal-hint">No support messages sent yet.</p>`}
          </div>
          <div class="portal-dept-strip">
            <span>Student Support: <a href="mailto:${escAttr(boot.departmentEmails?.support || "support@yuitor.com")}">${escapeHtml(boot.departmentEmails?.support || "support@yuitor.com")}</a></span>
            <span>Grievance Officer: <a href="mailto:${escAttr(boot.departmentEmails?.grievance || "grievance@yuitor.com")}">${escapeHtml(boot.departmentEmails?.grievance || "grievance@yuitor.com")}</a></span>
            <span>Complaints: <a href="mailto:${escAttr(boot.departmentEmails?.complain || "complain@yuitor.com")}">${escapeHtml(boot.departmentEmails?.complain || "complain@yuitor.com")}</a></span>
          </div>`;
      }

      const studentNoticeHtml = studentNotice
        ? `<div class="portal-message portal-message--${studentNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(studentNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: "Student Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          studentNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        onReadNotifs: async () => {
          await api("/api/student/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        onReadSingleNotif: async (notif) => {
          await api(`/api/student/notifications/${encodeURIComponent(notif.id)}/read`, { method: "POST" });
        },
        bodyHtml: studentNoticeHtml + bodyHtml,
      });

      main.querySelectorAll("[data-open-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          studentNotice = "";
          try {
            activeLessons = await api(`/api/student/courses/${b.getAttribute("data-open-course")}/lessons`);
          } catch (err) {
            activeLessons = null;
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-complete-lesson]").forEach((b) => {
        b.addEventListener("click", async () => {
          try {
            await api(`/api/student/lessons/${b.getAttribute("data-complete-lesson")}/complete`, { method: "POST", body: { timeSpentMinutes: 20 } });
            if (activeLessons?.enrollment?.course_id) {
              activeLessons = await api(`/api/student/courses/${activeLessons.enrollment.course_id}/lessons`);
            }
            studentNoticeType = "success";
            studentNotice = "Lesson marked complete.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelector("[data-enroll-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        const btn = formEl.querySelector('button[type="submit"]');
        const fb = main.querySelector("[data-enroll-fb]");
        const payload = Object.fromEntries(new FormData(formEl).entries());
        if (btn) btn.disabled = true;
        try {
          if (payload.paymentMethod === "gateway" && payCfg.razorpayEnabled) {
            const order = await api("/api/payments/create-order", {
              method: "POST",
              body: {
                courseId: Number(payload.courseId),
                plan: payload.plan,
                couponCode: payload.couponCode || "",
              },
            });
            let failedReported = false;
            const reportOrderFailed = (reason) => {
              if (failedReported || !order?.orderId) return;
              failedReported = true;
              api("/api/payments/order-failed", {
                method: "POST",
                body: { orderId: order.orderId, reason: String(reason || "cancelled").slice(0, 200) },
              }).catch(() => {});
            };
            const RazorpayCtor = await loadRazorpayCheckout();
            const gwResponse = await new Promise((resolve, reject) => {
              const rzp = new RazorpayCtor({
                key: order.keyId || payCfg.keyId,
                amount: order.amount,
                currency: order.currency || "INR",
                name: "Yuitor Smart Classes",
                description: "Course Enrollment Fee",
                order_id: order.orderId,
                prefill: {
                  name: session.user.full_name || "",
                  email: session.user.email || "",
                  contact: session.user.phone || "",
                },
                handler: (resp) => resolve(resp),
                modal: {
                  ondismiss: () => {
                    reportOrderFailed("Payment popup dismissed by student");
                    reject(new Error("Razorpay payment window closed before completion. You can retry anytime."));
                  },
                },
              });
              rzp.on("payment.failed", (resp) => {
                const desc = resp?.error?.description || "Online payment failed.";
                reportOrderFailed(desc);
                reject(new Error(desc));
              });
              rzp.open();
            });
            const verifiedRes = await api("/api/payments/enroll", {
              method: "POST",
              body: {
                ...payload,
                gatewayOrderId: gwResponse.razorpay_order_id,
                gatewayPaymentId: gwResponse.razorpay_payment_id,
                gatewaySignature: gwResponse.razorpay_signature,
              },
            });
            studentNoticeType = "success";
            studentNotice = verifiedRes.message;
            loadAndDraw();
            return;
          }
          const res = await api("/api/payments/enroll", { method: "POST", body: payload });
          studentNoticeType = "success";
          studentNotice = res.message || "Enrollment request submitted successfully.";
          loadAndDraw();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
      main.querySelector("[data-review-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await api("/api/student/reviews", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          studentNoticeType = "success";
          studentNotice = "Thank you! Your course review has been submitted.";
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message;
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-print-receipt]").forEach((b) => {
        b.addEventListener("click", () => {
          const info = JSON.parse(b.getAttribute("data-print-receipt"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:640px;margin:0 auto;">
              <p class="portal-kicker">Official Fee Receipt · Yuitor Smart Classes</p>
              <div class="portal-heading"><h1>Receipt ${escapeHtml(info.receipt)}</h1><button type="button" class="portal-button portal-button--small" onclick="window.print()">Print</button></div>
              <p class="portal-subtitle">Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · +91 78-2728-9292 · fee@yuitor.com</p>
              <div class="portal-personal-grid" style="margin-top:16px;">
                <div class="portal-detail"><span>Student</span><strong>${escapeHtml(info.student)}</strong></div>
                <div class="portal-detail"><span>Invoice</span><strong>${escapeHtml(info.invoice)}</strong></div>
                <div class="portal-detail"><span>Course</span><strong>${escapeHtml(info.course)}</strong></div>
                <div class="portal-detail"><span>Amount Paid</span><strong>${formatINR(info.amount)}</strong></div>
                <div class="portal-detail"><span>Date</span><strong>${escapeHtml(info.date)}</strong></div>
              </div>
              <div style="margin-top:18px;"><button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-fees>← Back to Fees</button></div>
            </div>`);
          getMain().querySelector("[data-back-fees]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-print-cert]").forEach((b) => {
        b.addEventListener("click", () => {
          const cert = JSON.parse(b.getAttribute("data-print-cert"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:680px;margin:0 auto;text-align:center;padding:36px;">
              <p class="portal-kicker" style="justify-content:center;">Certificate of Completion · Yuitor Smart Classes</p>
              <h1 style="margin:8px 0;">${escapeHtml(cert.student)}</h1>
              <p class="portal-subtitle" style="margin:0 auto 14px;">has successfully completed all lessons for <strong>${escapeHtml(cert.course)}</strong> at Yuitor Smart Classes, Muradnagar.</p>
              <p class="portal-hint">Certificate ID: <strong>${escapeHtml(cert.code)}</strong></p>
              <div class="portal-actions" style="justify-content:center;margin-top:20px;">
                <button type="button" class="portal-button portal-button--small" onclick="window.print()">Print Certificate</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-back-courses>← Back to Courses</button>
              </div>
            </div>`);
          getMain().querySelector("[data-back-courses]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-req-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          const reason = await openPromptModal({
            title: "Request Fee Refund",
            label: "Reason for refund request (min 5 characters)",
            defaultValue: "Batch change request",
            minLength: 5,
          });
          if (reason.trim().length < 5) return;
          try {
            await api("/api/payments/refund-request", {
              method: "POST",
              body: { paymentId: Number(b.getAttribute("data-req-refund")), reason },
            });
            studentNoticeType = "success";
            studentNotice = "Refund request submitted to Yuitor Admin.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-sub-assign]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const fd = new FormData(f);
            let fileUrl = "";
            const file = fd.get("file");
            if (file instanceof File && file.size > 0) {
              const up = await uploadFile(file);
              fileUrl = up.url;
            }
            await api(`/api/student/assignments/${f.getAttribute("data-sub-assign")}/submit`, {
              method: "POST",
              body: { submissionText: fd.get("submissionText"), fileUrl },
            });
            studentNoticeType = "success";
            studentNotice = "Assignment submitted.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-quiz-form]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const answers = Array.from(new FormData(f).values()).map(Number);
            const res = await api(`/api/student/quizzes/${f.getAttribute("data-quiz-form")}/attempt`, { method: "POST", body: { answers } });
            studentNoticeType = "success";
            studentNotice = res?.score !== undefined ? `Quiz submitted! Score: ${res.score}/${res.maxMarks || ""}` : "Quiz submitted.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      bindProfilePhotoCard(main, {
        session,
        onNotice: (type, msg) => {
          studentNoticeType = type;
          studentNotice = msg;
        },
        onRefresh: loadAndDraw,
      });
      main.querySelector("[data-support-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await api("/api/student/support", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          studentNoticeType = "success";
          studentNotice = "Support message sent to Yuitor Team.";
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message;
        }
        loadAndDraw();
      });
    }
    await loadAndDraw();
  }

  // ==================== TEACHER PANEL ====================
  function renderTeacherResumeGate(session, customMessage = "") {
    const resumeInfo = session?.teacherResume || {};
    const isRejected = resumeInfo.resumeStatus === "rejected";
    const main = mountShell(`
      ${impersonationBanner(session)}
      <div class="portal-card portal-profile yu-reg-card">
        <div class="yu-reg-hero">
          <p class="yu-reg-hero-kicker">Teacher Dashboard Access Restricted</p>
          <h1>Resume Submission Required</h1>
          <p>${escapeHtml(customMessage || TEACHER_MISSING_RESUME_MSG)}</p>
        </div>
        ${
          isRejected && resumeInfo.resumeNotes
            ? `<div class="portal-message portal-message--error">Admin Review Note: ${escapeHtml(resumeInfo.resumeNotes)}</div>`
            : ""
        }
        <form class="portal-form" data-teacher-gate-resume>
          <div class="portal-field">
            <label>Upload Updated Resume / CV (PDF, DOC, or DOCX · Max 5 MB) *</label>
            <div class="yu-resume-dropzone">
              <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
            </div>
          </div>
          <div class="portal-message" data-t-gate-fb hidden></div>
          <div class="portal-actions">
            <button type="submit" class="portal-button">Upload Resume &amp; Unlock Review</button>
            <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
          </div>
        </form>
      </div>`);

    main?.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
      await api("/api/auth/logout", { method: "POST" });
      window.location.assign("/login");
    });

    main?.querySelector("[data-teacher-gate-resume]")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const form = e.target;
      const fd = new FormData(form);
      const fb = main.querySelector("[data-t-gate-fb]");
      const btn = form.querySelector('button[type="submit"]');
      const file = fd.get("resume");
      if (!(file instanceof File) || file.size === 0) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = TEACHER_MISSING_RESUME_MSG;
        fb.hidden = false;
        return;
      }
      btn.disabled = true;
      try {
        await api("/api/auth/teacher-resume", { method: "POST", body: fd });
        const refreshed = await api("/api/auth/me");
        renderTeacherPanel(refreshed);
      } catch (err) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = err.message;
        fb.hidden = false;
        btn.disabled = false;
      }
    });
  }

  async function renderTeacherPanel(session) {
    const resumeState = session?.teacherResume || {};
    if (!resumeState.hasResume || resumeState.resumeStatus === "missing" || resumeState.resumeStatus === "rejected") {
      renderTeacherResumeGate(
        session,
        resumeState.resumeStatus === "rejected" ? TEACHER_REJECTED_RESUME_MSG : TEACHER_MISSING_RESUME_MSG
      );
      return;
    }

    if (session.user.verification_status !== "approved") {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Teacher Verification Pending</p>
          <div class="portal-heading"><h1>Application Under Review</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || TEACHER_PENDING_MSG)}</div>
          <p class="portal-hint" style="margin-bottom:14px;">Submitted resume: <strong>${escapeHtml(resumeState.resumeFilename || "On file")}</strong> (${escapeHtml(resumeState.resumeStatus || "submitted")})</p>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let selectedCourseId = null;
    let editingLessonId = null;
    let activeSubmissions = null;
    let teacherNotice = "";
    let teacherNoticeType = "success";

    async function loadAndDraw() {
      let dash;
      try {
        dash = await api("/api/teacher/dashboard");
      } catch (err) {
        if (err?.data?.code === "RESUME_REQUIRED" || err?.status === 403) {
          renderTeacherResumeGate(session, err?.message || TEACHER_MISSING_RESUME_MSG);
          return;
        }
        throw err;
      }
      if (!selectedCourseId && dash.courses?.length) selectedCourseId = dash.courses[0].id;
      const lessonsData = selectedCourseId ? await api(`/api/teacher/courses/${selectedCourseId}/lessons`) : { lessons: [] };
      const selectedCourse = (dash.courses || []).find((c) => Number(c.id) === Number(selectedCourseId));

      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["lessons", "Courses & Lessons", "book"],
        ["students", "Students & Attendance", "users"],
        ["schedules", "Schedules & Grading", "calendar"],
        ["profile", "Profile & Availability", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${(dash.courses || []).length}</strong><span>Assigned Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.students || []).length}</strong><span>Students</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.schedules || []).length}</strong><span>Class Schedules</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.assignments || []).length}</strong><span>Assignments</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Publish Class Announcement</h3>
            <form class="portal-form" data-t-ann-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course (Optional)</label><select name="courseId"><option value="">All My Students</option>${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
              </div>
              <div class="portal-field"><label>Announcement</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Post Announcement</button>
            </form>
          </div>`;
      } else if (tab === "lessons") {
        const editLesson = (lessonsData.lessons || []).find((l) => Number(l.id) === Number(editingLessonId));
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div class="portal-form-grid" style="margin-bottom:12px;">
              <div class="portal-field">
                <label>Select Assigned Course</label>
                <select data-t-course>${(dash.courses || []).map((c) => `<option value="${c.id}"${Number(selectedCourseId) === Number(c.id) ? " selected" : ""}>${escapeHtml(c.title)}</option>`).join("")}</select>
              </div>
            </div>
            ${
              selectedCourse
                ? `<form class="portal-form" data-t-course-edit style="margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--pt-border);">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course Description</label><input name="description" value="${escAttr(selectedCourse.description || "")}"></div>
                      <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="60" value="${Number(selectedCourse.duration_months || 12)}"></div>
                      <div class="portal-field"><label>Update Course Thumbnail</label><input name="thumbnail" type="file" accept=".png,.jpg,.jpeg,.webp"></div>
                    </div>
                    <div><button type="submit" class="portal-button portal-button--small portal-button--quiet">Update Course Details</button></div>
                  </form>`
                : ""
            }
            <h3 class="portal-section-title">${editLesson ? `Edit Lesson: ${escapeHtml(editLesson.title)}` : "Add Lesson"}</h3>
            <form class="portal-form" ${editLesson ? `data-t-edit-lesson="${editLesson.id}"` : "data-t-lesson-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Lesson Title *</label><input name="title" required value="${escAttr(editLesson?.title || "")}"></div>
                <div class="portal-field"><label>Type</label><select name="lessonType"><option value="text"${editLesson?.lesson_type === "text" ? " selected" : ""}>Text Notes</option><option value="video"${editLesson?.lesson_type === "video" ? " selected" : ""}>Video</option><option value="pdf"${editLesson?.lesson_type === "pdf" ? " selected" : ""}>PDF Notes</option></select></div>
                <div class="portal-field"><label>Material / Video URL</label><input name="materialUrl" value="${escAttr(editLesson?.material_url || editLesson?.video_url || "")}" placeholder="https:// or uploaded PDF URL"></div>
                <div class="portal-field"><label>Or Upload Study PDF / Image</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field"><label>Content / Summary</label><textarea name="content">${escapeHtml(editLesson?.content || "")}</textarea></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editLesson ? "Save Lesson" : "Add Lesson"}</button>
                ${editLesson ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-lesson>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Lessons Order (Drag &amp; Drop or use ↑ / ↓)</h3>
            <div data-drag-lesson-list>
              ${(lessonsData.lessons || []).map((l, idx) => `
                <div class="portal-detail portal-drag-row" draggable="true" data-lesson-id="${l.id}" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${idx + 1}. ${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.is_visible ? "Visible" : "Hidden"}${l.material_url ? " · Attachment linked" : ""}</span></div>
                  <div class="portal-actions">
                    ${idx > 0 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="-1">${icon("arrowUp")}</button>` : ""}
                    ${idx < lessonsData.lessons.length - 1 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="1">${icon("arrowDown")}</button>` : ""}
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-l="${l.id}">${icon("edit")} Edit</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-vis-l="${l.id}" data-vis="${l.is_visible ? 0 : 1}">${l.is_visible ? "Hide" : "Show"}</button>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-l="${l.id}">${icon("trash")}</button>
                  </div>
                </div>`).join("") || `<p class="portal-hint">No lessons yet.</p>`}
            </div>
          </div>`;
      } else if (tab === "students") {
        bodyHtml = `
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Progress</th><th>Mark Today</th></tr></thead>
            <tbody>
              ${(dash.students || []).map((s) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(s.full_name)}</span><span class="portal-cell-sub">${escapeHtml(s.phone)}</span></td>
                <td>${escapeHtml(s.course_title)}</td>
                <td>${s.progress_percent}%</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small" data-att="${s.id}" data-cid="${s.course_id}" data-st="present">Present</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-att="${s.id}" data-cid="${s.course_id}" data-st="absent">Absent</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No assigned students yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "schedules") {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Schedule Class / Online Session</h3>
            <form class="portal-form" data-t-sched-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Session Title</label><input name="title" required placeholder="e.g. Algebra Doubt Session"></div>
                <div class="portal-field"><label>Date</label><input name="scheduledDate" type="date" required></div>
                <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00" required></div>
                <div class="portal-field"><label>End Time</label><input name="endTime" value="17:00" required></div>
                <div class="portal-field"><label>Mode</label><select name="mode"><option value="offline">Classroom (Muradnagar)</option><option value="online">Online (Meet/Zoom)</option></select></div>
                <div class="portal-field"><label>Meeting Link (if online)</label><input name="meetingLink" placeholder="https://meet.google.com/..."></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Schedule Class</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create Assignment &amp; Grade Submissions</h3>
            <form class="portal-form" data-t-assign-form style="margin-bottom:16px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Due Date</label><input name="dueDate" type="date" required></div>
                <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="50"></div>
              </div>
              <div class="portal-field"><label>Instructions</label><textarea name="description"></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Publish Assignment</button>
            </form>
            ${(dash.assignments || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong><span>Due: ${escapeHtml(a.due_date)} · Submissions: ${a.submissions_count}</span></div><button type="button" class="portal-button portal-button--small portal-button--quiet" data-view-subs="${a.id}">Review Submissions</button></div>`).join("")}
            ${activeSubmissions ? `<div style="margin-top:12px;"><h4>Submissions</h4>${(activeSubmissions.submissions || []).map((s) => { const fUrl = safeHref(s.file_url); return `<form class="portal-form" data-grade-sub="${s.id}" style="border-top:1px solid var(--pt-border);padding-top:10px;margin-top:10px;"><div><strong>${escapeHtml(s.student_name)}</strong>: ${escapeHtml(s.submission_text)} ${fUrl ? `<a href="${escAttr(fUrl)}" target="_blank" rel="noopener noreferrer">View Attachment</a>` : ""}</div><div class="portal-form-grid"><input name="marksObtained" type="number" placeholder="Marks" value="${s.marks_obtained ?? ""}" required><input name="feedback" placeholder="Feedback" value="${escAttr(s.feedback || "")}"></div><button type="submit" class="portal-button portal-button--small">Save Grade</button></form>`; }).join("") || `<p class="portal-hint">No student submissions yet.</p>`}</div>` : ""}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quick MCQ Quiz Builder</h3>
            <form class="portal-form" data-t-quiz-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Quiz Title</label><input name="title" required></div>
                <div class="portal-field"><label>Question 1</label><input name="qText" required placeholder="e.g. What is SI unit of Force?"></div>
                <div class="portal-field"><label>4 Comma-Separated Options</label><input name="qOptions" required placeholder="Newton, Joule, Watt, Pascal"></div>
                <div class="portal-field"><label>Correct Option Index (0–3)</label><input name="correctIndex" type="number" min="0" max="3" value="0"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Publish Quiz</button>
            </form>
          </div>`;
      } else {
        const tp = dash.profile || {};
        const earn = dash.earningsSummary || {};
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Earnings &amp; Payout Status</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Monthly Payout Rate</span><strong>${formatINR(earn.monthlyPayoutRate || tp.monthly_payout_rate || 0)}</strong></div>
              <div class="portal-detail"><span>Assigned Active Students</span><strong>${Number(earn.activeStudentsCount || 0)}</strong></div>
              <div class="portal-detail"><span>Configured Payout UPI</span><strong>${escapeHtml(earn.payoutUpi || tp.payout_upi || "Not set yet")}</strong></div>
            </div>
            ${earn.limitationNote ? `<p class="portal-hint" style="margin-top:10px;">${escapeHtml(earn.limitationNote)}</p>` : ""}
          </div>
          ${renderProfilePhotoCard(session.user)}
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Resume &amp; Verification Document</h3>
            <div class="portal-personal-grid" style="margin-bottom:12px;">
              <div class="portal-detail"><span>Current Resume File</span><strong>${escapeHtml(tp.resume_filename || "Uploaded")}</strong></div>
              <div class="portal-detail"><span>Verification Status</span><strong>${statusBadge(tp.resume_status || "submitted")}</strong></div>
              <div class="portal-detail"><span>Uploaded Timestamp</span><strong>${escapeHtml(tp.resume_uploaded_at || "Recorded")}</strong></div>
            </div>
            <form class="portal-form" data-t-resume-update-form>
              <div class="portal-actions">
                ${tp.resume_url ? `<a href="/api/teacher/resume" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${icon("download")} View / Download Resume</a>` : ""}
                <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Update Resume</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Faculty Profile &amp; Availability</h3>
            <form class="portal-form" data-t-prof-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(session.user.full_name)}"></div>
                <div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                <div class="portal-field"><label>Availability Status</label><select name="availabilityStatus"><option value="available"${tp.availability_status === "available" ? " selected" : ""}>Available</option><option value="vacation"${tp.availability_status === "vacation" ? " selected" : ""}>Vacation Mode</option></select></div>
                <div class="portal-field"><label>Vacation Note</label><input name="vacationNote" value="${escAttr(tp.vacation_note || "")}"></div>
                <div class="portal-field"><label>Payout UPI (Optional)</label><input name="payoutUpi" value="${escAttr(tp.payout_upi || "")}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Save Profile</button>
            </form>
          </div>`;
      }

      const noticeHtml = teacherNotice
        ? `<div class="portal-message portal-message--${teacherNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(teacherNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: "Teacher Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          editingLessonId = null;
          teacherNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        onReadNotifs: async () => {
          await api("/api/teacher/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        onReadSingleNotif: async (notif) => {
          await api(`/api/teacher/notifications/${encodeURIComponent(notif.id)}/read`, { method: "POST" });
        },
        bodyHtml: noticeHtml + bodyHtml,
      });

      const runTeacherAction = async (fn, successMsg) => {
        try {
          await fn();
          teacherNoticeType = "success";
          teacherNotice = successMsg || "";
        } catch (err) {
          teacherNoticeType = "error";
          teacherNotice = err?.message || "Action failed. Please check inputs and try again.";
        }
        loadAndDraw();
      };

      main.querySelector("[data-t-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/announcements", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Announcement published.");
      });
      main.querySelector("[data-t-course]")?.addEventListener("change", (e) => {
        selectedCourseId = Number(e.target.value);
        editingLessonId = null;
        teacherNotice = "";
        loadAndDraw();
      });
      main.querySelector("[data-t-course-edit]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let thumbnailUrl;
          const f = fd.get("thumbnail");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            thumbnailUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}`, {
            method: "PATCH",
            body: { description: fd.get("description"), durationMonths: Number(fd.get("durationMonths") || 12), thumbnailUrl },
          });
        }, "Course details updated.");
      });
      main.querySelector("[data-t-lesson-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}/lessons`, {
            method: "POST",
            body: {
              title: fd.get("title"),
              lessonType: fd.get("lessonType"),
              materialUrl,
              content: fd.get("content"),
            },
          });
        }, "Lesson added.");
      });
      main.querySelector("[data-t-edit-lesson]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const lid = e.target.getAttribute("data-t-edit-lesson");
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/lessons/${lid}`, {
            method: "PATCH",
            body: { title: fd.get("title"), lessonType: fd.get("lessonType"), materialUrl, content: fd.get("content") },
          });
          editingLessonId = null;
        }, "Lesson updated.");
      });
      main.querySelector("[data-cancel-edit-lesson]")?.addEventListener("click", () => {
        editingLessonId = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-l]").forEach((b) => {
        b.addEventListener("click", () => {
          editingLessonId = Number(b.getAttribute("data-edit-l"));
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-del-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-del-l")}`, { method: "DELETE" });
          }, "Lesson deleted.");
        });
      });

      // Drag-and-drop lesson reorder
      const dragList = main.querySelector("[data-drag-lesson-list]");
      let draggedId = null;
      dragList?.querySelectorAll("[data-lesson-id]").forEach((row) => {
        row.addEventListener("dragstart", () => {
          draggedId = Number(row.getAttribute("data-lesson-id"));
          row.classList.add("is-dragging");
        });
        row.addEventListener("dragend", () => row.classList.remove("is-dragging"));
        row.addEventListener("dragover", (e) => e.preventDefault());
        row.addEventListener("drop", async (e) => {
          e.preventDefault();
          const targetId = Number(row.getAttribute("data-lesson-id"));
          if (!draggedId || draggedId === targetId) return;
          const ids = (lessonsData.lessons || []).map((l) => Number(l.id));
          const fromIdx = ids.indexOf(draggedId);
          const toIdx = ids.indexOf(targetId);
          if (fromIdx >= 0 && toIdx >= 0) {
            ids.splice(toIdx, 0, ids.splice(fromIdx, 1)[0]);
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });

      main.querySelectorAll("[data-move-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = Number(b.getAttribute("data-move-l"));
          const dir = Number(b.getAttribute("data-dir"));
          const ids = (lessonsData.lessons || []).map((l) => l.id);
          const idx = ids.indexOf(id);
          if (idx >= 0 && idx + dir >= 0 && idx + dir < ids.length) {
            [ids[idx], ids[idx + dir]] = [ids[idx + dir], ids[idx]];
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });
      main.querySelectorAll("[data-vis-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-vis-l")}`, {
              method: "PATCH",
              body: { isVisible: b.getAttribute("data-vis") === "1" },
            });
          }, "Lesson visibility updated.");
        });
      });
      main.querySelectorAll("[data-att]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api("/api/teacher/attendance", {
              method: "POST",
              body: {
                courseId: Number(b.getAttribute("data-cid")),
                attDate: new Date().toISOString().slice(0, 10),
                records: [{ studentId: Number(b.getAttribute("data-att")), status: b.getAttribute("data-st") }],
              },
            });
          }, "Attendance marked.");
        });
      });
      main.querySelector("[data-t-sched-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/schedules", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Class schedule saved.");
      });
      main.querySelector("[data-t-assign-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/assignments", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Assignment published.");
      });
      main.querySelectorAll("[data-view-subs]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            activeSubmissions = await api(`/api/teacher/assignments/${b.getAttribute("data-view-subs")}/submissions`);
          }, "");
        });
      });
      main.querySelectorAll("[data-grade-sub]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          await runTeacherAction(async () => {
            await api(`/api/teacher/submissions/${f.getAttribute("data-grade-sub")}/grade`, {
              method: "POST",
              body: Object.fromEntries(new FormData(f).entries()),
            });
          }, "Submission graded.");
        });
      });
      main.querySelector("[data-t-quiz-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const options = String(fd.get("qOptions") || "").split(",").map((s) => s.trim()).filter(Boolean);
        await runTeacherAction(async () => {
          await api("/api/teacher/quizzes", {
            method: "POST",
            body: {
              courseId: Number(fd.get("courseId")),
              title: fd.get("title"),
              maxMarks: 10,
              durationMinutes: 15,
              questions: [{ question: fd.get("qText"), options, correctIndex: Number(fd.get("correctIndex") || 0) }],
            },
          });
        }, "Quiz published.");
      });
      bindProfilePhotoCard(main, {
        session,
        onNotice: (type, msg) => {
          teacherNoticeType = type;
          teacherNotice = msg;
        },
        onRefresh: loadAndDraw,
      });
      main.querySelector("[data-t-resume-update-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const file = fd.get("resume");
        if (file instanceof File && file.size > 0) {
          await runTeacherAction(async () => {
            await api("/api/auth/teacher-resume", { method: "POST", body: fd });
          }, "Resume updated and recorded.");
        }
      });
      main.querySelector("[data-t-prof-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/profile", { method: "PATCH", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Faculty profile saved.");
      });
    }
    await loadAndDraw();
  }

  // ==================== ROUTER ====================
  const CUSTOM_PUBLIC_PATHS = new Set([
    "/admission",
    "/subjects",
    "/ai-learning",
    "/computer-courses",
    "/english-speaking",
    "/teachers",
    "/faqs",
    "/testimonials",
    "/courses",
  ]);

  function normalizePortalPath(rawPath) {
    return (
      String(rawPath || "/")
        .split(/[?#]/)[0]
        .replace(/\/+/g, "/")
        .replace(/\/+$/, "") || "/"
    );
  }

  function isHandledPath(rawPath) {
    const path = normalizePortalPath(rawPath);
    if (GATE_BASE && (path === GATE_BASE || path.startsWith(GATE_BASE + "/"))) {
      return true;
    }
    return (
      path.startsWith("/student") ||
      path.startsWith("/teacher") ||
      path === "/teacher-apply.php" ||
      path.startsWith("/unsubscribe/") ||
      path === "/login" ||
      path === "/login.php" ||
      path === "/register" ||
      path === "/register.php" ||
      path.startsWith("/register/") ||
      path === "/erp" ||
      path.startsWith("/erp/") ||
      CUSTOM_PUBLIC_PATHS.has(path)
    );
  }

  async function startPortal(rawPath) {
    const path = normalizePortalPath(rawPath);
    if (CUSTOM_PUBLIC_PATHS.has(path) || path.startsWith("/unsubscribe/")) {
      await renderPublicExtension(path);
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (GATE_BASE && (path === `${GATE_BASE}/setup` || path === `${GATE_BASE}/setup.php`)) {
      await renderAdminSetup();
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (
      path === "/register" ||
      path === "/register.php" ||
      path === "/register/student" ||
      path === "/student/register" ||
      path === "/student/register.php"
    ) {
      renderRegister("student");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (
      path === "/register/teacher" ||
      path === "/teacher/register" ||
      path === "/teacher/register.php" ||
      path === "/teacher-apply.php"
    ) {
      renderRegister("teacher");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    let session = null;
    try {
      session = await api("/api/auth/me");
    } catch {
      session = null;
    }
    const user = session?.authenticated ? session.user : null;

    if (GATE_BASE && (path === GATE_BASE || path.startsWith(GATE_BASE + "/"))) {
      if (user && (user.role === "super_admin" || user.role === "admin")) {
        await renderAdminPanel(session);
      } else {
        renderAdminGateLogin(user ? "Signed in with a non-administrator account. Sign in with an Admin account." : "");
      }
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (
      path === "/login" ||
      path === "/login.php" ||
      path === "/student/login" ||
      path === "/teacher/login" ||
      path === "/student/login.php" ||
      path === "/teacher/login.php"
    ) {
      const defRole = path.startsWith("/teacher") ? "teacher" : "student";
      if (user) {
        if (user.role === "teacher" && (!session.teacherResume?.hasResume || session.teacherResume?.resumeStatus === "missing" || session.teacherResume?.resumeStatus === "rejected")) {
          renderTeacherResumeGate(session, TEACHER_MISSING_RESUME_MSG);
          window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
          return;
        }
        if (user.role === "super_admin" || user.role === "admin") {
          renderLogin(defRole, "Administrator sessions stay isolated from Student/Teacher login.");
          window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
          return;
        }
        const dest = user.role === "teacher" ? "/teacher/" : "/student/";
        window.location.replace(dest);
        return;
      }
      renderLogin(defRole);
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/teacher")) {
      if (user && user.role === "teacher") {
        await renderTeacherPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("teacher", user ? "Signed in as non-teacher. Please sign in with a Teacher account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/student") || path === "/erp" || path.startsWith("/erp/")) {
      if (user && user.role === "student") {
        await renderStudentPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("student", user ? "Signed in as non-student. Please sign in with a Student account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
  }

  function boot() {
    let lastMountedPath = null;
    let mountRaf = 0;

    const clearPortalClasses = () => {
      const main = getMain();
      if (main) {
        main.classList.remove("portal-main", "portal-dark");
        delete main.dataset.yuPortalMounted;
      }
      lastMountedPath = null;
      document.documentElement.classList.remove("yu-portal-dark");
      document.documentElement.removeAttribute("data-yu-portal-active");
      document.documentElement.removeAttribute("data-yu-admin-gate");
    };

    const tryMountForCurrentPath = () => {
      const path = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(path)) {
        clearPortalClasses();
        return false;
      }
      const main = getMain();
      const header = root.querySelector(".yu-shared-header");
      const footer = root.querySelector(".yu-shared-footer");
      const host = main?.querySelector("[data-yu-portal-host]");
      if (!main || !header || !footer || !host) return false;
      const hasPortalDom = Boolean(host.querySelector(".portal-shell, .portal-workspace"));
      if (main.dataset.yuPortalMounted === "true" && lastMountedPath === path && hasPortalDom) {
        document.documentElement.removeAttribute("data-yu-portal-active");
        return true;
      }
      lastMountedPath = path;
      main.classList.add("portal-main");
      main.dataset.yuPortalMounted = "true";
      document.documentElement.removeAttribute("data-yu-portal-active");
      startPortal(path);
      return true;
    };

    tryMountForCurrentPath();

    const scheduleMount = () => {
      const path = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(path)) {
        clearPortalClasses();
        return;
      }
      if (mountRaf) return;
      mountRaf = window.requestAnimationFrame(() => {
        mountRaf = 0;
        tryMountForCurrentPath();
      });
    };

    const observer = new MutationObserver(scheduleMount);
    observer.observe(root, { childList: true, subtree: true });

    const origPush = history.pushState;
    history.pushState = function (...args) {
      origPush.apply(this, args);
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    };

    const origReplace = history.replaceState;
    history.replaceState = function (...args) {
      origReplace.apply(this, args);
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    };

    window.addEventListener("popstate", () => {
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
