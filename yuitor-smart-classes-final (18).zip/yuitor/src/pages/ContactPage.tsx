import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageSquare, HelpCircle, ShieldAlert } from 'lucide-react';
import type { BootstrapData } from '../types';
import {
  BRAND_INFO,
  CAMPUS_GALLERY_PREVIEW,
  DEPARTMENT_HELPLINES,
} from '../data/siteContent';
import { EnquiryForm } from '../components/EnquiryForm';
import { SafeImage } from '../components/SafeImage';

interface ContactPageProps {
  boot: BootstrapData;
  citySlug?: string;
  isAdmission?: boolean;
  onNavigate: (path: string) => void;
}

export function ContactPage({ boot, citySlug, isAdmission = false, onNavigate }: ContactPageProps) {
  const initialIndex = citySlug
    ? Math.max(
        0,
        CAMPUS_GALLERY_PREVIEW.findIndex((o) => o.slug === citySlug.toLowerCase())
      )
    : 0;
  const [selectedIdx, setSelectedIdx] = useState(initialIndex);
  const activeWing = CAMPUS_GALLERY_PREVIEW[selectedIdx] || CAMPUS_GALLERY_PREVIEW[0];

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      {/* Simandhar-style Interactive Campus Gallery + Muradnagar Wing Selector */}
      <section className="bg-white border-b border-[#EADFE2] py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Interactive Campus Photo Gallery */}
          <div className="lg:col-span-6 space-y-3">
            <div className="rounded-2xl overflow-hidden border border-[#EADFE2] aspect-[16/10] bg-[#24040C]">
              <SafeImage
                src={activeWing.image}
                alt={`${activeWing.city} at ${BRAND_INFO.name}`}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-5 gap-2">
              {CAMPUS_GALLERY_PREVIEW.map((loc, idx) => (
                <button
                  key={loc.slug}
                  type="button"
                  onClick={() => setSelectedIdx(idx)}
                  aria-label={`View ${loc.city}`}
                  className={`rounded-xl overflow-hidden border-2 aspect-[4/3] cursor-pointer transition-all ${
                    selectedIdx === idx
                      ? 'border-[#7A0F28] ring-2 ring-[#7A0F28]/25'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <SafeImage
                    src={loc.image}
                    alt={`${loc.city} thumbnail`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Right Heading & Campus Details */}
          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
              {isAdmission
                ? 'Admissions Open 2026–27 · Free 2-Day Demo Classes'
                : 'Muradnagar’s Premier AI-Assisted Smart Coaching'}
            </p>
            <h1 className="font-editorial text-3xl sm:text-5xl font-bold text-[#1D1014] leading-tight">
              {isAdmission ? (
                <>
                  Apply for Admission &amp;{' '}
                  <span className="text-[#7A0F28]">Book Free Demo</span>
                </>
              ) : (
                <>
                  Contact {BRAND_INFO.name}{' '}
                  <span className="text-[#7A0F28]">Muradnagar</span>
                </>
              )}
            </h1>
            <p className="text-base text-[#4B3B40] leading-relaxed">
              Visit our campus at Trimurti Vihar, Near Venus Academy or call/WhatsApp us for Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English &amp; Coding Classes admissions.
            </p>

            {/* Interactive Campus Wing Tabs */}
            <div className="flex flex-wrap gap-2">
              {CAMPUS_GALLERY_PREVIEW.map((loc, idx) => (
                <button
                  key={loc.slug}
                  type="button"
                  onClick={() => setSelectedIdx(idx)}
                  className={`rounded-full px-4 py-2 text-xs sm:text-sm font-semibold border transition-colors cursor-pointer ${
                    selectedIdx === idx
                      ? 'bg-[#7A0F28] text-white border-[#7A0F28]'
                      : 'bg-white text-[#7A0F28] border-[#7A0F28]/40 hover:bg-[#FAF7F5]'
                  }`}
                >
                  {loc.city}
                </button>
              ))}
            </div>

            <div className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4 space-y-1.5 text-sm">
              <div className="font-bold text-[#1D1014]">
                {activeWing.city} — {activeWing.regionLabel}
              </div>
              <div className="text-[#5E4B51] text-xs leading-relaxed">{activeWing.address}</div>
              <div className="text-xs text-[#7A0F28] font-semibold pt-1">
                Programs: {activeWing.credentials}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* For Enquiry — 4 Direct Contact Cards (Exact User Phone, Email & Complaints) */}
      <section className="py-14 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-8">
            <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">Direct Contact &amp; Helplines</h2>
            <p className="mt-1.5 text-sm text-[#5E4B51]">
              Reach our admissions, WhatsApp counselling, general inquiry, or complaints desk directly.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {DEPARTMENT_HELPLINES.map((dept) => {
              const isEmail = dept.href.startsWith('mailto:');
              const isComplaint = dept.title.toLowerCase().includes('complaint');
              return (
                <div
                  key={dept.title}
                  className="rounded-2xl bg-white border border-[#EADFE2] p-6 text-center hover:border-[#7A0F28]/50 transition-colors"
                >
                  {isComplaint ? (
                    <ShieldAlert className="w-5 h-5 text-[#7A0F28] mx-auto" aria-hidden="true" />
                  ) : isEmail ? (
                    <Mail className="w-5 h-5 text-[#7A0F28] mx-auto" aria-hidden="true" />
                  ) : (
                    <Phone className="w-5 h-5 text-[#7A0F28] mx-auto" aria-hidden="true" />
                  )}
                  <h3 className="mt-3 font-editorial text-lg font-bold text-[#1D1014]">
                    {dept.title}
                  </h3>
                  <p className="mt-1 text-xs text-[#5E4B51]">{dept.detail}</p>
                  <a
                    href={dept.href}
                    className="mt-4 inline-block font-mono tabular-nums text-xs sm:text-sm font-bold text-[#7A0F28] hover:underline break-all"
                  >
                    {dept.phone}
                  </a>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Live Backend Inquiry & Demo Booking Form + Student & Parent Support */}
      <section className="py-16 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-7">
            <EnquiryForm
              heading={
                isAdmission
                  ? 'Admission & Free Demo Application'
                  : 'Send Us an Enquiry or Book Free Demo'
              }
              subheading="Your enquiry is saved directly to our Muradnagar Admissions CRM and our team calls back promptly."
              ctaLabel={isAdmission ? 'Submit Admission Application' : 'Submit Enquiry'}
              source={isAdmission ? 'admission_page' : 'contact_page'}
              courses={boot.courses}
              branches={boot.branches}
              showDemoFields
            />
          </div>

          <div className="lg:col-span-5 space-y-6">
            {/* Official Address & Contact Box */}
            <div className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6 space-y-3 text-sm">
              <h3 className="font-editorial text-xl font-bold text-[#1D1014]">
                Official Campus Details
              </h3>
              <div className="space-y-2.5 text-xs text-[#4B3B40]">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <strong className="block text-[#1D1014]">Address</strong>
                    <span>{BRAND_INFO.address}</span>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Phone className="w-4 h-4 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <strong className="block text-[#1D1014]">Phone / WhatsApp</strong>
                    <a href={BRAND_INFO.phoneHref} className="font-mono font-semibold text-[#7A0F28] hover:underline">
                      {BRAND_INFO.phoneDisplay}
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Mail className="w-4 h-4 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <strong className="block text-[#1D1014]">Email &amp; Complaints</strong>
                    <a href={`mailto:${BRAND_INFO.email}`} className="text-[#7A0F28] hover:underline block">
                      {BRAND_INFO.email}
                    </a>
                    <a href={`mailto:${BRAND_INFO.complaintsEmail}`} className="text-[#7A0F28] hover:underline block">
                      Complaints: {BRAND_INFO.complaintsEmail}
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <strong className="block text-[#1D1014]">Campus Timings</strong>
                    <span>{BRAND_INFO.timings}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl bg-[#24040C] text-white p-7">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#F3CF7A]">
                <HelpCircle className="w-4 h-4" aria-hidden="true" />
                <span>Already a Yuitor Student or Parent?</span>
              </div>
              <h3 className="mt-2 font-editorial text-2xl font-bold text-white">
                Unified Portal Support
              </h3>
              <ul className="mt-4 space-y-2.5 text-sm text-white/80">
                <li>• Track daily attendance &amp; class schedules</li>
                <li>• View Sunday test marks, ranks &amp; teacher remarks</li>
                <li>• Download chapter notes, homework &amp; digital fee receipts</li>
                <li>• Message teachers directly through the Parent Portal</li>
              </ul>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href="/student/login"
                  onClick={(e) => go(e, '/student/login')}
                  className="rounded-full bg-[#E6B450] hover:bg-[#F3CF7A] text-[#1D1014] font-bold px-5 py-2.5 text-xs transition-colors"
                >
                  Student / Parent Portal
                </a>
                <a
                  href="/teacher/login"
                  onClick={(e) => go(e, '/teacher/login')}
                  className="rounded-full border border-white/30 hover:border-white px-5 py-2.5 text-xs font-semibold text-white transition-colors"
                >
                  Teacher Portal
                </a>
              </div>
            </div>

            <div className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6 space-y-2 text-sm">
              <div className="inline-flex items-center gap-2 font-bold text-[#1D1014]">
                <MessageSquare className="w-4 h-4 text-[#7A0F28]" aria-hidden="true" />
                <span>Quality Coaching at Affordable Monthly Fees</span>
              </div>
              <p className="text-xs text-[#5E4B51] leading-relaxed">
                Small batches, printed study material, practical computer lab, merit scholarships up to 50%, and zero hidden portal fees.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
