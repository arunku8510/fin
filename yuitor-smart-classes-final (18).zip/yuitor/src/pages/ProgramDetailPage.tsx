import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  BookOpen,
  Briefcase,
  Award,
  ChevronDown,
  ChevronUp,
  ArrowRight,
} from 'lucide-react';
import type { BootstrapData } from '../types';
import { getProgramBySlug, TOP_ACHIEVERS } from '../data/siteContent';
import { EnquiryForm } from '../components/EnquiryForm';
import { SafeImage } from '../components/SafeImage';
import { formatINR } from '../utils/catalog';

interface ProgramDetailPageProps {
  slug: string;
  boot: BootstrapData;
  onNavigate: (path: string) => void;
}

export function ProgramDetailPage({ slug, boot, onNavigate }: ProgramDetailPageProps) {
  const program = getProgramBySlug(slug);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      {/* Burgundy Sub-Navigation Anchor Strip */}
      <div className="bg-[#7A0F28] text-white border-b border-[#58091B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center gap-6 overflow-x-auto text-xs sm:text-sm font-medium whitespace-nowrap">
          <a href="#overview" className="hover:text-[#F3CF7A] transition-colors">
            {program.shortCode} Overview
          </a>
          <a href="#eligibility" className="hover:text-[#F3CF7A] transition-colors">
            Who Can Join
          </a>
          <a href="#syllabus" className="hover:text-[#F3CF7A] transition-colors">
            Syllabus &amp; Subjects
          </a>
          <a href="#journey" className="hover:text-[#F3CF7A] transition-colors">
            Study Roadmap
          </a>
          <a href="#fees" className="hover:text-[#F3CF7A] transition-colors">
            Fees &amp; Scholarship
          </a>
          <a href="#faqs" className="hover:text-[#F3CF7A] transition-colors">
            FAQs
          </a>
        </div>
      </div>

      {/* Split Hero + Free Demo Live Backend Form */}
      <section className="relative bg-gradient-to-br from-[#FFF9F6] via-[#FAF2F3] to-[#F5E6E9] border-b border-[#EADFE2] py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Hero Story */}
          <div className="lg:col-span-7 space-y-5">
            <div className="text-xs font-semibold tracking-wider text-[#7A0F28]">
              {program.category} · {program.partnerNote}
            </div>

            <h1 className="font-editorial text-3xl sm:text-5xl font-bold text-[#1D1014] leading-[1.12]">
              Excel in{' '}
              <span className="inline-block bg-[#7A0F28] text-white px-3.5 py-1 rounded-xl mt-1">
                {program.shortCode}
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#4B3B40] leading-relaxed max-w-2xl">
              {program.subtitle}
            </p>

            {/* Quick Facts Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="rounded-xl bg-white border border-[#EADFE2] p-3.5 flex items-center gap-3">
                <BookOpen className="w-5 h-5 text-[#7A0F28] shrink-0" aria-hidden="true" />
                <div>
                  <div className="text-xs text-[#76646A]">Testing Pattern</div>
                  <div className="text-sm font-bold text-[#1D1014]">{program.examsCount}</div>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-[#EADFE2] p-3.5 flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#7A0F28] shrink-0" aria-hidden="true" />
                <div>
                  <div className="text-xs text-[#76646A]">Batch Duration</div>
                  <div className="text-sm font-bold text-[#1D1014]">{program.duration}</div>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-[#EADFE2] p-3.5 flex items-center gap-3">
                <Briefcase className="w-5 h-5 text-[#7A0F28] shrink-0" aria-hidden="true" />
                <div>
                  <div className="text-xs text-[#76646A]">Subjects / Focus</div>
                  <div className="text-sm font-bold text-[#1D1014]">{program.avgSalary}</div>
                </div>
              </div>
            </div>

            {/* Classroom Photo */}
            <div className="rounded-2xl overflow-hidden border border-[#EADFE2] aspect-[16/9] max-h-[300px]">
              <SafeImage
                src={program.heroImage}
                alt={program.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Right Form Card — Live Backend POST /api/public/inquiries */}
          <div className="lg:col-span-5">
            <EnquiryForm
              heading={`Book Free Demo for ${program.shortCode}`}
              subheading="Get syllabus booklet, monthly fee sheet, batch timings, and up to 50% scholarship info."
              ctaLabel={`Request ${program.shortCode} Demo`}
              defaultCourse={program.title}
              source={`course_page_${program.slug}`}
              courses={boot.courses}
              branches={boot.branches}
              compact
            />
          </div>
        </div>

        {/* Toppers Gold & Burgundy Banner */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 mt-10">
          <div className="rounded-2xl bg-gradient-to-r from-[#58091B] via-[#8C102B] to-[#58091B] p-6 sm:p-7 text-white shadow-[0_14px_34px_rgba(88,9,27,0.22)]">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-bold tracking-wider text-[#F3CF7A]">
                  <Award className="w-4 h-4" aria-hidden="true" />
                  <span>VERIFIED YUITOR RESULTS</span>
                </div>
                <div className="mt-1 font-editorial text-2xl sm:text-3xl font-bold text-white">
                  95%+ Toppers &amp; {program.passRate}
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                {TOP_ACHIEVERS.map((t) => (
                  <div
                    key={t.name}
                    className="rounded-xl bg-white text-[#1D1014] px-3 py-2.5 text-center"
                  >
                    <div className="text-xs font-bold truncate">{t.name}</div>
                    <div className="text-[11px] font-semibold text-[#7A0F28]">{t.score}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Overview & Eligibility */}
      <section id="overview" className="py-16 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
              About {program.title}
            </h2>
            <p className="mt-4 text-base text-[#4B3B40] leading-relaxed">{program.overview}</p>
            <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4">
                <div className="text-xs text-[#76646A]">Success Track</div>
                <div className="mt-1 font-mono tabular-nums text-lg font-bold text-[#7A0F28]">
                  {program.passRate}
                </div>
              </div>
              <div className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4">
                <div className="text-xs text-[#76646A]">Key Outcome</div>
                <div className="mt-1 text-sm font-bold text-[#1D1014]">
                  {program.placementHighlight}
                </div>
              </div>
              <div className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4">
                <div className="text-xs text-[#76646A]">ERP Access</div>
                <div className="mt-1 text-sm font-bold text-[#1D1014]">
                  Student &amp; Parent Portal Included
                </div>
              </div>
            </div>
          </div>

          <div id="eligibility" className="lg:col-span-5 rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-7">
            <h3 className="font-editorial text-2xl font-bold text-[#1D1014]">
              Who Should Join
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-[#4B3B40]">
              {program.eligibility.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#7A0F28] shrink-0 mt-1" aria-hidden="true" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Syllabus / Subjects Structure */}
      <section id="syllabus" className="py-16 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
            Subjects &amp; Curriculum Breakdown
          </h2>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-5">
            {program.syllabus.map((mod) => (
              <div key={mod.code} className="rounded-2xl bg-white border border-[#EADFE2] p-6">
                <div className="font-mono text-xs font-bold text-[#7A0F28]">{mod.code}</div>
                <h3 className="mt-1 font-editorial text-xl font-bold text-[#1D1014]">{mod.title}</h3>
                <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed">{mod.focus}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4-Step Study Journey */}
      <section id="journey" className="py-16 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
            How We Prepare You in {program.duration}
          </h2>
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {program.journeySteps.map((step) => (
              <div key={step.step} className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
                <div className="font-mono tabular-nums text-2xl font-bold text-[#7A0F28]">
                  {step.step}
                </div>
                <h3 className="mt-2 font-editorial text-lg font-bold text-[#1D1014]">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed">{step.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fees & Scholarship Strip */}
      <section id="fees" className="py-16 bg-[#24040C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div>
            <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
              Affordable Monthly Tuition &amp; Merit Scholarships
            </p>
            <h2 className="mt-2 font-editorial text-3xl font-bold text-white">
              {program.shortCode} Fee Structure
            </h2>
            <p className="mt-2 text-sm text-white/75 max-w-xl">
              Includes classroom teaching, printed chapter notes, Sunday tests, AI practice sheets, and full Student &amp; Parent Portal access. Up to 50% scholarship available for deserving students.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <div>
              <div className="text-xs text-white/65">Monthly Tuition</div>
              <div className="font-mono tabular-nums text-2xl font-bold text-[#F3CF7A]">
                {formatINR(program.monthlyFee)}/mo
              </div>
            </div>
            <div>
              <div className="text-xs text-white/65">Full Session Estimate</div>
              <div className="font-mono tabular-nums text-2xl font-bold text-white">
                {formatINR(program.totalFee)}
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <a
                href="/fee-calculator"
                onClick={(e) => go(e, '/fee-calculator')}
                className="inline-flex items-center gap-1.5 rounded-full bg-[#E6B450] hover:bg-[#F3CF7A] text-[#1D1014] font-bold px-5 py-3 text-sm transition-colors"
              >
                <span>Open Fee Calculator</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="/register/student"
                onClick={(e) => go(e, '/register/student')}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/30 hover:border-white px-5 py-3 text-sm font-semibold text-white transition-colors"
              >
                Student Registration
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section id="faqs" className="py-16 bg-[#FAF7F5]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
            Frequently Asked Questions
          </h2>
          <div className="mt-6 space-y-3">
            {program.faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={faq.q}
                  className="rounded-xl bg-white border border-[#EADFE2] overflow-hidden"
                >
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full px-5 py-4 flex items-center justify-between gap-4 text-left font-semibold text-sm sm:text-base text-[#1D1014] cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-[#7A0F28] shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-[#76646A] shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-4 text-sm text-[#5E4B51] leading-relaxed border-t border-[#F4EBEE] pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
