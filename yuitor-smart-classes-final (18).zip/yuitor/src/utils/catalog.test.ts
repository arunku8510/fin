import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateFeeSummary,
  filterBackendCourses,
  formatINR,
  isPortalPath,
  resolveRoute,
  validateInquiryPayload,
} from './catalog';
import { BOARD_LINKS, CLASS_LINKS, EXAM_LINKS, SKILL_LINKS, getProgramBySlug } from '../data/siteContent';

test('isPortalPath detects backend portal and admin gate paths accurately', () => {
  assert.equal(isPortalPath('/login'), true);
  assert.equal(isPortalPath('/register/student'), true);
  assert.equal(isPortalPath('/student/dashboard'), true);
  assert.equal(isPortalPath('/teacher/'), true);
  assert.equal(isPortalPath('/parent/'), true);
  assert.equal(isPortalPath('/staff/'), true);
  assert.equal(isPortalPath('/erp'), true);
  assert.equal(isPortalPath('/secret-admin-gate/panel', '/secret-admin-gate'), true);
  assert.equal(isPortalPath('/courses'), false);
  assert.equal(isPortalPath('/class/10'), false);
  assert.equal(isPortalPath('/about'), false);
});

test('catalog contains ONLY the exact 19 requested subjects and rejects removed subjects', () => {
  assert.equal(CLASS_LINKS.length, 7);
  assert.equal(BOARD_LINKS.length, 3);
  assert.equal(EXAM_LINKS.length, 6);
  assert.equal(SKILL_LINKS.length, 3);

  // Removed subjects MUST NOT resolve
  assert.deepEqual(resolveRoute('/class/5'), { page: 'not-found' });
  assert.deepEqual(resolveRoute('/board/cbse'), { page: 'not-found' });
  assert.deepEqual(resolveRoute('/ai-learning'), { page: 'not-found' });

  // Exact Classes 6 to 12
  for (let cls = 6; cls <= 12; cls++) {
    const resolved = resolveRoute(`/class/${cls}`);
    assert.deepEqual(resolved, { page: 'program', slug: `class-${cls}` });
    const prog = getProgramBySlug(`class-${cls}`);
    assert.ok(prog.title.includes(`Class ${cls}`), `Program title should mention Class ${cls}`);
  }

  // Exact Boards
  for (const board of ['up-board', 'icse', 'state-board']) {
    const resolved = resolveRoute(`/board/${board}`);
    assert.deepEqual(resolved, { page: 'program', slug: `board-${board}` });
    const prog = getProgramBySlug(`board-${board}`);
    assert.ok(prog.title.length > 5);
  }

  // Exact Competitive Exams
  for (const exam of ['neet', 'jee', 'cuet', 'nda', 'ssc', 'banking']) {
    const resolved = resolveRoute(`/exam/${exam}`);
    assert.deepEqual(resolved, { page: 'program', slug: `exam-${exam}` });
    const prog = getProgramBySlug(`exam-${exam}`);
    assert.ok(prog.title.length > 5);
  }

  // Exact Skill Courses
  assert.deepEqual(resolveRoute('/course/computer'), { page: 'program', slug: 'computer' });
  assert.deepEqual(resolveRoute('/computer-courses'), { page: 'program', slug: 'computer' });
  assert.deepEqual(resolveRoute('/course/spoken-english'), { page: 'program', slug: 'spoken-english' });
  assert.deepEqual(resolveRoute('/english-speaking'), { page: 'program', slug: 'spoken-english' });
  assert.deepEqual(resolveRoute('/course/coding'), { page: 'program', slug: 'coding' });

  // Core Website & Portal Pages
  assert.deepEqual(resolveRoute('/'), { page: 'home' });
  assert.deepEqual(resolveRoute('/courses'), { page: 'courses', presetCategory: 'All' });
  assert.deepEqual(resolveRoute('/subjects'), { page: 'courses', presetCategory: 'Subjects' });
  assert.deepEqual(resolveRoute('/about'), { page: 'about', tab: 'about' });
  assert.deepEqual(resolveRoute('/teachers'), { page: 'about', tab: 'teachers' });
  assert.deepEqual(resolveRoute('/contact'), { page: 'contact' });
  assert.deepEqual(resolveRoute('/admission'), { page: 'contact', isAdmission: true });
  assert.deepEqual(resolveRoute('/results'), { page: 'alumni', tab: 'results' });
  assert.deepEqual(resolveRoute('/testimonials'), { page: 'alumni', tab: 'testimonials' });
  assert.deepEqual(resolveRoute('/gallery'), { page: 'gallery' });
  assert.deepEqual(resolveRoute('/fee-calculator'), { page: 'fee-calculator' });
  assert.deepEqual(resolveRoute('/scholarship'), { page: 'scholarship' });
  assert.deepEqual(resolveRoute('/comparison'), { page: 'comparison' });
  assert.deepEqual(resolveRoute('/faqs'), { page: 'faqs' });
  assert.deepEqual(resolveRoute('/blog/study-tips'), { page: 'blogs', slug: 'study-tips' });
  assert.deepEqual(resolveRoute('/privacy'), { page: 'legal', doc: 'privacy' });
  assert.deepEqual(resolveRoute('/terms'), { page: 'legal', doc: 'terms' });
  assert.deepEqual(resolveRoute('/refund'), { page: 'legal', doc: 'refund' });
  assert.deepEqual(resolveRoute('/cookie-policy'), { page: 'legal', doc: 'cookies' });
  assert.deepEqual(resolveRoute('/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/student/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/teacher/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/student-login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/teacher-login'), { page: 'portal' });

  // Zero-404 Course & Info Aliases
  assert.deepEqual(resolveRoute('/course/class-10'), { page: 'program', slug: 'class-10' });
  assert.deepEqual(resolveRoute('/course/exam-neet'), { page: 'program', slug: 'exam-neet' });
  assert.deepEqual(resolveRoute('/course/board-up-board'), { page: 'program', slug: 'board-up-board' });
  assert.deepEqual(resolveRoute('/classes/12'), { page: 'program', slug: 'class-12' });
  assert.deepEqual(resolveRoute('/admissions'), { page: 'contact', isAdmission: true });
  assert.deepEqual(resolveRoute('/faq'), { page: 'faqs' });
  assert.deepEqual(resolveRoute('/fees'), { page: 'fee-calculator' });
  assert.deepEqual(resolveRoute('/faculty'), { page: 'about', tab: 'teachers' });
});

test('validateInquiryPayload rejects invalid fields and accepts valid submissions', () => {
  const invalid = validateInquiryPayload({
    name: 'A',
    phone: '12345',
    email: 'not-an-email',
    class_or_course: '',
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.phone);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.class_or_course);

  const valid = validateInquiryPayload({
    name: 'Ananya Verma',
    phone: '+91 78272 89292',
    email: 'inquiry@yuitor.com',
    class_or_course: 'Class 10',
  });
  assert.equal(valid.valid, true);
  assert.deepEqual(valid.errors, {});
});

test('calculateFeeSummary computes lump-sum discount, scholarship, and installments deterministically', () => {
  const result = calculateFeeSummary({
    baseTotalFee: 20000,
    plan: 'lump-sum',
    months: 12,
    scholarshipPercent: 20,
    includeEvalSupport: false,
  });
  assert.equal(result.grossFee, 20000);
  assert.equal(result.scholarshipDiscount, 4000);
  assert.equal(result.planDiscount, 1600);
  assert.equal(result.evalSupportFee, 0);
  assert.equal(result.netPayable, 14400);
  assert.equal(result.installmentCount, 1);
  assert.equal(formatINR(result.netPayable), '₹14,400');
});

test('filterBackendCourses filters by category and search query', () => {
  const sample = [
    { id: 1, title: 'Class 10 UP Board Mastery', category: 'Classes 6-12', monthly_fee: 1400 },
    { id: 2, title: 'NEET Coaching Batch', category: 'Competitive', monthly_fee: 2400 },
    { id: 3, title: 'Coding Classes (Python)', category: 'Coding', monthly_fee: 1500 },
  ];
  assert.equal(filterBackendCourses(sample, 'all', '').length, 3);
  assert.equal(filterBackendCourses(sample, 'Competitive', '').length, 1);
  assert.equal(filterBackendCourses(sample, 'all', 'python').length, 1);
});
