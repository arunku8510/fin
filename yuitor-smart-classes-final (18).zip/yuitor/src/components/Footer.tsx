import React from 'react';
import { Phone, Mail, MapPin, ShieldAlert } from 'lucide-react';
import {
  BOARD_LINKS,
  BRAND_INFO,
  CLASS_LINKS,
  EXAM_LINKS,
  SKILL_LINKS,
} from '../data/siteContent';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  return (
    <footer className="yu-shared-footer bg-[#18060B] text-white/90 border-t border-[#3E1320]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-16 pb-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Col 1: Authentic Yuitor Smart Classes Brand & Exact Contact Details */}
          <div className="space-y-4">
            <a
              href="/"
              onClick={(e) => go(e, '/')}
              className="inline-flex items-center gap-3 group"
            >
              <img
                src={BRAND_INFO.logo}
                alt="Yuitor Smart Classes Logo"
                className="w-12 h-12 rounded-full object-contain bg-white p-0.5 border border-[#E6B450]/50 shrink-0"
              />
              <div className="flex flex-col">
                <span className="font-editorial text-xl font-bold text-white leading-tight">
                  {BRAND_INFO.name}
                </span>
                <span className="font-editorial italic text-[13px] text-[#F3CF7A] tracking-wide leading-tight mt-0.5">
                  Ek Kadam Safalta Ki Our
                </span>
              </div>
            </a>
            <div className="space-y-2.5 text-xs text-white/80 pt-1">
              <a href={BRAND_INFO.phoneHref} className="flex items-center gap-2 hover:text-[#F3CF7A]">
                <Phone className="w-3.5 h-3.5 text-[#E6B450] shrink-0" aria-hidden="true" />
                <span className="font-mono tabular-nums">{BRAND_INFO.phoneDisplay}</span>
              </a>
              <a href={`mailto:${BRAND_INFO.email}`} className="flex items-center gap-2 hover:text-[#F3CF7A]">
                <Mail className="w-3.5 h-3.5 text-[#E6B450] shrink-0" aria-hidden="true" />
                <span>{BRAND_INFO.email}</span>
              </a>
              <a href={`mailto:${BRAND_INFO.complaintsEmail}`} className="flex items-center gap-2 hover:text-[#F3CF7A]">
                <ShieldAlert className="w-3.5 h-3.5 text-[#E6B450] shrink-0" aria-hidden="true" />
                <span>Complaints: {BRAND_INFO.complaintsEmail}</span>
              </a>
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#E6B450] shrink-0 mt-0.5" aria-hidden="true" />
                <span className="leading-relaxed">{BRAND_INFO.address}</span>
              </div>
            </div>
          </div>

          {/* Col 2: Classes 6-12 */}
          <div>
            <h4 className="font-editorial text-base font-semibold text-[#F3CF7A] mb-4">
              Classes 6th – 12th
            </h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              {CLASS_LINKS.map((item) => (
                <li key={item.path}>
                  <a
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="hover:text-white transition-colors"
                  >
                    {item.label} Coaching
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Boards & Competitive Exams */}
          <div>
            <h4 className="font-editorial text-base font-semibold text-[#F3CF7A] mb-4">
              Boards &amp; Exams
            </h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              {[...BOARD_LINKS, ...EXAM_LINKS].map((item) => (
                <li key={item.path}>
                  <a
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Skill Courses & Academic Tools */}
          <div>
            <h4 className="font-editorial text-base font-semibold text-[#F3CF7A] mb-4">
              Skill Courses &amp; Info
            </h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              {[
                ...SKILL_LINKS,
                { label: 'All Courses & Fees', path: '/courses' },
                { label: 'Subjects Directory', path: '/subjects' },
                { label: 'Fee Calculator', path: '/fee-calculator' },
                { label: 'Scholarships', path: '/scholarship' },
                { label: 'Why Yuitor (Comparison)', path: '/comparison' },
                { label: 'Study Blog & Tips', path: '/blog' },
              ].map((item) => (
                <li key={item.path}>
                  <a
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 5: Institute */}
          <div>
            <h4 className="font-editorial text-base font-semibold text-[#F3CF7A] mb-4">
              Institute
            </h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              {[
                { label: 'About Us', path: '/about' },
                { label: 'Faculty & Teachers', path: '/teachers' },
                { label: 'Results & Toppers', path: '/results' },
                { label: 'Testimonials', path: '/testimonials' },
                { label: 'Campus Gallery', path: '/gallery' },
                { label: 'Admissions & Free Demo', path: '/admission' },
                { label: 'Contact Us', path: '/contact' },
                { label: 'FAQs', path: '/faqs' },
              ].map((item) => (
                <li key={item.path}>
                  <a
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Copyright & Legal */}
        <div className="pt-7 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/60">
          <p>Copyright © {new Date().getFullYear()} {BRAND_INFO.name}, Muradnagar. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4">
            <a href="/terms" onClick={(e) => go(e, '/terms')} className="hover:text-white">
              Terms of Service
            </a>
            <span aria-hidden="true">|</span>
            <a href="/privacy" onClick={(e) => go(e, '/privacy')} className="hover:text-white">
              Privacy Policy
            </a>
            <span aria-hidden="true">|</span>
            <a href="/refund" onClick={(e) => go(e, '/refund')} className="hover:text-white">
              Refund Policy
            </a>
            <span aria-hidden="true">|</span>
            <a href="/cookie-policy" onClick={(e) => go(e, '/cookie-policy')} className="hover:text-white">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
