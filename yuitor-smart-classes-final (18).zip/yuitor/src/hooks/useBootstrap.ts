import { useEffect, useState } from 'react';
import type { BootstrapData, InquiryPayload } from '../types';

const EMPTY_BOOTSTRAP: BootstrapData = {
  courses: [],
  subjects: [],
  teachers: [],
  faqs: [],
  testimonials: [],
  announcements: [],
  blogs: [],
  branches: [],
  batches: [],
  departmentEmails: {},
  settings: {},
};

let cachedBootstrap: BootstrapData | null = null;
let inflightPromise: Promise<BootstrapData> | null = null;

async function fetchBootstrapOnce(): Promise<BootstrapData> {
  if (cachedBootstrap) return cachedBootstrap;
  if (inflightPromise) return inflightPromise;

  inflightPromise = fetch('/api/public/bootstrap', {
    credentials: 'same-origin',
    headers: { Accept: 'application/json' },
  })
    .then(async (res) => {
      if (!res.ok) throw new Error(`Bootstrap failed (${res.status})`);
      const json = await res.json();
      const normalized: BootstrapData = {
        courses: Array.isArray(json.courses) ? json.courses : [],
        subjects: Array.isArray(json.subjects) ? json.subjects : [],
        teachers: Array.isArray(json.teachers) ? json.teachers : [],
        faqs: Array.isArray(json.faqs) ? json.faqs : [],
        testimonials: Array.isArray(json.testimonials) ? json.testimonials : [],
        announcements: Array.isArray(json.announcements) ? json.announcements : [],
        blogs: Array.isArray(json.blogs) ? json.blogs : [],
        branches: Array.isArray(json.branches) ? json.branches : [],
        batches: Array.isArray(json.batches) ? json.batches : [],
        departmentEmails: json.departmentEmails || {},
        settings: json.settings || {},
      };
      cachedBootstrap = normalized;
      return normalized;
    })
    .catch(() => EMPTY_BOOTSTRAP)
    .finally(() => {
      inflightPromise = null;
    });

  return inflightPromise;
}

export function useBootstrap() {
  const [data, setData] = useState<BootstrapData>(cachedBootstrap || EMPTY_BOOTSTRAP);
  const [loading, setLoading] = useState(!cachedBootstrap);

  useEffect(() => {
    let active = true;
    fetchBootstrapOnce().then((res) => {
      if (active) {
        setData(res);
        setLoading(false);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  return { data, loading };
}

function getCsrfToken(): string {
  if (typeof document === 'undefined') return '';
  const match = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}

export async function submitPublicInquiry(
  payload: InquiryPayload
): Promise<{ ok: boolean; message: string }> {
  const csrf = getCsrfToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
  if (csrf) headers['X-CSRF-Token'] = csrf;
  const res = await fetch('/api/public/inquiries', {
    method: 'POST',
    credentials: 'same-origin',
    headers,
    body: JSON.stringify(payload),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json.error || 'Could not submit enquiry. Please verify your details.');
  }
  return {
    ok: true,
    message:
      json.message ||
      'Thank you! Your enquiry has been recorded. Our academic counsellor will reach out shortly.',
  };
}
