# Yuitor Smart Classes — cPanel Shared Hosting Deployment Guide

This package is pre-built for **Shared Hosting (cPanel / CloudLinux / LiteSpeed)** with **no SSH build step, no Redis, no Supervisor, and no `exec()`/`shell_exec()` required**.

`yuitor-deploy-shared-hosting.zip` is **1-Unzip Ready for cPanel CloudLinux**: extract it once in your **cPanel Home Directory** (`/home/YOUR_CPANEL_USER/`), and **no moving files between folders is needed**.

*(Note: CloudLinux / cPanel Setup Node.js App rejects `Directory "public_html" not allowed`. Using `yuitor` as the Application Root solves this cleanly while keeping your database, logs, and `.env` outside `public_html`.)*

---

## Quick 3-Step Install (Zero File Moving)

### Step 1: Upload & Extract Inside Home Directory (`/home/YOUR_CPANEL_USER/`)
1. Open **cPanel -> File Manager**. You start in your **Home Directory** (`/home/YOUR_CPANEL_USER/` — **do NOT go inside `public_html/`**).
2. Upload `yuitor-deploy-shared-hosting.zip` right there and click **Extract**.
   - This creates one folder: `/home/YOUR_CPANEL_USER/yuitor/` (containing `public/`, `data/`, `backups/`, `logs/`, `database/`, `scripts/`, `node_modules/`, `server.js`, and `app.cjs`).
3. If `public_html/` has old files from an earlier upload, delete those old site files inside `public_html/` (keep `.well-known/` if present for SSL).
4. Verify folder permissions inside `yuitor/`: `data/`, `backups/`, `logs/`, and `uploads/` are `755` (`server.js` and `app.cjs` `644`).

### Step 2: Create & Start Node.js App in cPanel
Open **cPanel -> Setup Node.js App -> Create Application**:
- **Node.js Version:** `22.x` (required for built-in `node:sqlite`)
- **Application Mode:** `Production`
- **Application Root:** `yuitor` *(never type `public_html` here)*
- **Application URL:** `yuitor.com`
- **Application Startup File:** `app.cjs`

*(No `.env` edit and no `npm install` are required before starting! `node_modules/` is already pre-bundled inside `yuitor/`, `SESSION_SECRET` auto-generates safely in SQLite, `yuitor/public/` is detected automatically, and your stealth slug is bootstrapped from `database/initial-gate.txt`. If cPanel shows **"Detected configuration files -> Run NPM Install"**, you can skip clicking it and directly click **Start App** — and even if you click it in Production mode, only the 7 lightweight backend packages are checked.)*
Click **Create** and **Start App**. cPanel Phusion Passenger will route `https://yuitor.com/*` directly to your Node app.

### Step 3: Run the OTP-Protected Stealth Installer
Open your release's stealth Installer URL printed when the ZIP was built:
```
https://yuitor.com/<your-yt-ctrl-XXXX-gate>/setup
```
1. Inspect the **Pre-Install Requirements Check** (`Node >= 22`, `node:sqlite`, core files, writable folders, DB connectivity).
2. **Step 1A (cPanel Mail SSL/TLS):** Confirm your cPanel SMTP details (`mail.yuitor.com`, Port `465` SSL/TLS, Username `no-reply@yuitor.com`, mailbox password) and your preferred **OTP Recipient Email** (defaults to `info@yuitor.com` or `ADMIN_OTP_EMAIL` in `.env`).
3. **Step 1B — Verify Owner Identity:** Click **Send OTP** and enter the 6-digit OTP from your configured inbox.
4. **Step 2:** Create the first **Super Admin** account and click **Verify OTP & Complete Setup**. The installer permanently locks afterwards.
5. Bookmark your **Secret Admin Gate Login URL** (`https://yuitor.com/<your-yt-ctrl-XXXX-gate>/`). Every future admin sign-in verifies your password first and then emails a fresh 6-digit OTP to your configured `ADMIN_OTP_EMAIL`.
6. Confirm `/admin`, `/admin/login`, `/wp-admin`, and `/login-admin` return `404`.

---

### Fixing `404 Not Found` or `Directory "public_html" not allowed`
1. **`Directory "public_html" not allowed`:** Never set `Application Root` to `public_html`. Extract the ZIP in your Home Directory (`/home/USER/`) and set `Application Root` = `yuitor`.
2. **Do NOT visit `/admin` or `/admin/setup`:** Predictable admin URLs intentionally return `404`. Always use your stealth slug (`yt-ctrl-XXXX-gate`).
3. **Check Node.js App status:** In cPanel **Setup Node.js App**, confirm the app is **Running** with Application Root `yuitor`, Application URL `yuitor.com`, and Startup File `app.cjs`.
4. **Stale files in `public_html/`:** Ensure `public_html/` does not contain an old conflicting `index.html` / `.htaccess` overwriting cPanel's `# DO NOT REMOVE. CLOUDLINUX PASSENGER CONFIGURATION` block.

### Optional Cron Job (Scheduled Email Campaigns)
Open **cPanel -> Cron Jobs** and add one entry running every **5 minutes**:
```
*/5 * * * * /home/YOUR_CPANEL_USER/nodevenv/yuitor/22/bin/node /home/YOUR_CPANEL_USER/yuitor/scripts/run-scheduled.mjs >/dev/null 2>&1
```

*(Need separate `public_html/` + `yuitor_core/` Layout A instead? Build with `node scripts/build-shared-hosting.mjs --layout-a`.)*
