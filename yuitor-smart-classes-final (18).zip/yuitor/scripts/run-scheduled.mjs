// server/cron.ts
import "dotenv/config";

// server/db.ts
import fs from "node:fs";
import path from "node:path";
import crypto2 from "node:crypto";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

// server/security.ts
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
var SESSION_TTL_SECONDS = 60 * 60 * 12;
var IMPERSONATION_TTL_SECONDS = 60 * 30;
var OTP_TTL_SECONDS = 60 * 10;
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function normalizePhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith("0")) {
    return digits.slice(1);
  }
  return digits;
}
function normalizeEmail(raw) {
  return String(raw ?? "").trim().toLowerCase();
}
function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] || c);
}
function decryptVaultSecret(payload, keyBuf) {
  const raw = String(payload || "").trim();
  if (!raw.startsWith("enc:v1:")) return "";
  const parts = raw.split(":");
  if (parts.length !== 5) return "";
  try {
    const iv = Buffer.from(parts[2], "hex");
    const tag = Buffer.from(parts[3], "hex");
    const data = Buffer.from(parts[4], "hex");
    const decipher = crypto.createDecipheriv("aes-256-gcm", keyBuf, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

// server/settings.ts
var SETTING_DEFINITIONS = [
  {
    key: "APP_URL",
    category: "general",
    label: "Public App URL (APP_URL)",
    description: "Primary live domain URL used in emails, unsubscribe links, and origin checks.",
    isSecret: false,
    defaultValue: "https://yuitor.com",
    placeholder: "https://yuitor.com",
    inputType: "url"
  },
  {
    key: "SESSION_SECRET",
    category: "general",
    label: "Session Signing Secret (SESSION_SECRET)",
    description: "Strong random secret (min 16 chars, recommended 64-char hex) for signing cookies, OTPs, and download links.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter or generate a strong 64-char hex secret",
    inputType: "password"
  },
  {
    key: "YU_ADMIN_SETUP_KEY",
    category: "general",
    label: "First-Admin Setup Key (YU_ADMIN_SETUP_KEY)",
    description: "Optional security key required when creating the first Super Admin in the installer.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Optional secret key for installer setup",
    inputType: "password"
  },
  {
    key: "ADMIN_IP_ALLOWLIST",
    category: "general",
    label: "Admin IP Allow-List (Optional)",
    description: "Optional comma-separated IPs or IPv4 CIDRs allowed to sign into the Admin Gate (leave blank for any IP).",
    isSecret: false,
    defaultValue: "",
    placeholder: "e.g. 127.0.0.1, 203.0.113.0/24",
    inputType: "text"
  },
  {
    key: "ADMIN_OTP_EMAIL",
    category: "general",
    label: "Admin & Installer 2FA OTP Email (ADMIN_OTP_EMAIL)",
    description: "Verification email address that receives a 6-digit OTP for Installer verification and every Admin Console sign-in.",
    isSecret: false,
    defaultValue: "info@yuitor.com",
    placeholder: "admin@yuitor.com",
    inputType: "email"
  },
  {
    key: "GEMINI_API_KEY",
    category: "ai",
    label: "Google Gemini API Key (GEMINI_API_KEY)",
    description: "Enables live Gemini LLM responses for Shreya Smart AI (deterministic bilingual fallback runs when unset).",
    isSecret: true,
    defaultValue: "",
    placeholder: "AIza...",
    inputType: "password"
  },
  {
    key: "GEMINI_MODEL",
    category: "ai",
    label: "Gemini Model Name (GEMINI_MODEL)",
    description: "Gemini model ID used for live Shreya AI replies (recommended: gemini-2.5-flash).",
    isSecret: false,
    defaultValue: "gemini-2.5-flash",
    placeholder: "gemini-2.5-flash",
    inputType: "text"
  },
  {
    key: "SMTP_HOST",
    category: "email",
    label: "SMTP Host (SMTP_HOST)",
    description: "Outgoing mail server hostname (e.g. mail.yuitor.com).",
    isSecret: false,
    defaultValue: "",
    placeholder: "mail.yuitor.com",
    inputType: "text"
  },
  {
    key: "SMTP_PORT",
    category: "email",
    label: "SMTP Port (SMTP_PORT)",
    description: "SMTP port number (465 for SSL/TLS recommended on cPanel, 587 for STARTTLS).",
    isSecret: false,
    defaultValue: "465",
    placeholder: "465",
    inputType: "number"
  },
  {
    key: "SMTP_SECURE",
    category: "email",
    label: "Use SSL/TLS (SMTP_SECURE)",
    description: "Enable direct TLS (true for port 465 SSL/TLS, false for port 587 STARTTLS).",
    isSecret: false,
    defaultValue: "true",
    placeholder: "true",
    inputType: "boolean"
  },
  {
    key: "SMTP_USER",
    category: "email",
    label: "SMTP Username (SMTP_USER)",
    description: "Authenticated email login username.",
    isSecret: false,
    defaultValue: "",
    placeholder: "no-reply@yuitor.com",
    inputType: "text"
  },
  {
    key: "SMTP_PASS",
    category: "email",
    label: "SMTP Password (SMTP_PASS)",
    description: "SMTP mailbox password or app password (stored securely on server).",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter SMTP password or app password",
    inputType: "password"
  },
  {
    key: "MAIL_FROM_NAME",
    category: "email",
    label: "Sender Display Name (MAIL_FROM_NAME)",
    description: "Display name shown in outgoing emails.",
    isSecret: false,
    defaultValue: "Yuitor Smart Classes",
    placeholder: "Yuitor Smart Classes",
    inputType: "text"
  },
  {
    key: "MAIL_FROM_EMAIL",
    category: "email",
    label: "Sender Email (MAIL_FROM_EMAIL)",
    description: "From address for system & marketing emails (default: no-reply@yuitor.com).",
    isSecret: false,
    defaultValue: "no-reply@yuitor.com",
    placeholder: "no-reply@yuitor.com",
    inputType: "email"
  },
  {
    key: "REPLY_TO_EMAIL",
    category: "email",
    label: "Reply-To Email (REPLY_TO_EMAIL)",
    description: "Address where replies from students/parents are delivered.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "ADMIN_NOTIFY_EMAIL",
    category: "email",
    label: "Admin Alert Email (ADMIN_NOTIFY_EMAIL)",
    description: "Recipient email for new admission enquiries and registration approvals.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_ADMISSION",
    category: "email",
    label: "Department: Admissions Email",
    description: "Shown on Admission & Contact sections and used as Reply-To for enquiry/admission notifications.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_INQUIRY",
    category: "email",
    label: "Department: General Inquiry Email",
    description: "Primary public general inquiry address in header, footer, and contact cards.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_COMPLAIN",
    category: "email",
    label: "Department: Complaints Email",
    description: "Official complaints address displayed in footer, contact, and student support sections.",
    isSecret: false,
    defaultValue: "complain@yuitor.com",
    placeholder: "complain@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_SUPPORT",
    category: "email",
    label: "Department: Student & Portal Support Email",
    description: "Technical and student support contact inside Contact & Student Support portal tabs.",
    isSecret: false,
    defaultValue: "support@yuitor.com",
    placeholder: "support@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_GRIEVANCE",
    category: "email",
    label: "Department: Academic Grievance Email",
    description: "Escalation & dispute contact linked on Terms of Use and Student Support.",
    isSecret: false,
    defaultValue: "grievance@yuitor.com",
    placeholder: "grievance@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_FEE",
    category: "email",
    label: "Department: Fee & Billing Desk Email",
    description: "Reply-To for fee receipts and shown inside Student Fees & Receipts.",
    isSecret: false,
    defaultValue: "fee@yuitor.com",
    placeholder: "fee@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_CAREER",
    category: "email",
    label: "Department: Faculty Careers Email",
    description: "Contact email for teaching applications & resume queries on Teacher Registration.",
    isSecret: false,
    defaultValue: "career@yuitor.com",
    placeholder: "career@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_PRIVACY",
    category: "email",
    label: "Department: Privacy & Data Officer Email",
    description: "Data protection contact email displayed on Privacy Policy.",
    isSecret: false,
    defaultValue: "privacy@yuitor.com",
    placeholder: "privacy@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_REFUND",
    category: "email",
    label: "Department: Refund Desk Email",
    description: "Refund requests & withdrawal contact linked on Refund Policy and Fees.",
    isSecret: false,
    defaultValue: "refund@yuitor.com",
    placeholder: "refund@yuitor.com",
    inputType: "email"
  },
  {
    key: "FAST2SMS_API_KEY",
    category: "sms",
    label: "Fast2SMS API Key (FAST2SMS_API_KEY)",
    description: "Sends live 6-digit SMS OTPs to mobile numbers during registration and password reset.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Fast2SMS authorization key",
    inputType: "password"
  },
  {
    key: "FAST2SMS_ROUTE",
    category: "sms",
    label: "Fast2SMS Route (FAST2SMS_ROUTE)",
    description: "Choose 'q' for Quick SMS, 'otp' for OTP route, or 'dlt' for TRAI DLT approved templates.",
    isSecret: false,
    defaultValue: "q",
    placeholder: "q",
    inputType: "text"
  },
  {
    key: "FAST2SMS_SENDER_ID",
    category: "sms",
    label: "Fast2SMS Sender ID (Optional)",
    description: "Approved 6-character DLT sender ID (e.g. YUITOR) when using DLT route.",
    isSecret: false,
    defaultValue: "",
    placeholder: "YUITOR",
    inputType: "text"
  },
  {
    key: "FAST2SMS_DLT_TEMPLATE_ID",
    category: "sms",
    label: "Fast2SMS DLT Template ID (Optional)",
    description: "Registered TRAI DLT Template/Message ID when FAST2SMS_ROUTE is set to dlt.",
    isSecret: false,
    defaultValue: "",
    placeholder: "17071...",
    inputType: "text"
  },
  {
    key: "WHATSAPP_ACCESS_TOKEN",
    category: "sms",
    label: "WhatsApp Cloud API Access Token (Optional)",
    description: "Meta WhatsApp Business Cloud API Bearer token for automated one-click WhatsApp fee & attendance alerts (1-click wa.me links work without token).",
    isSecret: true,
    defaultValue: "",
    placeholder: "EAAG...",
    inputType: "password"
  },
  {
    key: "WHATSAPP_PHONE_NUMBER_ID",
    category: "sms",
    label: "WhatsApp Phone Number ID (Optional)",
    description: "Meta WhatsApp Business Phone Number ID paired with WHATSAPP_ACCESS_TOKEN.",
    isSecret: false,
    defaultValue: "",
    placeholder: "1029384756...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_ID",
    category: "payments",
    label: "Razorpay Key ID (RAZORPAY_KEY_ID)",
    description: "Public Razorpay Merchant Key ID (starts with rzp_live_ or rzp_test_).",
    isSecret: false,
    defaultValue: "",
    placeholder: "rzp_live_...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_SECRET",
    category: "payments",
    label: "Razorpay Key Secret (RAZORPAY_KEY_SECRET)",
    description: "Secret key used to create Razorpay orders and verify HMAC-SHA256 payment signatures.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter Razorpay key secret",
    inputType: "password"
  },
  {
    key: "RAZORPAY_WEBHOOK_SECRET",
    category: "payments",
    label: "Razorpay Webhook Secret (Optional)",
    description: "Webhook signing secret used to verify incoming Razorpay webhook events.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter webhook secret",
    inputType: "password"
  }
];
var SETTING_MAP = new Map(SETTING_DEFINITIONS.map((d) => [d.key, d]));
var ENV_BASELINE = /* @__PURE__ */ new Map();
var baselineCaptured = false;
function captureEnvBaseline() {
  if (baselineCaptured) return;
  for (const def of SETTING_DEFINITIONS) {
    ENV_BASELINE.set(def.key, process.env[def.key]);
  }
  baselineCaptured = true;
}
function hydrateRuntimeSettings(db) {
  captureEnvBaseline();
  const rows = db.prepare("SELECT key, value FROM system_settings").all();
  const dbMap = new Map(rows.map((r) => [r.key, String(r.value ?? "")]));
  for (const def of SETTING_DEFINITIONS) {
    const saved = dbMap.get(def.key);
    if (saved !== void 0 && saved.trim() !== "") {
      process.env[def.key] = saved;
    } else {
      const orig = ENV_BASELINE.get(def.key);
      if (orig !== void 0) {
        process.env[def.key] = orig;
      } else {
        delete process.env[def.key];
      }
    }
  }
  hydrateRuntimeSettingsExtra(dbMap);
}
function hydrateRuntimeSettingsExtra(dbMap) {
  const adminPathSaved = dbMap.get("ADMIN_PATH");
  if (adminPathSaved !== void 0 && adminPathSaved.trim() !== "") {
    process.env.ADMIN_PATH = adminPathSaved.trim();
  }
}
function getDepartmentEmails() {
  const pick = (key, fallback) => {
    const val = String(process.env[key] || "").trim();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val) ? val : fallback;
  };
  return {
    admission: pick("EMAIL_ADMISSION", "admission@yuitor.com"),
    support: pick("EMAIL_SUPPORT", "support@yuitor.com"),
    grievance: pick("EMAIL_GRIEVANCE", "grievance@yuitor.com"),
    fee: pick("EMAIL_FEE", "fee@yuitor.com"),
    career: pick("EMAIL_CAREER", "career@yuitor.com"),
    privacy: pick("EMAIL_PRIVACY", "privacy@yuitor.com"),
    refund: pick("EMAIL_REFUND", "refund@yuitor.com"),
    inquiry: pick("EMAIL_INQUIRY", "inquiry@yuitor.com"),
    complain: pick("EMAIL_COMPLAIN", "complain@yuitor.com")
  };
}

// server/db.ts
function resolveAppRoot() {
  const hasPublicContext = (dir) => fs.existsSync(path.join(dir, "public")) || fs.existsSync(path.join(dir, "index.html")) || fs.existsSync(path.resolve(dir, "..", "public_html"));
  const candidates = [];
  try {
    const selfDir = path.dirname(fileURLToPath(import.meta.url));
    candidates.push(selfDir, path.resolve(selfDir, ".."));
  } catch {
  }
  candidates.push(process.cwd());
  if (process.argv[1]) {
    const argvDir = path.dirname(path.resolve(process.argv[1]));
    candidates.push(argvDir, path.resolve(argvDir, ".."));
  }
  for (const dir of candidates) {
    if (fs.existsSync(path.join(dir, "database")) && hasPublicContext(dir)) {
      return dir;
    }
  }
  return process.cwd();
}
var APP_ROOT = resolveAppRoot();
function resolvePublicDir(appRoot = APP_ROOT) {
  const envDir = (process.env.YUITOR_PUBLIC_DIR || "").trim();
  if (envDir) {
    const resolved = path.isAbsolute(envDir) ? envDir : path.resolve(appRoot, envDir);
    if (fs.existsSync(resolved)) {
      return resolved;
    }
  }
  const bundledPublic = path.join(appRoot, "public");
  if (fs.existsSync(bundledPublic)) {
    return bundledPublic;
  }
  if (fs.existsSync(path.join(appRoot, "index.html"))) {
    return appRoot;
  }
  const siblingPublicHtml = path.resolve(appRoot, "..", "public_html");
  if (fs.existsSync(siblingPublicHtml)) {
    return siblingPublicHtml;
  }
  return bundledPublic;
}
var PUBLIC_DIR = resolvePublicDir();
var DATA_DIR = path.join(APP_ROOT, "data");
var BACKUPS_DIR = path.join(APP_ROOT, "backups");
var LOGS_DIR = path.join(APP_ROOT, "logs");
var UPLOADS_DIR = path.join(APP_ROOT, "uploads");
var RESUMES_DIR = path.join(UPLOADS_DIR, "resumes");
var KNOWLEDGE_DIR = path.join(UPLOADS_DIR, "knowledge");
var DB_PATH = path.join(DATA_DIR, "yuitor.db");
var LEGACY_DB_PATH = path.join(DATA_DIR, "legacy-portal.sqlite");
var MIGRATION_PATH = path.join(APP_ROOT, "database", "migrations", "001_unified_portal.sql");
var dbInstance = null;
function addMissingColumn(db, table, col, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === col)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
function upgradeUsersRoleConstraintIfNeeded(db) {
  const row = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
  const sql = String(row?.sql || "");
  if (!sql || sql.includes("'parent'")) {
    return;
  }
  db.exec("PRAGMA foreign_keys = OFF;");
  db.exec("BEGIN IMMEDIATE;");
  try {
    db.exec(`
      CREATE TABLE users_upgraded (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL CHECK (role IN ('super_admin', 'admin', 'teacher', 'student', 'parent', 'staff')),
        staff_role TEXT NOT NULL DEFAULT '',
        staff_permissions_json TEXT NOT NULL DEFAULT '[]',
        branch_id INTEGER,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL COLLATE NOCASE UNIQUE,
        phone TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        avatar_url TEXT NOT NULL DEFAULT '',
        mobile_verified INTEGER NOT NULL DEFAULT 0,
        verification_status TEXT NOT NULL DEFAULT 'pending_otp'
          CHECK (verification_status IN ('pending_otp', 'otp_verified', 'pending_approval', 'approved', 'rejected', 'suspended')),
        is_active INTEGER NOT NULL DEFAULT 1,
        marketing_opt_in INTEGER NOT NULL DEFAULT 1,
        unsubscribe_token TEXT NOT NULL UNIQUE,
        last_login_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      INSERT INTO users_upgraded (
        id, role, full_name, email, phone, password_hash, avatar_url, mobile_verified,
        verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at
      )
      SELECT
        id, role, full_name, email, phone, password_hash, avatar_url, mobile_verified,
        verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at
      FROM users;
      DROP TABLE users;
      ALTER TABLE users_upgraded RENAME TO users;
      CREATE INDEX IF NOT EXISTS idx_users_role_status ON users(role, verification_status);
      CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    `);
    db.exec("COMMIT;");
  } catch (err) {
    try {
      db.exec("ROLLBACK;");
    } catch {
    }
    throw err;
  } finally {
    db.exec("PRAGMA foreign_keys = ON;");
  }
}
function ensureSchemaUpgrades(db) {
  upgradeUsersRoleConstraintIfNeeded(db);
  addMissingColumn(db, "users", "staff_role", "staff_role TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "users", "staff_permissions_json", "staff_permissions_json TEXT NOT NULL DEFAULT '[]'");
  addMissingColumn(db, "users", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "teacher_profiles", "resume_url", "resume_url TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_filename", "resume_filename TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_mime", "resume_mime TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_size", "resume_size INTEGER NOT NULL DEFAULT 0");
  addMissingColumn(db, "teacher_profiles", "resume_status", "resume_status TEXT NOT NULL DEFAULT 'missing'");
  addMissingColumn(db, "teacher_profiles", "resume_uploaded_at", "resume_uploaded_at TEXT");
  addMissingColumn(db, "teacher_profiles", "resume_notes", "resume_notes TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "student_profiles", "roll_number", "roll_number TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "student_profiles", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "student_profiles", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "courses", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "enrollments", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "attendance", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "attendance", "marked_via", "marked_via TEXT NOT NULL DEFAULT 'manual'");
  addMissingColumn(db, "class_schedules", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "class_schedules", "room_name", "room_name TEXT NOT NULL DEFAULT 'Room 101'");
  addMissingColumn(db, "fee_records", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "inquiries", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "inquiries", "follow_up_date", "follow_up_date TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "follow_up_notes", "follow_up_notes TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "assigned_staff", "assigned_staff TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "demo_date", "demo_date TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "demo_time_slot", "demo_time_slot TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "support_messages", "course_id", "course_id INTEGER");
  addMissingColumn(db, "support_messages", "teacher_id", "teacher_id INTEGER");
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      is_secret INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT '',
      updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS knowledge_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/pdf',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      file_path TEXT NOT NULL DEFAULT '',
      extracted_text TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS admin_login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      identifier TEXT NOT NULL DEFAULT '',
      ip_address TEXT NOT NULL DEFAULT '',
      user_agent TEXT NOT NULL DEFAULT '',
      outcome TEXT NOT NULL DEFAULT 'failed',
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_created ON admin_login_attempts(created_at DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_gateway_payment_id
      ON payments(gateway_payment_id)
      WHERE gateway_payment_id != '';

    CREATE TABLE IF NOT EXISTS branches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      address TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT 'Muradnagar',
      phone TEXT NOT NULL DEFAULT '+91 78-2728-9292',
      email TEXT NOT NULL DEFAULT 'inquiry@yuitor.com',
      timing_note TEXT NOT NULL DEFAULT 'Mon\u2013Sat \xB7 7:00 AM \u2013 8:00 PM',
      map_url TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      room_name TEXT NOT NULL DEFAULT 'Room 101',
      seat_limit INTEGER NOT NULL DEFAULT 40,
      schedule_days TEXT NOT NULL DEFAULT 'Mon\u2013Sat',
      start_time TEXT NOT NULL DEFAULT '16:00',
      end_time TEXT NOT NULL DEFAULT '17:30',
      start_date TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS timetable_slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE CASCADE,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      day_of_week TEXT NOT NULL DEFAULT 'Monday',
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      subject_name TEXT NOT NULL DEFAULT '',
      room_name TEXT NOT NULL DEFAULT 'Room 101',
      mode TEXT NOT NULL DEFAULT 'offline',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS parent_links (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      relation TEXT NOT NULL DEFAULT 'Parent / Guardian',
      created_at TEXT NOT NULL,
      UNIQUE(parent_user_id, student_user_id)
    );
    CREATE TABLE IF NOT EXISTS parent_teacher_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_role TEXT NOT NULL DEFAULT 'parent',
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS qr_attendance_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      session_date TEXT NOT NULL,
      token_code TEXT NOT NULL UNIQUE,
      expires_at INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS offline_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      subject_name TEXT NOT NULL DEFAULT 'All Subjects',
      test_date TEXT NOT NULL,
      max_marks INTEGER NOT NULL DEFAULT 100,
      passing_marks INTEGER NOT NULL DEFAULT 33,
      room_name TEXT NOT NULL DEFAULT 'Exam Hall 1',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS offline_test_marks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL REFERENCES offline_tests(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      marks_obtained REAL NOT NULL DEFAULT 0,
      is_absent INTEGER NOT NULL DEFAULT 0,
      remarks TEXT NOT NULL DEFAULT '',
      rank_position INTEGER,
      graded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(test_id, student_id)
    );
    CREATE TABLE IF NOT EXISTS teacher_leave_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      from_date TEXT NOT NULL,
      to_date TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_note TEXT NOT NULL DEFAULT '',
      reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL,
      reviewed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS fee_installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fee_record_id INTEGER NOT NULL REFERENCES fee_records(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      installment_no INTEGER NOT NULL DEFAULT 1,
      title TEXT NOT NULL,
      amount INTEGER NOT NULL DEFAULT 0,
      paid_amount INTEGER NOT NULL DEFAULT 0,
      due_date TEXT NOT NULL,
      payment_id INTEGER REFERENCES payments(id) ON DELETE SET NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      reminder_sent_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS teacher_payouts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      salary_month TEXT NOT NULL,
      base_amount INTEGER NOT NULL DEFAULT 0,
      bonus_amount INTEGER NOT NULL DEFAULT 0,
      deduction_amount INTEGER NOT NULL DEFAULT 0,
      net_amount INTEGER NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'upi',
      reference_no TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      paid_at TEXT,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Operations',
      amount INTEGER NOT NULL DEFAULT 0,
      expense_date TEXT NOT NULL,
      payment_method TEXT NOT NULL DEFAULT 'upi',
      notes TEXT NOT NULL DEFAULT '',
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS library_books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL DEFAULT 'Study Module',
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      total_copies INTEGER NOT NULL DEFAULT 10,
      available_copies INTEGER NOT NULL DEFAULT 10,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS library_issues (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES library_books(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      issued_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      issued_at TEXT NOT NULL,
      due_return_date TEXT NOT NULL,
      returned_at TEXT,
      status TEXT NOT NULL DEFAULT 'issued',
      remarks TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS toppers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      student_name TEXT NOT NULL,
      exam_name TEXT NOT NULL,
      rank_label TEXT NOT NULL DEFAULT '',
      score_label TEXT NOT NULL DEFAULT '',
      batch_label TEXT NOT NULL DEFAULT '',
      photo_url TEXT NOT NULL DEFAULT '/assets/images/student-achievement.webp',
      is_featured INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS alert_dispatch_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel TEXT NOT NULL DEFAULT 'sms',
      recipient_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      recipient_name TEXT NOT NULL DEFAULT '',
      recipient_contact TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'announcement',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'logged',
      provider_response TEXT NOT NULL DEFAULT '',
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS mail_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL COLLATE NOCASE UNIQUE,
      display_name TEXT NOT NULL DEFAULT 'Yuitor Smart Classes',
      smtp_host TEXT NOT NULL DEFAULT 'mail.yuitor.com',
      smtp_port INTEGER NOT NULL DEFAULT 465,
      smtp_secure INTEGER NOT NULL DEFAULT 1,
      smtp_user TEXT NOT NULL DEFAULT '',
      imap_host TEXT NOT NULL DEFAULT 'mail.yuitor.com',
      imap_port INTEGER NOT NULL DEFAULT 993,
      imap_secure INTEGER NOT NULL DEFAULT 1,
      imap_user TEXT NOT NULL DEFAULT '',
      password_enc TEXT NOT NULL DEFAULT '',
      is_default INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      last_sync_at TEXT,
      last_uid INTEGER NOT NULL DEFAULT 0,
      last_error TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS mail_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id INTEGER NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
      folder TEXT NOT NULL DEFAULT 'inbox',
      direction TEXT NOT NULL DEFAULT 'inbound',
      remote_uid INTEGER,
      message_id TEXT NOT NULL DEFAULT '',
      in_reply_to TEXT NOT NULL DEFAULT '',
      from_name TEXT NOT NULL DEFAULT '',
      from_email TEXT NOT NULL DEFAULT '',
      to_emails TEXT NOT NULL DEFAULT '',
      cc_emails TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '(No Subject)',
      snippet TEXT NOT NULL DEFAULT '',
      text_body TEXT NOT NULL DEFAULT '',
      html_body TEXT NOT NULL DEFAULT '',
      has_attachments INTEGER NOT NULL DEFAULT 0,
      attachments_json TEXT NOT NULL DEFAULT '[]',
      is_read INTEGER NOT NULL DEFAULT 0,
      is_starred INTEGER NOT NULL DEFAULT 0,
      mail_date TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mail_messages_account_folder ON mail_messages(account_id, folder, mail_date DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_mail_messages_uid ON mail_messages(account_id, folder, remote_uid) WHERE remote_uid IS NOT NULL;
  `);
  seedDefaultMailAccounts(db);
}
function seedDefaultMailAccounts(db) {
  const seeded = db.prepare("SELECT value FROM schema_meta WHERE key = 'mail_accounts_seeded_v1'").get();
  if (seeded?.value === "1") return;
  const now = nowIso();
  const defaults = [
    { email: "no-reply@yuitor.com", displayName: "Yuitor Smart Classes (No-Reply)", isDefault: 1 },
    { email: "admission@yuitor.com", displayName: "Yuitor Admissions Desk", isDefault: 0 },
    { email: "info@yuitor.com", displayName: "Yuitor Info Desk", isDefault: 0 },
    { email: "support@yuitor.com", displayName: "Yuitor Student Support", isDefault: 0 }
  ];
  const ins = db.prepare(
    `INSERT OR IGNORE INTO mail_accounts (
      email, display_name, smtp_host, smtp_port, smtp_secure, smtp_user,
      imap_host, imap_port, imap_secure, imap_user, password_enc,
      is_default, is_active, created_at, updated_at
    ) VALUES (?, ?, 'mail.yuitor.com', 465, 1, ?, 'mail.yuitor.com', 993, 1, ?, '', ?, 1, ?, ?)`
  );
  for (const item of defaults) {
    ins.run(item.email, item.displayName, item.email, item.email, item.isDefault, now, now);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('mail_accounts_seeded_v1', '1')").run();
}
function ensureSessionSecret(db) {
  const cur = (process.env.SESSION_SECRET || "").trim();
  if (cur && cur !== "replace-with-64-char-random-hex-secret") {
    return;
  }
  const row = db.prepare("SELECT value FROM system_settings WHERE key = 'SESSION_SECRET'").get();
  if (row?.value && row.value.trim().length >= 16) {
    process.env.SESSION_SECRET = row.value.trim();
    return;
  }
  const generated = crypto2.randomBytes(32).toString("hex");
  db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES ('SESSION_SECRET', ?, 1, ?, NULL)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, is_secret = 1, updated_at = excluded.updated_at`
  ).run(generated, nowIso());
  process.env.SESSION_SECRET = generated;
}
function getDb() {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  fs.mkdirSync(RESUMES_DIR, { recursive: true });
  fs.mkdirSync(KNOWLEDGE_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec("PRAGMA busy_timeout = 5000;");
  const schemaSql = fs.readFileSync(MIGRATION_PATH, "utf8");
  db.exec(schemaSql);
  ensureSchemaUpgrades(db);
  hydrateRuntimeSettings(db);
  ensureSessionSecret(db);
  migrateLegacySqliteIfNeeded(db);
  seedDefaultContent(db);
  ensureStartupBackup(db);
  dbInstance = db;
  return db;
}
function migrateLegacySqliteIfNeeded(db) {
  const migratedFlag = db.prepare("SELECT value FROM schema_meta WHERE key = 'legacy_portal_migrated'").get();
  if (migratedFlag?.value === "1") return;
  if (!fs.existsSync(LEGACY_DB_PATH)) {
    db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
    return;
  }
  try {
    const legacy = new DatabaseSync(LEGACY_DB_PATH, { readOnly: true });
    const now = nowIso();
    const admins = legacy.prepare("SELECT * FROM admins").all();
    for (const a of admins) {
      const email = normalizeEmail(a.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
           VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', ?, 0, ?, ?, ?, ?)`
        ).run(
          a.display_name || "Admin",
          email,
          normalizePhone(a.phone || "7827289292"),
          a.password_hash,
          Number(a.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          a.last_login_at || null,
          a.created_at || now,
          now
        );
      }
    }
    const students = legacy.prepare("SELECT * FROM students").all();
    for (const s of students) {
      const email = normalizeEmail(s.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        const vStatus = s.registration_status === "active" || s.registration_status === "completed" ? "approved" : s.registration_status === "inactive" ? "suspended" : "pending_approval";
        const res = db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
             VALUES ('student', ?, ?, ?, ?, 1, ?, ?, 1, ?, ?, ?, ?)`
        ).run(
          s.full_name || "Student",
          email,
          normalizePhone(s.phone || ""),
          s.password_hash,
          vStatus,
          Number(s.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          s.last_login_at || null,
          s.created_at || now,
          s.updated_at || now
        );
        const uid = Number(res.lastInsertRowid);
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, admission_date, enrollment_status)
           VALUES (?, ?, 'CBSE', ?, ?, ?, ?)`
        ).run(
          uid,
          s.class_level ? `Class ${s.class_level}`.replace(/^Class Class /i, "Class ") : "Class 10",
          JSON.stringify(s.selected_subject ? [s.selected_subject] : ["Mathematics", "Science"]),
          Number(s.course_duration_months || 12),
          s.admission_date || null,
          s.registration_status || "active"
        );
      }
    }
    const inqs = legacy.prepare("SELECT * FROM inquiries").all();
    for (const q of inqs) {
      const exists = db.prepare("SELECT id FROM inquiries WHERE name = ? AND phone = ? AND created_at = ?").get(q.name || "", q.phone || "", q.received_at || now);
      if (!exists) {
        const mappedStatus = q.status === "converted" ? "admitted" : ["new", "contacted", "admitted", "closed"].includes(q.status) ? q.status : "new";
        db.prepare(
          `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
           VALUES (?, ?, ?, ?, ?, 'legacy_import', ?, ?)`
        ).run(
          q.name || "Visitor",
          q.phone || "",
          q.email || "",
          q.course || "General Inquiry",
          q.message || "",
          mappedStatus,
          q.received_at || now
        );
      }
    }
    const fest = legacy.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    if (fest) {
      db.prepare(
        `INSERT OR REPLACE INTO festival_settings (id, mode, manual_festival_id, simulated_date_ist, overrides_json, updated_at)
         VALUES (1, ?, ?, ?, ?, ?)`
      ).run(
        fest.mode || "automatic",
        fest.manual_festival_id || null,
        fest.simulated_date_ist || null,
        fest.overrides_json || "{}",
        fest.updated_at || now
      );
    }
    legacy.close();
  } catch (err) {
    console.warn("[Yuitor DB] Legacy SQLite migration skipped:", err);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
}
function seedDefaultContent(db) {
  const now = nowIso();
  const courseCount = db.prepare("SELECT COUNT(*) as c FROM courses").get().c;
  if (courseCount === 0) {
    const courses = [
      {
        title: "Class 6th\u20138th Foundation Batch",
        slug: "class-6-8-foundation",
        category: "Classes 6-12",
        class_range: "Classes 6\u20138",
        board: "CBSE / ICSE / UP Board",
        description: "Strong conceptual foundation in Mathematics, Science, English, and Social Studies with weekly unit tests and doubt-clearing sessions.",
        duration_months: 12,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/teacher-led-class.webp"
      },
      {
        title: "Class 9th\u201310th Board Mastery Batch",
        slug: "class-9-10-board-mastery",
        category: "Classes 6-12",
        class_range: "Classes 9\u201310",
        board: "CBSE / UP Board / ICSE",
        description: "Complete NCERT + reference syllabus coverage, board sample papers, practical prep, and personal mentor tracking in Muradnagar.",
        duration_months: 12,
        monthly_fee: 1400,
        yearly_fee: 14300,
        thumbnail_url: "/assets/images/math-board.webp"
      },
      {
        title: "Class 11th\u201312th Science & Commerce",
        slug: "class-11-12-board-stream",
        category: "Classes 6-12",
        class_range: "Classes 11\u201312",
        board: "CBSE / UP Board",
        description: "In-depth coaching for Physics, Chemistry, Mathematics, Biology, Accountancy, and Economics with full board mock series.",
        duration_months: 12,
        monthly_fee: 1700,
        yearly_fee: 17300,
        thumbnail_url: "/assets/images/science-lab.webp"
      },
      {
        title: "NEET UG & JEE Foundation / Target",
        slug: "neet-jee-target",
        category: "Competitive",
        class_range: "Classes 11\u201312 & Dropper",
        board: "NTA / Competitive",
        description: "Structured Physics, Chemistry, Biology & Mathematics coaching with daily DPPs, OMR/CBT mock tests, and error analysis.",
        duration_months: 12,
        monthly_fee: 2400,
        yearly_fee: 24500,
        thumbnail_url: "/assets/images/exam-writing.webp"
      },
      {
        title: "CUET UG Entrance Preparation",
        slug: "cuet-ug-prep",
        category: "Competitive",
        class_range: "Class 12 & Graduates",
        board: "NTA CUET",
        description: "Domain subjects, General Test (Quant & Reasoning), and English Language speed-accuracy drills for top central universities.",
        duration_months: 6,
        monthly_fee: 1800,
        yearly_fee: 18400,
        thumbnail_url: "/assets/images/group-study.webp"
      },
      {
        title: "Computer Courses (DCA, Tally Prime & Web)",
        slug: "computer-dca-tally",
        category: "Computer",
        class_range: "Students & Job Seekers",
        board: "Practical Certification",
        description: "Hands-on training in MS Office, Tally Prime with GST, CCC, HTML/CSS, and practical computer lab sessions.",
        duration_months: 6,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/computer-class.webp"
      },
      {
        title: "AI Learning & Python Coding Lab",
        slug: "ai-learning-python",
        category: "AI Learning",
        class_range: "Class 6th to College",
        board: "Applied Tech Track",
        description: "Learn Python programming, AI prompt engineering, automation workflows, and real student mini-projects in our guided lab.",
        duration_months: 6,
        monthly_fee: 1500,
        yearly_fee: 15300,
        thumbnail_url: "/assets/images/coding-workshop.webp"
      },
      {
        title: "Spoken English & Communication Skills",
        slug: "spoken-english-fluency",
        category: "English Speaking",
        class_range: "All Age Groups",
        board: "Fluency & Confidence",
        description: "Daily speaking practice, grammar correction, pronunciation drills, group discussions, and interview readiness.",
        duration_months: 3,
        monthly_fee: 900,
        yearly_fee: 9200,
        thumbnail_url: "/assets/images/student-project-presentation.webp"
      }
    ];
    const insertCourse = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, thumbnail_url, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );
    for (const c of courses) {
      insertCourse.run(
        c.title,
        c.slug,
        c.category,
        c.class_range,
        c.board,
        c.description,
        c.duration_months,
        c.monthly_fee,
        c.yearly_fee,
        c.thumbnail_url,
        now
      );
    }
    const firstCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insLesson = db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, '', ?, 35, ?, 1, ?)`
    );
    for (const fc of firstCourses) {
      insLesson.run(fc.id, `Orientation & Syllabus Roadmap \u2014 ${fc.title}`, "text", "Complete chapter weightage, study calendar, and weekly test schedule.", 1, now);
      insLesson.run(fc.id, "Core Concepts & Formula Sheet (Module 1)", "pdf", "Structured concept notes and solved board-level practice questions.", 2, now);
    }
  }
  const subjCount = db.prepare("SELECT COUNT(*) as c FROM subjects").get().c;
  if (subjCount === 0) {
    const subjects = [
      ["Mathematics", "MATH-612", "Classes 6\u201312", "NCERT concept clarity, shortcut methods, and weekly chapter tests for CBSE, ICSE, and UP Board."],
      ["Science (Foundation)", "SCI-610", "Classes 6\u201310", "Integrated Physics, Chemistry, and Biology with visual demonstrations and diagram practice."],
      ["Physics", "PHY-1112", "Classes 11\u201312 / JEE / NEET", "Mechanics, Electrostatics, Optics, and numerical problem solving for Boards and competitive exams."],
      ["Chemistry", "CHEM-1112", "Classes 11\u201312 / JEE / NEET", "Physical, Organic, and Inorganic Chemistry with reaction mechanisms and NCERT line-by-line mastery."],
      ["Biology", "BIO-1112", "Classes 11\u201312 / NEET", "Botany & Zoology diagrams, NCERT assertion-reason drills, and NEET PYQ practice."],
      ["English & Spoken Communication", "ENG-ALL", "Classes 6\u201312 & Spoken", "Reading comprehension, board writing formats, grammar accuracy, and daily speaking fluency."],
      ["Computer Applications & DCA", "COMP-DCA", "Classes 6\u201312 & Skill Track", "MS Office, Tally Prime with GST, Internet tools, and fundamentals of computing."],
      ["AI Learning & Python Coding", "AI-PY", "Classes 6\u201312 & Tech", "Python syntax, logic building, responsible AI tools, and practical project creation."]
    ];
    const insSubj = db.prepare(
      "INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const s of subjects) insSubj.run(s[0], s[1], s[2], s[3], now);
  }
  const faqCount = db.prepare("SELECT COUNT(*) as c FROM faqs").get().c;
  if (faqCount === 0) {
    const faqs = [
      ["Where is Yuitor Smart Classes located?", "Our coaching centre is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India."],
      ["Which classes and boards do you teach?", "We offer coaching for Classes 5th to 12th across CBSE, UP Board, and ICSE, alongside JEE, NEET, CUET, Computer Courses, AI Learning, and Spoken English."],
      ["Can students attend a demo class before admission?", "Yes! You can book a free counselling and demo session by submitting the Admission form or calling +91 78-2728-9292."],
      ["How does portal registration and approval work?", "Students and teachers register online, verify their 6-digit mobile OTP, and then the Yuitor Team reviews and approves the account for portal access."],
      ["What is your refund policy?", "Yuitor offers a transparent 7-day refund policy subject to the published admission and refund terms on our website."]
    ];
    const insFaq = db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, ?, 1, ?)");
    faqs.forEach((f, idx) => insFaq.run(f[0], f[1], idx + 1, now));
  }
  const testCount = db.prepare("SELECT COUNT(*) as c FROM testimonials").get().c;
  if (testCount === 0) {
    const tests = [
      ["Aarav Verma", "Class 10 CBSE Student", "95.4% in Board Exams", "Weekly tests and personal doubt sessions at Yuitor Muradnagar made Mathematics and Science much easier to score high in."],
      ["Ananya Tyagi", "Class 12 Science Student", "94% in Physics & Chemistry", "Small batch sizes meant our teachers checked every answer sheet and guided us step by step before boards."],
      ["Mrs. Sunita Chaudhary", "Parent, Muradnagar", "Consistent Academic Growth", "Regular attendance updates and transparent fee tracking keep parents completely informed throughout the session."]
    ];
    const insTest = db.prepare(
      "INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const t of tests) insTest.run(t[0], t[1], t[2], t[3], now);
  }
  const couponCount = db.prepare("SELECT COUNT(*) as c FROM coupons").get().c;
  if (couponCount === 0) {
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES ('YUITOR10', 'percent', 10, 500, 0, 1, ?)"
    ).run(now);
  }
  const tmplCount = db.prepare("SELECT COUNT(*) as c FROM email_templates").get().c;
  if (tmplCount === 0) {
    const templates = [
      ["New Batch Admission Open", "Admission", "Admissions Open at Yuitor Smart Classes, Muradnagar!", "Limited seats for Classes 6th\u201312th, JEE, NEET & Skills.", "<p>Dear {{name}},</p><p>Admissions are now open for our upcoming batches at <strong>Yuitor Smart Classes, Muradnagar</strong> (Classes 6th\u201312th, JEE/NEET/CUET, Computer, AI Learning &amp; Spoken English).</p><p>Book your counselling or demo session today at Trimurti Vihar, Near Venus Academy.</p>"],
      ["Skill & AI Course Promotion", "Course Promotion", "Upgrade Your Skills: AI Learning, Coding & Spoken English", "Practical weekend & weekday batches in Muradnagar.", "<p>Dear {{name}},</p><p>Build future-ready skills with Yuitor Smart Classes! Join our hands-on batches for <strong>AI Learning &amp; Python Coding</strong>, <strong>DCA + Tally Prime</strong>, and <strong>Spoken English</strong>.</p>"],
      ["Monthly Fee Reminder", "Fee Reminder", "Friendly Fee Schedule Reminder \u2014 Yuitor Smart Classes", "Check your fee status and downloadable receipt in Student Portal.", "<p>Dear {{name}},</p><p>This is a gentle reminder to review your current fee schedule in your Student Portal or at the Muradnagar centre desk. Kindly ignore if already settled.</p>"],
      ["Unit & Board Exam Announcement", "Exam Announcement", "Upcoming Test Series & Exam Schedule \u2014 Yuitor Smart Classes", "Important dates and revision checklist inside.", "<p>Dear {{name}},</p><p>Our upcoming weekly evaluation and mock test schedule has been published. Please review your syllabus notes in the Student Portal and arrive 10 minutes early.</p>"],
      ["Student Important Notice", "Student Notice", "Important Student Notice \u2014 Yuitor Smart Classes", "Batch timing and study material update.", "<p>Dear {{name}},</p><p>Please check your Student Dashboard for the latest batch timing updates and newly uploaded PDF notes from your faculty.</p>"],
      ["Faculty & Teacher Notice", "Teacher Notice", "Faculty Coordination Notice \u2014 Yuitor Smart Classes", "Academic schedule and attendance update reminder.", "<p>Dear {{name}},</p><p>Kindly ensure daily batch attendance and weekly assignment grades are updated in the Teacher Portal before 7:00 PM.</p>"],
      ["Festive Wishes from Yuitor", "Festival", "Warm Festive Wishes from Yuitor Smart Classes!", "Wishing you and your family joy, health, and success.", "<p>Dear {{name}},</p><p>Yuitor Smart Classes wishes you and your family a joyful and prosperous celebration! Keep learning and shining.</p>"],
      ["Yuitor Monthly Newsletter", "Newsletter", "Yuitor Monthly Academic Digest & Study Tips", "Highlights, topper strategies, and upcoming workshops.", "<p>Dear {{name}},</p><p>Here is your monthly summary of upcoming workshops, board preparation strategies, and new study resources at Yuitor Smart Classes, Muradnagar.</p>"],
      ["Special Workshop & Occasion", "Special Occasion", "Special Career & Scholarship Seminar \u2014 Yuitor Muradnagar", "Reserve your seat for our weekend seminar.", "<p>Dear {{name}},</p><p>You are invited to our upcoming Career Guidance &amp; Scholarship Evaluation Session at Yuitor Smart Classes, Trimurti Vihar, Muradnagar.</p>"]
    ];
    const insTmpl = db.prepare(
      "INSERT INTO email_templates (name, category, subject, preview_text, html_body, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const t of templates) insTmpl.run(t[0], t[1], t[2], t[3], t[4], now);
  }
  const branchCount = db.prepare("SELECT COUNT(*) as c FROM branches").get().c;
  if (branchCount === 0) {
    db.prepare(
      `INSERT INTO branches (name, code, address, city, phone, email, timing_note, map_url, is_active, created_at)
       VALUES (?, 'MRD-01', ?, 'Muradnagar', '+91 78-2728-9292', 'inquiry@yuitor.com', 'Mon\u2013Sat \xB7 7:00 AM \u2013 8:00 PM', 'https://maps.google.com/?q=Trimurti+Vihar+Muradnagar+201206', 1, ?)`
    ).run("Muradnagar Main Centre", "Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh", now);
  }
  const mainBranch = db.prepare("SELECT id FROM branches ORDER BY id ASC LIMIT 1").get();
  if (mainBranch) {
    db.prepare("UPDATE courses SET branch_id = ? WHERE branch_id IS NULL").run(mainBranch.id);
    db.prepare("UPDATE student_profiles SET branch_id = ? WHERE branch_id IS NULL").run(mainBranch.id);
  }
  const missingRolls = db.prepare("SELECT user_id FROM student_profiles WHERE COALESCE(roll_number, '') = ''").all();
  const updRoll = db.prepare("UPDATE student_profiles SET roll_number = ? WHERE user_id = ?");
  for (const r of missingRolls) {
    updRoll.run(`YTR-STU-${String(r.user_id).padStart(4, "0")}`, r.user_id);
  }
  const batchCount = db.prepare("SELECT COUNT(*) as c FROM batches").get().c;
  if (batchCount === 0 && mainBranch) {
    const sampleCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insBatch = db.prepare(
      `INSERT INTO batches (course_id, branch_id, name, code, room_name, seat_limit, schedule_days, start_time, end_time, start_date, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, 40, 'Mon\u2013Sat', ?, ?, ?, 1, ?)`
    );
    const timings = [
      ["Room 101", "15:30", "17:00"],
      ["Room 102", "17:00", "18:30"],
      ["Hall A", "16:00", "18:00"],
      ["Lab 1", "18:00", "19:30"]
    ];
    sampleCourses.forEach((c, idx) => {
      const [room, st, et] = timings[idx % timings.length];
      insBatch.run(c.id, mainBranch.id, `${c.title} \u2014 Batch A`, `YTR-B${c.id}A`, room, st, et, now.slice(0, 10), now);
    });
  }
  const topperCount = db.prepare("SELECT COUNT(*) as c FROM toppers").get().c;
  if (topperCount === 0) {
    const defaultToppers = [
      ["Anjali Yadav", "NEET 2025", "AIR 842", "680/720", "NEET Batch 2023-25", "/assets/images/student-medical-future.webp"],
      ["Mohit Kumar", "JEE Mains 2025", "99.2 Percentile", "285/300", "JEE Batch 2024-25", "/assets/images/engineering-aspirant.webp"],
      ["Priya Singh", "Class 12 CBSE", "School Topper", "98.2%", "Class 12 2024-25", "/assets/images/students-group.webp"],
      ["Arjun Sharma", "Class 10 UP Board", "District 2nd", "95.4%", "Class 10 2024-25", "/assets/images/happy-students.webp"],
      ["Nisha Gupta", "NEET 2024", "AIR 1240", "660/720", "NEET Batch 2022-24", "/assets/images/student-achievement.webp"],
      ["Rahul Tiwari", "JEE Advanced 2025", "AIR 3840", "Qualified", "JEE Batch 2023-25", "/assets/images/math-board.webp"]
    ];
    const insTop = db.prepare(
      `INSERT INTO toppers (branch_id, student_name, exam_name, rank_label, score_label, batch_label, photo_url, is_featured, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    );
    defaultToppers.forEach((t, idx) => {
      insTop.run(mainBranch?.id || null, t[0], t[1], t[2], t[3], t[4], t[5], idx + 1, now);
    });
  }
}
function verifyBackupIntegrity(backupPath) {
  let checkDb = null;
  try {
    checkDb = new DatabaseSync(backupPath, { readOnly: true });
    const row = checkDb.prepare("PRAGMA quick_check").get();
    const result = row ? Object.values(row)[0] : "";
    return { ok: result === "ok", detail: result || "unknown" };
  } catch (err) {
    return { ok: false, detail: err?.message || "Integrity check failed" };
  } finally {
    try {
      checkDb?.close();
    } catch {
    }
  }
}
function createDatabaseBackup(db, label = "manual") {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const safeLabel = label.replace(/[^a-z0-9_-]/gi, "").slice(0, 20) || "backup";
  const filename = `yuitor-${safeLabel}-${stamp}.db`;
  const dest = path.join(BACKUPS_DIR, filename);
  const escaped = dest.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}';`);
  const stat = fs.statSync(dest);
  const integrity = verifyBackupIntegrity(dest);
  return { filename, sizeBytes: stat.size, createdAt: nowIso(), integrityOk: integrity.ok };
}
function ensureStartupBackup(db) {
  try {
    const files = fs.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db"));
    if (files.length === 0) {
      createDatabaseBackup(db, "startup");
    }
  } catch (err) {
    console.warn("[Yuitor DB] Startup backup warning:", err);
  }
}

// server/mailer.ts
import nodemailer2 from "nodemailer";
import path3 from "node:path";
import fs3 from "node:fs";

// server/mail-hub.ts
import crypto3 from "node:crypto";
import fs2 from "node:fs";
import path2 from "node:path";
import nodemailer from "nodemailer";
import { ImapFlow } from "imapflow";
import { simpleParser } from "mailparser";
var VAULT_KEY_PATH = path2.join(DATA_DIR, ".mail-vault.key");
var cachedVaultKey = null;
function getMailVaultKey() {
  const envRaw = (process.env.MAIL_VAULT_KEY || "").trim();
  if (envRaw) {
    if (/^[a-f0-9]{64}$/i.test(envRaw)) {
      return Buffer.from(envRaw, "hex");
    }
    return crypto3.createHash("sha256").update(envRaw).digest();
  }
  if (cachedVaultKey) return cachedVaultKey;
  fs2.mkdirSync(DATA_DIR, { recursive: true });
  if (fs2.existsSync(VAULT_KEY_PATH)) {
    const hex = fs2.readFileSync(VAULT_KEY_PATH, "utf8").trim();
    if (/^[a-f0-9]{64}$/i.test(hex)) {
      cachedVaultKey = Buffer.from(hex, "hex");
      return cachedVaultKey;
    }
  }
  const key = crypto3.randomBytes(32);
  fs2.writeFileSync(VAULT_KEY_PATH, key.toString("hex"), { mode: 384 });
  cachedVaultKey = key;
  return key;
}
function getMailboxPassword(row) {
  if (!row?.password_enc) return "";
  return decryptVaultSecret(row.password_enc, getMailVaultKey());
}
function getDefaultMailAccountWithSecret(db) {
  const rows = db.prepare(
    `SELECT * FROM mail_accounts
       WHERE is_active = 1 AND password_enc != ''
       ORDER BY is_default DESC, id ASC`
  ).all();
  for (const row of rows) {
    const pass = getMailboxPassword(row);
    if (pass && row.smtp_host) {
      return { account: row, password: pass };
    }
  }
  return null;
}
function createMailboxSmtpTransport(row, password) {
  const port = Number(row.smtp_port || 465);
  const secure = port === 465 ? true : port === 587 ? false : Number(row.smtp_secure) === 1;
  return nodemailer.createTransport({
    host: row.smtp_host || "mail.yuitor.com",
    port,
    secure,
    auth: {
      user: (row.smtp_user || row.email).trim(),
      pass: password
    },
    connectionTimeout: 12e3,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}

// server/mailer.ts
var mailerDbRef = null;
function isEnvSmtpConfigured() {
  const host = (process.env.SMTP_HOST || "").trim();
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return Boolean(host && host !== "smtp.example.com" && user && pass && !pass.startsWith("replace-with"));
}
function getFallbackMailbox() {
  if (!mailerDbRef) return null;
  try {
    return getDefaultMailAccountWithSecret(mailerDbRef);
  } catch {
    return null;
  }
}
var getSenderName = () => {
  const envName = (process.env.MAIL_FROM_NAME || "").trim();
  if (envName) return envName;
  if (!isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb?.account.display_name) return fb.account.display_name;
  }
  return "Yuitor Smart Classes";
};
var getSenderEmail = () => {
  const envEmail = (process.env.MAIL_FROM_EMAIL || "").trim();
  if (isEnvSmtpConfigured() && envEmail) return envEmail;
  if (!isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb?.account.email) return fb.account.email;
  }
  return envEmail || "no-reply@yuitor.com";
};
var getReplyToEmail = (department) => {
  if (department) {
    return getDepartmentEmails()[department];
  }
  return (process.env.REPLY_TO_EMAIL || "").trim() || getDepartmentEmails().inquiry || "inquiry@yuitor.com";
};
var getAdminNotifyEmail = () => (process.env.ADMIN_NOTIFY_EMAIL || "").trim() || getDepartmentEmails().admission || "admission@yuitor.com";
var SENDER_NAME = getSenderName();
var SENDER_EMAIL = getSenderEmail();
var REPLY_TO_EMAIL = getReplyToEmail();
var ADMIN_NOTIFY_EMAIL = getAdminNotifyEmail();
function isSmtpConfigured() {
  if (isEnvSmtpConfigured()) return true;
  return Boolean(getFallbackMailbox());
}
function resolveSmtpSecure(port, secureRaw) {
  if (port === 465) return true;
  if (port === 587) return false;
  if (typeof secureRaw === "boolean") return secureRaw;
  const norm = String(secureRaw ?? "").trim().toLowerCase();
  return norm === "true" || norm === "1";
}
function getTransporter(smtpOverride) {
  if (smtpOverride) {
    const port2 = Number(smtpOverride.port || 465);
    const secure2 = resolveSmtpSecure(port2, smtpOverride.secure);
    return nodemailer2.createTransport({
      host: smtpOverride.host.trim(),
      port: port2,
      secure: secure2,
      auth: { user: smtpOverride.user.trim(), pass: smtpOverride.pass },
      connectionTimeout: 12e3,
      greetingTimeout: 1e4,
      socketTimeout: 15e3
    });
  }
  if (!isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb) {
      return createMailboxSmtpTransport(fb.account, fb.password);
    }
  }
  const host = (process.env.SMTP_HOST || "").trim();
  const port = Number(process.env.SMTP_PORT || 465);
  const secure = resolveSmtpSecure(port, process.env.SMTP_SECURE);
  const user = (process.env.SMTP_USER || "").trim();
  const pass = process.env.SMTP_PASS || "";
  return nodemailer2.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    connectionTimeout: 12e3,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}
function getPublicSiteUrl(preferredOrigin) {
  const candidates = [preferredOrigin, process.env.APP_URL, process.env.SITE_URL, process.env.PUBLIC_URL, "https://yuitor.com"];
  for (const raw of candidates) {
    const val = String(raw || "").trim().replace(/\/+$/, "");
    if (!val || /^MY_APP_URL$/i.test(val)) continue;
    if (/^https?:\/\/[a-z0-9.-]+(?::\d+)?(?:\/.*)?$/i.test(val)) {
      return val;
    }
  }
  return "https://yuitor.com";
}
function renderBrandedEmailHtml(opts) {
  const siteUrl = getPublicSiteUrl(opts.siteUrl);
  const logoUrl = `${siteUrl}/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png`;
  const personalized = opts.htmlBody.replace(/\{\{\s*name\s*\}\}/gi, escapeHtml(opts.recipientName || "Student"));
  const ctaBlock = opts.ctaLabel && opts.ctaUrl ? `<p style="margin:24px 0;"><a href="${escapeHtml(opts.ctaUrl)}" style="display:inline-block;background:#1677ff;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:10px;">${escapeHtml(opts.ctaLabel)}</a></p>` : "";
  const unsubBlock = opts.unsubscribeUrl ? `<p style="margin-top:16px;font-size:12px;color:#64748b;">Prefer not to receive promotional updates? <a href="${escapeHtml(opts.unsubscribeUrl)}" style="color:#0f54c4;">Manage email preferences / Unsubscribe</a></p>` : "";
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(opts.subject)}</title></head>
<body style="margin:0;padding:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
  ${opts.previewText ? `<div style="display:none;max-height:0;overflow:hidden;">${escapeHtml(opts.previewText)}</div>` : ""}
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;">
        <tr><td style="background:#0f172a;padding:20px 24px;color:#ffffff;">
          <table role="presentation" width="100%"><tr>
            <td><strong style="font-size:18px;letter-spacing:-0.01em;">Yuitor Smart Classes</strong><div style="font-size:12px;color:#78d3d3;margin-top:2px;">Muradnagar, Ghaziabad \xB7 Classes 6th\u201312th, JEE, NEET &amp; Skills</div></td>
            <td align="right"><div style="display:inline-block;background:#ffffff;padding:4px;border-radius:10px;"><img src="${escapeHtml(logoUrl)}" alt="Yuitor Smart Classes" width="42" height="42" style="border-radius:6px;display:block;object-fit:contain;"></div></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:26px 24px;font-size:15px;line-height:1.65;">
          ${personalized}
          ${ctaBlock}
          <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
            <strong>Yuitor Smart Classes</strong><br>
            Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh<br>
            Call / WhatsApp: <a href="tel:+917827289292" style="color:#0f54c4;">+91 78-2728-9292</a> \xB7 <a href="${siteUrl}/admission" style="color:#0f54c4;">Apply for Admission</a>
            ${unsubBlock}
          </div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
async function sendEmailDirect(opts) {
  if (!opts.smtpOverride && !isSmtpConfigured()) {
    return { ok: false, error: "SMTP credentials (SMTP_HOST, SMTP_USER, SMTP_PASS) are not configured on the server." };
  }
  try {
    const transporter = getTransporter(opts.smtpOverride);
    const attachments = [];
    if (opts.attachmentUrl && opts.attachmentUrl.startsWith("/uploads/")) {
      const safeName = path3.basename(opts.attachmentUrl);
      const fullPath = path3.join(UPLOADS_DIR, safeName);
      if (fs3.existsSync(fullPath)) {
        attachments.push({ filename: safeName, path: fullPath });
      }
    }
    const fromName = opts.smtpOverride?.fromName || getSenderName();
    const fromEmail = opts.smtpOverride?.fromEmail || opts.smtpOverride?.user || getSenderEmail();
    const info = await transporter.sendMail({
      from: `"${fromName}" <${fromEmail}>`,
      replyTo: opts.replyTo || getReplyToEmail(opts.department),
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text || opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
      attachments
    });
    return { ok: true, messageId: info.messageId || "sent" };
  } catch (err) {
    return { ok: false, error: err?.message || "SMTP delivery failed." };
  }
}
async function sendTransactionalEmail(opts) {
  if (!opts.smtpOverride && !isSmtpConfigured() || !opts.to) {
    return { ok: false, error: "SMTP not configured or recipient missing." };
  }
  const html = renderBrandedEmailHtml({
    subject: opts.subject,
    previewText: opts.previewText,
    htmlBody: opts.htmlBody,
    recipientName: opts.recipientName,
    ctaLabel: opts.ctaLabel,
    ctaUrl: opts.ctaUrl
  });
  const res = await sendEmailDirect({
    to: opts.to,
    subject: opts.subject,
    html,
    department: opts.department,
    replyTo: opts.replyTo,
    smtpOverride: opts.smtpOverride
  });
  if (!res.ok) {
    console.warn(`[Yuitor Mailer] Transactional email to ${opts.to} (${opts.subject}) failed: ${res.error}`);
    return { ok: false, error: res.error };
  }
  return { ok: true };
}
async function processCampaignQueue(db, campaignId, batchSize = 25) {
  const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(campaignId);
  if (!camp || ["paused", "cancelled", "draft"].includes(camp.status)) {
    return { sent: 0, failed: 0 };
  }
  db.prepare("UPDATE email_campaigns SET status = 'sending', updated_at = ? WHERE id = ?").run(nowIso(), campaignId);
  const pendingRows = db.prepare(
    `SELECT d.*, u.unsubscribe_token
       FROM email_deliveries d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.campaign_id = ? AND (d.status = 'pending' OR (d.status = 'failed' AND d.retry_count < 2))
       ORDER BY d.id ASC LIMIT ?`
  ).all(campaignId, batchSize);
  const siteUrl = getPublicSiteUrl();
  let sent = 0;
  let failed = 0;
  for (const row of pendingRows) {
    const latest = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
    if (!latest || latest.status === "paused" || latest.status === "cancelled") break;
    const unsubUrl = row.unsubscribe_token ? `${siteUrl}/unsubscribe/${row.unsubscribe_token}` : void 0;
    const html = renderBrandedEmailHtml({
      subject: camp.subject,
      previewText: camp.preview_text,
      htmlBody: camp.html_body,
      recipientName: row.recipient_name,
      ctaLabel: camp.cta_label,
      ctaUrl: camp.cta_url,
      unsubscribeUrl: unsubUrl
    });
    const result = await sendEmailDirect({
      to: row.recipient_email,
      subject: camp.subject,
      html,
      attachmentUrl: camp.attachment_url
    });
    if (result.ok) {
      db.prepare(
        "UPDATE email_deliveries SET status = 'sent', provider_message_id = ?, error_message = '', sent_at = ? WHERE id = ?"
      ).run(result.messageId, nowIso(), row.id);
      sent++;
    } else {
      db.prepare(
        "UPDATE email_deliveries SET status = 'failed', error_message = ?, retry_count = retry_count + 1 WHERE id = ?"
      ).run(result.error, row.id);
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40));
  }
  const counts = db.prepare(
    `SELECT
         SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent_c,
         SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_c,
         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_c
       FROM email_deliveries WHERE campaign_id = ?`
  ).get(campaignId);
  const currentCamp = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
  let nextStatus = currentCamp?.status || "completed";
  if (nextStatus !== "paused" && nextStatus !== "cancelled") {
    nextStatus = Number(counts?.pending_c || 0) > 0 ? "queued" : Number(counts?.sent_c || 0) > 0 ? "completed" : "failed";
  }
  db.prepare(
    "UPDATE email_campaigns SET status = ?, sent_count = ?, failed_count = ?, updated_at = ? WHERE id = ?"
  ).run(nextStatus, Number(counts?.sent_c || 0), Number(counts?.failed_c || 0), nowIso(), campaignId);
  return { sent, failed };
}

// server/cron.ts
async function processFeeInstallmentReminders(db) {
  const now = nowIso();
  const today = now.slice(0, 10);
  const inTwoDays = new Date(Date.now() + 2 * 86400 * 1e3).toISOString().slice(0, 10);
  const threeDaysAgo = new Date(Date.now() - 3 * 86400 * 1e3).toISOString();
  const overdueRes = db.prepare(
    `UPDATE fee_installments SET status = 'overdue'
       WHERE status IN ('pending', 'partial') AND due_date < ?`
  ).run(today);
  const dueRows = db.prepare(
    `SELECT fi.*, u.full_name as student_name, u.email as student_email, u.phone as student_phone
       FROM fee_installments fi
       JOIN users u ON u.id = fi.student_id
       WHERE fi.status IN ('pending', 'partial', 'overdue')
         AND fi.due_date <= ?
         AND (fi.reminder_sent_at IS NULL OR fi.reminder_sent_at <= ?)
       LIMIT 50`
  ).all(inTwoDays, threeDaysAgo);
  let remindersSent = 0;
  for (const row of dueRows) {
    const dueAmt = Math.max(0, Number(row.amount || 0) - Number(row.paid_amount || 0));
    if (dueAmt <= 0) continue;
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      row.student_id,
      `Fee Reminder: ${row.title}`,
      `Installment of \u20B9${dueAmt} is ${row.status === "overdue" ? "overdue" : "due"} on ${row.due_date}. Please pay via Student Portal or Desk.`,
      now
    );
    const linkedParents = db.prepare("SELECT parent_user_id FROM parent_links WHERE student_user_id = ?").all(row.student_id);
    for (const p of linkedParents) {
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
      ).run(
        p.parent_user_id,
        `Fee Due Alert (${row.student_name})`,
        `${row.student_name}'s fee installment (${row.title}) of \u20B9${dueAmt} is ${row.status === "overdue" ? "overdue" : "due"} on ${row.due_date}.`,
        now
      );
    }
    if (isSmtpConfigured() && row.student_email) {
      void sendTransactionalEmail({
        to: row.student_email,
        recipientName: row.student_name || "Student",
        subject: `Fee Due Reminder (${row.title}) \u2014 Yuitor Smart Classes`,
        previewText: `Fee installment of \u20B9${dueAmt} due on ${row.due_date}.`,
        htmlBody: `<p>Dear {{name}},</p><p>This is a friendly reminder that your fee installment <strong>${escapeHtml(row.title)}</strong> of <strong>\u20B9${escapeHtml(dueAmt)}</strong> is <strong>${escapeHtml(row.status)}</strong> (Due Date: ${escapeHtml(row.due_date)}).</p>`,
        department: "fee"
      });
    }
    db.prepare("UPDATE fee_installments SET reminder_sent_at = ? WHERE id = ?").run(now, row.id);
    remindersSent++;
  }
  return {
    overdueMarked: Number(overdueRes.changes || 0),
    remindersSent
  };
}
async function runScheduledTasks() {
  const db = getDb();
  const nowEpoch = Math.floor(Date.now() / 1e3);
  const nowStr = nowIso();
  const sessRes = db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(nowEpoch);
  const otpRes = db.prepare("DELETE FROM otp_tokens WHERE expires_at <= ?").run(nowEpoch);
  const rlRes = db.prepare("DELETE FROM rate_limits WHERE locked_until IS NOT NULL AND locked_until <= ? AND window_started <= ?").run(nowEpoch, nowEpoch - 3600);
  const due = db.prepare(
    `SELECT id FROM email_campaigns
       WHERE (status = 'queued' AND (scheduled_at IS NULL OR scheduled_at <= ?))
          OR (send_mode = 'scheduled' AND status = 'queued' AND scheduled_at <= ?)`
  ).all(nowStr, nowStr);
  let totalSent = 0;
  let totalFailed = 0;
  for (const camp of due) {
    const res = await processCampaignQueue(db, camp.id, 30);
    totalSent += res.sent;
    totalFailed += res.failed;
  }
  const feeSummary = await processFeeInstallmentReminders(db);
  console.log(
    JSON.stringify({
      ok: true,
      ranAt: nowStr,
      cleaned: {
        expiredSessions: Number(sessRes.changes || 0),
        expiredOtps: Number(otpRes.changes || 0),
        staleRateLimits: Number(rlRes.changes || 0)
      },
      campaignsProcessed: due.length,
      emailsSent: totalSent,
      emailsFailed: totalFailed,
      feeInstallments: feeSummary
    })
  );
  db.close();
}
var isCliRun = typeof process !== "undefined" && Array.isArray(process.argv) && process.argv[1] && (process.argv[1].endsWith("cron.ts") || process.argv[1].endsWith("run-scheduled.mjs"));
if (isCliRun) {
  runScheduledTasks().catch((err) => {
    console.error("[Yuitor Cron Error]", err?.message || err);
    process.exit(1);
  });
}
export {
  processFeeInstallmentReminders,
  runScheduledTasks
};
