#!/usr/bin/env node
/**
 * Yuitor Smart Classes — End-to-End Security Smoke Test Suite
 * Runs real HTTP assertions against the running server (default http://127.0.0.1:3000)
 * AND verifies payment/installer/ClamAV edge cases honestly (no fake PASS).
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import bcrypt from "bcryptjs";
import { scanUploadedFileWithClamAv } from "../server/security-hardening.mjs";

const BASE = (process.env.SMOKE_BASE_URL || "http://127.0.0.1:3000").replace(/\/+$/, "");
const ORIGIN = BASE;
const DB_PATH = path.resolve(process.cwd(), "data", "yuitor.db");

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail });
  const tag = status === "PASS" ? "[PASS]" : status === "FAIL" ? "[FAIL]" : "[NOT TESTED]";
  console.log(`${tag} ${name} — ${detail}`);
}

function parseCookies(setCookieHeaders) {
  const jar = {};
  for (const h of setCookieHeaders || []) {
    const first = String(h).split(";")[0];
    const eq = first.indexOf("=");
    if (eq > 0) {
      jar[first.slice(0, eq).trim()] = first.slice(eq + 1).trim();
    }
  }
  return jar;
}

function cookieHeader(jar) {
  return Object.entries(jar)
    .filter(([, v]) => v !== "")
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

async function req(urlPath, { method = "GET", headers = {}, body, cookies = {}, includeOrigin = true } = {}) {
  const h = { ...headers };
  if (includeOrigin && !["GET", "HEAD", "OPTIONS"].includes(method.toUpperCase()) && !h.Origin && !h.Referer) {
    h.Origin = ORIGIN;
  }
  const cStr = cookieHeader(cookies);
  if (cStr) h.Cookie = cStr;
  let payload = body;
  if (body && typeof body === "object" && !(body instanceof FormData) && !(body instanceof Uint8Array)) {
    h["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  const resp = await fetch(`${BASE}${urlPath}`, {
    method,
    headers: h,
    body: payload,
    redirect: "manual"
  });
  const rawSetCookies = typeof resp.headers.getSetCookie === "function" ? resp.headers.getSetCookie() : [];
  const nextCookies = { ...cookies, ...parseCookies(rawSetCookies) };
  const text = await resp.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  return { status: resp.status, headers: resp.headers, text, json, cookies: nextCookies, rawSetCookies };
}

async function run() {
  const db = new DatabaseSync(DB_PATH);
  const tag = `sec_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const createdUserIds = [];
  const createdPaymentIds = [];
  const createdFiles = [];
  let createdBackupFile = "";
  let createdBranchId = null;

  try {
    // Resolve active secret admin gate path from DB (never hardcoded)
    const gateRow = db.prepare("SELECT value FROM system_settings WHERE key = 'ADMIN_PATH'").get();
    const adminSlug = String(gateRow?.value || "");

    // 1. Security Headers + x-powered-by disabled
    {
      const r = await req("/api/health", { includeOrigin: false });
      const csp = r.headers.get("content-security-policy") || "";
      const nosniff = r.headers.get("x-content-type-options") || "";
      const refPol = r.headers.get("referrer-policy") || "";
      const permPol = r.headers.get("permissions-policy") || "";
      const powered = r.headers.get("x-powered-by");
      const ok =
        r.status === 200 &&
        csp.includes("frame-ancestors 'self'") &&
        csp.includes("checkout.razorpay.com") &&
        nosniff === "nosniff" &&
        Boolean(refPol) &&
        Boolean(permPol) &&
        !powered;
      record(
        "Security Headers (CSP, nosniff, Referrer, Permissions, no x-powered-by)",
        ok ? "PASS" : "FAIL",
        ok ? "All required headers present and x-powered-by disabled" : `Missing/invalid headers (status=${r.status}, csp=${Boolean(csp)}, powered=${powered})`
      );
    }

    // 2. CSRF Protection (missing Origin blocked, cross-origin blocked, token allowed, webhook exempt)
    {
      const rMissing = await req("/api/auth/login", {
        method: "POST",
        includeOrigin: false,
        body: { identifier: "nobody@example.com", password: "wrong" }
      });
      const rCross = await req("/api/auth/login", {
        method: "POST",
        includeOrigin: false,
        headers: { Origin: "https://attacker.example" },
        body: { identifier: "nobody@example.com", password: "wrong" }
      });
      const rGet = await req("/api/health", { includeOrigin: false });
      const csrfToken = rGet.cookies.yu_csrf || "";
      const rTokenOk = await req("/api/auth/login", {
        method: "POST",
        includeOrigin: false,
        cookies: { yu_csrf: csrfToken },
        headers: { "X-CSRF-Token": csrfToken },
        body: { identifier: "nobody@example.com", password: "wrong" }
      });
      const rWebhook = await req("/api/payments/webhook", {
        method: "POST",
        includeOrigin: false,
        body: { event: "payment.captured" }
      });
      const ok =
        rMissing.status === 403 &&
        rCross.status === 403 &&
        rTokenOk.status === 401 && // passed CSRF, reached auth handler
        rWebhook.status !== 403; // exempt from CSRF (400 or 503 signature check)
      record(
        "CSRF Protection (missing Origin, cross-origin, token, webhook exempt)",
        ok ? "PASS" : "FAIL",
        `missing=${rMissing.status}, cross=${rCross.status}, token=${rTokenOk.status}, webhook=${rWebhook.status}`
      );
    }

    // Seed temporary test accounts directly in SQLite (cleaned up in finally)
    const pw = "StrongTestPass!2026";
    const pwHash = bcrypt.hashSync(pw, 10);
    const now = new Date().toISOString();

    const insertUser = (role, name, email, phone, extra = {}) => {
      const ins = db
        .prepare(
          `INSERT INTO users (role, staff_role, staff_permissions_json, branch_id, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved', 1, 0, ?, ?, ?)`
        )
        .run(
          role,
          extra.staffRole || "",
          JSON.stringify(extra.perms || []),
          extra.branchId ?? null,
          name,
          email,
          phone,
          pwHash,
          extra.mobileVerified ?? 1,
          crypto.randomBytes(12).toString("hex"),
          now,
          now
        );
      const id = Number(ins.lastInsertRowid);
      createdUserIds.push(id);
      return id;
    };

    const existingBranch = db.prepare("SELECT id FROM branches ORDER BY id ASC LIMIT 1").get();
    const branch1Id = existingBranch ? Number(existingBranch.id) : 1;
    const brIns = db
      .prepare("INSERT INTO branches (name, code, address, city, phone, is_active, created_at) VALUES (?, ?, 'Test Rd', 'Muradnagar', '9999999999', 1, ?)")
      .run(`Smoke Branch ${tag}`, `SB-${tag.slice(-6).toUpperCase()}`, now);
    createdBranchId = Number(brIns.lastInsertRowid);

    const stuEmail = `${tag}_stu@example.test`;
    const stuId = insertUser("student", "Smoke Student One", stuEmail, "9810000101");
    const stuRoll = `YTR-SMK-${stuId}`;
    db.prepare(
      `INSERT INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, parent_phone, enrollment_status, roll_number, branch_id)
       VALUES (?, 'Class 12', 'CBSE', '["Physics"]', 12, '9810000999', 'active', ?, ?)`
    ).run(stuId, stuRoll, branch1Id);

    const stu2Id = insertUser("student", "Smoke Student Branch2", `${tag}_stu2@example.test`, "9810000102");
    db.prepare(
      `INSERT INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, parent_phone, enrollment_status, roll_number, branch_id)
       VALUES (?, 'Class 10', 'UP Board', '["Math"]', 12, '9810000888', 'active', ?, ?)`
    ).run(stu2Id, `YTR-SMK-${stu2Id}`, createdBranchId);

    // 3. Login + Session Regeneration + Logout Invalidation
    let stuCookies = {};
    {
      const r1 = await req("/api/auth/login", { method: "POST", body: { identifier: stuEmail, password: pw } });
      const sid1 = r1.cookies.yu_session || "";
      const r2 = await req("/api/auth/login", { method: "POST", cookies: r1.cookies, body: { identifier: stuEmail, password: pw } });
      const sid2 = r2.cookies.yu_session || "";
      const sid1Id = sid1.split(".")[0];
      const oldSessionInDb = sid1Id ? db.prepare("SELECT id FROM sessions WHERE id = ?").get(sid1Id) : null;

      const rLogout = await req("/api/auth/logout", { method: "POST", cookies: r2.cookies });
      const rMeAfter = await req("/api/auth/me", { cookies: r2.cookies }); // reusing old cookie
      const ok =
        r1.status === 200 &&
        r2.status === 200 &&
        Boolean(sid1) &&
        Boolean(sid2) &&
        sid1 !== sid2 &&
        !oldSessionInDb &&
        rLogout.status === 200 &&
        rMeAfter.json?.authenticated === false;
      record(
        "Auth Login, Session Regeneration & Logout Invalidation",
        ok ? "PASS" : "FAIL",
        ok ? "New session token issued on re-login, prior session purged, logout invalidates token" : `r1=${r1.status}, regen=${sid1 !== sid2}, oldDeleted=${!oldSessionInDb}, postLogoutAuth=${rMeAfter.json?.authenticated}`
      );
      // Re-login cleanly for subsequent student tests
      const r3 = await req("/api/auth/login", { method: "POST", body: { identifier: stuEmail, password: pw } });
      stuCookies = r3.cookies;
    }

    // 4. Rate Limit + IP Spoofing Immunity (X-Forwarded-For rotation)
    {
      const targetEmail = `${tag}_rl@example.test`;
      let hit429 = false;
      for (let i = 1; i <= 8; i++) {
        const r = await req("/api/auth/login", {
          method: "POST",
          headers: { "X-Forwarded-For": `203.0.113.${i}` },
          body: { identifier: targetEmail, password: "wrong-password" }
        });
        if (r.status === 429) {
          hit429 = true;
          break;
        }
      }
      // Clean up rate limit entry created by smoke test
      db.prepare("DELETE FROM rate_limits WHERE key LIKE ?").run(`%${targetEmail}%`);
      record(
        "Rate Limit Lockout & X-Forwarded-For Spoof Immunity",
        hit429 ? "PASS" : "FAIL",
        hit429 ? "429 lockout triggered despite rotating forged X-Forwarded-For headers" : "Did not trigger 429 lockout"
      );
    }

    // 5. Parent-Student Link (Roll-only IDOR blocked + Admin approval flow + IDOR messages blocked)
    {
      const attackerParentEmail = `${tag}_att_parent@example.test`;
      insertUser("parent", "Attacker Parent", attackerParentEmail, "9810000222", { mobileVerified: 1 });
      const attLogin = await req("/api/auth/login", { method: "POST", body: { identifier: attackerParentEmail, password: pw } });

      // Attempt 1: Roll-number-only link MUST fail 403!
      const rRollOnly = await req("/api/parent/link-child", {
        method: "POST",
        cookies: attLogin.cookies,
        body: { rollNumber: stuRoll }
      });
      // Attempt 2: Parent messaging unlinked child MUST fail 403!
      const rIdorMsg = await req("/api/parent/messages", {
        method: "POST",
        cookies: attLogin.cookies,
        body: { studentId: stuId, teacherId: 1, message: "Unauthorized probe" }
      });
      // Attempt 3: Request admin approval -> 202 pendingApproval (not yet linked!)
      const rReqApprove = await req("/api/parent/link-child", {
        method: "POST",
        cookies: attLogin.cookies,
        body: { rollNumber: stuRoll, requestApproval: true }
      });
      const linkExistsBeforeAdmin = db
        .prepare("SELECT id FROM parent_links WHERE student_user_id = ?")
        .get(stuId);

      // Attempt 4: Legitimate parent with matching verified parent_phone requests OTP -> 200
      const legitParentEmail = `${tag}_legit_parent@example.test`;
      insertUser("parent", "Legit Parent", legitParentEmail, "9810000999", { mobileVerified: 1 });
      const legitLogin = await req("/api/auth/login", { method: "POST", body: { identifier: legitParentEmail, password: pw } });
      const rReqOtp = await req("/api/parent/link-child/request-otp", {
        method: "POST",
        cookies: legitLogin.cookies,
        body: { rollNumber: stuRoll }
      });
      const ok =
        rRollOnly.status === 403 &&
        rIdorMsg.status === 403 &&
        rReqApprove.status === 202 &&
        rReqApprove.json?.pendingApproval === true &&
        !linkExistsBeforeAdmin &&
        rReqOtp.status === 200;
      record(
        "Parent-Student Link (Roll-Only Blocked, IDOR Blocked, OTP & Admin Approval)",
        ok ? "PASS" : "FAIL",
        `rollOnly=${rRollOnly.status}, idorMsg=${rIdorMsg.status}, approvalReq=${rReqApprove.status}, notAutoLinked=${!linkExistsBeforeAdmin}, legitOtpReq=${rReqOtp.status}`
      );
    }

    // 6. First-Admin Setup Hardening (Pre-setup empty key / SMTP / email override blocked + Post-setup 410 lockdown)
    let tempAdminId = null;
    {
      const existingAdmins = Number(db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('admin','super_admin')").get()?.c || 0);
      if (existingAdmins === 0 && adminSlug) {
        const rSmtp = await req(`/api/${adminSlug}/installer/send-otp`, {
          method: "POST",
          body: { setupKey: "x".repeat(24), smtp: { host: "evil.smtp", port: 465, user: "a@b.com", pass: "123" } }
        });
        const rEmail = await req(`/api/${adminSlug}/installer/send-otp`, {
          method: "POST",
          body: { setupKey: "x".repeat(24), otpEmail: "attacker@evil.com" }
        });
        const rEmptyKey = await req(`/api/${adminSlug}/installer/send-otp`, {
          method: "POST",
          body: { setupKey: "" }
        });
        const rRunEmpty = await req(`/api/${adminSlug}/installer/run`, {
          method: "POST",
          body: { setupKey: "", email: "hack@evil.com", fullName: "Hack", password: "Password1234", otp: "123456" }
        });
        // Now insert temporary super_admin to verify post-setup permanent 410 disablement!
        tempAdminId = insertUser("super_admin", "Smoke Super Admin", `${tag}_admin@example.test`, "9810000777");
        const rPreLocked = await req(`/api/${adminSlug}/installer/preflight`);
        const rSendLocked = await req(`/api/${adminSlug}/installer/send-otp`, { method: "POST", body: { setupKey: "x".repeat(24) } });
        const rRunLocked = await req(`/api/${adminSlug}/installer/run`, { method: "POST", body: { setupKey: "x".repeat(24) } });
        const ok =
          rSmtp.status === 403 &&
          rEmail.status === 403 &&
          rEmptyKey.status === 403 &&
          rRunEmpty.status === 403 &&
          rPreLocked.status === 410 &&
          rSendLocked.status === 410 &&
          rRunLocked.status === 410;
        record(
          "Admin Installer Hardening (No Empty Key, No SMTP/Email Override, Post-Setup 410 Lock)",
          ok ? "PASS" : "FAIL",
          `smtp=${rSmtp.status}, customEmail=${rEmail.status}, emptyKey=${rEmptyKey.status}, runEmpty=${rRunEmpty.status}, lockedPre=${rPreLocked.status}, lockedSend=${rSendLocked.status}, lockedRun=${rRunLocked.status}`
        );
      } else if (existingAdmins > 0 && adminSlug) {
        const rPre = await req(`/api/${adminSlug}/installer/preflight`);
        const rSend = await req(`/api/${adminSlug}/installer/send-otp`, { method: "POST", body: { setupKey: "" } });
        const rRun = await req(`/api/${adminSlug}/installer/run`, { method: "POST", body: { setupKey: "" } });
        const ok = rPre.status === 410 && rSend.status === 410 && rRun.status === 410;
        record(
          "Admin Installer Lockdown (Disabled After Setup)",
          ok ? "PASS" : "FAIL",
          `preflight=${rPre.status}, sendOtp=${rSend.status}, run=${rRun.status}`
        );
      } else {
        record("Admin Installer Lockdown", "NOT TESTED", "ADMIN_PATH not found in DB");
      }
    }

    // 7. Staff Role + Branch Isolation & Librarian PII Strip
    {
      const libEmail = `${tag}_lib@example.test`;
      insertUser("staff", "Smoke Librarian", libEmail, "9810000333", { staffRole: "librarian", branchId: branch1Id });
      const libLogin = await req("/api/auth/login", { method: "POST", body: { identifier: libEmail, password: pw } });
      const rDash = await req("/api/staff/dashboard", { cookies: libLogin.cookies });
      const rLib = await req("/api/staff/library", { cookies: libLogin.cookies });
      const rReports = await req("/api/staff/reports/overview", { cookies: libLogin.cookies });

      const dashStudents = Array.isArray(rDash.json?.students) ? rDash.json.students : [];
      const hasPiiLeak = dashStudents.some((s) => "phone" in s || "roll_number" in s || "class_level" in s);
      const hasBranch2Leak = dashStudents.some((s) => Number(s.id) === stu2Id);
      const libIssues = Array.isArray(rLib.json?.issues) ? rLib.json.issues : [];
      const issueHasRoll = libIssues.some((i) => "roll_number" in i);
      const ok =
        rDash.status === 200 &&
        !hasPiiLeak &&
        !hasBranch2Leak &&
        rLib.status === 200 &&
        !issueHasRoll &&
        rReports.status === 403;
      record(
        "Staff Branch Scoping & Librarian PII/Academic Isolation",
        ok ? "PASS" : "FAIL",
        `dash=${rDash.status}, piiLeak=${hasPiiLeak}, crossBranchLeak=${hasBranch2Leak}, issueRollLeak=${issueHasRoll}, reportsBlocked=${rReports.status}`
      );
    }

    // 8. Payment Verify, Webhook Signature & Idempotency
    {
      const hasRzpSecret = Boolean((process.env.RAZORPAY_KEY_SECRET || "").trim());
      const hasWebhookSecret = Boolean((process.env.RAZORPAY_WEBHOOK_SECRET || "").trim());
      const courseRow = db.prepare("SELECT id FROM courses WHERE is_active = 1 LIMIT 1").get();
      if (hasWebhookSecret) {
        const badSig = await req("/api/payments/webhook", {
          method: "POST",
          includeOrigin: false,
          headers: { "X-Razorpay-Signature": "0".repeat(64) },
          body: { event: "payment.captured" }
        });
        record(
          "Razorpay Webhook Signature Verification",
          badSig.status === 400 ? "PASS" : "FAIL",
          `Invalid webhook signature returned HTTP ${badSig.status}`
        );
      } else {
        const noSecret = await req("/api/payments/webhook", {
          method: "POST",
          includeOrigin: false,
          body: { event: "payment.captured" }
        });
        record(
          "Razorpay Webhook Signature Verification (Fail-Closed when Secret Unset)",
          noSecret.status === 503 ? "PASS" : "FAIL",
          `RAZORPAY_WEBHOOK_SECRET not configured in dev env; endpoint fails closed with HTTP ${noSecret.status}`
        );
      }
      if (hasRzpSecret && courseRow) {
        const forgedSig = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET).update("order_forged|pay_forged").digest("hex");
        const rForged = await req("/api/payments/enroll", {
          method: "POST",
          cookies: stuCookies,
          body: {
            courseId: courseRow.id,
            plan: "monthly",
            paymentMethod: "gateway",
            gatewayOrderId: "order_forged",
            gatewayPaymentId: "pay_forged",
            gatewaySignature: forgedSig
          }
        });
        record(
          "Payment Server-Side Order Ownership Check",
          rForged.status === 400 ? "PASS" : "FAIL",
          `Forged non-server order rejected with HTTP ${rForged.status}`
        );
      } else {
        record(
          "Live Razorpay Gateway Signature & Order Creation",
          "NOT TESTED",
          "RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET not configured in local dev environment (HMAC/idempotency verified via isolated test)"
        );
      }
    }

    // 9. File Upload Magic-Bytes + Auth Download + Path Traversal + ClamAV status
    {
      const badForm = new FormData();
      badForm.append("file", new Blob(["<?php echo 'pwn'; ?>"], { type: "application/pdf" }), "shell.pdf");
      const rBadUp = await req("/api/uploads", { method: "POST", cookies: stuCookies, body: badForm });

      const dblForm = new FormData();
      dblForm.append("file", new Blob(["%PDF-1.7\n1 0 obj\n<<>>\nendobj\n"], { type: "application/pdf" }), "evil.php.pdf");
      const rDblUp = await req("/api/uploads", { method: "POST", cookies: stuCookies, body: dblForm });

      const goodForm = new FormData();
      goodForm.append("file", new Blob(["%PDF-1.7\n1 0 obj\n<<>>\nendobj\n"], { type: "application/pdf" }), "notes.pdf");
      const rGoodUp = await req("/api/uploads", { method: "POST", cookies: stuCookies, body: goodForm });
      const uploadedName = rGoodUp.json?.filename || "";
      if (uploadedName) {
        createdFiles.push(path.resolve(process.cwd(), "uploads", uploadedName));
      }
      const rUnauthDl = uploadedName ? await req(`/uploads/${uploadedName}`) : { status: 0 };
      const rAuthDl = uploadedName ? await req(`/uploads/${uploadedName}`, { cookies: stuCookies }) : { status: 0 };
      const rResumeBlock = await req("/uploads/resumes/test.pdf");
      const rTrav = await req("/uploads/..%2Fserver.js", { cookies: stuCookies });

      const ok =
        rBadUp.status === 400 &&
        rDblUp.status === 400 &&
        rGoodUp.status === 201 &&
        rUnauthDl.status === 401 &&
        rAuthDl.status === 200 &&
        rResumeBlock.status === 403 &&
        (rTrav.status === 400 || rTrav.status === 403 || rTrav.status === 404);
      record(
        "File Upload Magic-Bytes, Double-Ext Block & Auth-Gated PDF Download",
        ok ? "PASS" : "FAIL",
        `fakePdf=${rBadUp.status}, dblExt=${rDblUp.status}, validPdf=${rGoodUp.status}, unauthDl=${rUnauthDl.status}, authDl=${rAuthDl.status}, resumes=${rResumeBlock.status}, traversal=${rTrav.status}`
      );

      const avCheck = uploadedName ? scanUploadedFileWithClamAv(path.resolve(process.cwd(), "uploads", uploadedName)) : { available: false };
      record(
        "ClamAV Malware Scanning on Upload",
        avCheck.available && avCheck.scanned ? "PASS" : "NOT TESTED",
        avCheck.available ? `Scanned (${avCheck.status})` : "ClamAV binary (clamdscan/clamscan) not installed in container; hook integrated"
      );
    }

    // 10. DB / Secrets / Backups Public URL Exposure & Admin-Only Backup Access
    {
      const probes = [
        "/data/yuitor.db",
        "/.env",
        "/backups/test.db",
        "/backup_original/server.js",
        "/logs/install.log",
        "/server.js",
        "/SECURITY_REPORT.md"
      ];
      const probeStatuses = [];
      for (const p of probes) {
        const r = await req(p);
        probeStatuses.push(`${p}:${r.status}`);
      }
      const allBlocked = probeStatuses.every((s) => s.endsWith(":404"));

      const rUnauthBackup = adminSlug ? await req(`/api/${adminSlug}/backups`) : { status: 404 };
      const rStuBackup = adminSlug ? await req(`/api/${adminSlug}/backups`, { cookies: stuCookies }) : { status: 404 };

      const dataMode = (fs.statSync(path.resolve(process.cwd(), "data")).mode & 0o777).toString(8);
      const dbMode = (fs.statSync(DB_PATH).mode & 0o777).toString(8);
      const backupsMode = (fs.statSync(path.resolve(process.cwd(), "backups")).mode & 0o777).toString(8);

      // Admin public password reset must be blocked
      const rAdminReset = tempAdminId
        ? await req("/api/auth/reset-password", {
            method: "POST",
            body: { identifier: `${tag}_admin@example.test`, otp: "123456", newPassword: "NewPassword!999" }
          })
        : { status: 400 };

      const ok =
        allBlocked &&
        (rUnauthBackup.status === 401 || rUnauthBackup.status === 403) &&
        rStuBackup.status === 403 &&
        dataMode === "700" &&
        backupsMode === "700" &&
        dbMode === "600" &&
        rAdminReset.status === 400;
      record(
        "Sensitive Files Blocked (404), Backup Auth, Admin Public Reset Blocked & 0700/0600 Permissions",
        ok ? "PASS" : "FAIL",
        `allPublicBlocked=${allBlocked}, unauthBackup=${rUnauthBackup.status}, studentBackup=${rStuBackup.status}, dataMode=${dataMode}, backupsMode=${backupsMode}, dbMode=${dbMode}, adminPublicReset=${rAdminReset.status}`
      );
    }
  } finally {
    // Cleanup all temporary smoke test records & files
    for (const pid of createdPaymentIds) {
      try {
        db.prepare("DELETE FROM payments WHERE id = ?").run(pid);
      } catch {}
    }
    for (const uid of createdUserIds) {
      try {
        db.prepare("DELETE FROM users WHERE id = ?").run(uid);
      } catch {}
    }
    if (createdBranchId) {
      try {
        db.prepare("DELETE FROM branches WHERE id = ?").run(createdBranchId);
      } catch {}
    }
    try {
      db.prepare("DELETE FROM audit_logs WHERE details LIKE '%Smoke%' OR target_name LIKE ? OR actor_name LIKE '%Smoke%'").run(`%${tag}%`);
    } catch {}
    for (const fp of createdFiles) {
      try {
        if (fs.existsSync(fp)) fs.unlinkSync(fp);
      } catch {}
    }
    if (createdBackupFile && fs.existsSync(createdBackupFile)) {
      try {
        fs.unlinkSync(createdBackupFile);
      } catch {}
    }
    db.close();
  }

  const failed = results.filter((r) => r.status === "FAIL");
  console.log("\n=== SUMMARY ===");
  console.log(`PASS: ${results.filter((r) => r.status === "PASS").length} | FAIL: ${failed.length} | NOT TESTED: ${results.filter((r) => r.status === "NOT TESTED").length}`);
  if (failed.length > 0) {
    process.exitCode = 1;
  }
}

run().catch((err) => {
  console.error("Smoke test crashed:", err);
  process.exitCode = 1;
});
