import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { execFileSync } from "node:child_process";

const CSRF_COOKIE_NAME = "yu_csrf";

const DANGEROUS_EXT_RE = /\.(?:php\d?|phtml|phar|exe|dll|bat|cmd|com|msi|sh|bash|zsh|ps1|vbs|js|mjs|cjs|jsx|ts|tsx|html?|xhtml|svg|svgz|jsp|jspx|asp|aspx|cgi|pl|py|rb|jar|war|htaccess)(?:\.|$)/i;

const EXTENSION_MIME_ALLOWLIST = {
  ".pdf": new Set(["application/pdf", "application/x-pdf"]),
  ".png": new Set(["image/png"]),
  ".jpg": new Set(["image/jpeg", "image/jpg", "image/pjpeg"]),
  ".jpeg": new Set(["image/jpeg", "image/jpg", "image/pjpeg"]),
  ".webp": new Set(["image/webp"]),
  ".doc": new Set(["application/msword", "application/rtf", "text/rtf"]),
  ".docx": new Set([
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/zip"
  ]),
  ".txt": new Set(["text/plain"]),
  ".md": new Set(["text/markdown", "text/plain", "text/x-markdown"])
};

let cachedClamBinary = undefined;

export function resolveTrustProxySetting(rawEnv) {
  const raw = String(rawEnv ?? "").trim();
  if (!raw || raw.toLowerCase() === "false" || raw === "0" || raw.toLowerCase() === "off") {
    return false;
  }
  if (raw.toLowerCase() === "true") {
    return true;
  }
  if (/^\d+$/.test(raw)) {
    const hops = Number(raw);
    return Number.isSafeInteger(hops) && hops >= 0 && hops <= 10 ? hops : false;
  }
  return raw;
}

export function normalizeIpAddress(raw) {
  const s = String(raw ?? "").trim();
  if (!s) return "0.0.0.0";
  if (s.startsWith("::ffff:")) {
    return s.slice(7);
  }
  return s;
}

export function safeClientIp(req) {
  // Never blindly read req.headers['x-forwarded-for']!
  // Express computes req.ip strictly according to app.set('trust proxy', ...).
  const ip = req?.ip || req?.socket?.remoteAddress || req?.connection?.remoteAddress || "0.0.0.0";
  return normalizeIpAddress(ip);
}

export function verifyStrictSetupKey(providedKey, expectedKey = process.env.YU_ADMIN_SETUP_KEY) {
  const expected = String(expectedKey ?? "").trim();
  const provided = String(providedKey ?? "").trim();
  // Fail-closed: YU_ADMIN_SETUP_KEY MUST be explicitly configured with >= 16 chars
  if (!expected || expected.length < 16 || !provided) {
    return false;
  }
  const a = Buffer.from(provided, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function isInstallerWindowExpired(expiresAtRaw = process.env.YU_ADMIN_SETUP_EXPIRES_AT, nowMs = Date.now()) {
  const raw = String(expiresAtRaw ?? "").trim();
  if (!raw) return false;
  if (/^\d{10,13}$/.test(raw)) {
    const num = Number(raw);
    const ms = raw.length === 10 ? num * 1000 : num;
    return Number.isFinite(ms) && nowMs > ms;
  }
  const parsed = Date.parse(raw);
  if (Number.isNaN(parsed)) return true; // fail-closed on malformed expiry
  return nowMs > parsed;
}

export function resolveInstallerOwnerEmail(env = process.env) {
  const candidate = String(env.OWNER_EMAIL || env.ADMIN_OTP_EMAIL || "").trim().toLowerCase();
  if (!candidate || candidate.length > 254) return "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(candidate)) return "";
  return candidate;
}

export function generateHighEntropyAdminSlug() {
  // 16 cryptographically random bytes = 128 bits of entropy (34-char URL slug)
  return `g-${crypto.randomBytes(16).toString("hex")}`;
}

export function redactSecretsForLog(input, extraSecrets = []) {
  let text = String(input ?? "");
  if (!text) return "";

  // Redact explicit runtime secrets first
  const runtimeSecrets = [
    process.env.SESSION_SECRET,
    process.env.YU_ADMIN_SETUP_KEY,
    process.env.ADMIN_PATH,
    process.env.SMTP_PASS,
    process.env.RAZORPAY_KEY_SECRET,
    process.env.RAZORPAY_WEBHOOK_SECRET,
    process.env.GEMINI_API_KEY,
    process.env.FAST2SMS_API_KEY,
    process.env.WHATSAPP_API_TOKEN,
    ...extraSecrets
  ]
    .map((s) => String(s ?? "").trim())
    .filter((s) => s.length >= 6);

  for (const secret of runtimeSecrets) {
    if (text.includes(secret)) {
      text = text.split(secret).join("[REDACTED]");
    }
  }

  // Redact common credential / token / OTP key-value patterns
  text = text
    .replace(/\b(Bearer\s+)[A-Za-z0-9._~+/=-]{8,}/gi, "$1[REDACTED]")
    .replace(/\b(yu_session=)[^;\s]+/gi, "$1[REDACTED]")
    .replace(
      /\b(password|passwd|pwd|otp|otp_code|otpCode|api[_-]?key|secret|token|authorization|cookie|setup[_-]?key)\s*[:=]\s*["']?[^\s"',;}{]+["']?/gi,
      "$1=[REDACTED]"
    )
    .replace(/\b(AIza[0-9A-Za-z_-]{20,}|rzp_(?:live|test)_[0-9A-Za-z]{10,})\b/g, "[REDACTED]");

  return text.slice(0, 1200);
}

export function buildCspHeader() {
  return [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://checkout.razorpay.com https://static.cloudflareinsights.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: blob: https:",
    "manifest-src 'self'",
    "worker-src 'self' blob:",
    "child-src 'self' blob: https://api.razorpay.com https://checkout.razorpay.com",
    "connect-src 'self' https://api.razorpay.com https://lumberjack.razorpay.com https://generativelanguage.googleapis.com https://cloudflareinsights.com",
    "frame-src 'self' https://api.razorpay.com https://checkout.razorpay.com",
    "frame-ancestors 'self'",
    "base-uri 'self'",
    "form-action 'self'",
    "object-src 'none'"
  ].join("; ");
}

export function issueCsrfCookieIfMissing(req, res) {
  const existing = String(req.cookies?.[CSRF_COOKIE_NAME] || "").trim();
  if (/^[a-f0-9]{32,64}$/i.test(existing)) {
    return existing;
  }
  const token = crypto.randomBytes(24).toString("hex");
  const isHttps = Boolean(req.secure || (req.app?.get("trust proxy") && req.headers["x-forwarded-proto"] === "https"));
  res.cookie(CSRF_COOKIE_NAME, token, {
    httpOnly: false, // readable by same-origin JS for double-submit header
    sameSite: "lax",
    secure: isHttps,
    path: "/"
  });
  return token;
}

export function verifyCsrfProtection(req) {
  const method = String(req.method || "GET").toUpperCase();
  if (["GET", "HEAD", "OPTIONS"].includes(method)) {
    return { ok: true };
  }
  // Razorpay webhook is authenticated via HMAC-SHA256 X-Razorpay-Signature
  if (req.path === "/payments/webhook" || String(req.originalUrl || "").startsWith("/api/payments/webhook")) {
    return { ok: true };
  }

  const allowedHosts = new Set();
  const hostCandidates = [
    req.headers.host,
    req.hostname
  ];
  if (req.app?.get("trust proxy")) {
    hostCandidates.push(req.headers["x-forwarded-host"]);
  }
  for (const raw of hostCandidates) {
    for (const part of String(raw || "").split(",")) {
      const h = part.trim().split(":")[0].toLowerCase().replace(/^www\./, "");
      if (h) allowedHosts.add(h);
    }
  }
  const appUrl = String(process.env.APP_URL || "").trim();
  if (appUrl && !appUrl.includes("MY_APP_URL")) {
    try {
      allowedHosts.add(new URL(appUrl).hostname.toLowerCase().replace(/^www\./, ""));
    } catch {
      // ignore invalid APP_URL
    }
  }

  const rawOrigin = String(req.headers.origin || "").trim();
  const rawReferer = String(req.headers.referer || "").trim();
  // Some mobile WebViews / privacy proxies send literal "null" for Origin; fall back cleanly to Referer or CSRF token.
  const sourceHeader = (rawOrigin && rawOrigin.toLowerCase() !== "null") ? rawOrigin : rawReferer;
  if (sourceHeader && sourceHeader.toLowerCase() !== "null") {
    try {
      const originUrl = new URL(sourceHeader);
      if (originUrl.protocol !== "http:" && originUrl.protocol !== "https:") {
        return { ok: false, reason: "Invalid request origin protocol." };
      }
      const originHost = originUrl.hostname.toLowerCase().replace(/^www\./, "");
      if (allowedHosts.size > 0 && !allowedHosts.has(originHost)) {
        return { ok: false, reason: "Cross-origin state-changing request blocked." };
      }
      return { ok: true };
    } catch {
      return { ok: false, reason: "Invalid Origin/Referer header." };
    }
  }

  // Origin/Referer missing or literal "null": require explicit double-submit CSRF token!
  const cookieToken = String(req.cookies?.[CSRF_COOKIE_NAME] || "").trim();
  const headerToken = String(req.headers["x-csrf-token"] || req.headers["x-xsrf-token"] || "").trim();
  if (
    cookieToken &&
    headerToken &&
    /^[a-f0-9]{32,64}$/i.test(cookieToken) &&
    cookieToken.length === headerToken.length &&
    crypto.timingSafeEqual(Buffer.from(cookieToken, "utf8"), Buffer.from(headerToken, "utf8"))
  ) {
    return { ok: true };
  }

  return {
    ok: false,
    reason: "CSRF protection: missing Origin/Referer header and valid X-CSRF-Token."
  };
}

export function hasExecutableSignature(buf) {
  if (!buf || buf.length < 2) return false;
  // PE/MZ (Windows .exe/.dll), ELF (Linux binary), Mach-O, Shebang (#!)
  if (buf[0] === 0x4d && buf[1] === 0x5a) return true;
  if (buf.length >= 4 && buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46) return true;
  if (buf.length >= 4 && (
    (buf[0] === 0xfe && buf[1] === 0xed && buf[2] === 0xfa && (buf[3] === 0xce || buf[3] === 0xcf)) ||
    (buf[0] === 0xcf && buf[1] === 0xfa && buf[2] === 0xed && buf[3] === 0xfe)
  )) return true;
  if (buf[0] === 0x23 && buf[1] === 0x21) return true; // #!
  const headText = buf.subarray(0, Math.min(buf.length, 64)).toString("utf8").trimStart().toLowerCase();
  if (headText.startsWith("<?php") || headText.startsWith("<script") || headText.startsWith("<svg") || headText.startsWith("<!doctype html") || headText.startsWith("<html")) {
    return true;
  }
  return false;
}

export function validateUploadMagicAndMime(filePath, originalName, mimeType, allowedExts) {
  try {
    const baseName = path.basename(String(originalName || ""));
    if (!baseName || baseName.includes("\0") || DANGEROUS_EXT_RE.test(baseName)) {
      return { ok: false, error: "Executable or disallowed file extension blocked." };
    }
    const ext = path.extname(baseName).toLowerCase();
    if (!allowedExts.has(ext)) {
      return { ok: false, error: "File extension is not allowed." };
    }

    const normalizedMime = String(mimeType || "").split(";")[0].trim().toLowerCase();
    const expectedMimes = EXTENSION_MIME_ALLOWLIST[ext];
    if (normalizedMime && expectedMimes && !expectedMimes.has(normalizedMime)) {
      return { ok: false, error: `File MIME type (${normalizedMime}) does not match ${ext}.` };
    }

    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size <= 0) {
      return { ok: false, error: "Uploaded file is empty." };
    }

    const readLen = Math.min(stat.size, 8192);
    const fd = fs.openSync(filePath, "r");
    const buf = Buffer.alloc(readLen);
    const bytesRead = fs.readSync(fd, buf, 0, readLen, 0);
    fs.closeSync(fd);
    if (bytesRead < 3) {
      return { ok: false, error: "Uploaded file is too small or corrupted." };
    }

    if (hasExecutableSignature(buf.subarray(0, bytesRead))) {
      return { ok: false, error: "Executable or active script payload detected and blocked." };
    }

    if (ext === ".pdf") {
      return buf.subarray(0, 5).toString("ascii") === "%PDF-"
        ? { ok: true }
        : { ok: false, error: "File signature does not match a valid PDF document." };
    }
    if (ext === ".png") {
      const ok = bytesRead >= 8 &&
        buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
        buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a;
      return ok ? { ok: true } : { ok: false, error: "File signature does not match PNG." };
    }
    if (ext === ".jpg" || ext === ".jpeg") {
      const ok = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
      return ok ? { ok: true } : { ok: false, error: "File signature does not match JPEG." };
    }
    if (ext === ".webp") {
      const ok = bytesRead >= 12 &&
        buf.subarray(0, 4).toString("ascii") === "RIFF" &&
        buf.subarray(8, 12).toString("ascii") === "WEBP";
      return ok ? { ok: true } : { ok: false, error: "File signature does not match WebP." };
    }
    if (ext === ".doc") {
      const isOle = bytesRead >= 4 && buf[0] === 0xd0 && buf[1] === 0xcf && buf[2] === 0x11 && buf[3] === 0xe0;
      const isRtf = bytesRead >= 5 && buf.subarray(0, 5).toString("ascii") === "{\\rtf";
      return isOle || isRtf ? { ok: true } : { ok: false, error: "File signature does not match DOC/RTF." };
    }
    if (ext === ".docx") {
      const isZip = bytesRead >= 4 && buf[0] === 0x50 && buf[1] === 0x4b && (buf[2] === 0x03 || buf[2] === 0x05);
      if (!isZip) {
        return { ok: false, error: "File signature does not match DOCX archive." };
      }
      const asciiScan = buf.subarray(0, bytesRead).toString("latin1");
      const hasDocxMarkers = asciiScan.includes("[Content_Types].xml") || asciiScan.includes("word/");
      if (!hasDocxMarkers) {
        return { ok: false, error: "ZIP archive is not a valid Word DOCX document." };
      }
      return { ok: true };
    }
    if (ext === ".txt" || ext === ".md") {
      if (buf.subarray(0, bytesRead).includes(0)) {
        return { ok: false, error: "Binary content rejected for text document." };
      }
      return { ok: true };
    }
    return { ok: false, error: "Unsupported file type." };
  } catch {
    return { ok: false, error: "Could not validate uploaded file." };
  }
}

function findClamBinary() {
  if (cachedClamBinary !== undefined) return cachedClamBinary;
  for (const bin of ["clamdscan", "clamscan"]) {
    try {
      const out = execFileSync("which", [bin], { encoding: "utf8", timeout: 2000 }).trim();
      if (out) {
        cachedClamBinary = out;
        return cachedClamBinary;
      }
    } catch {
      // try next
    }
  }
  cachedClamBinary = null;
  return null;
}

export function scanUploadedFileWithClamAv(filePath) {
  if (String(process.env.CLAMAV_ENABLED || "").trim() === "0") {
    return { available: false, scanned: false, clean: true, status: "disabled" };
  }
  const bin = findClamBinary();
  if (!bin) {
    return {
      available: false,
      scanned: false,
      clean: true,
      status: "not_verified",
      reason: "ClamAV binary not installed on host"
    };
  }
  try {
    execFileSync(bin, ["--no-summary", "--infected", filePath], {
      encoding: "utf8",
      timeout: 15000
    });
    return { available: true, scanned: true, clean: true, status: "clean" };
  } catch (err) {
    if (err && err.status === 1) {
      return { available: true, scanned: true, clean: false, status: "infected", reason: "Malware detected by ClamAV" };
    }
    return {
      available: true,
      scanned: false,
      clean: true,
      status: "scan_error",
      reason: "ClamAV scan returned transient error"
    };
  }
}

export function isStrictLibrarian(ctx) {
  if (!ctx || ctx.user?.role !== "staff") return false;
  const role = String(ctx.user.staff_role || "").toLowerCase();
  if (role !== "librarian") return false;
  const perms = Array.isArray(ctx.user.staff_permissions) ? ctx.user.staff_permissions : [];
  const academicOrPiiPerms = ["admissions", "fees", "payments", "attendance", "tests", "inquiries", "reports", "*"];
  return !perms.some((p) => academicOrPiiPerms.includes(p));
}

export function getStaffBranchScope(ctx) {
  if (!ctx || ctx.user?.role !== "staff") return null;
  const bid = Number(ctx.user.branch_id || 0);
  return Number.isInteger(bid) && bid > 0 ? bid : null;
}

export function stripLibrarianStudentPii(students) {
  return (students || []).map((s) => ({
    id: s.id,
    full_name: s.full_name
  }));
}

export function stripLibrarianLibraryIssues(issues) {
  return (issues || []).map((row) => {
    const copy = { ...row };
    delete copy.roll_number;
    delete copy.phone;
    delete copy.student_phone;
    delete copy.parent_phone;
    delete copy.class_level;
    return copy;
  });
}

export function hardenRuntimePermissions({ dirs = [], files = [] }) {
  const results = { dirsUpdated: 0, filesUpdated: 0 };
  for (const dirPath of dirs) {
    try {
      if (dirPath && fs.existsSync(dirPath)) {
        fs.chmodSync(dirPath, 0o700);
        results.dirsUpdated += 1;
      }
    } catch {
      // Best-effort on shared hosting / non-POSIX mounts
    }
  }
  for (const filePath of files) {
    try {
      if (filePath && fs.existsSync(filePath)) {
        fs.chmodSync(filePath, 0o600);
        results.filesUpdated += 1;
      }
    } catch {
      // Best-effort
    }
  }
  return results;
}

// ============================================================================
// REAL TEACHER RESUME CONTENT VERIFICATION ENGINE (PDF / DOCX / DOC / RTF)
// Prevents uploading non-resume documents (images, blank PDFs, invoices, random docs)
// ============================================================================

const MAX_RESUME_INFLATE_BYTES = 2 * 1024 * 1024;
const MAX_RESUME_TOTAL_TEXT = 200_000;

function decodeXmlEntities(xml) {
  return String(xml || "")
    .replace(/<w:tab\b[^>]*\/>/gi, " ")
    .replace(/<w:br\b[^>]*\/>/gi, "\n")
    .replace(/<\/w:p>/gi, "\n")
    .replace(/<\/w:tr>/gi, "\n")
    .replace(/<\/w:tc>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => {
      const code = parseInt(hex, 16);
      return Number.isFinite(code) && code >= 32 && code <= 65535 ? String.fromCharCode(code) : " ";
    })
    .replace(/&#(\d+);/g, (_m, dec) => {
      const code = parseInt(dec, 10);
      return Number.isFinite(code) && code >= 32 && code <= 65535 ? String.fromCharCode(code) : " ";
    });
}

export function extractTextFromDocxBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) return "";
  const minOff = Math.max(0, buf.length - 65558);
  let eocd = -1;
  for (let i = buf.length - 22; i >= minOff; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      const cLen = buf.readUInt16LE(i + 20);
      if (i + 22 + cLen === buf.length) {
        eocd = i;
        break;
      }
    }
  }
  if (eocd < 0) return "";
  const entryCount = Math.min(buf.readUInt16LE(eocd + 10), 500);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  let cursor = cdOffset;
  const parts = [];
  let hasDocumentXml = false;

  for (let i = 0; i < entryCount; i++) {
    if (cursor + 46 > eocd || buf.readUInt32LE(cursor) !== 0x02014b50) break;
    const method = buf.readUInt16LE(cursor + 10);
    const compSize = buf.readUInt32LE(cursor + 20);
    const uncompSize = buf.readUInt32LE(cursor + 24);
    const nameLen = buf.readUInt16LE(cursor + 28);
    const extraLen = buf.readUInt16LE(cursor + 30);
    const commLen = buf.readUInt16LE(cursor + 32);
    const localOff = buf.readUInt32LE(cursor + 42);
    const name = buf.subarray(cursor + 46, cursor + 46 + nameLen).toString("utf8");
    cursor += 46 + nameLen + extraLen + commLen;

    const lower = name.toLowerCase();
    if (lower === "word/document.xml") hasDocumentXml = true;
    const isWanted =
      lower === "word/document.xml" ||
      /^word\/(?:header|footer)\d*\.xml$/.test(lower);
    if (!isWanted || uncompSize > MAX_RESUME_INFLATE_BYTES) continue;
    if (localOff + 30 > buf.length || buf.readUInt32LE(localOff) !== 0x04034b50) continue;
    const lNameLen = buf.readUInt16LE(localOff + 26);
    const lExtraLen = buf.readUInt16LE(localOff + 28);
    const start = localOff + 30 + lNameLen + lExtraLen;
    const end = start + compSize;
    if (end > buf.length) continue;

    try {
      const slice = buf.subarray(start, end);
      let rawXml;
      if (method === 0) {
        rawXml = slice.toString("utf8");
      } else if (method === 8) {
        rawXml = zlib.inflateRawSync(slice, { maxOutputLength: MAX_RESUME_INFLATE_BYTES }).toString("utf8");
      } else {
        continue;
      }
      parts.push(decodeXmlEntities(rawXml));
    } catch {
      // Skip unreadable XML stream
    }
  }

  if (!hasDocumentXml) return "";
  return parts.join("\n").slice(0, MAX_RESUME_TOTAL_TEXT);
}

function unescapePdfLiteral(str) {
  let out = "";
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (ch === "\\" && i + 1 < str.length) {
      const nxt = str[++i];
      if (nxt === "n") out += "\n";
      else if (nxt === "r") out += "\r";
      else if (nxt === "t") out += "\t";
      else if (nxt === "b") out += " ";
      else if (nxt === "f") out += " ";
      else if (nxt === "(" || nxt === ")" || nxt === "\\") out += nxt;
      else if (/[0-7]/.test(nxt)) {
        let oct = nxt;
        if (i + 1 < str.length && /[0-7]/.test(str[i + 1])) oct += str[++i];
        if (i + 1 < str.length && /[0-7]/.test(str[i + 1])) oct += str[++i];
        const code = parseInt(oct, 8);
        if (code >= 32 && code <= 126) out += String.fromCharCode(code);
      } else if (nxt === "\r" || nxt === "\n") {
        // line continuation
      } else {
        out += nxt;
      }
    } else {
      out += ch;
    }
  }
  return out;
}

function decodePdfHexString(hexRaw) {
  const clean = hexRaw.replace(/\s+/g, "");
  if (clean.length < 2) return "";
  const padded = clean.length % 2 === 1 ? `${clean}0` : clean;
  const bytes = Buffer.from(padded, "hex");
  // UTF-16BE BOM or wide 0x00XX encoded glyphs
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    let s = "";
    for (let i = 2; i + 1 < bytes.length; i += 2) {
      const code = (bytes[i] << 8) | bytes[i + 1];
      if (code >= 32 && code <= 65534) s += String.fromCharCode(code);
    }
    return s;
  }
  let zeroEven = 0;
  for (let i = 0; i + 1 < bytes.length; i += 2) {
    if (bytes[i] === 0) zeroEven++;
  }
  if (bytes.length >= 4 && zeroEven >= Math.floor(bytes.length / 2) * 0.7) {
    let s = "";
    for (let i = 0; i + 1 < bytes.length; i += 2) {
      const code = (bytes[i] << 8) | bytes[i + 1];
      if (code >= 32 && code <= 126) s += String.fromCharCode(code);
    }
    return s;
  }
  return bytes.toString("latin1").replace(/[^\x20-\x7e\n\r\t]/g, " ");
}

function extractPdfContentOperators(chunkStr) {
  const collected = [];
  // Extract (literal) strings before Tj/TJ/'/" or inside [...] TJ
  let i = 0;
  const len = chunkStr.length;
  while (i < len) {
    const c = chunkStr[i];
    if (c === "(") {
      let depth = 1;
      let start = i + 1;
      i++;
      while (i < len && depth > 0) {
        if (chunkStr[i] === "\\") {
          i += 2;
          continue;
        }
        if (chunkStr[i] === "(") depth++;
        else if (chunkStr[i] === ")") depth--;
        i++;
      }
      const lit = unescapePdfLiteral(chunkStr.slice(start, i - 1));
      if (lit.trim()) collected.push(lit);
    } else if (c === "<" && chunkStr[i + 1] !== "<") {
      const close = chunkStr.indexOf(">", i + 1);
      if (close > i + 1 && close - i < 4096) {
        const inner = chunkStr.slice(i + 1, close);
        if (/^[0-9a-fA-F\s]+$/.test(inner)) {
          const decoded = decodePdfHexString(inner);
          if (decoded.trim()) collected.push(decoded);
        }
        i = close + 1;
      } else {
        i++;
      }
    } else {
      i++;
    }
  }
  return collected.join(" ");
}

export function extractTextFromPdfBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 16) return "";
  const latin = buf.toString("latin1");
  const pieces = [];
  let totalExtracted = 0;

  // 1. Decompress PDF streams and extract text operators
  const streamToken = "stream";
  const endStreamToken = "endstream";
  let pos = 0;
  let streamCount = 0;
  while (pos < latin.length && streamCount < 150 && totalExtracted < MAX_RESUME_TOTAL_TEXT) {
    const sIdx = latin.indexOf(streamToken, pos);
    if (sIdx < 0) break;
    // Ensure word boundary before "stream" (not "endstream")
    if (sIdx > 0 && /[A-Za-z0-9]/.test(latin[sIdx - 1])) {
      pos = sIdx + 6;
      continue;
    }
    let dataStart = sIdx + 6;
    if (latin[dataStart] === "\r" && latin[dataStart + 1] === "\n") dataStart += 2;
    else if (latin[dataStart] === "\n" || latin[dataStart] === "\r") dataStart += 1;
    else {
      pos = sIdx + 6;
      continue;
    }
    const eIdx = latin.indexOf(endStreamToken, dataStart);
    if (eIdx < 0) break;
    pos = eIdx + endStreamToken.length;
    streamCount++;

    const headerSlice = latin.slice(Math.max(0, sIdx - 400), sIdx);
    // Skip image / font / ICC binary streams to avoid noise
    if (/\/Subtype\s*\/Image\b/i.test(headerSlice)) continue;

    const rawStream = buf.subarray(dataStart, eIdx);
    let decodedStr = "";
    if (/\/FlateDecode\b/i.test(headerSlice)) {
      try {
        const inflated = zlib.inflateSync(rawStream, { maxOutputLength: MAX_RESUME_INFLATE_BYTES });
        decodedStr = inflated.toString("latin1");
      } catch {
        try {
          const inflated = zlib.inflateRawSync(rawStream, { maxOutputLength: MAX_RESUME_INFLATE_BYTES });
          decodedStr = inflated.toString("latin1");
        } catch {
          decodedStr = "";
        }
      }
    } else if (!/\/(?:DCTDecode|JPXDecode|JBIG2Decode|CCITTFaxDecode)\b/i.test(headerSlice)) {
      decodedStr = rawStream.toString("latin1");
    }

    if (decodedStr && (decodedStr.includes("Tj") || decodedStr.includes("TJ") || decodedStr.includes("BT") || decodedStr.includes("("))) {
      const txt = extractPdfContentOperators(decodedStr);
      if (txt) {
        pieces.push(txt);
        totalExtracted += txt.length;
      }
    }
  }

  // 2. Fallback for uncompressed simple PDFs where text operators live outside Flate streams
  if (totalExtracted < 60) {
    const direct = extractPdfContentOperators(latin.slice(0, 300_000));
    if (direct.length > totalExtracted) {
      pieces.push(direct);
    }
  }

  return pieces.join("\n").slice(0, MAX_RESUME_TOTAL_TEXT);
}

export function extractTextFromDocBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 16) return "";
  const head = buf.subarray(0, 8).toString("ascii");
  // RTF format
  if (head.startsWith("{\\rtf")) {
    const rtf = buf.toString("latin1").slice(0, MAX_RESUME_TOTAL_TEXT * 2);
    return rtf
      .replace(/\\'([0-9a-f]{2})/gi, (_m, hex) => String.fromCharCode(parseInt(hex, 16)))
      .replace(/\\[a-z]+-?\d*\s?/gi, " ")
      .replace(/[{}]/g, " ")
      .slice(0, MAX_RESUME_TOTAL_TEXT);
  }
  // Legacy OLE binary .doc: extract UTF-16LE runs + ASCII runs
  const parts = [];
  const utf16 = buf.toString("utf16le");
  const u16Matches = utf16.match(/[A-Za-z0-9@.+:,;()\-/& ]{6,}/g) || [];
  for (const m of u16Matches) {
    if (/[A-Za-z]{3,}/.test(m)) parts.push(m);
    if (parts.length > 4000) break;
  }
  const ascii = buf.toString("latin1");
  const aMatches = ascii.match(/[A-Za-z0-9@.+:,;()\-/& ]{8,}/g) || [];
  for (const m of aMatches) {
    if (/[A-Za-z]{3,}/.test(m) && !/^Microsoft\s+Word|^Root\s+Entry|^WordDocument$/i.test(m.trim())) {
      parts.push(m);
    }
    if (parts.length > 8000) break;
  }
  return parts.join(" ").slice(0, MAX_RESUME_TOTAL_TEXT);
}

const RESUME_SIGNAL_GROUPS = [
  {
    id: "profile",
    label: "Profile / Summary",
    patterns: [
      /\b(?:resume|curriculum\s+vitae|bio[\s-]?data|c\.?\s*v\.?)\b/i,
      /\b(?:career\s+objective|professional\s+summary|profile\s+summary|objective|about\s+me|personal\s+details|declaration)\b/i
    ]
  },
  {
    id: "education",
    label: "Education / Qualification",
    patterns: [
      /\b(?:education|educational\s+qualification|qualifications?|academic\s+(?:details|background|qualifications?))\b/i,
      /\b(?:b\.?\s*ed|m\.?\s*ed|b\.?\s*sc|m\.?\s*sc|b\.?\s*tech|m\.?\s*tech|b\.?\s*a\.?|m\.?\s*a\.?|b\.?\s*com|m\.?\s*com|mba|bca|mca|ph\.?\s*d|diploma|graduation|post\s+graduation|bachelor|master|ctet|uptet|tet|ugc\s*net|gate)\b/i,
      /\b(?:university|college|school|cgpa|percentage|board|cbse|icse|up\s+board|10th|12th|high\s+school|intermediate|degree)\b/i
    ]
  },
  {
    id: "experience",
    label: "Teaching / Work Experience",
    patterns: [
      /\b(?:experience|work\s+history|employment|career\s+history|professional\s+experience|teaching\s+experience)\b/i,
      /\b(?:teacher|teaching|faculty|lecturer|tutor|professor|instructor|mentor|educator|trainer|principal|coordinator|coaching|institute|academy|internship|fresher)\b/i,
      /\b(?:responsibilities|worked\s+as|present|since\s+20\d\d|years?\s+of\s+experience|classes?\s+\d)\b/i
    ]
  },
  {
    id: "skills",
    label: "Skills / Subjects / Certifications",
    patterns: [
      /\b(?:skills|technical\s+skills|core\s+competencies|key\s+skills|strengths|achievements|awards|certifications?|certificates?|languages?\s+known|projects?)\b/i,
      /\b(?:mathematics|maths|physics|chemistry|biology|science|english|hindi|social\s+science|computer|coding|python|java|accountancy|commerce|economics|history|geography|neet|jee|cuet|ssc|nda)\b/i
    ]
  },
  {
    id: "contact",
    label: "Contact Details",
    patterns: [
      /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,
      /(?:\+91[\s-]?)?[6-9]\d{9}\b|\b\d{3}[\s-]?\d{3}[\s-]?\d{4}\b/,
      /\b(?:mobile|phone|contact|email|e-mail|address|date\s+of\s+birth|dob|linkedin|gender|nationality|marital\s+status)\b/i
    ]
  }
];

const NON_RESUME_RED_FLAGS = [
  /\b(?:tax\s+invoice|gstin|bill\s+to|ship\s+to|subtotal|grand\s+total|amount\s+payable|invoice\s+no|receipt\s+no|igst|cgst|sgst)\b/i,
  /\b(?:bank\s+statement|account\s+statement|opening\s+balance|closing\s+balance|ifsc\s+code|cheque\s+no)\b/i,
  /\b(?:electricity\s+bill|water\s+bill|gas\s+bill|boarding\s+pass|pnr\s+number|irctc|ticket\s+booking)\b/i,
  /\b(?:function\s+\w+\s*\(|const\s+\w+\s*=|import\s+[\w{]|class\s+\w+\s*\{|SELECT\s+\*\s+FROM)\b/
];

export function analyzeResumeText(rawText) {
  const normalized = String(rawText || "")
    .replace(/\u0000/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const words = normalized.split(/\s+/).filter((w) => /[A-Za-z0-9]/.test(w));
  const alphaChars = (normalized.match(/[A-Za-z]/g) || []).length;

  if (normalized.length < 40 || alphaChars < 25 || words.length < 10) {
    return {
      ok: false,
      code: "RESUME_UNREADABLE_OR_BLANK",
      wordCount: words.length,
      categories: [],
      error: "This file appears blank, too short, or a scanned image without readable text. Please upload a valid text-based PDF, DOC, or DOCX Resume/CV containing your qualifications, experience, and contact details."
    };
  }

  const matched = [];
  for (const group of RESUME_SIGNAL_GROUPS) {
    if (group.patterns.some((re) => re.test(normalized))) {
      matched.push(group);
    }
  }
  const matchedIds = new Set(matched.map((g) => g.id));
  const matchedLabels = matched.map((g) => g.label);

  const nonResumeHits = NON_RESUME_RED_FLAGS.filter((re) => re.test(normalized)).length;
  const hasCoreAcademicOrWork = matchedIds.has("education") || matchedIds.has("experience");
  const hasResumeHeader = matchedIds.has("profile");

  // Reject invoices, bank statements, tickets, or source code disguised as a resume
  if (nonResumeHits >= 1 && (!hasResumeHeader || matched.length < 4)) {
    return {
      ok: false,
      code: "NOT_A_RESUME",
      wordCount: words.length,
      categories: matchedLabels,
      error: "The uploaded file looks like a non-resume document (such as an invoice, bill, statement, or code file). Please upload your actual Teacher Resume / CV."
    };
  }

  // Require at least 3 independent resume sections AND at least Education or Experience, with meaningful content (>= 15 words)
  if (words.length < 15 || matched.length < 3 || !hasCoreAcademicOrWork) {
    return {
      ok: false,
      code: "NOT_A_RESUME",
      wordCount: words.length,
      categories: matchedLabels,
      error: "The uploaded file could not be verified as a genuine Resume / CV. Make sure your PDF/DOCX resume clearly includes your Education/Qualification, Teaching/Work Experience or Skills, and Contact details."
    };
  }

  return {
    ok: true,
    code: "VERIFIED_RESUME",
    wordCount: words.length,
    categories: matchedLabels,
    summary: `Verified Resume (${matchedLabels.join(", ")})`
  };
}

export function verifyResumeDocumentContent(filePath, originalName, mimeType, allowedExts = new Set([".pdf", ".doc", ".docx"])) {
  const sig = validateUploadMagicAndMime(filePath, originalName, mimeType, allowedExts);
  if (!sig.ok) {
    return { ok: false, code: "INVALID_RESUME_FORMAT", error: sig.error || "Invalid resume file format." };
  }
  const av = scanUploadedFileWithClamAv(filePath);
  if (!av.clean) {
    return { ok: false, code: "MALWARE_DETECTED", error: av.reason || "Uploaded resume failed security scan." };
  }

  const ext = path.extname(path.basename(String(originalName || ""))).toLowerCase();
  let buf;
  try {
    buf = fs.readFileSync(filePath);
  } catch {
    return { ok: false, code: "RESUME_READ_ERROR", error: "Could not read uploaded resume file." };
  }

  let extractedText = "";
  if (ext === ".docx") {
    extractedText = extractTextFromDocxBuffer(buf);
  } else if (ext === ".pdf") {
    extractedText = extractTextFromPdfBuffer(buf);
  } else if (ext === ".doc") {
    extractedText = extractTextFromDocBuffer(buf);
  }

  const analysis = analyzeResumeText(extractedText);
  if (!analysis.ok) {
    return analysis;
  }

  try {
    fs.chmodSync(filePath, 0o600);
  } catch {
    // Best-effort
  }

  return {
    ok: true,
    code: "VERIFIED_RESUME",
    format: ext.replace(".", "").toUpperCase(),
    wordCount: analysis.wordCount,
    categories: analysis.categories,
    summary: `Auto-verified ${ext.replace(".", "").toUpperCase()} resume (${analysis.categories.join(", ")})`
  };
}
