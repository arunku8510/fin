import crypto from "node:crypto";
import { nowIso, runInImmediateTx } from "./addons-db.mjs";

function cleanStr(val, maxLen = 120) {
  return String(val || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLen);
}

export function mergeGuestCartToUser(db, userId, guestToken) {
  const token = cleanStr(guestToken, 80);
  if (!userId || !token) return 0;

  return runInImmediateTx(db, () => {
    const guestItems = db
      .prepare("SELECT * FROM cart_items WHERE guest_token = ? AND user_id IS NULL")
      .all(token);
    if (guestItems.length === 0) return 0;

    let merged = 0;
    const now = nowIso();
    for (const item of guestItems) {
      const existing = db
        .prepare("SELECT id FROM cart_items WHERE user_id = ? AND course_id = ? LIMIT 1")
        .get(userId, item.course_id);
      if (existing) {
        db.prepare(
          "UPDATE cart_items SET plan = ?, batch_id = COALESCE(?, batch_id), updated_at = ? WHERE id = ?"
        ).run(item.plan, item.batch_id || null, now, existing.id);
        db.prepare("DELETE FROM cart_items WHERE id = ?").run(item.id);
      } else {
        db.prepare(
          "UPDATE cart_items SET user_id = ?, guest_token = '', updated_at = ? WHERE id = ?"
        ).run(userId, now, item.id);
      }
      merged++;
    }
    return merged;
  });
}

export function getCartDetails(db, { userId = null, guestToken = "", couponCode = "" }) {
  const token = cleanStr(guestToken, 80);
  if (userId && token) {
    mergeGuestCartToUser(db, userId, token);
  }

  let rows = [];
  if (userId) {
    rows = db
      .prepare(
        `SELECT ci.*, c.title, c.slug, c.category, c.board, c.duration_months,
                c.monthly_fee, c.yearly_fee, c.thumbnail_url,
                b.name AS batch_name, b.room_name AS batch_room, b.schedule_days AS batch_days
         FROM cart_items ci
         JOIN courses c ON c.id = ci.course_id AND c.is_active = 1
         LEFT JOIN batches b ON b.id = ci.batch_id
         WHERE ci.user_id = ?
         ORDER BY ci.id DESC`
      )
      .all(userId);
  } else if (token) {
    rows = db
      .prepare(
        `SELECT ci.*, c.title, c.slug, c.category, c.board, c.duration_months,
                c.monthly_fee, c.yearly_fee, c.thumbnail_url,
                b.name AS batch_name, b.room_name AS batch_room, b.schedule_days AS batch_days
         FROM cart_items ci
         JOIN courses c ON c.id = ci.course_id AND c.is_active = 1
         LEFT JOIN batches b ON b.id = ci.batch_id
         WHERE ci.guest_token = ? AND ci.user_id IS NULL
         ORDER BY ci.id DESC`
      )
      .all(token);
  }

  const items = rows.map((r) => {
    const unitPrice = r.plan === "yearly" ? Number(r.yearly_fee || 0) : Number(r.monthly_fee || 0);
    return {
      id: Number(r.id),
      courseId: Number(r.course_id),
      batchId: r.batch_id ? Number(r.batch_id) : null,
      batchName: r.batch_name || "",
      plan: r.plan === "yearly" ? "yearly" : "monthly",
      title: r.title,
      category: r.category,
      board: r.board,
      durationMonths: Number(r.duration_months || 12),
      monthlyFee: Number(r.monthly_fee || 0),
      yearlyFee: Number(r.yearly_fee || 0),
      thumbnailUrl: r.thumbnail_url || "",
      unitPrice
    };
  });

  const subtotal = items.reduce((sum, it) => sum + it.unitPrice, 0);
  let discountAmount = 0;
  let couponApplied = null;
  let couponError = "";
  const cleanCode = cleanStr(couponCode, 30).toUpperCase();

  if (cleanCode && subtotal > 0) {
    const today = nowIso().slice(0, 10);
    const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(cleanCode);
    if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses) || (coupon.expires_at && coupon.expires_at < today)) {
      couponError = "Invalid or expired coupon code.";
    } else {
      discountAmount =
        coupon.discount_type === "percent"
          ? Math.round((subtotal * Number(coupon.discount_value || 0)) / 100)
          : Math.min(subtotal, Number(coupon.discount_value || 0));
      couponApplied = {
        code: coupon.code,
        discountType: coupon.discount_type,
        discountValue: Number(coupon.discount_value || 0)
      };
    }
  }

  const totalAmount = Math.max(0, subtotal - discountAmount);
  return {
    items,
    count: items.length,
    subtotal,
    discountAmount,
    totalAmount,
    couponApplied,
    couponError
  };
}

export function addOrUpdateCartItem(db, { userId = null, guestToken = "", courseId, plan = "monthly", batchId = null }) {
  const cid = Number(courseId);
  const course = db.prepare("SELECT id, title, is_active FROM courses WHERE id = ? AND is_active = 1").get(cid);
  if (!course) throw new Error("Selected course not found or inactive.");

  const safePlan = plan === "yearly" ? "yearly" : "monthly";
  const safeBatchId = batchId ? Number(batchId) : null;
  if (safeBatchId) {
    const batch = db.prepare("SELECT id, course_id, is_active FROM batches WHERE id = ?").get(safeBatchId);
    if (!batch || Number(batch.is_active) !== 1 || Number(batch.course_id) !== cid) {
      throw new Error("Selected batch does not match this course.");
    }
  }

  const token = cleanStr(guestToken, 80);
  if (!userId && !token) throw new Error("Missing cart session identifier.");

  const now = nowIso();
  return runInImmediateTx(db, () => {
    const existing = userId
      ? db.prepare("SELECT id FROM cart_items WHERE user_id = ? AND course_id = ? LIMIT 1").get(userId, cid)
      : db
          .prepare("SELECT id FROM cart_items WHERE guest_token = ? AND user_id IS NULL AND course_id = ? LIMIT 1")
          .get(token, cid);

    if (existing) {
      db.prepare("UPDATE cart_items SET plan = ?, batch_id = ?, updated_at = ? WHERE id = ?").run(
        safePlan,
        safeBatchId,
        now,
        existing.id
      );
      return { itemId: Number(existing.id), updated: true, courseTitle: course.title };
    }

    const ins = db
      .prepare(
        `INSERT INTO cart_items (user_id, guest_token, course_id, batch_id, plan, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(userId || null, userId ? "" : token, cid, safeBatchId, safePlan, now, now);

    return { itemId: Number(ins.lastInsertRowid), updated: false, courseTitle: course.title };
  });
}

export function updateCartItemPlanOrBatch(db, { userId = null, guestToken = "", itemId, plan, batchId }) {
  const id = Number(itemId);
  const item = db.prepare("SELECT * FROM cart_items WHERE id = ?").get(id);
  if (!item) throw new Error("Cart item not found.");
  if (userId && Number(item.user_id) !== Number(userId)) throw new Error("Access denied.");
  if (!userId && item.guest_token !== cleanStr(guestToken, 80)) throw new Error("Access denied.");

  const nextPlan = plan === "yearly" ? "yearly" : plan === "monthly" ? "monthly" : item.plan;
  const nextBatch = batchId === null || batchId === "" ? null : batchId !== undefined ? Number(batchId) : item.batch_id;
  if (nextBatch) {
    const batch = db.prepare("SELECT id, course_id, is_active FROM batches WHERE id = ?").get(nextBatch);
    if (!batch || Number(batch.is_active) !== 1 || Number(batch.course_id) !== Number(item.course_id)) {
      throw new Error("Invalid batch selection for this course.");
    }
  }
  db.prepare("UPDATE cart_items SET plan = ?, batch_id = ?, updated_at = ? WHERE id = ?").run(
    nextPlan,
    nextBatch || null,
    nowIso(),
    id
  );
  return { updated: true };
}

export function removeCartItem(db, { userId = null, guestToken = "", itemId }) {
  const id = Number(itemId);
  const item = db.prepare("SELECT * FROM cart_items WHERE id = ?").get(id);
  if (!item) return { deleted: false };
  if (userId && Number(item.user_id) !== Number(userId)) throw new Error("Access denied.");
  if (!userId && item.guest_token !== cleanStr(guestToken, 80)) throw new Error("Access denied.");

  db.prepare("DELETE FROM cart_items WHERE id = ?").run(id);
  return { deleted: true };
}

export function clearCart(db, { userId = null, guestToken = "" }) {
  if (userId) {
    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(userId);
  } else if (guestToken) {
    db.prepare("DELETE FROM cart_items WHERE guest_token = ? AND user_id IS NULL").run(cleanStr(guestToken, 80));
  }
}

export function createCartCheckoutBatch({
  db,
  student,
  cart,
  paymentMethod = "upi",
  utrReference = "",
  gatewayOrderId = "",
  gatewayPaymentId = "",
  gatewaySignature = "",
  isGatewayVerified = false,
  validateBatchCapacityFn,
  writeAuditLogFn,
  ipAddress = ""
}) {
  if (!cart.items || cart.items.length === 0) {
    throw new Error("Your shopping cart is empty.");
  }

  for (const item of cart.items) {
    if (typeof validateBatchCapacityFn === "function" && item.batchId) {
      const check = validateBatchCapacityFn(db, item.courseId, item.batchId, student.id);
      if (!check.ok) throw new Error(check.error);
    }
  }

  return runInImmediateTx(db, () => {
    const now = nowIso();
    const orderCode = `YTR-ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
    const invoiceNumber = `YTR-INV-C${Date.now().toString().slice(-6)}`;
    const verificationStatus = isGatewayVerified ? "verified" : "pending_verification";
    const enrollmentStatus = isGatewayVerified ? "active" : "pending";
    const receiptNumber = isGatewayVerified ? `YTR-RCP-C${Date.now().toString().slice(-6)}` : "";
    const paidAt = isGatewayVerified ? now : null;

    if (cart.couponApplied?.code) {
      const today = now.slice(0, 10);
      const c = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(cart.couponApplied.code);
      if (!c || Number(c.used_count) >= Number(c.max_uses) || (c.expires_at && c.expires_at < today)) {
        throw new Error("Coupon code expired or max uses reached.");
      }
      db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(c.id);
    }

    // Pro-rate discount across items reliably so per-course payments sum cleanly to cart totalAmount
    const subtotal = Math.max(1, cart.subtotal);
    let remainingDiscount = cart.discountAmount || 0;
    const createdPaymentIds = [];

    const hasEnrollmentBatchCol = db
      .prepare("PRAGMA table_info(enrollments)")
      .all()
      .some((c) => c.name === "batch_id");

    cart.items.forEach((item, idx) => {
      const isLast = idx === cart.items.length - 1;
      const itemDiscount = isLast
        ? remainingDiscount
        : Math.min(item.unitPrice, Math.round((cart.discountAmount * item.unitPrice) / subtotal));
      remainingDiscount = Math.max(0, remainingDiscount - itemDiscount);
      const itemFinal = Math.max(0, item.unitPrice - itemDiscount);

      const months = item.plan === "yearly" ? 12 : 1;
      const exp = new Date();
      exp.setMonth(exp.getMonth() + months);
      const expiresAt = exp.toISOString().slice(0, 10);

      if (hasEnrollmentBatchCol) {
        db.prepare(
          `INSERT INTO enrollments (student_id, course_id, batch_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
           VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)
           ON CONFLICT(student_id, course_id) DO UPDATE SET
             plan = excluded.plan,
             batch_id = COALESCE(excluded.batch_id, enrollments.batch_id),
             status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
             expires_at = excluded.expires_at`
        ).run(student.id, item.courseId, item.batchId || null, item.plan, enrollmentStatus, expiresAt, now);
      } else {
        db.prepare(
          `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
           VALUES (?, ?, ?, ?, 0, 0, ?, ?)
           ON CONFLICT(student_id, course_id) DO UPDATE SET
             plan = excluded.plan,
             status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
             expires_at = excluded.expires_at`
        ).run(student.id, item.courseId, item.plan, enrollmentStatus, expiresAt, now);
      }

      const enrollment = db
        .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?")
        .get(student.id, item.courseId);

      const itemInv = `${invoiceNumber}-${idx + 1}`;
      const itemRcp = receiptNumber ? `${receiptNumber}-${idx + 1}` : "";
      const itemGwPayId = gatewayPaymentId ? (cart.items.length > 1 ? `${gatewayPaymentId}#${idx + 1}` : gatewayPaymentId) : "";
      const payIns = db
        .prepare(
          `INSERT INTO payments (
             student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code,
             payment_method, utr_reference, gateway_order_id, gateway_payment_id, gateway_signature,
             verification_status, invoice_number, receipt_number, paid_at, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          student.id,
          item.courseId,
          enrollment.id,
          item.plan,
          item.unitPrice,
          itemDiscount,
          itemFinal,
          cart.couponApplied?.code || "",
          paymentMethod,
          utrReference,
          gatewayOrderId,
          itemGwPayId,
          gatewaySignature,
          verificationStatus,
          itemInv,
          itemRcp,
          paidAt,
          now
        );
      createdPaymentIds.push(Number(payIns.lastInsertRowid));

      db.prepare(
        `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        student.id,
        item.courseId,
        `${item.title} (${item.plan})`,
        item.unitPrice,
        itemDiscount,
        isGatewayVerified ? itemFinal : 0,
        now.slice(0, 10),
        isGatewayVerified ? "paid" : "pending",
        now
      );
    });

    db.prepare(
      `INSERT INTO cart_orders (
         order_code, student_id, items_json, subtotal_amount, discount_amount, total_amount, coupon_code,
         payment_method, utr_reference, gateway_order_id, gateway_payment_id, verification_status,
         invoice_number, receipt_number, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      orderCode,
      student.id,
      JSON.stringify(cart.items),
      cart.subtotal,
      cart.discountAmount,
      cart.totalAmount,
      cart.couponApplied?.code || "",
      paymentMethod,
      utrReference,
      gatewayOrderId,
      gatewayPaymentId,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      now,
      now
    );

    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(student.id);

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `Multi-Course Cart Order (${paymentMethod.toUpperCase()})`,
      `${student.full_name} checked out ${cart.items.length} course(s) totaling ₹${cart.totalAmount} (${verificationStatus}).`,
      now
    );

    if (typeof writeAuditLogFn === "function") {
      writeAuditLogFn(db, {
        actorId: student.id,
        actorName: student.full_name,
        targetId: student.id,
        targetName: orderCode,
        action: "cart_checkout_completed",
        details: `${cart.items.length} courses · ₹${cart.totalAmount} (${verificationStatus})`,
        ipAddress
      });
    }

    return {
      orderCode,
      invoiceNumber,
      receiptNumber,
      verificationStatus,
      totalAmount: cart.totalAmount,
      itemCount: cart.items.length,
      createdPaymentIds
    };
  });
}
