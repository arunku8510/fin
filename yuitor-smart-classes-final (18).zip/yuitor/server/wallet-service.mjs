import crypto from "node:crypto";
import { getReferralSettings, nowIso, runInImmediateTx } from "./addons-db.mjs";
import { VALID_WITHDRAWAL_TRANSITIONS, validateIfscCode, validateUpiId } from "./referral-math.mjs";

function makeTxCode(prefix = "YTR-TXN") {
  const rand = crypto.randomBytes(3).toString("hex").toUpperCase();
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${rand}`;
}

export function getOrCreateWallet(db, userId, roleHint = "") {
  const existing = db.prepare("SELECT * FROM wallets WHERE user_id = ?").get(userId);
  if (existing) return existing;

  const user = db.prepare("SELECT id, role FROM users WHERE id = ?").get(userId);
  if (!user) throw new Error("User account not found for wallet.");
  const r = roleHint || user.role;
  const walletType = r === "teacher" ? "teacher" : "student";
  const now = nowIso();
  db.prepare(
    `INSERT OR IGNORE INTO wallets (
       user_id, wallet_type, available_balance, pending_rewards, pending_withdrawal_hold,
       total_earnings, withdrawn_amount, referral_rewards_total, is_frozen, freeze_reason, created_at, updated_at
     ) VALUES (?, ?, 0, 0, 0, 0, 0, 0, 0, '', ?, ?)`
  ).run(userId, walletType, now, now);

  return db.prepare("SELECT * FROM wallets WHERE user_id = ?").get(userId);
}

export function syncWalletPendingRewards(db, userId) {
  const user = db.prepare("SELECT id, role FROM users WHERE id = ?").get(userId);
  if (!user || (user.role !== "student" && user.role !== "teacher")) return 0;
  const wallet = getOrCreateWallet(db, userId, user.role);
  const pendingRow = db
    .prepare(
      `SELECT COALESCE(SUM(pending_estimated_reward), 0) AS total
       FROM referrals
       WHERE referrer_user_id = ? AND status IN ('registered', 'in_progress')`
    )
    .get(userId);
  const nextPending = Math.max(0, Math.round(Number(pendingRow?.total || 0)));
  db.prepare("UPDATE wallets SET pending_rewards = ?, updated_at = ? WHERE id = ?").run(
    nextPending,
    nowIso(),
    wallet.id
  );
  return nextPending;
}

export function creditWalletImmutable(db, {
  userId,
  walletType = "",
  amount,
  category = "referral_reward",
  referenceType = "",
  referenceId = "",
  description = "",
  idempotencyKey = null,
  actorId = null,
  countAsReferralReward = false
}) {
  const amt = Math.round(Number(amount || 0));
  if (!Number.isFinite(amt) || amt <= 0) {
    return { credited: false, duplicate: false, reason: "Zero or invalid credit amount" };
  }

  return runInImmediateTx(db, () => {
    if (idempotencyKey) {
      const dup = db
        .prepare("SELECT id, tx_code FROM wallet_transactions WHERE idempotency_key = ? LIMIT 1")
        .get(idempotencyKey);
      if (dup) {
        const current = getOrCreateWallet(db, userId, walletType);
        return { credited: false, duplicate: true, txCode: dup.tx_code, wallet: current };
      }
    }

    const wallet = getOrCreateWallet(db, userId, walletType);
    const nextBalance = Number(wallet.available_balance) + amt;
    const nextEarnings = Number(wallet.total_earnings) + amt;
    const nextRefTotal = Number(wallet.referral_rewards_total || 0) + (countAsReferralReward ? amt : 0);
    const now = nowIso();

    db.prepare(
      `UPDATE wallets
       SET available_balance = ?, total_earnings = ?, referral_rewards_total = ?, updated_at = ?
       WHERE id = ?`
    ).run(nextBalance, nextEarnings, nextRefTotal, now, wallet.id);

    const txCode = makeTxCode("YTR-TXN");
    db.prepare(
      `INSERT INTO wallet_transactions (
         tx_code, wallet_id, user_id, tx_type, category, amount, credit_amount, debit_amount,
         remaining_balance, status, reference_type, reference_id, idempotency_key, description, created_by, created_at
       ) VALUES (?, ?, ?, 'credit', ?, ?, ?, 0, ?, 'completed', ?, ?, ?, ?, ?, ?)`
    ).run(
      txCode,
      wallet.id,
      userId,
      category,
      amt,
      amt,
      nextBalance,
      String(referenceType || ""),
      String(referenceId || ""),
      idempotencyKey || null,
      String(description || "Wallet credit"),
      actorId || null,
      now
    );

    const updated = db.prepare("SELECT * FROM wallets WHERE id = ?").get(wallet.id);
    return { credited: true, duplicate: false, txCode, wallet: updated };
  });
}

export function debitWalletImmutable(db, {
  userId,
  walletType = "",
  amount,
  category = "admin_debit",
  referenceType = "",
  referenceId = "",
  description = "",
  idempotencyKey = null,
  actorId = null,
  requireAvailable = true,
  adjustEarningsOnReversal = false
}) {
  const amt = Math.round(Number(amount || 0));
  if (!Number.isFinite(amt) || amt <= 0) {
    throw new Error("Debit amount must be greater than ₹0.");
  }

  return runInImmediateTx(db, () => {
    if (idempotencyKey) {
      const dup = db
        .prepare("SELECT id, tx_code FROM wallet_transactions WHERE idempotency_key = ? LIMIT 1")
        .get(idempotencyKey);
      if (dup) {
        const current = getOrCreateWallet(db, userId, walletType);
        return { debited: false, duplicate: true, txCode: dup.tx_code, wallet: current };
      }
    }

    const wallet = getOrCreateWallet(db, userId, walletType);
    const curAvail = Number(wallet.available_balance);
    if (requireAvailable && curAvail < amt) {
      throw new Error(`Insufficient available wallet balance (Available: ₹${curAvail}).`);
    }

    const actualDebit = requireAvailable ? amt : Math.min(curAvail, amt);
    const nextBalance = Math.max(0, curAvail - actualDebit);
    const nextEarnings = adjustEarningsOnReversal
      ? Math.max(0, Number(wallet.total_earnings) - actualDebit)
      : Number(wallet.total_earnings);
    const nextRefTotal = adjustEarningsOnReversal
      ? Math.max(0, Number(wallet.referral_rewards_total || 0) - actualDebit)
      : Number(wallet.referral_rewards_total || 0);
    const now = nowIso();

    db.prepare(
      `UPDATE wallets
       SET available_balance = ?, total_earnings = ?, referral_rewards_total = ?, updated_at = ?
       WHERE id = ?`
    ).run(nextBalance, nextEarnings, nextRefTotal, now, wallet.id);

    const txCode = makeTxCode("YTR-TXN");
    db.prepare(
      `INSERT INTO wallet_transactions (
         tx_code, wallet_id, user_id, tx_type, category, amount, credit_amount, debit_amount,
         remaining_balance, status, reference_type, reference_id, idempotency_key, description, created_by, created_at
       ) VALUES (?, ?, ?, 'debit', ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      txCode,
      wallet.id,
      userId,
      category,
      actualDebit,
      actualDebit,
      nextBalance,
      category === "reward_reversal" ? "reversed" : "completed",
      String(referenceType || ""),
      String(referenceId || ""),
      idempotencyKey || null,
      String(description || "Wallet debit"),
      actorId || null,
      now
    );

    const updated = db.prepare("SELECT * FROM wallets WHERE id = ?").get(wallet.id);
    return { debited: true, actualDebit, duplicate: false, txCode, wallet: updated };
  });
}

export function requestWithdrawal(db, {
  userId,
  userRole,
  amount,
  payoutMethod,
  upiId = "",
  accountHolderName = "",
  bankName = "",
  accountNumber = "",
  ifscCode = ""
}) {
  const settings = getReferralSettings(db);
  const reqAmount = Math.round(Number(amount || 0));
  const minLimit = Math.max(1, Number(settings.min_withdrawal_amount || 200));
  const maxLimit = Math.max(minLimit, Number(settings.max_withdrawal_amount || 50000));
  const method = payoutMethod === "bank" ? "bank" : "upi";

  if (!Number.isFinite(reqAmount) || reqAmount < minLimit) {
    throw new Error(`Minimum withdrawal amount is ₹${minLimit}.`);
  }
  if (reqAmount > maxLimit) {
    throw new Error(`Maximum withdrawal amount per request is ₹${maxLimit.toLocaleString("en-IN")}.`);
  }

  const cleanUpi = String(upiId || "").trim();
  const cleanHolder = String(accountHolderName || "").trim();
  const cleanBank = String(bankName || "").trim();
  const cleanAcc = String(accountNumber || "").replace(/\s+/g, "");
  const cleanIfsc = String(ifscCode || "").trim().toUpperCase();

  if (method === "upi") {
    if (!validateUpiId(cleanUpi)) {
      throw new Error("Enter a valid UPI ID (e.g. name@okaxis or mobile@ybl).");
    }
  } else {
    if (cleanHolder.length < 2 || cleanBank.length < 2 || !/^\d{9,18}$/.test(cleanAcc) || !validateIfscCode(cleanIfsc)) {
      throw new Error("Provide valid Account Holder Name, Bank Name, 9–18 digit Account Number, and 11-char IFSC Code.");
    }
  }

  return runInImmediateTx(db, () => {
    const wallet = getOrCreateWallet(db, userId, userRole);
    if (Number(wallet.is_frozen) === 1) {
      throw new Error(wallet.freeze_reason ? `Wallet frozen: ${wallet.freeze_reason}` : "Your wallet is currently frozen by Admin.");
    }

    if (Number(settings.prevent_duplicate_withdrawals) === 1) {
      const openReq = db
        .prepare(
          `SELECT id, request_code, status FROM withdrawal_requests
           WHERE user_id = ? AND status IN ('pending', 'under_review', 'approved', 'processing')
           LIMIT 1`
        )
        .get(userId);
      if (openReq) {
        throw new Error(`You already have an active withdrawal request (${openReq.request_code} · ${openReq.status}). Wait for completion before submitting another.`);
      }
    }

    if (Number(wallet.available_balance) < reqAmount) {
      throw new Error(
        `Insufficient Available Balance (Available: ₹${Number(wallet.available_balance).toLocaleString("en-IN")}). Pending Rewards (₹${Number(wallet.pending_rewards || 0).toLocaleString("en-IN")}) cannot be withdrawn.`
      );
    }

    const now = nowIso();
    const requestCode = makeTxCode("YTR-WDR");
    const initialStatus = Number(settings.require_admin_approval) === 1 ? "pending" : "approved";
    const nextAvail = Number(wallet.available_balance) - reqAmount;
    const nextHold = Number(wallet.pending_withdrawal_hold || 0) + reqAmount;

    db.prepare(
      `UPDATE wallets
       SET available_balance = ?, pending_withdrawal_hold = ?, updated_at = ?
       WHERE id = ?`
    ).run(nextAvail, nextHold, now, wallet.id);

    const ins = db
      .prepare(
        `INSERT INTO withdrawal_requests (
           request_code, wallet_id, user_id, user_role, amount, payout_method,
           upi_id, account_holder_name, bank_name, account_number, ifsc_code,
           status, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        requestCode,
        wallet.id,
        userId,
        wallet.wallet_type,
        reqAmount,
        method,
        cleanUpi,
        cleanHolder,
        cleanBank,
        cleanAcc,
        cleanIfsc,
        initialStatus,
        now,
        now
      );
    const withdrawalId = Number(ins.lastInsertRowid);

    const txCode = makeTxCode("YTR-TXN");
    db.prepare(
      `INSERT INTO wallet_transactions (
         tx_code, wallet_id, user_id, tx_type, category, amount, credit_amount, debit_amount,
         remaining_balance, status, reference_type, reference_id, idempotency_key, description, created_by, created_at
       ) VALUES (?, ?, ?, 'debit', 'withdrawal_hold', ?, 0, ?, ?, 'pending', 'withdrawal', ?, ?, ?, ?, ?)`
    ).run(
      txCode,
      wallet.id,
      userId,
      reqAmount,
      reqAmount,
      nextAvail,
      String(withdrawalId),
      `wdr_hold:${withdrawalId}`,
      `Withdrawal requested via ${method.toUpperCase()} (${requestCode})`,
      userId,
      now
    );

    const created = db.prepare("SELECT * FROM withdrawal_requests WHERE id = ?").get(withdrawalId);
    const updatedWallet = db.prepare("SELECT * FROM wallets WHERE id = ?").get(wallet.id);
    return { request: created, wallet: updatedWallet, txCode };
  });
}

export function transitionWithdrawalStatus(db, {
  withdrawalId,
  nextStatus,
  adminId,
  adminNote = "",
  payoutReference = ""
}) {
  const target = String(nextStatus || "").trim().toLowerCase();
  return runInImmediateTx(db, () => {
    const reqRow = db.prepare("SELECT * FROM withdrawal_requests WHERE id = ?").get(withdrawalId);
    if (!reqRow) throw new Error("Withdrawal request not found.");

    const allowedNext = VALID_WITHDRAWAL_TRANSITIONS[reqRow.status] || [];
    if (!allowedNext.includes(target)) {
      throw new Error(`Cannot move withdrawal from "${reqRow.status}" to "${target}".`);
    }

    const wallet = db.prepare("SELECT * FROM wallets WHERE id = ?").get(reqRow.wallet_id);
    if (!wallet) throw new Error("Associated wallet not found.");

    const now = nowIso();
    const cleanNote = String(adminNote || "").trim().slice(0, 400);
    const cleanRef = String(payoutReference || "").trim().slice(0, 120);

    if (target === "paid") {
      const nextHold = Math.max(0, Number(wallet.pending_withdrawal_hold || 0) - Number(reqRow.amount));
      const nextWithdrawn = Number(wallet.withdrawn_amount || 0) + Number(reqRow.amount);
      db.prepare(
        `UPDATE wallets SET pending_withdrawal_hold = ?, withdrawn_amount = ?, updated_at = ? WHERE id = ?`
      ).run(nextHold, nextWithdrawn, now, wallet.id);

      db.prepare(
        `UPDATE wallet_transactions
         SET status = 'completed',
             description = ?
         WHERE reference_type = 'withdrawal' AND reference_id = ? AND category = 'withdrawal_hold'`
      ).run(
        `Withdrawal Paid via ${reqRow.payout_method.toUpperCase()} (${reqRow.request_code})${cleanRef ? ` · Ref: ${cleanRef}` : ""}`,
        String(reqRow.id)
      );

      db.prepare(
        `UPDATE withdrawal_requests
         SET status = 'paid', admin_note = ?, payout_reference = ?, reviewed_by = ?, reviewed_at = ?, paid_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(cleanNote || reqRow.admin_note, cleanRef || reqRow.payout_reference, adminId || null, reqRow.reviewed_at || now, now, now, reqRow.id);
    } else if (target === "rejected") {
      const nextHold = Math.max(0, Number(wallet.pending_withdrawal_hold || 0) - Number(reqRow.amount));
      const nextAvail = Number(wallet.available_balance || 0) + Number(reqRow.amount);
      db.prepare(
        `UPDATE wallets SET pending_withdrawal_hold = ?, available_balance = ?, updated_at = ? WHERE id = ?`
      ).run(nextHold, nextAvail, now, wallet.id);

      db.prepare(
        `UPDATE wallet_transactions
         SET status = 'cancelled'
         WHERE reference_type = 'withdrawal' AND reference_id = ? AND category = 'withdrawal_hold'`
      ).run(String(reqRow.id));

      const txCode = makeTxCode("YTR-TXN");
      db.prepare(
        `INSERT INTO wallet_transactions (
           tx_code, wallet_id, user_id, tx_type, category, amount, credit_amount, debit_amount,
           remaining_balance, status, reference_type, reference_id, idempotency_key, description, created_by, created_at
         ) VALUES (?, ?, ?, 'credit', 'withdrawal_refund', ?, ?, 0, ?, 'completed', 'withdrawal', ?, ?, ?, ?, ?)`
      ).run(
        txCode,
        wallet.id,
        reqRow.user_id,
        reqRow.amount,
        reqRow.amount,
        nextAvail,
        String(reqRow.id),
        `wdr_refund:${reqRow.id}`,
        `Withdrawal ${reqRow.request_code} rejected & refunded${cleanNote ? `: ${cleanNote}` : ""}`,
        adminId || null,
        now
      );

      db.prepare(
        `UPDATE withdrawal_requests
         SET status = 'rejected', admin_note = ?, reviewed_by = ?, reviewed_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(cleanNote || "Rejected by Admin", adminId || null, now, now, reqRow.id);
    } else {
      db.prepare(
        `UPDATE withdrawal_requests
         SET status = ?, admin_note = COALESCE(NULLIF(?, ''), admin_note),
             payout_reference = COALESCE(NULLIF(?, ''), payout_reference),
             reviewed_by = ?, reviewed_at = COALESCE(reviewed_at, ?), updated_at = ?
         WHERE id = ?`
      ).run(target, cleanNote, cleanRef, adminId || null, now, now, reqRow.id);
    }

    const updatedReq = db.prepare("SELECT * FROM withdrawal_requests WHERE id = ?").get(reqRow.id);
    const updatedWallet = db.prepare("SELECT * FROM wallets WHERE id = ?").get(wallet.id);
    return { request: updatedReq, wallet: updatedWallet };
  });
}

export function getWalletDashboardData(db, userId, userRole, filters = {}) {
  const wallet = getOrCreateWallet(db, userId, userRole);
  const settings = getReferralSettings(db);
  const limit = Math.min(200, Math.max(10, Number(filters.limit || 50)));
  const offset = Math.max(0, Number(filters.offset || 0));

  const txWhere = ["user_id = ?"];
  const txParams = [userId];
  if (filters.txType && (filters.txType === "credit" || filters.txType === "debit")) {
    txWhere.push("tx_type = ?");
    txParams.push(filters.txType);
  }
  if (filters.status) {
    txWhere.push("status = ?");
    txParams.push(String(filters.status));
  }
  if (filters.search) {
    const q = `%${String(filters.search).trim()}%`;
    txWhere.push("(tx_code LIKE ? OR description LIKE ? OR category LIKE ?)");
    txParams.push(q, q, q);
  }

  const transactions = db
    .prepare(
      `SELECT * FROM wallet_transactions
       WHERE ${txWhere.join(" AND ")}
       ORDER BY id DESC
       LIMIT ? OFFSET ?`
    )
    .all(...txParams, limit, offset);

  const txTotal = Number(
    db.prepare(`SELECT COUNT(*) AS c FROM wallet_transactions WHERE ${txWhere.join(" AND ")}`).get(...txParams)?.c || 0
  );

  const withdrawals = db
    .prepare(
      `SELECT * FROM withdrawal_requests
       WHERE user_id = ?
       ORDER BY id DESC
       LIMIT 100`
    )
    .all(userId);

  return {
    wallet,
    transactions,
    transactionsTotal: txTotal,
    withdrawals,
    rules: {
      minWithdrawalAmount: Number(settings.min_withdrawal_amount || 200),
      maxWithdrawalAmount: Number(settings.max_withdrawal_amount || 50000),
      requireAdminApproval: Number(settings.require_admin_approval) === 1,
      preventDuplicateWithdrawals: Number(settings.prevent_duplicate_withdrawals) === 1
    }
  };
}
