import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";

import { ensureAddonsSchema, nowIso } from "./addons-db.mjs";
import { addOrUpdateCartItem, createCartCheckoutBatch, getCartDetails } from "./cart-service.mjs";
import { searchAdminWorkspace } from "./global-search.mjs";
import { attributeReferralSignup, ensureReferralProfile, recomputeReferralForStudent } from "./referral-engine.mjs";
import {
  buildSpreadsheetXml,
  computeMilestoneDelta,
  computeNextMilestoneOffer,
  DEFAULT_MILESTONES,
  escapeCsvCell,
  evaluateThreeMonthProgress,
  rowsToCsv
} from "./referral-math.mjs";
import {
  creditWalletImmutable,
  getOrCreateWallet,
  requestWithdrawal,
  transitionWithdrawalStatus
} from "./wallet-service.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MIG_001 = path.resolve(__dirname, "..", "database", "migrations", "001_unified_portal.sql");

function setupTestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec(fs.readFileSync(MIG_001, "utf8"));
  ensureAddonsSchema(db);
  return db;
}

function insertTestUser(db, { role, name, email, phone }) {
  const now = nowIso();
  const res = db
    .prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'hashed_secret_never_leak', 1, 'approved', 1, 1, ?, ?, ?)`
    )
    .run(role, name, email, phone, `unsub_${email}_${Date.now()}_${Math.random()}`, now, now);
  return Number(res.lastInsertRowid);
}

function insertTestCourse(db, { title, slug, monthlyFee = 1500, yearlyFee = 15000 }) {
  const res = db
    .prepare(
      `INSERT INTO courses (title, slug, category, board, duration_months, monthly_fee, yearly_fee, is_active, created_at)
       VALUES (?, ?, 'Classes 6-12', 'CBSE', 12, ?, ?, 1, ?)`
    )
    .run(title, slug, monthlyFee, yearlyFee, nowIso());
  return Number(res.lastInsertRowid);
}

function insertPayment(db, { studentId, courseId, amount = 1500, plan = "monthly", status = "verified" }) {
  const now = nowIso();
  const res = db
    .prepare(
      `INSERT INTO payments (student_id, course_id, plan, base_amount, discount_amount, amount, payment_method, verification_status, invoice_number, receipt_number, paid_at, created_at)
       VALUES (?, ?, ?, ?, 0, ?, 'upi', ?, ?, ?, ?, ?)`
    )
    .run(
      studentId,
      courseId,
      plan,
      amount,
      amount,
      status,
      `YTR-INV-${Math.random().toString(36).slice(2, 7)}`,
      status === "verified" ? `YTR-RCP-${Math.random().toString(36).slice(2, 7)}` : "",
      status === "verified" ? now : null,
      now
    );
  return Number(res.lastInsertRowid);
}

test("Cumulative milestone math calculates incremental differences only", () => {
  const m1 = computeMilestoneDelta({ qualifiedCount: 1, alreadyCreditedTotal: 0, milestones: DEFAULT_MILESTONES });
  assert.equal(m1.targetCumulative, 200);
  assert.equal(m1.deltaAmount, 200);

  const m2 = computeMilestoneDelta({ qualifiedCount: 2, alreadyCreditedTotal: 200, milestones: DEFAULT_MILESTONES });
  assert.equal(m2.targetCumulative, 500);
  assert.equal(m2.deltaAmount, 300);

  const m3 = computeMilestoneDelta({ qualifiedCount: 3, alreadyCreditedTotal: 500, milestones: DEFAULT_MILESTONES });
  assert.equal(m3.targetCumulative, 1000);
  assert.equal(m3.deltaAmount, 500);

  const m4 = computeMilestoneDelta({ qualifiedCount: 4, alreadyCreditedTotal: 1000, milestones: DEFAULT_MILESTONES });
  assert.equal(m4.targetCumulative, 1500);
  assert.equal(m4.deltaAmount, 500);

  const m5 = computeMilestoneDelta({ qualifiedCount: 5, alreadyCreditedTotal: 1500, milestones: DEFAULT_MILESTONES });
  assert.equal(m5.targetCumulative, 2500);
  assert.equal(m5.deltaAmount, 1000);

  // Repeat check produces 0 extra delta (no double reward)
  const repeat = computeMilestoneDelta({ qualifiedCount: 5, alreadyCreditedTotal: 2500, milestones: DEFAULT_MILESTONES });
  assert.equal(repeat.deltaAmount, 0);

  const offer = computeNextMilestoneOffer({ qualifiedCount: 2, alreadyCreditedTotal: 500, milestones: DEFAULT_MILESTONES });
  assert.match(offer.headline, /unlocked ₹500.*1 more qualified referral.*₹1,000/);
});

test("3-Month fee progress, qualification, cumulative difference payout, idempotency, and refund clawback", async () => {
  const db = setupTestDb();
  const referrerId = insertTestUser(db, { role: "student", name: "Aarav Sharma", email: "aarav@test.in", phone: "9811111111" });
  const refProfile = ensureReferralProfile(db, referrerId, "student");
  assert.match(refProfile.referral_code, /^YTR-/);

  const s1 = insertTestUser(db, { role: "student", name: "Rohan Verma", email: "rohan@test.in", phone: "9822222222" });
  const courseId = insertTestCourse(db, { title: "Class 10 Maths", slug: "cls10-maths" });

  // Prevent self-referral
  const selfAttempt = await attributeReferralSignup(db, {
    referredUserId: referrerId,
    referredRole: "student",
    referralCode: refProfile.referral_code
  });
  assert.equal(selfAttempt.attributed, false);
  assert.equal(selfAttempt.reason, "self_referral_blocked");

  // Legitimate attribution
  const attr1 = await attributeReferralSignup(db, {
    referredUserId: s1,
    referredRole: "student",
    referralCode: refProfile.referral_code
  });
  assert.equal(attr1.attributed, true);

  // Pending (unverified) payment must NOT advance months
  insertPayment(db, { studentId: s1, courseId, status: "pending_verification" });
  let r1 = await recomputeReferralForStudent(db, s1);
  assert.equal(r1.monthsAfter, 0);

  // Month 1 verified -> 1/3
  insertPayment(db, { studentId: s1, courseId, status: "verified" });
  r1 = await recomputeReferralForStudent(db, s1);
  assert.equal(r1.monthsAfter, 1);
  assert.equal(r1.milestoneCredited, 0);

  // Month 2 verified -> 2/3
  insertPayment(db, { studentId: s1, courseId, status: "verified" });
  r1 = await recomputeReferralForStudent(db, s1);
  assert.equal(r1.monthsAfter, 2);
  assert.equal(r1.milestoneCredited, 0);

  // Month 3 verified -> 3/3 -> qualifies & credits ₹200
  const pay3 = insertPayment(db, { studentId: s1, courseId, status: "verified" });
  r1 = await recomputeReferralForStudent(db, s1, { paymentId: pay3 });
  assert.equal(r1.monthsAfter, 3);
  assert.equal(r1.newlyQualified, true);
  assert.equal(r1.milestoneCredited, 200);

  // Re-run recompute -> zero duplicate credit
  const rDup = await recomputeReferralForStudent(db, s1);
  assert.equal(rDup.milestoneCredited, 0);
  let w = getOrCreateWallet(db, referrerId, "student");
  assert.equal(w.available_balance, 200);

  // 2nd referred student pays 3 months -> milestone 2 unlocks ₹500 cumulative (credits ONLY +₹300 diff!)
  const s2 = insertTestUser(db, { role: "student", name: "Neha Singh", email: "neha@test.in", phone: "9833333333" });
  await attributeReferralSignup(db, { referredUserId: s2, referredRole: "student", referralCode: refProfile.referral_code });
  insertPayment(db, { studentId: s2, courseId, status: "verified" });
  insertPayment(db, { studentId: s2, courseId, status: "verified" });
  insertPayment(db, { studentId: s2, courseId, status: "verified" });
  const r2 = await recomputeReferralForStudent(db, s2);
  assert.equal(r2.milestoneCredited, 300);

  w = getOrCreateWallet(db, referrerId, "student");
  assert.equal(w.available_balance, 500);
  assert.equal(w.referral_rewards_total, 500);

  // Refund pay3 on student 1 -> drops qualified referrals back from 2 to 1 -> clawback ₹300 reversal!
  db.prepare("UPDATE payments SET verification_status = 'refunded' WHERE id = ?").run(pay3);
  const rev = await recomputeReferralForStudent(db, s1, { eventType: "payment_refunded", paymentId: pay3 });
  assert.equal(rev.monthsAfter, 2);
  assert.equal(rev.milestoneReversed, 300);

  w = getOrCreateWallet(db, referrerId, "student");
  assert.equal(w.available_balance, 200);
});

test("Teacher wallet, frozen guard, duplicate withdrawal block, and rejection hold release", () => {
  const db = setupTestDb();
  const teacherId = insertTestUser(db, { role: "teacher", name: "Prof. K. Verma", email: "kverma@test.in", phone: "9844444444" });
  const adminId = insertTestUser(db, { role: "super_admin", name: "Super Admin", email: "admin@test.in", phone: "9800000000" });

  creditWalletImmutable(db, {
    userId: teacherId,
    walletType: "teacher",
    amount: 1000,
    category: "referral_reward",
    description: "Milestone credit",
    idempotencyKey: "t_credit_1"
  });

  // Duplicate idempotency key is ignored
  const dup = creditWalletImmutable(db, {
    userId: teacherId,
    walletType: "teacher",
    amount: 1000,
    category: "referral_reward",
    description: "Milestone credit duplicate",
    idempotencyKey: "t_credit_1"
  });
  assert.equal(dup.duplicate, true);
  assert.equal(getOrCreateWallet(db, teacherId, "teacher").available_balance, 1000);

  // Below minimum withdrawal fails
  assert.throws(() => {
    requestWithdrawal(db, {
      userId: teacherId,
      userRole: "teacher",
      amount: 100,
      payoutMethod: "upi",
      upiId: "verma@okaxis"
    });
  }, /Minimum withdrawal amount/);

  // Valid UPI withdrawal moves funds to hold
  const w1 = requestWithdrawal(db, {
    userId: teacherId,
    userRole: "teacher",
    amount: 600,
    payoutMethod: "upi",
    upiId: "verma@okaxis"
  });
  assert.equal(w1.wallet.available_balance, 400);
  assert.equal(w1.wallet.pending_withdrawal_hold, 600);

  // Duplicate concurrent withdrawal blocked cleanly
  assert.throws(() => {
    requestWithdrawal(db, {
      userId: teacherId,
      userRole: "teacher",
      amount: 250,
      payoutMethod: "upi",
      upiId: "verma@okaxis"
    });
  }, /already have an active withdrawal request/);

  // Rejecting refunds hold back to available_balance
  const rej = transitionWithdrawalStatus(db, {
    withdrawalId: w1.request.id,
    nextStatus: "rejected",
    adminId,
    adminNote: "UPI mismatch"
  });
  assert.equal(rej.wallet.available_balance, 1000);
  assert.equal(rej.wallet.pending_withdrawal_hold, 0);

  // Freeze wallet blocks new withdrawal
  db.prepare("UPDATE wallets SET is_frozen = 1, freeze_reason = 'Audit check' WHERE user_id = ?").run(teacherId);
  assert.throws(() => {
    requestWithdrawal(db, {
      userId: teacherId,
      userRole: "teacher",
      amount: 300,
      payoutMethod: "bank",
      accountHolderName: "K Verma",
      bankName: "SBI",
      accountNumber: "12345678901",
      ifscCode: "SBIN0001234"
    });
  }, /Wallet frozen: Audit check/);

  // Unfreeze & complete full payout lifecycle
  db.prepare("UPDATE wallets SET is_frozen = 0, freeze_reason = '' WHERE user_id = ?").run(teacherId);
  const w2 = requestWithdrawal(db, {
    userId: teacherId,
    userRole: "teacher",
    amount: 500,
    payoutMethod: "bank",
    accountHolderName: "K Verma",
    bankName: "SBI",
    accountNumber: "12345678901",
    ifscCode: "SBIN0001234"
  });
  transitionWithdrawalStatus(db, { withdrawalId: w2.request.id, nextStatus: "under_review", adminId });
  transitionWithdrawalStatus(db, { withdrawalId: w2.request.id, nextStatus: "approved", adminId });
  const paid = transitionWithdrawalStatus(db, {
    withdrawalId: w2.request.id,
    nextStatus: "paid",
    adminId,
    payoutReference: "UTR99887766"
  });
  assert.equal(paid.wallet.available_balance, 500);
  assert.equal(paid.wallet.withdrawn_amount, 500);
  assert.equal(paid.wallet.pending_withdrawal_hold, 0);
});

test("Guest cart merges into student account and creates multi-course enrollment + payment batch", () => {
  const db = setupTestDb();
  const studentId = insertTestUser(db, { role: "student", name: "Priya Gupta", email: "priya@test.in", phone: "9855555555" });
  const c1 = insertTestCourse(db, { title: "Physics 12", slug: "phys-12", monthlyFee: 2000, yearlyFee: 20000 });
  const c2 = insertTestCourse(db, { title: "Chemistry 12", slug: "chem-12", monthlyFee: 1800, yearlyFee: 18000 });
  const student = db.prepare("SELECT * FROM users WHERE id = ?").get(studentId);

  addOrUpdateCartItem(db, { guestToken: "guest_tok_123456", courseId: c1, plan: "monthly" });
  addOrUpdateCartItem(db, { guestToken: "guest_tok_123456", courseId: c2, plan: "monthly" });

  db.prepare("INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES ('SAVE10', 'percent', 10, 50, 0, 1, ?)").run(
    nowIso()
  );

  const mergedCart = getCartDetails(db, { userId: studentId, guestToken: "guest_tok_123456", couponCode: "SAVE10" });
  assert.equal(mergedCart.count, 2);
  assert.equal(mergedCart.subtotal, 3800);
  assert.equal(mergedCart.discountAmount, 380);
  assert.equal(mergedCart.totalAmount, 3420);

  const checkout = createCartCheckoutBatch({
    db,
    student,
    cart: mergedCart,
    paymentMethod: "gateway",
    gatewayOrderId: "order_abc",
    gatewayPaymentId: "pay_abc",
    isGatewayVerified: true
  });
  assert.equal(checkout.itemCount, 2);
  assert.equal(checkout.createdPaymentIds.length, 2);
  assert.equal(getCartDetails(db, { userId: studentId }).count, 0);

  const sumPayments = Number(
    db.prepare("SELECT SUM(amount) AS s FROM payments WHERE student_id = ?").get(studentId)?.s || 0
  );
  assert.equal(sumPayments, 3420);
});

test("Global Search redacts secret fields and finds pages/users/referrals; exports escape formula injection", () => {
  const db = setupTestDb();
  const sId = insertTestUser(db, { role: "student", name: "Karan Mehta", email: "karan@test.in", phone: "9866666666" });
  const prof = ensureReferralProfile(db, sId, "student");

  const searchRes = searchAdminWorkspace(db, {
    query: "Karan",
    settingDefinitions: [
      { key: "SESSION_SECRET", label: "Session Signing Secret", category: "general", isSecret: true },
      { key: "APP_URL", label: "Public App URL", category: "general", isSecret: false }
    ]
  });
  assert.ok(searchRes.totalHits >= 1);
  assert.ok(searchRes.groups.Students?.items?.length >= 1);
  const serialized = JSON.stringify(searchRes);
  assert.equal(serialized.includes("hashed_secret_never_leak"), false);

  const secretQuery = searchAdminWorkspace(db, {
    query: "SESSION_SECRET",
    settingDefinitions: [{ key: "SESSION_SECRET", label: "Session Signing Secret", category: "general", isSecret: true }]
  });
  assert.equal(secretQuery.groups.Settings, undefined);

  const refSearch = searchAdminWorkspace(db, { query: prof.referral_code });
  assert.ok(refSearch.totalHits >= 0);

  assert.equal(escapeCsvCell("=CMD|'/C calc'!A0"), `"'=CMD|'/C calc'!A0"`);
  const csv = rowsToCsv(["Name", "Formula"], [["Safe", "=1+1"]]);
  assert.match(csv, /"'=1\+1"/);

  const xml = buildSpreadsheetXml([{ name: "Test", headers: ["Col"], rows: [[123]] }]);
  assert.match(xml, /<Worksheet ss:Name="Test">/);
  assert.match(xml, /<Data ss:Type="Number">123<\/Data>/);

  const prog = evaluateThreeMonthProgress({ paidMonthsCount: 2, requiredMonths: 3 });
  assert.equal(prog.month1Paid, 1);
  assert.equal(prog.month2Paid, 1);
  assert.equal(prog.month3Paid, 0);
  assert.equal(prog.isEligible, false);
});
