import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DEFAULT_MILESTONES } from "./referral-math.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_MIGRATION_002 = path.resolve(__dirname, "..", "database", "migrations", "002_referrals_wallets_cart.sql");

export function nowIso() {
  return new Date().toISOString();
}

const txDepthMap = new WeakMap();

export function runInImmediateTx(db, fn) {
  const depth = txDepthMap.get(db) || 0;
  const spName = `sp_ytr_${depth}`;
  if (depth === 0) {
    db.exec("BEGIN IMMEDIATE;");
  } else {
    db.exec(`SAVEPOINT ${spName};`);
  }
  txDepthMap.set(db, depth + 1);
  try {
    const out = fn();
    if (depth === 0) {
      db.exec("COMMIT;");
    } else {
      db.exec(`RELEASE SAVEPOINT ${spName};`);
    }
    return out;
  } catch (err) {
    try {
      if (depth === 0) {
        db.exec("ROLLBACK;");
      } else {
        db.exec(`ROLLBACK TO SAVEPOINT ${spName};`);
        db.exec(`RELEASE SAVEPOINT ${spName};`);
      }
    } catch {
      // ignore rollback failure if already closed
    }
    throw err;
  } finally {
    if (depth === 0) {
      txDepthMap.delete(db);
    } else {
      txDepthMap.set(db, depth);
    }
  }
}

export function ensureAddonsSchema(db, migrationPath = DEFAULT_MIGRATION_002) {
  const sql = fs.readFileSync(migrationPath, "utf8");
  db.exec(sql);
  seedReferralDefaults(db);
}

export function seedReferralDefaults(db) {
  const now = nowIso();
  db.prepare(
    `INSERT OR IGNORE INTO referral_settings (id, updated_at) VALUES (1, ?)`
  ).run(now);

  const row = db.prepare("SELECT terms_and_conditions FROM referral_settings WHERE id = 1").get();
  if (row && typeof row.terms_and_conditions === "string" && row.terms_and_conditions.includes("\\n")) {
    const cleaned = row.terms_and_conditions.replace(/\\n/g, "\n");
    db.prepare("UPDATE referral_settings SET terms_and_conditions = ? WHERE id = 1").run(cleaned);
  }

  const count = Number(db.prepare("SELECT COUNT(*) AS c FROM referral_milestones").get()?.c || 0);
  if (count === 0) {
    const ins = db.prepare(
      `INSERT INTO referral_milestones (qualified_count, cumulative_reward, title, badge_label, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, 1, ?, ?)`
    );
    for (const m of DEFAULT_MILESTONES) {
      ins.run(m.qualified_count, m.cumulative_reward, m.title, m.badge_label, now, now);
    }
  }
}

export function getReferralSettings(db) {
  seedReferralDefaults(db);
  return db.prepare("SELECT * FROM referral_settings WHERE id = 1").get();
}

export function getActiveMilestones(db) {
  return db
    .prepare("SELECT * FROM referral_milestones WHERE is_active = 1 ORDER BY qualified_count ASC")
    .all();
}

export function getAllMilestones(db) {
  return db
    .prepare("SELECT * FROM referral_milestones ORDER BY qualified_count ASC")
    .all();
}
