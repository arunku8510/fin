import test from "node:test";
import assert from "node:assert/strict";
import {
  computeRemainingPopupDelayMs,
  evaluatePopupDecision,
  isHandledPortalOrExtensionPath,
  isPrivateOrPortalPath,
  normalizePathname,
} from "./part1-rules.js";

test("normalizePathname handles trailing slashes, duplicate slashes, and queries", () => {
  assert.equal(normalizePathname("/"), "/");
  assert.equal(normalizePathname("/register/"), "/register");
  assert.equal(normalizePathname("/student//login.php?next=/student/"), "/student/login.php");
  assert.equal(normalizePathname("https://yuitor.com/about/#team"), "/about");
});

test("isHandledPortalOrExtensionPath covers all registration, login, portal, and custom routes", () => {
  const handled = [
    "/register",
    "/register/",
    "/register.php",
    "/register/student",
    "/register/teacher",
    "/student/register.php",
    "/teacher/register.php",
    "/teacher-apply.php",
    "/login",
    "/login.php",
    "/student/login.php",
    "/teacher/login.php",
    "/admin/login.php",
    "/admin/setup",
    "/student/",
    "/teacher/",
    "/admin/",
    "/erp",
    "/erp/index.php",
    "/admission",
    "/courses",
    "/subjects",
    "/ai-learning",
    "/computer-courses",
    "/english-speaking",
    "/teachers",
    "/faqs",
    "/testimonials",
    "/unsubscribe/abc123",
  ];
  for (const route of handled) {
    assert.equal(isHandledPortalOrExtensionPath(route), true, `Expected ${route} to be handled`);
  }

  assert.equal(isHandledPortalOrExtensionPath("/non-existent-page-xyz"), false);
  assert.equal(isHandledPortalOrExtensionPath("/about"), false);
  assert.equal(isHandledPortalOrExtensionPath("/contact"), false);
});

test("isPrivateOrPortalPath flags portals and auth routes accurately", () => {
  assert.equal(isPrivateOrPortalPath("/student/dashboard"), true);
  assert.equal(isPrivateOrPortalPath("/teacher/lessons"), true);
  assert.equal(isPrivateOrPortalPath("/admin/settings"), true);
  assert.equal(isPrivateOrPortalPath("/register/teacher"), true);
  assert.equal(isPrivateOrPortalPath("/login"), true);
  assert.equal(isPrivateOrPortalPath("/courses"), false);
  assert.equal(isPrivateOrPortalPath("/"), false);
});

test("computeRemainingPopupDelayMs enforces >= 45s wait anchored to session start", () => {
  const start = 1_000_000;
  assert.equal(computeRemainingPopupDelayMs(start, start, 45_000), 45_000);
  assert.equal(computeRemainingPopupDelayMs(start, start + 20_000, 45_000), 25_000);
  assert.equal(computeRemainingPopupDelayMs(start, start + 45_000, 45_000), 0);
  assert.equal(computeRemainingPopupDelayMs(start, start + 90_000, 45_000), 0);
});

test("evaluatePopupDecision enforces dismissal, route suppression, 45s/90s timing, and modal mutex", () => {
  const start = 10_000;
  // Never fires immediately on entry
  const early = evaluatePopupDecision({
    pathname: "/",
    sessionStartedAtMs: start,
    nowMs: start + 5_000,
    minDelayMs: 45_000,
    isDismissed: false,
    hasOtherModalOpen: false,
    isChatOpen: false,
  });
  assert.equal(early.show, false);
  assert.equal(early.reason, "waiting_delay");
  assert.equal(early.waitMs, 40_000);

  // Suppressed if dismissed
  const dismissed = evaluatePopupDecision({
    pathname: "/courses",
    sessionStartedAtMs: start,
    nowMs: start + 60_000,
    minDelayMs: 45_000,
    isDismissed: true,
    hasOtherModalOpen: false,
    isChatOpen: false,
  });
  assert.equal(dismissed.show, false);
  assert.equal(dismissed.reason, "dismissed");

  // Defers when another popup or chat is open
  const conflict = evaluatePopupDecision({
    pathname: "/about",
    sessionStartedAtMs: start,
    nowMs: start + 95_000,
    minDelayMs: 90_000,
    isDismissed: false,
    hasOtherModalOpen: true,
    isChatOpen: false,
  });
  assert.equal(conflict.show, false);
  assert.equal(conflict.reason, "modal_conflict");
  assert.equal(conflict.waitMs, 5000);

  // Ready after delay on public route with no active modal/chat
  const ready = evaluatePopupDecision({
    pathname: "/contact",
    sessionStartedAtMs: start,
    nowMs: start + 45_000,
    minDelayMs: 45_000,
    isDismissed: false,
    hasOtherModalOpen: false,
    isChatOpen: false,
  });
  assert.equal(ready.show, true);
  assert.equal(ready.reason, "ready");
});
