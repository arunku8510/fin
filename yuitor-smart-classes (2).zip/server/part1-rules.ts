export interface PopupScheduleContext {
  pathname: string;
  sessionStartedAtMs: number;
  nowMs: number;
  minDelayMs: number;
  isDismissed: boolean;
  hasOtherModalOpen: boolean;
  isChatOpen: boolean;
}

export type PopupDecision =
  | { show: true; waitMs: 0; reason: "ready" }
  | { show: false; waitMs: number; reason: "portal_route" | "dismissed" | "waiting_delay" | "modal_conflict" };

const PRIVATE_OR_PORTAL_RE =
  /^\/(?:admin(?:-setup)?|student|teacher|teacher-apply\.php|login|register|unsubscribe|erp)(?:\/|$|\.)/i;

export const CUSTOM_PUBLIC_PATHS = new Set<string>([
  "/admission",
  "/subjects",
  "/ai-learning",
  "/computer-courses",
  "/english-speaking",
  "/teachers",
  "/faqs",
  "/testimonials",
  "/courses",
]);

export function normalizePathname(rawUrlOrPath: string): string {
  const withoutOrigin = String(rawUrlOrPath || "/")
    .trim()
    .replace(/^https?:\/\/[^/]+/i, "")
    .split(/[?#]/)[0];
  const collapsed = ("/" + withoutOrigin).replace(/\/+/g, "/");
  const trimmed = collapsed.replace(/\/+$/, "") || "/";
  try {
    return decodeURI(trimmed);
  } catch {
    return trimmed;
  }
}

export function isPrivateOrPortalPath(rawPath: string): boolean {
  const normalized = normalizePathname(rawPath);
  return PRIVATE_OR_PORTAL_RE.test(normalized);
}

export function isHandledPortalOrExtensionPath(rawPath: string): boolean {
  const path = normalizePathname(rawPath);
  return (
    path.startsWith("/admin") ||
    path.startsWith("/student") ||
    path.startsWith("/teacher") ||
    path === "/teacher-apply.php" ||
    path.startsWith("/unsubscribe/") ||
    path === "/login" ||
    path === "/login.php" ||
    path === "/register" ||
    path === "/register.php" ||
    path.startsWith("/register/") ||
    path === "/erp" ||
    path.startsWith("/erp/") ||
    CUSTOM_PUBLIC_PATHS.has(path)
  );
}

export function computeRemainingPopupDelayMs(
  sessionStartedAtMs: number,
  nowMs: number,
  minDelayMs: number
): number {
  const start = Number.isFinite(sessionStartedAtMs) && sessionStartedAtMs > 0 ? sessionStartedAtMs : nowMs;
  const elapsed = Math.max(0, nowMs - start);
  return Math.max(0, minDelayMs - elapsed);
}

export function evaluatePopupDecision(ctx: PopupScheduleContext): PopupDecision {
  if (isPrivateOrPortalPath(ctx.pathname)) {
    return { show: false, waitMs: 0, reason: "portal_route" };
  }
  if (ctx.isDismissed) {
    return { show: false, waitMs: 0, reason: "dismissed" };
  }
  const waitMs = computeRemainingPopupDelayMs(ctx.sessionStartedAtMs, ctx.nowMs, ctx.minDelayMs);
  if (waitMs > 0) {
    return { show: false, waitMs, reason: "waiting_delay" };
  }
  if (ctx.hasOtherModalOpen || ctx.isChatOpen) {
    return { show: false, waitMs: 5000, reason: "modal_conflict" };
  }
  return { show: true, waitMs: 0, reason: "ready" };
}
