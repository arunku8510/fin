import test from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { generateShreyaReply, sanitizeChatTextForStorage, SHREYA_INTRO } from "./chatbot.js";
import { seedDefaultContent } from "./db.js";

function createTestDb(): { db: DatabaseSync; cleanup: () => void } {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "yuitor-chat-test-"));
  const dbPath = path.join(dir, "test.db");
  const db = new DatabaseSync(dbPath);
  db.exec(`
    CREATE TABLE courses (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, slug TEXT, category TEXT, class_range TEXT, board TEXT, description TEXT, duration_months INTEGER, monthly_fee INTEGER, yearly_fee INTEGER, thumbnail_url TEXT, is_active INTEGER, created_at TEXT);
    CREATE TABLE lessons (id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER, title TEXT, lesson_type TEXT, material_url TEXT, content TEXT, duration_minutes INTEGER, sort_order INTEGER, is_visible INTEGER, created_at TEXT);
    CREATE TABLE subjects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, code TEXT, class_level TEXT, description TEXT, is_active INTEGER, created_at TEXT);
    CREATE TABLE faqs (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT, answer TEXT, sort_order INTEGER, is_active INTEGER, created_at TEXT);
    CREATE TABLE testimonials (id INTEGER PRIMARY KEY AUTOINCREMENT, author_name TEXT, author_role TEXT, outcome_metric TEXT, quote TEXT, is_approved INTEGER, created_at TEXT);
    CREATE TABLE coupons (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, discount_type TEXT, discount_value INTEGER, max_uses INTEGER, used_count INTEGER, is_active INTEGER, created_at TEXT);
    CREATE TABLE email_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT, subject TEXT, preview_text TEXT, html_body TEXT, created_at TEXT);
    CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, verification_status TEXT);
    CREATE TABLE chatbot_conversations (id TEXT PRIMARY KEY, visitor_id TEXT, visitor_name TEXT, visitor_phone TEXT, visitor_email TEXT, status TEXT, rating INTEGER, feedback TEXT, last_message TEXT, created_at TEXT, updated_at TEXT);
    CREATE TABLE chatbot_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id TEXT, sender TEXT, message TEXT, created_at TEXT);
  `);
  seedDefaultContent(db);
  return {
    db,
    cleanup: () => {
      db.close();
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
}

test("Shreya returns exact greeting intro", async () => {
  const { db, cleanup } = createTestDb();
  try {
    const out = await generateShreyaReply(db, "conv-1", "Hello");
    assert.equal(out.reply, SHREYA_INTRO);
    assert.equal(out.escalate, false);
  } finally {
    cleanup();
  }
});

test("Shreya answers bilingual fee queries and mandatory teacher resume queries", async () => {
  const { db, cleanup } = createTestDb();
  const prevKey = process.env.GEMINI_API_KEY;
  process.env.GEMINI_API_KEY = "";
  try {
    const feeReply = await generateShreyaReply(db, "conv-2", "Class 10 fees kitni hai?");
    assert.match(feeReply.reply, /1400/);
    assert.equal(feeReply.escalate, false);

    const teacherReply = await generateShreyaReply(db, "conv-2", "How do I apply as a teacher and upload resume?");
    assert.match(teacherReply.reply, /\/teacher\/register\.php/);
    assert.match(teacherReply.reply, /PDF\/DOC\/DOCX/i);
  } finally {
    if (prevKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = prevKey;
    cleanup();
  }
});

test("Shreya solves dynamic academic calculations and expands physics concepts", async () => {
  const { db, cleanup } = createTestDb();
  const prevKey = process.env.GEMINI_API_KEY;
  process.env.GEMINI_API_KEY = "";
  try {
    const pct = await generateShreyaReply(db, "conv-3", "20% of 1400");
    assert.match(pct.reply, /280/);

    const ohm = await generateShreyaReply(db, "conv-3", "Explain ohm's law formula");
    assert.match(ohm.reply, /V = I × R/);
  } finally {
    if (prevKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = prevKey;
    cleanup();
  }
});

test("Shreya redacts sensitive OTPs/passwords and triggers human escalation", async () => {
  const { db, cleanup } = createTestDb();
  const prevKey = process.env.GEMINI_API_KEY;
  process.env.GEMINI_API_KEY = "";
  try {
    const safe = sanitizeChatTextForStorage("My password is MySecret123 and otp: 458912");
    assert.ok(!safe.includes("MySecret123"));
    assert.ok(!safe.includes("458912"));

    const esc = await generateShreyaReply(db, "conv-4", "I want to speak to human about a refund issue");
    assert.equal(esc.escalate, true);
    assert.match(esc.reply, /\+91 78-2728-9292/);
  } finally {
    if (prevKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = prevKey;
    cleanup();
  }
});
