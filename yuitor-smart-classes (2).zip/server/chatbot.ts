import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, nowIso } from "./security.js";

export const SHREYA_INTRO =
  "Hello! My name is Shreya, and I am Yuitor Smart Classes’ Smart AI Assistant. How can I help you?";

function redactSensitiveText(text: string): string {
  return text
    .replace(/\b(password|passwd|pwd)\s*(?:is|was|:|=)\s*\S+/gi, "$1: [REDACTED]")
    .replace(/\b(otp|code|pin)\s*(?:is|was|:|=)?\s*\d{4,8}\b/gi, "$1 [REDACTED]");
}

function buildKnowledgeContext(db: DatabaseSync): string {
  const courses = db
    .prepare("SELECT title, category, class_range, board, duration_months, monthly_fee, yearly_fee FROM courses WHERE is_active = 1 ORDER BY id")
    .all() as any[];
  const subjects = db.prepare("SELECT name, class_level FROM subjects WHERE is_active = 1 ORDER BY id").all() as any[];
  const faqs = db.prepare("SELECT question, answer FROM faqs WHERE is_active = 1 ORDER BY sort_order").all() as any[];
  const approvedTeachers = (
    db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'teacher' AND verification_status = 'approved'").get() as { c: number }
  ).c;

  const courseLines = courses
    .map(
      (c) =>
        `- ${c.title} (${c.category}, ${c.class_range}, ${c.board}, ${c.duration_months} months): ₹${c.monthly_fee}/month or ₹${c.yearly_fee}/year`
    )
    .join("\n");
  const subjectLines = subjects.map((s) => `- ${s.name} (${s.class_level})`).join("\n");
  const faqLines = faqs.map((f) => `Q: ${f.question} | A: ${f.answer}`).join("\n");

  return `OFFICIAL YUITOR SMART CLASSES DATA (Source of truth — NEVER invent courses, fees, discounts, or policies):
- Brand: Yuitor Smart Classes
- Address: Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India
- Call / WhatsApp: +91 78-2728-9292 | Branch: +91 1232314337
- Admission Email: admission@yuitor.com | Inquiry Email: inquiry@yuitor.com
- Website & Key Routes: https://yuitor.com | Admission form: /admission | Fee calculator: /fee-calculator | Scholarship: /scholarship | Register: /register (Student: /student/register.php, Teacher: /teacher/register.php) | Login: /login | Portals: /student/, /teacher/
- Student Registration & Approval Flow: Students register online -> verify 6-digit mobile OTP -> account enters Pending Yuitor Team Approval -> Admin approves account for Student Dashboard (lessons, schedules, attendance, assignments, quizzes, fees & receipts, certificates).
- Teacher Registration & Mandatory Resume Flow: Teachers apply via /teacher/register.php with qualifications, subjects, AND a mandatory PDF/DOC/DOCX resume (max 5 MB) -> verify 6-digit mobile OTP -> Academic Team reviews resume & profile -> Admin approves account before Teacher Dashboard access (/teacher/ for lessons, schedules, attendance, assignments & quizzes) is unlocked.
- Approved Faculty Directory (/teachers): ${approvedTeachers} approved faculty profiles currently listed; core faculty team leads Physics, Chemistry, Biology, Mathematics, Computer & Spoken English.
- Fee & Refund Policy: 100% fee refund within 7 days subject to published admission terms (/refund). Never promise unpublished discounts or unverified scholarships.

COURSES & FEES:
${courseLines}

SUBJECTS:
${subjectLines}

FAQs:
${faqLines}`;
}

const FUZZY_VOCAB = [
  "admission",
  "fees",
  "teacher",
  "resume",
  "verify",
  "verification",
  "otp",
  "login",
  "password",
  "register",
  "registration",
  "scholarship",
  "refund",
  "computer",
  "english",
  "python",
  "muradnagar",
  "syllabus",
  "mathematics",
  "physics",
  "chemistry",
  "biology",
  "portal",
  "dashboard",
  "schedule",
  "assignment",
  "quiz",
  "certificate",
  "receipt",
  "contact",
  "razorpay",
  "payment",
  "attendance",
  "timings",
  "cbse",
  "icse",
];

function levenshteinDistance(a: string, b: string): number {
  if (a === b) return 0;
  const al = a.length;
  const bl = b.length;
  if (Math.abs(al - bl) > 2) return 99;
  const prev = Array.from({ length: bl + 1 }, (_, j) => j);
  const curr = new Array<number>(bl + 1);
  for (let i = 1; i <= al; i++) {
    curr[0] = i;
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= bl; j++) prev[j] = curr[j];
  }
  return prev[bl];
}

function normalizeUserQuery(raw: string): string {
  const lower = raw.toLowerCase();
  const corrected = lower.replace(/\b[a-z]{4,16}\b/g, (word) => {
    if (FUZZY_VOCAB.includes(word)) return word;
    let best = word;
    let bestDist = 3;
    const maxDist = word.length >= 7 ? 2 : 1;
    for (const vocab of FUZZY_VOCAB) {
      const d = levenshteinDistance(word, vocab);
      if (d <= maxDist && d < bestDist) {
        best = vocab;
        bestDist = d;
      }
    }
    return best;
  });
  return corrected;
}

function safeEvalArithmetic(exprRaw: string): number | null {
  const cleaned = exprRaw
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/\^/g, "**")
    .replace(/[^0-9+\-*/().%\s*]/g, "")
    .trim();
  if (!cleaned || !/\d/.test(cleaned) || !/[+\-*/%]/.test(cleaned)) return null;
  if (cleaned.length > 64) return null;
  try {
    const val = Function(`"use strict"; return (${cleaned});`)();
    return typeof val === "number" && Number.isFinite(val) ? Number(val.toFixed(6)) : null;
  } catch {
    return null;
  }
}

function tryDynamicAcademicSolver(userMsg: string, isHindi: boolean): string | null {
  const q = userMsg.trim();
  const ql = q.toLowerCase();

  // 1. Percentage: "20% of 1400" / "15 percent of 2000"
  const pctMatch = ql.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of|ka|on)\s*(\d+(?:\.\d+)?)/i);
  if (pctMatch) {
    const p = Number(pctMatch[1]);
    const base = Number(pctMatch[2]);
    const ans = Number(((p / 100) * base).toFixed(4));
    return isHindi
      ? `${base} ka ${p}% = ${ans} hota hai.`
      : `${p}% of ${base} = ${ans}.`;
  }

  // 2. Multiplication table: "table of 17" / "17 ka pahada"
  const tableMatch = ql.match(/(?:table\s+of|pahada\s+of|(\d+)\s+ka\s+pahada)\s*(\d+)?/i);
  if (tableMatch) {
    const n = Number(tableMatch[1] || tableMatch[2]);
    if (Number.isFinite(n) && n >= 1 && n <= 1000) {
      const rows = Array.from({ length: 10 }, (_, i) => `${n}×${i + 1}=${n * (i + 1)}`).join(", ");
      return `Table of ${n}: ${rows}.`;
    }
  }

  // 3. Square / Cube / Square Root
  const sqrtMatch = ql.match(/(?:square\s*root|sqrt|vargmul)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqrtMatch) {
    const n = Number(sqrtMatch[1]);
    if (n >= 0) {
      return `√${n} = ${Number(Math.sqrt(n).toFixed(6))}.`;
    }
  }
  const sqMatch = ql.match(/(?:square|varg)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqMatch) {
    const n = Number(sqMatch[1]);
    return `${n}² = ${Number((n * n).toFixed(6))}.`;
  }
  const cubeMatch = ql.match(/(?:cube|ghan)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (cubeMatch) {
    const n = Number(cubeMatch[1]);
    return `${n}³ = ${Number((n * n * n).toFixed(6))}.`;
  }

  // 4. Unit conversions
  const cToF = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:c|celsius)\s*(?:to|in)\s*(?:f|fahrenheit)/i);
  if (cToF) {
    const c = Number(cToF[1]);
    return `${c}°C = ${Number(((c * 9) / 5 + 32).toFixed(2))}°F.`;
  }
  const fToC = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:f|fahrenheit)\s*(?:to|in)\s*(?:c|celsius)/i);
  if (fToC) {
    const f = Number(fToC[1]);
    return `${f}°F = ${Number((((f - 32) * 5) / 9).toFixed(2))}°C.`;
  }
  const kmhToMs = ql.match(/(\d+(?:\.\d+)?)\s*km\/?h\s*(?:to|in)\s*m\/?s/i);
  if (kmhToMs) {
    const v = Number(kmhToMs[1]);
    return `${v} km/h = ${Number(((v * 5) / 18).toFixed(3))} m/s.`;
  }

  // 5. Simple Interest: "si of 10000 at 5% for 2 years"
  const siMatch = ql.match(/(?:si|simple interest)\s*(?:of|on)?\s*(\d+(?:\.\d+)?)\s*(?:at|rate)?\s*(\d+(?:\.\d+)?)%?\s*(?:for|time)?\s*(\d+(?:\.\d+)?)/i);
  if (siMatch) {
    const p = Number(siMatch[1]);
    const r = Number(siMatch[2]);
    const t = Number(siMatch[3]);
    const si = Number(((p * r * t) / 100).toFixed(2));
    return `Simple Interest = (P×R×T)/100 = ₹${si} (Total Amount: ₹${Number((p + si).toFixed(2))}).`;
  }

  // 6. Direct arithmetic: "what is 125 * 18", "solve 45+55", "240/6"
  const arithCandidate = ql
    .replace(/^(?:what is|calculate|solve|eval|evaluate|kitna hota hai|batao)\s+/i, "")
    .replace(/\?+$/, "")
    .trim();
  if (/^[\d\s+\-*/().^×÷]+$/.test(arithCandidate) && /[+\-*/^×÷]/.test(arithCandidate)) {
    const res = safeEvalArithmetic(arithCandidate);
    if (res !== null) {
      return `${arithCandidate} = ${res}`;
    }
  }

  return null;
}

const ACADEMIC_CONCEPTS: Array<{ keys: RegExp; answer: string }> = [
  {
    keys: /\b(newton|laws of motion|f=ma|force formula)\b/i,
    answer:
      "Newton's Laws: (1) Inertia — object stays at rest/motion unless external force acts; (2) F = m × a (Force = mass × acceleration, SI unit: Newton); (3) Every action has an equal and opposite reaction.",
  },
  {
    keys: /\b(ohm'?s law|v=ir|resistance formula)\b/i,
    answer:
      "Ohm's Law states V = I × R (at constant temperature, current I is directly proportional to voltage V). SI units: Voltage (Volt), Current (Ampere), Resistance (Ohm Ω).",
  },
  {
    keys: /\b(electric power|joule'?s law|current formula)\b/i,
    answer:
      "Electric Current I = Q / t (Ampere). Electric Power P = V × I = I²R = V²/R (Watt). Heat produced H = I²Rt (Joule's Law of Heating).",
  },
  {
    keys: /\b(pythagoras|hypotenuse)\b/i,
    answer:
      "Pythagoras Theorem (right triangle): Hypotenuse² = Base² + Perpendicular² (c² = a² + b²).",
  },
  {
    keys: /\b(quadratic|sridharacharya|discriminant)\b/i,
    answer:
      "Quadratic Formula for ax² + bx + c = 0: x = [-b ± √(b² - 4ac)] / (2a), where Discriminant D = b² - 4ac determines real/equal/complex roots.",
  },
  {
    keys: /\b(arithmetic progression|nth term|ap formula)\b/i,
    answer:
      "Arithmetic Progression (AP): nth term aₙ = a + (n - 1)d, and Sum of n terms Sₙ = (n/2)[2a + (n - 1)d] = (n/2)(a + l).",
  },
  {
    keys: /\b(mensuration|surface area|volume of sphere|cylinder|cone)\b/i,
    answer:
      "Key Mensuration Formulas: Sphere Volume = (4/3)πr³ (SA = 4πr²); Cylinder Volume = πr²h (CSA = 2πrh); Cone Volume = (1/3)πr²h (CSA = πrl).",
  },
  {
    keys: /\b(photosynthesis)\b/i,
    answer:
      "Photosynthesis equation: 6CO₂ + 6H₂O + Sunlight (Chlorophyll) → C₆H₁₂O₆ (Glucose) + 6O₂. Plants convert light energy into chemical energy inside chloroplasts.",
  },
  {
    keys: /\b(mitochondria|cell organelle|dna|nucleus)\b/i,
    answer:
      "Cell Biology: Mitochondria are the powerhouse of the cell (synthesize ATP); Nucleus holds DNA and controls cellular activities; Ribosomes synthesize proteins.",
  },
  {
    keys: /\b(acid|base|ph scale|neutralization)\b/i,
    answer:
      "Acids turn blue litmus red (pH < 7, give H⁺ ions); Bases turn red litmus blue (pH > 7, give OH⁻ ions); pH 7 is neutral. Acid + Base → Salt + Water (Neutralization).",
  },
  {
    keys: /\b(periodic table|atomic number|valency)\b/i,
    answer:
      "Modern Periodic Law (Moseley): Properties of elements are periodic functions of their atomic number (Z). E.g., H(1), He(2), C(6), N(7), O(8), Na(11), Cl(17), Ca(20).",
  },
  {
    keys: /\b(trigonometry|sin|cos|tan|identity)\b/i,
    answer:
      "Core Trigonometry Identities: sin²θ + cos²θ = 1, 1 + tan²θ = sec²θ, 1 + cot²θ = cosec²θ. Standard values: sin30° = 1/2, sin45° = 1/√2, sin60° = √3/2, sin90° = 1.",
  },
  {
    keys: /\b(lens formula|mirror formula|magnification)\b/i,
    answer:
      "Mirror Formula: 1/f = 1/v + 1/u (m = -v/u). Lens Formula: 1/f = 1/v - 1/u (m = v/u), Power P = 1/f (in metres, Dioptre D).",
  },
  {
    keys: /\b(tense|grammar|parts of speech|noun|verb|active passive)\b/i,
    answer:
      "English Grammar Basics: 3 main tenses (Present, Past, Future), each with Simple, Continuous, Perfect & Perfect Continuous forms. Yuitor's Spoken English & Class 6–12 batches cover grammar, fluency & interview skills.",
  },
  {
    keys: /\b(python|loop|function|html|javascript|sql)\b/i,
    answer:
      "Python uses `def` for functions and `for`/`while` for loops; SQL uses `SELECT/INSERT/UPDATE/DELETE`; HTML structures web pages and JS adds interactivity. All of these are taught practically in Yuitor's Computer & AI Coding tracks!",
  },
];

function ruleBasedFallback(
  userMsg: string,
  history: Array<{ sender: string; message: string }>,
  db: DatabaseSync
): { reply: string; escalate: boolean } {
  const q = normalizeUserQuery(userMsg);
  const isHindi =
    /[\u0900-\u097F]|\b(kya|kaise|kitni|fees|batayein|batao|chahiye|karna|nahi|ho raha|madad|admission lena|namaste|kab|kahan|kaun|padhna|padhana|doubts?|kripya|samjhao)\b/i.test(
      userMsg
    );

  // Greeting
  if (/^(hi|hello|hey|namaste|hlo|good morning|good evening|good afternoon)[!.\s]*$/i.test(q.trim())) {
    return { reply: SHREYA_INTRO, escalate: false };
  }

  // Who are you
  if (/\b(who are you|your name|kaun ho|aap kaun|shreya)\b/i.test(q) && q.length < 45) {
    return { reply: SHREYA_INTRO, escalate: false };
  }

  // Detect unresolved / human handoff requests
  if (/\b(complaint|refund issue|speak to human|talk to sir|call me|human|manager|principal|unresolved|team se baat)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Main aapki query Yuitor Team ko transfer kar rahi hoon. Aap kripya +91 78-2728-9292 par call/WhatsApp karein ya Info tab mein apna number share karein."
        : "I have flagged this for the Yuitor Team. You can also call or WhatsApp +91 78-2728-9292 or leave your contact in the Info box so our team can reach out.",
      escalate: true,
    };
  }

  // Dynamic Math / Unit / Academic doubt solver
  const solved = tryDynamicAcademicSolver(userMsg, isHindi);
  if (solved) {
    return { reply: solved, escalate: false };
  }

  for (const item of ACADEMIC_CONCEPTS) {
    if (item.keys.test(q)) {
      return { reply: item.answer, escalate: false };
    }
  }

  // Teacher registration & resume workflow
  if (
    /\b(resume|cv|teacher register|teacher registration|apply as teacher|join as teacher|teaching job|faculty apply|padhana)\b/i.test(
      q
    ) ||
    (/\b(teacher|faculty)\b/i.test(q) && /\b(register|registration|apply|join|resume|document)\b/i.test(q))
  ) {
    return {
      reply: isHindi
        ? "Teacher Registration ke liye /teacher/register.php par jayein, apni qualification aur valid PDF/DOC/DOCX resume (max 5 MB) upload karein, phir 6-digit OTP verify karein. Resume verification aur Admin approval ke baad Teacher Dashboard unlock hota hai."
        : "To apply as a teacher, visit /teacher/register.php, upload your updated PDF/DOC/DOCX resume (required, max 5 MB), and complete 6-digit OTP verification. The Teacher Dashboard unlocks once the Yuitor Academic Team verifies your resume and approves your profile.",
      escalate: false,
    };
  }

  // Portal / Dashboard / Study Material / Assignment / Exam info
  if (/\b(portal|dashboard|study material|notes|assignment|quiz|syllabus)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Approved students (/student/) aur teachers (/teacher/) apne dashboard se study notes, class schedule, attendance, assignments, MCQs aur fee receipts access kar sakte hain. Sign in ke liye /login par jayein."
        : "Approved students (/student/) and teachers (/teacher/) can access notes, schedules, attendance, assignments, MCQ quizzes, and verified receipts from their portal after signing in at /login.",
      escalate: false,
    };
  }

  // Registration general query
  if (/\b(register|registration|signup|sign up|create account|new account)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Aap /register par Student ya Teacher registration kar sakte hain (Teachers ke liye resume upload zaroori hai). Kya aap Student ya Teacher ke roop mein register karna chahte hain?"
        : "You can register as a Student or Teacher on /register (teachers must attach a PDF/DOC/DOCX resume). Would you like to register as a Student or a Teacher?",
      escalate: false,
    };
  }

  // Exact examples from specification
  if (
    /^\s*(i want admission|admission|apply|join|enroll|daakhila)\b/i.test(q) &&
    !/\b(class|neet|jee|cuet|computer|english|ai|python|6|7|8|9|10|11|12)\b/i.test(q)
  ) {
    return {
      reply: isHindi
        ? "Bilkul! Aap kis class ya course mein admission lena chahte hain?"
        : "Sure! Which class or course are you interested in?",
      escalate: false,
    };
  }

  if (
    /\b(fees?|price|charges|kitni|paisa|amount)\b/i.test(q) &&
    !/\b(5|6|7|8|9|10|11|12|neet|jee|cuet|computer|english|ai|python|spoken|nda|ssc|banking)\b/i.test(q)
  ) {
    return {
      reply: isHindi
        ? "Aap kis class ya course ki fees jaanna chahte hain?"
        : "Which class or course would you like to know the fees for?",
      escalate: false,
    };
  }

  if (/\b(cannot log in|can't login|cant login|login problem|login issue|otp|sign in|unable to login|log in|password)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Kya aapko OTP verification mein dikkat aa rahi hai ya password/login karne mein? Password reset karne ke liye /login par 'Forgot Password?' use kar sakte hain."
        : "Are you having trouble with OTP verification or signing into your account? You can also use 'Forgot Password?' on /login to reset your password with a 6-digit OTP.",
      escalate: false,
    };
  }

  // Dynamic DB course lookup
  const courses = db
    .prepare("SELECT title, category, class_range, monthly_fee, yearly_fee FROM courses WHERE is_active = 1")
    .all() as any[];

  if (/\b(class\s*5|5th)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Class 5th Foundation fees CBSE ₹1,000/month (₹10,200/year), UP Board ₹900/month, ICSE ₹1,200/month hai. Kya aap free demo class book karna chahenge?"
        : "Class 5th coaching fees start at ₹900–₹1,200/month depending on board (CBSE/UP/ICSE). Would you like to book a free demo class?",
      escalate: false,
    };
  }
  if (/\b(class\s*6|class\s*7|class\s*8|6th|7th|8th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("6th–8th"));
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Would you like to book a demo class?`,
        escalate: false,
      };
    }
  }
  if (/\b(class\s*9|class\s*10|9th|10th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("9th–10th"));
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Would you like to apply via /admission?`,
        escalate: false,
      };
    }
  }
  if (/\b(class\s*11|class\s*12|11th|12th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("11th–12th"));
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Which stream or board are you looking for?`,
        escalate: false,
      };
    }
  }
  if (/\b(neet|jee)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("NEET"));
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Are you preparing for NEET or JEE?`,
        escalate: false,
      };
    }
  }
  if (/\b(cuet|nda|ssc|banking)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("CUET"));
    const base = c ? `₹${c.monthly_fee}/month (₹${c.yearly_fee}/year)` : "₹1,800–₹2,200/month";
    return {
      reply: `Competitive & CUET batch fees start at ${base}. Would you like to know the Muradnagar batch timings?`,
      escalate: false,
    };
  }
  if (/\b(computer|dca|tally|ccc|ms office)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "Computer");
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Would you like details on DCA or Tally Prime?`,
        escalate: false,
      };
    }
  }
  if (/\b(ai|python|coding|web development|full stack)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "AI Learning");
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Which class or skill level are you in?`,
        escalate: false,
      };
    }
  }
  if (/\b(english|spoken)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "English Speaking");
    if (c) {
      return {
        reply: `${c.title} fees: ₹${c.monthly_fee}/month (or ₹${c.yearly_fee}/year). Would you like to join the next batch?`,
        escalate: false,
      };
    }
  }
  if (/\b(coupon|discount|scholarship|offer|festival)\b/i.test(q)) {
    return {
      reply:
        "You can check scholarship tests on /scholarship or use active festival/enrollment promo codes (such as YUITOR10 for eligible batches) in your Student Portal or Fee Calculator (/fee-calculator).",
      escalate: false,
    };
  }
  if (/\b(demo|trial|timing|batch|schedule)\b/i.test(q)) {
    return {
      reply:
        "Morning and evening batches run Monday to Saturday at Yuitor Smart Classes, Muradnagar. You can request a free demo class via /contact or /admission.",
      escalate: false,
    };
  }
  if (/\b(teacher|faculty|staff|sir|mam)\b/i.test(q)) {
    return {
      reply:
        "Yuitor Smart Classes is led by experienced Physics, Chemistry, Biology, Mathematics, Computer & English faculty (visit /teachers for full profiles). Interested in applying as a teacher? Visit /teacher/register.php.",
      escalate: false,
    };
  }
  if (/\b(razorpay|upi|online payment|pay fee|fee payment|payment method|cash desk)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Approved students /student/ portal ke 'Courses & Learning' aur 'Fees & Receipts' tab se UPI, Centre Cash Desk ya Online Gateway (Razorpay) ke zariye fee submit kar sakte hain aur YTR-RCP receipt download kar sakte hain."
        : "Approved students can pay fees from /student/ using Online Gateway (Razorpay), UPI / Desk Transfer, or Centre Cash Desk, and print official YTR-RCP receipts right from 'Fees & Receipts'.",
      escalate: false,
    };
  }
  if (/\b(cbse|icse|up board|board)\b/i.test(q) && !/\b(10|12|9|11|6|7|8|5)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Yuitor Smart Classes mein CBSE, ICSE aur UP Board (Hindi & English medium) ke liye Classes 5th–12th ke alag-alag batches chalte hain. Exact fees ke liye /fee-calculator dekhein."
        : "Yuitor Smart Classes runs dedicated batches for CBSE, ICSE, and UP Board across Classes 5th–12th in Muradnagar. Check /fee-calculator or apply on /admission.",
      escalate: false,
    };
  }
  if (/\b(refund|certificate|receipt|invoice)\b/i.test(q)) {
    return {
      reply:
        "Yuitor provides a 100% fee refund within 7 days subject to published terms (/refund). Verified payments generate downloadable YTR-RCP receipts, and 100% course completion unlocks YTR-CERT certificates in your Student Portal.",
      escalate: false,
    };
  }
  if (/\b(address|location|where|muradnagar|kahan|center|centre)\b/i.test(q)) {
    return {
      reply:
        "Yuitor Smart Classes is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh. Call/WhatsApp: +91 78-2728-9292.",
      escalate: false,
    };
  }
  if (/\b(contact|phone|number|whatsapp|email|call)\b/i.test(q)) {
    return {
      reply:
        "Call/WhatsApp: +91 78-2728-9292 · Branch: +91 1232314337 · Admission: admission@yuitor.com · Inquiry: inquiry@yuitor.com.",
      escalate: false,
    };
  }
  if (/\b(pending|approval|verify|verification)\b/i.test(q)) {
    return {
      reply:
        "After mobile OTP verification, your account stays in Pending Yuitor Team Approval until reviewed by an administrator. You can call +91 78-2728-9292 for urgent verification.",
      escalate: false,
    };
  }

  // FAQ DB fuzzy keyword check
  const faqs = db.prepare("SELECT question, answer FROM faqs WHERE is_active = 1").all() as Array<{ question: string; answer: string }>;
  const words = q.split(/\W+/).filter((w) => w.length >= 4);
  if (words.length > 0) {
    let bestFaq: { answer: string; score: number } | null = null;
    for (const f of faqs) {
      const hay = `${f.question} ${f.answer}`.toLowerCase();
      const score = words.reduce((acc, w) => acc + (hay.includes(w) ? 1 : 0), 0);
      if (score >= 2 && (!bestFaq || score > bestFaq.score)) {
        bestFaq = { answer: f.answer, score };
      }
    }
    if (bestFaq) {
      return { reply: bestFaq.answer, escalate: false };
    }
  }

  // Context follow-up if previous message asked which class/course
  const prevAssistant = [...history].reverse().find((h) => h.sender === "assistant")?.message || "";
  if (prevAssistant.includes("Which class or course") && q.length <= 40) {
    return {
      reply: `Thanks! You can view exact fees on /fee-calculator or submit an enquiry on /admission, or call +91 78-2728-9292 for ${userMsg} batch timings.`,
      escalate: false,
    };
  }

  return {
    reply: isHindi
      ? "Main aapki madad Yuitor Smart Classes ke courses, fees, admission, portal login aur Class 6–12 study doubts mein kar sakti hoon. Kya aap kisi specific class ya topic ke baare mein poochna chahte hain?"
      : "I can help with Yuitor Smart Classes courses, fees, Muradnagar admissions, portal support, and Class 6–12 Math/Science study doubts. Which class, course, or topic would you like help with?",
    escalate: history.length > 6,
  };
}

export async function generateShreyaReply(
  db: DatabaseSync,
  conversationId: string,
  userMessage: string
): Promise<{ reply: string; escalate: boolean }> {
  const safeQuestion = redactSensitiveText(cleanText(userMessage, 500));
  const history = db
    .prepare("SELECT sender, message FROM chatbot_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 10")
    .all(conversationId) as Array<{ sender: string; message: string }>;
  history.reverse();

  // Instant response for dynamic calculations & exact institutional fee queries without network latency
  const quickMatch = ruleBasedFallback(safeQuestion, history, db);
  const isSpecificQuery =
    tryDynamicAcademicSolver(safeQuestion, false) !== null ||
    /^(hi|hello|hey|namaste|hlo)[!.\s]*$/i.test(safeQuestion.trim());
  if (isSpecificQuery) {
    return quickMatch;
  }

  const apiKey = (process.env.GEMINI_API_KEY || "").trim();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return quickMatch;
  }

  try {
    const modelName = (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash";
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const knowledge = buildKnowledgeContext(db);
    const systemInstruction = `You are Shreya, Yuitor Smart Classes' Smart AI Assistant.
Exact intro if asked who you are: "${SHREYA_INTRO}"

STRICT RULES:
1. Understand Hindi, English, and Hinglish (including minor spelling mistakes/typos); reply naturally in the same language as the visitor.
2. Give short, clear, direct answers (1-3 sentences max). Answer ONLY what the visitor asks without fluff.
3. Maintain conversation context from prior messages and avoid repeating what was already answered.
4. Ask at most ONE relevant follow-up question when clarification is needed.
5. NEVER invent courses, fees, discounts, batch dates, or policies not listed in OFFICIAL DATA below.
6. Never ask for or repeat passwords or OTPs.
7. If asked about teacher registration, clearly explain that submitting a valid PDF/DOC/DOCX resume during /teacher/register.php and passing academic review is mandatory before Teacher Dashboard access.
8. You can solve Class 5–12 academic doubts (Math, Physics, Chemistry, Biology, English, Computer/Python) directly and accurately.
9. If the visitor has an unresolved complaint or asks to talk to staff, politely transfer to the Yuitor Team (+91 78-2728-9292 / inquiry@yuitor.com) and end your message with [ESCALATE].

${knowledge}`;

    const transcript = history
      .map((m) => `${m.sender === "user" ? "Visitor" : "Shreya"}: ${m.message}`)
      .join("\n");

    const genConfig: Record<string, any> = { systemInstruction };
    if (!modelName.includes("2.0")) {
      genConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
    }

    const response = await Promise.race([
      ai.models.generateContent({
        model: modelName,
        contents: transcript ? `${transcript}\nVisitor: ${safeQuestion}` : `Visitor: ${safeQuestion}`,
        config: genConfig,
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Gemini response timeout")), 6500)
      ),
    ]);

    let raw = (response.text || "").trim();
    if (!raw) return quickMatch;

    const escalate = raw.includes("[ESCALATE]");
    raw = raw.replace(/\[ESCALATE\]/g, "").trim();
    return { reply: raw, escalate };
  } catch (err) {
    console.warn("[Shreya AI] Gemini fallback triggered:", (err as Error)?.message || err);
    return quickMatch;
  }
}

export async function testGeminiConnection(): Promise<{ ok: true; message: string } | { ok: false; error: string }> {
  const apiKey = (process.env.GEMINI_API_KEY || "").trim();
  const modelName = (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash";
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return { ok: false, error: "Save a valid GEMINI_API_KEY first before testing." };
  }
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await Promise.race([
      ai.models.generateContent({
        model: modelName,
        contents: "Reply with exactly: OK",
      }),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error("Gemini test timed out")), 8000)),
    ]);
    const txt = (response.text || "").trim();
    if (!txt) {
      return { ok: false, error: "Gemini API returned an empty response." };
    }
    return { ok: true, message: `Gemini API connected cleanly (${modelName}): "${txt.slice(0, 80)}"` };
  } catch (err: any) {
    return { ok: false, error: err?.message || "Gemini API connection failed." };
  }
}

export function sanitizeChatTextForStorage(text: string): string {
  return redactSensitiveText(cleanText(text, 2000));
}

export function saveChatTurn(
  db: DatabaseSync,
  conversationId: string,
  visitorMsg: string,
  assistantMsg: string,
  escalated: boolean
): void {
  const safeUser = sanitizeChatTextForStorage(visitorMsg);
  const safeBot = sanitizeChatTextForStorage(assistantMsg);
  const now = nowIso();
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'user', ?, ?)").run(
    conversationId,
    safeUser,
    now
  );
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
    conversationId,
    safeBot,
    now
  );
  db.prepare(
    `UPDATE chatbot_conversations
     SET last_message = ?, status = CASE WHEN ? = 1 THEN 'escalated' ELSE status END, updated_at = ?
     WHERE id = ?`
  ).run(safeUser.slice(0, 240), escalated ? 1 : 0, now, conversationId);
}
