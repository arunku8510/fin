import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { SETTING_DEFINITIONS, getAdminSettingsView, updateAdminSettings } from "./settings.js";
import { buildFast2SmsPayload } from "./mailer.js";
import { verifyRazorpaySignature, verifyRazorpayWebhookSignature } from "./routes/payments.js";

function createTestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec(`
    CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT);
    INSERT INTO users (id, role) VALUES (1, 'super_admin');
    CREATE TABLE system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      is_secret INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT '',
      updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
    );
  `);
  return db;
}

test("SETTING_DEFINITIONS includes all required secret and integration keys", () => {
  const keys = new Set(SETTING_DEFINITIONS.map((d) => d.key));
  for (const required of [
    "APP_URL",
    "SESSION_SECRET",
    "YU_ADMIN_SETUP_KEY",
    "GEMINI_API_KEY",
    "GEMINI_MODEL",
    "SMTP_HOST",
    "SMTP_PORT",
    "SMTP_SECURE",
    "SMTP_USER",
    "SMTP_PASS",
    "MAIL_FROM_NAME",
    "MAIL_FROM_EMAIL",
    "REPLY_TO_EMAIL",
    "ADMIN_NOTIFY_EMAIL",
    "FAST2SMS_API_KEY",
    "FAST2SMS_ROUTE",
    "FAST2SMS_SENDER_ID",
    "FAST2SMS_DLT_TEMPLATE_ID",
    "RAZORPAY_KEY_ID",
    "RAZORPAY_KEY_SECRET",
    "RAZORPAY_WEBHOOK_SECRET",
  ]) {
    assert.ok(keys.has(required), `Missing setting definition: ${required}`);
  }
});

test("updateAdminSettings stores secrets securely, masks output, preserves blank secrets, and clears overrides", () => {
  const db = createTestDb();
  const res1 = updateAdminSettings(
    db,
    {
      APP_URL: "https://yuitor.com/",
      SESSION_SECRET: "a1b2c3d4e5f60718293a4b5c6d7e8f90",
      GEMINI_API_KEY: "AIzaSyTestSecretKey123456",
      GEMINI_MODEL: "gemini-2.5-flash",
      FAST2SMS_API_KEY: "fast2sms-secret-998877",
      FAST2SMS_ROUTE: "DLT",
      FAST2SMS_SENDER_ID: "YUITOR",
      RAZORPAY_KEY_ID: "rzp_test_12345",
      RAZORPAY_KEY_SECRET: "rzp_secret_987654",
      RAZORPAY_WEBHOOK_SECRET: "whsec_abcdef123456",
    },
    [],
    1
  );

  assert.ok(res1.sessionSecretRotated);
  assert.equal(res1.updatedKeys.length, 10);
  assert.equal(process.env.APP_URL, "https://yuitor.com");
  assert.equal(process.env.FAST2SMS_ROUTE, "dlt");

  const view = getAdminSettingsView(db);
  const geminiItem = view.settings.find((s) => s.key === "GEMINI_API_KEY")!;
  assert.equal(geminiItem.value, ""); // Never leaked back to frontend
  assert.ok(geminiItem.maskedValue.startsWith("AI") && geminiItem.maskedValue.endsWith("3456"));
  assert.equal(geminiItem.source, "admin");
  assert.equal(view.readiness.geminiAi, true);
  assert.equal(view.readiness.razorpay, true);
  assert.equal(view.readiness.razorpayWebhook, true);

  // Submitting blank secret preserves existing saved secret
  updateAdminSettings(db, { GEMINI_API_KEY: "", APP_URL: "https://yuitor.com" }, [], 1);
  assert.equal(process.env.GEMINI_API_KEY, "AIzaSyTestSecretKey123456");

  // Explicit clear removes Admin override
  const cleared = updateAdminSettings(db, {}, ["RAZORPAY_WEBHOOK_SECRET"], 1);
  assert.deepEqual(cleared.clearedKeys, ["RAZORPAY_WEBHOOK_SECRET"]);
  assert.equal(getAdminSettingsView(db).readiness.razorpayWebhook, false);
});

test("updateAdminSettings rejects invalid URLs, short SESSION_SECRET, invalid port, and invalid route", () => {
  const db = createTestDb();
  assert.throws(() => updateAdminSettings(db, { APP_URL: "not-a-url" }, [], 1), /APP_URL/);
  assert.throws(() => updateAdminSettings(db, { SESSION_SECRET: "short" }, [], 1), /SESSION_SECRET/);
  assert.throws(() => updateAdminSettings(db, { SMTP_PORT: "99999" }, [], 1), /SMTP_PORT/);
  assert.throws(() => updateAdminSettings(db, { FAST2SMS_ROUTE: "invalid" }, [], 1), /FAST2SMS_ROUTE/);
});

test("buildFast2SmsPayload adapts to q, otp, and dlt routes", () => {
  process.env.FAST2SMS_ROUTE = "q";
  const qPayload = buildFast2SmsPayload("9876543210", "654321", "Registration");
  assert.equal(qPayload.route, "q");
  assert.equal(qPayload.numbers, "9876543210");

  process.env.FAST2SMS_ROUTE = "dlt";
  process.env.FAST2SMS_SENDER_ID = "YUITOR";
  process.env.FAST2SMS_DLT_TEMPLATE_ID = "170710001";
  const dltPayload = buildFast2SmsPayload("9876543210", "654321", "Registration");
  assert.equal(dltPayload.route, "dlt");
  assert.equal(dltPayload.sender_id, "YUITOR");
  assert.equal(dltPayload.message, "170710001");
  assert.equal(dltPayload.variables_values, "654321");
});

test("Razorpay checkout and webhook HMAC signature helpers verify accurately", () => {
  const secret = "test_rzp_secret_123";
  const orderId = "order_ABC123";
  const paymentId = "pay_XYZ789";
  const validSig = crypto.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  assert.equal(verifyRazorpaySignature(orderId, paymentId, validSig, secret), true);
  assert.equal(verifyRazorpaySignature(orderId, paymentId, "deadbeef", secret), false);

  const whSecret = "whsec_test_999";
  const body = JSON.stringify({ event: "payment.captured" });
  const whSig = crypto.createHmac("sha256", whSecret).update(body).digest("hex");
  assert.equal(verifyRazorpayWebhookSignature(body, whSig, whSecret), true);
  assert.equal(verifyRazorpayWebhookSignature(body, "wrong", whSecret), false);
});
