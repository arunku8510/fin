import nodemailer from "nodemailer";
import path from "node:path";
import fs from "node:fs";
import type { DatabaseSync } from "node:sqlite";
import { UPLOADS_DIR } from "./db.js";
import { nowIso, normalizeEmail } from "./security.js";

export const getSenderName = () => (process.env.MAIL_FROM_NAME || "").trim() || "Yuitor Smart Classes";
export const getSenderEmail = () => (process.env.MAIL_FROM_EMAIL || "").trim() || "info@yuitor.com";
export const getReplyToEmail = () => (process.env.REPLY_TO_EMAIL || "").trim() || "inquiry@yuitor.com";
export const getAdminNotifyEmail = () => (process.env.ADMIN_NOTIFY_EMAIL || "").trim() || "admission@yuitor.com";

export const SENDER_NAME = getSenderName();
export const SENDER_EMAIL = getSenderEmail();
export const REPLY_TO_EMAIL = getReplyToEmail();
export const ADMIN_NOTIFY_EMAIL = getAdminNotifyEmail();

export function isSmtpConfigured(): boolean {
  const host = (process.env.SMTP_HOST || "").trim();
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return Boolean(host && host !== "smtp.example.com" && user && pass && !pass.startsWith("replace-with"));
}

function getTransporter() {
  const host = (process.env.SMTP_HOST || "").trim();
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || "").toLowerCase() === "true" || port === 465;
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 15000,
  });
}

function escapeHtml(v: string): string {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] || c));
}

export function renderBrandedEmailHtml(opts: {
  subject: string;
  previewText?: string;
  htmlBody: string;
  recipientName: string;
  ctaLabel?: string;
  ctaUrl?: string;
  unsubscribeUrl?: string;
}): string {
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const personalized = opts.htmlBody.replace(/\{\{\s*name\s*\}\}/gi, escapeHtml(opts.recipientName || "Student"));
  const ctaBlock =
    opts.ctaLabel && opts.ctaUrl
      ? `<p style="margin:24px 0;"><a href="${escapeHtml(opts.ctaUrl)}" style="display:inline-block;background:#1677ff;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:10px;">${escapeHtml(opts.ctaLabel)}</a></p>`
      : "";
  const unsubBlock = opts.unsubscribeUrl
    ? `<p style="margin-top:16px;font-size:12px;color:#64748b;">Prefer not to receive promotional updates? <a href="${escapeHtml(opts.unsubscribeUrl)}" style="color:#0f54c4;">Manage email preferences / Unsubscribe</a></p>`
    : "";

  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(opts.subject)}</title></head>
<body style="margin:0;padding:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
  ${opts.previewText ? `<div style="display:none;max-height:0;overflow:hidden;">${escapeHtml(opts.previewText)}</div>` : ""}
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;">
        <tr><td style="background:#0f172a;padding:20px 24px;color:#ffffff;">
          <table role="presentation" width="100%"><tr>
            <td><strong style="font-size:18px;letter-spacing:-0.01em;">Yuitor Smart Classes</strong><div style="font-size:12px;color:#78d3d3;margin-top:2px;">Muradnagar, Ghaziabad · Classes 6th–12th, JEE, NEET &amp; Skills</div></td>
            <td align="right"><img src="${siteUrl}/yuitor-icon-192.png" alt="Yuitor Smart Classes" width="40" height="40" style="border-radius:8px;display:block;"></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:26px 24px;font-size:15px;line-height:1.65;">
          ${personalized}
          ${ctaBlock}
          <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
            <strong>Yuitor Smart Classes</strong><br>
            Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh<br>
            Call / WhatsApp: <a href="tel:+917827289292" style="color:#0f54c4;">+91 78-2728-9292</a> · Branch: +91 1232314337 · <a href="${siteUrl}/admission" style="color:#0f54c4;">Apply for Admission</a>
            ${unsubBlock}
          </div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

export async function sendEmailDirect(opts: {
  to: string;
  subject: string;
  html: string;
  text?: string;
  attachmentUrl?: string;
}): Promise<{ ok: true; messageId: string } | { ok: false; error: string }> {
  if (!isSmtpConfigured()) {
    return { ok: false, error: "SMTP credentials (SMTP_HOST, SMTP_USER, SMTP_PASS) are not configured on the server." };
  }
  try {
    const transporter = getTransporter();
    const attachments: Array<{ filename: string; path: string }> = [];
    if (opts.attachmentUrl && opts.attachmentUrl.startsWith("/uploads/")) {
      const safeName = path.basename(opts.attachmentUrl);
      const fullPath = path.join(UPLOADS_DIR, safeName);
      if (fs.existsSync(fullPath)) {
        attachments.push({ filename: safeName, path: fullPath });
      }
    }
    const info = await transporter.sendMail({
      from: `"${getSenderName()}" <${getSenderEmail()}>`,
      replyTo: getReplyToEmail(),
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text || opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
      attachments,
    });
    return { ok: true, messageId: info.messageId || "sent" };
  } catch (err: any) {
    return { ok: false, error: err?.message || "SMTP delivery failed." };
  }
}

export async function testSmtpConnection(testRecipient?: string): Promise<{ ok: true; message: string } | { ok: false; error: string }> {
  if (!isSmtpConfigured()) {
    return { ok: false, error: "SMTP_HOST, SMTP_USER, and SMTP_PASS must be configured before testing SMTP." };
  }
  try {
    const transporter = getTransporter();
    await transporter.verify();
    if (testRecipient && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(testRecipient.trim())) {
      const info = await transporter.sendMail({
        from: `"${getSenderName()}" <${getSenderEmail()}>`,
        replyTo: getReplyToEmail(),
        to: testRecipient.trim(),
        subject: "Yuitor Smart Classes — SMTP Test Successful",
        html: `<p>Your SMTP configuration for <strong>Yuitor Smart Classes</strong> is verified and working properly.</p>`,
        text: "Your SMTP configuration for Yuitor Smart Classes is verified and working properly.",
      });
      return { ok: true, message: `SMTP verified & test email sent (Message ID: ${info.messageId || "ok"}).` };
    }
    return { ok: true, message: "SMTP connection & authentication verified successfully." };
  } catch (err: any) {
    return { ok: false, error: err?.message || "SMTP verification failed." };
  }
}

export function buildFast2SmsPayload(phone: string, otp: string, purposeLabel: string): Record<string, unknown> {
  const route = ((process.env.FAST2SMS_ROUTE || "q").trim().toLowerCase() || "q") as "q" | "otp" | "dlt";
  const senderId = (process.env.FAST2SMS_SENDER_ID || "").trim();
  const dltTemplateId = (process.env.FAST2SMS_DLT_TEMPLATE_ID || "").trim();

  if (route === "dlt") {
    const payload: Record<string, unknown> = {
      route: "dlt",
      message: dltTemplateId || `Your Yuitor Smart Classes ${purposeLabel} OTP is ${otp}. Valid for 10 minutes. Do not share it with anyone.`,
      variables_values: otp,
      flash: 0,
      numbers: phone,
    };
    if (senderId) payload.sender_id = senderId;
    return payload;
  }

  if (route === "otp") {
    return {
      route: "otp",
      variables_values: otp,
      flash: 0,
      numbers: phone,
    };
  }

  return {
    route: "q",
    message: `Your Yuitor Smart Classes ${purposeLabel} OTP is ${otp}. Valid for 10 minutes. Do not share it with anyone.`,
    language: "english",
    flash: 0,
    numbers: phone,
  };
}

export async function dispatchSmsOtp(phone: string, otp: string, purposeLabel: string): Promise<{ sent: boolean; note: string }> {
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return {
      sent: false,
      note: `SMS gateway (FAST2SMS_API_KEY) is not configured in this environment. Server generated a secure time-limited OTP for verification testing (${purposeLabel} OTP: ${otp}). Configure FAST2SMS_API_KEY for live SMS delivery.`,
    };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/bulkV2", {
      method: "POST",
      headers: {
        authorization: fast2smsKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(buildFast2SmsPayload(phone, otp, purposeLabel)),
    });
    const data = (await resp.json()) as any;
    if (resp.ok && data?.return === true) {
      return { sent: true, note: "OTP sent to your registered mobile number." };
    }
    return {
      sent: false,
      note: `SMS provider rejected delivery (${data?.message || resp.status}). Check FAST2SMS_API_KEY configuration.`,
    };
  } catch (err: any) {
    return {
      sent: false,
      note: `SMS gateway connection error: ${err?.message || "network error"}.`,
    };
  }
}

export async function testFast2SmsConnection(
  testPhone?: string
): Promise<{ ok: true; message: string } | { ok: false; error: string }> {
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return { ok: false, error: "Save a valid FAST2SMS_API_KEY first before testing Fast2SMS." };
  }
  const cleanPhone = String(testPhone || "").replace(/\D+/g, "").slice(-10);
  if (cleanPhone && /^[6-9]\d{9}$/.test(cleanPhone)) {
    const result = await dispatchSmsOtp(cleanPhone, "123456", "Admin Test");
    if (!result.sent) {
      return { ok: false, error: result.note };
    }
    return { ok: true, message: `Test SMS OTP dispatched to ${cleanPhone} via Fast2SMS (${(process.env.FAST2SMS_ROUTE || "q").trim()} route).` };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/wallet", {
      method: "POST",
      headers: { authorization: fast2smsKey },
    });
    const data = (await resp.json()) as any;
    if (resp.ok && data?.return === true) {
      const bal = data?.wallet !== undefined ? ` (Wallet balance: ₹${data.wallet})` : "";
      return { ok: true, message: `Fast2SMS API key verified successfully${bal}.` };
    }
    return { ok: false, error: data?.message || `Fast2SMS returned status ${resp.status}.` };
  } catch (err: any) {
    return { ok: false, error: err?.message || "Unable to reach Fast2SMS API." };
  }
}

export interface CampaignFilters {
  audienceGroup?: "all_students" | "all_teachers" | "all_opted_in" | "recently_registered";
  accountStatus?: "all" | "approved" | "pending_approval";
  classLevel?: string;
  subject?: string;
  courseId?: number;
  registeredAfter?: string;
  selectedUserIds?: number[];
}

export function resolveCampaignRecipients(
  db: DatabaseSync,
  filters: CampaignFilters
): {
  eligible: Array<{ id: number; full_name: string; email: string; role: string; unsubscribe_token: string }>;
  excludedCount: number;
} {
  const suppressedSet = new Set(
    (db.prepare("SELECT email FROM email_suppressions").all() as Array<{ email: string }>).map((r) => normalizeEmail(r.email))
  );

  let users: any[] = [];
  if (Array.isArray(filters.selectedUserIds) && filters.selectedUserIds.length > 0) {
    const ids = filters.selectedUserIds.map(Number).filter((n) => Number.isInteger(n) && n > 0);
    if (ids.length > 0) {
      const ph = ids.map(() => "?").join(",");
      users = db
        .prepare(
          `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                  tp.subjects_json as teacher_subjects
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
           WHERE u.id IN (${ph}) AND u.role IN ('student', 'teacher')`
        )
        .all(...ids) as any[];
    }
  } else {
    users = db
      .prepare(
        `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                tp.subjects_json as teacher_subjects
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role IN ('student', 'teacher')`
      )
      .all() as any[];
  }

  let enrolledUserIds: Set<number> | null = null;
  if (filters.courseId && Number(filters.courseId) > 0) {
    const rows = db
      .prepare("SELECT student_id FROM enrollments WHERE course_id = ? AND status IN ('active', 'completed')")
      .all(Number(filters.courseId)) as Array<{ student_id: number }>;
    const courseTeacher = db.prepare("SELECT teacher_id FROM courses WHERE id = ?").get(Number(filters.courseId)) as
      | { teacher_id: number | null }
      | undefined;
    enrolledUserIds = new Set(rows.map((r) => Number(r.student_id)));
    if (courseTeacher?.teacher_id) enrolledUserIds.add(Number(courseTeacher.teacher_id));
  }

  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400 * 1000).toISOString();
  const eligible: Array<{ id: number; full_name: string; email: string; role: string; unsubscribe_token: string }> = [];
  let excludedCount = 0;

  for (const u of users) {
    if (!filters.selectedUserIds?.length) {
      if (filters.audienceGroup === "all_students" && u.role !== "student") continue;
      if (filters.audienceGroup === "all_teachers" && u.role !== "teacher") continue;
      if (filters.audienceGroup === "recently_registered" && (u.role !== "student" || u.created_at < thirtyDaysAgo)) continue;
      if (filters.accountStatus === "approved" && u.verification_status !== "approved") continue;
      if (filters.accountStatus === "pending_approval" && u.verification_status !== "pending_approval") continue;
      if (filters.classLevel && u.role === "student" && !String(u.class_level || "").toLowerCase().includes(filters.classLevel.toLowerCase())) {
        continue;
      }
      if (filters.subject) {
        const subBlob = `${u.student_subjects || ""} ${u.teacher_subjects || ""}`.toLowerCase();
        if (!subBlob.includes(filters.subject.toLowerCase())) continue;
      }
      if (enrolledUserIds && !enrolledUserIds.has(Number(u.id))) continue;
      if (filters.registeredAfter && u.created_at < filters.registeredAfter) continue;
    }

    const email = normalizeEmail(u.email);
    const isSuppressed = suppressedSet.has(email) || Number(u.marketing_opt_in) !== 1 || Number(u.is_active) !== 1;
    if (isSuppressed) {
      excludedCount++;
      continue;
    }
    eligible.push({
      id: Number(u.id),
      full_name: u.full_name,
      email,
      role: u.role,
      unsubscribe_token: u.unsubscribe_token,
    });
  }

  return { eligible, excludedCount };
}

export async function processCampaignQueue(db: DatabaseSync, campaignId: number, batchSize = 25): Promise<{ sent: number; failed: number }> {
  const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(campaignId) as any;
  if (!camp || ["paused", "cancelled", "draft"].includes(camp.status)) {
    return { sent: 0, failed: 0 };
  }

  db.prepare("UPDATE email_campaigns SET status = 'sending', updated_at = ? WHERE id = ?").run(nowIso(), campaignId);
  const pendingRows = db
    .prepare(
      `SELECT d.*, u.unsubscribe_token
       FROM email_deliveries d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.campaign_id = ? AND (d.status = 'pending' OR (d.status = 'failed' AND d.retry_count < 2))
       ORDER BY d.id ASC LIMIT ?`
    )
    .all(campaignId, batchSize) as any[];

  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  let sent = 0;
  let failed = 0;

  for (const row of pendingRows) {
    // Re-check campaign status for mid-flight pause/cancel
    const latest = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId) as { status: string } | undefined;
    if (!latest || latest.status === "paused" || latest.status === "cancelled") break;

    const unsubUrl = row.unsubscribe_token ? `${siteUrl}/unsubscribe/${row.unsubscribe_token}` : undefined;
    const html = renderBrandedEmailHtml({
      subject: camp.subject,
      previewText: camp.preview_text,
      htmlBody: camp.html_body,
      recipientName: row.recipient_name,
      ctaLabel: camp.cta_label,
      ctaUrl: camp.cta_url,
      unsubscribeUrl: unsubUrl,
    });

    const result = await sendEmailDirect({
      to: row.recipient_email,
      subject: camp.subject,
      html,
      attachmentUrl: camp.attachment_url,
    });

    if (result.ok) {
      db.prepare(
        "UPDATE email_deliveries SET status = 'sent', provider_message_id = ?, error_message = '', sent_at = ? WHERE id = ?"
      ).run(result.messageId, nowIso(), row.id);
      sent++;
    } else {
      db.prepare(
        "UPDATE email_deliveries SET status = 'failed', error_message = ?, retry_count = retry_count + 1 WHERE id = ?"
      ).run(result.error, row.id);
      failed++;
    }
    // Gentle spacing for SMTP rate limits
    await new Promise((r) => setTimeout(r, 40));
  }

  const counts = db
    .prepare(
      `SELECT
         SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent_c,
         SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_c,
         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_c
       FROM email_deliveries WHERE campaign_id = ?`
    )
    .get(campaignId) as any;

  const currentCamp = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId) as any;
  let nextStatus = currentCamp?.status || "completed";
  if (nextStatus !== "paused" && nextStatus !== "cancelled") {
    nextStatus = Number(counts?.pending_c || 0) > 0 ? "queued" : Number(counts?.sent_c || 0) > 0 ? "completed" : "failed";
  }

  db.prepare(
    "UPDATE email_campaigns SET status = ?, sent_count = ?, failed_count = ?, updated_at = ? WHERE id = ?"
  ).run(nextStatus, Number(counts?.sent_c || 0), Number(counts?.failed_c || 0), nowIso(), campaignId);

  return { sent, failed };
}

export function startEmailScheduler(db: DatabaseSync): void {
  setInterval(() => {
    try {
      const now = nowIso();
      const due = db
        .prepare(
          `SELECT id FROM email_campaigns
           WHERE (status = 'queued' AND (scheduled_at IS NULL OR scheduled_at <= ?))
              OR (send_mode = 'scheduled' AND status = 'queued' AND scheduled_at <= ?)`
        )
        .all(now, now) as Array<{ id: number }>;
      for (const c of due) {
        void processCampaignQueue(db, c.id, 20);
      }
    } catch (err) {
      console.warn("[Yuitor Mailer] Scheduler error:", err);
    }
  }, 30000);
}
