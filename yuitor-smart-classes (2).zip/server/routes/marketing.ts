import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, clientIp, getSessionContext, isValidEmail, normalizeEmail, nowIso, writeAuditLog } from "../security.js";
import {
  getReplyToEmail,
  getSenderEmail,
  isSmtpConfigured,
  processCampaignQueue,
  renderBrandedEmailHtml,
  resolveCampaignRecipients,
  sendEmailDirect,
} from "../mailer.js";

export function createMarketingRouter(db: DatabaseSync): Router {
  const router = Router();

  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    (req as any).ctx = ctx;
    next();
  });

  router.get("/overview", (_req, res) => {
    const campaigns = db.prepare("SELECT * FROM email_campaigns ORDER BY id DESC").all() as any[];
    const totalCampaigns = campaigns.length;
    const totalEligible = campaigns.reduce((acc, c) => acc + Number(c.total_recipients || 0), 0);
    const totalSent = campaigns.reduce((acc, c) => acc + Number(c.sent_count || 0), 0);
    const totalFailed = campaigns.reduce((acc, c) => acc + Number(c.failed_count || 0), 0);

    const templates = db.prepare("SELECT * FROM email_templates ORDER BY id ASC").all();
    const courses = db.prepare("SELECT id, title FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const students = db
      .prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'student' ORDER BY full_name")
      .all();
    const teachers = db
      .prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'teacher' ORDER BY full_name")
      .all();
    const suppressions = db.prepare("SELECT * FROM email_suppressions ORDER BY id DESC LIMIT 100").all();

    res.json({
      summary: {
        totalCampaigns,
        totalEligible,
        totalSent,
        totalFailed,
        openClickTrackingNote: "Opens/clicks reported only when webhook/pixel tracking is enabled on your SMTP provider.",
      },
      senderEmail: getSenderEmail(),
      replyToEmail: getReplyToEmail(),
      smtpConfigured: isSmtpConfigured(),
      templates,
      courses,
      students,
      teachers,
      campaigns,
      suppressions,
    });
  });

  router.post("/preview-recipients", (req, res) => {
    const filters = req.body?.filters || {};
    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    res.json({
      eligibleCount: eligible.length,
      excludedCount,
    });
  });

  router.post("/campaigns", async (req, res) => {
    const ctx = (req as any).ctx;
    const name = cleanText(req.body?.name, 160);
    const subject = cleanText(req.body?.subject, 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "").trim();
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);
    const attachmentUrl = cleanText(req.body?.attachmentUrl, 300);
    const sendMode = ["draft", "immediate", "scheduled"].includes(req.body?.sendMode) ? req.body.sendMode : "draft";
    const scheduledAt = req.body?.scheduledAt ? cleanText(req.body.scheduledAt, 40) : null;
    const templateId = req.body?.templateId ? Number(req.body.templateId) : null;
    const filters = req.body?.filters || {};

    if (!name || !subject || !htmlBody) {
      res.status(400).json({ error: "Campaign name, email subject, and HTML body are required." });
      return;
    }

    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    const initialStatus = sendMode === "draft" ? "draft" : "queued";
    const now = nowIso();

    const ins = db
      .prepare(
        `INSERT INTO email_campaigns
         (name, template_id, subject, preview_text, html_body, cta_label, cta_url, attachment_url,
          filters_json, send_mode, scheduled_at, status, total_recipients, excluded_count, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        name,
        templateId,
        subject,
        previewText,
        htmlBody,
        ctaLabel,
        ctaUrl,
        attachmentUrl,
        JSON.stringify(filters),
        sendMode,
        scheduledAt,
        initialStatus,
        eligible.length,
        excludedCount,
        ctx.user.id,
        now,
        now
      );

    const campaignId = Number(ins.lastInsertRowid);
    const insDelivery = db.prepare(
      `INSERT OR IGNORE INTO email_deliveries (campaign_id, user_id, recipient_name, recipient_email, status, created_at)
       VALUES (?, ?, ?, ?, 'pending', ?)`
    );
    for (const r of eligible) {
      insDelivery.run(campaignId, r.id, r.full_name, r.email, now);
    }

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: campaignId,
      targetName: name,
      action: "email_campaign_created",
      details: `${sendMode} · ${eligible.length} eligible (${excludedCount} excluded)`,
      ipAddress: clientIp(req),
    });

    if (sendMode === "immediate" && eligible.length > 0) {
      void processCampaignQueue(db, campaignId, 25);
    }

    res.status(201).json({ id: campaignId, eligibleCount: eligible.length, excludedCount });
  });

  router.post("/campaigns/:id/action", async (req, res) => {
    const cid = Number(req.params.id);
    const action = String(req.body?.action || "");
    const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(cid) as any;
    if (!camp) {
      res.status(404).json({ error: "Campaign not found." });
      return;
    }

    if (action === "pause") {
      db.prepare("UPDATE email_campaigns SET status = 'paused', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "paused" });
      return;
    }
    if (action === "cancel") {
      db.prepare("UPDATE email_campaigns SET status = 'cancelled', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "cancelled" });
      return;
    }
    if (action === "resume" || action === "process_now") {
      db.prepare("UPDATE email_campaigns SET status = 'queued', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      const result = await processCampaignQueue(db, cid, 30);
      res.json({ processed: true, ...result });
      return;
    }

    res.status(400).json({ error: "Unsupported campaign action." });
  });

  router.get("/campaigns/:id/deliveries", (req, res) => {
    const deliveries = db
      .prepare("SELECT * FROM email_deliveries WHERE campaign_id = ? ORDER BY id ASC LIMIT 500")
      .all(Number(req.params.id));
    res.json({ deliveries });
  });

  router.post("/test-send", async (req, res) => {
    const to = normalizeEmail(req.body?.to);
    const subject = cleanText(req.body?.subject || "Yuitor Smart Classes Test Email", 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "<p>Test campaign preview from Yuitor Smart Classes.</p>");
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);

    if (!isValidEmail(to)) {
      res.status(400).json({ error: "Enter a valid recipient email address for test delivery." });
      return;
    }

    const html = renderBrandedEmailHtml({
      subject,
      previewText,
      htmlBody,
      recipientName: "Yuitor Team",
      ctaLabel,
      ctaUrl,
    });

    const result = await sendEmailDirect({ to, subject: `[TEST] ${subject}`, html });
    if (!result.ok) {
      res.status(503).json({ error: result.error });
      return;
    }
    res.json({ sent: true, messageId: result.messageId });
  });

  router.post("/suppressions", (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const reason = cleanText(req.body?.reason || "unsubscribed", 60);
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Enter a valid email address." });
      return;
    }
    db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, ?, ?)").run(
      email,
      reason,
      nowIso()
    );
    db.prepare("UPDATE users SET marketing_opt_in = 0, updated_at = ? WHERE email = ?").run(nowIso(), email);
    res.status(201).json({ suppressed: true });
  });

  return router;
}
