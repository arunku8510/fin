import { Router } from "express";
import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, clientIp, getSessionContext, nowIso, writeAuditLog } from "../security.js";

export function verifyRazorpaySignature(
  orderId: string,
  paymentId: string,
  signature: string,
  secret: string
): boolean {
  if (!orderId || !paymentId || !signature || !secret) return false;
  const expectedSig = crypto.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function verifyRazorpayWebhookSignature(
  payloadBody: string,
  signature: string,
  webhookSecret: string
): boolean {
  if (!payloadBody || !signature || !webhookSecret) return false;
  const expectedSig = crypto.createHmac("sha256", webhookSecret).update(payloadBody).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export async function testRazorpayConnection(): Promise<{ ok: true; message: string } | { ok: false; error: string }> {
  const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
  const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keyId || !keySecret) {
    return { ok: false, error: "Save both RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET first before testing." };
  }
  try {
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const resp = await fetch("https://api.razorpay.com/v1/orders?count=1", {
      method: "GET",
      headers: { Authorization: `Basic ${auth}` },
    });
    const data = (await resp.json()) as any;
    if (resp.ok) {
      const mode = keyId.startsWith("rzp_live_") ? "LIVE" : "TEST";
      return { ok: true, message: `Razorpay ${mode} credentials verified successfully.` };
    }
    return { ok: false, error: data?.error?.description || `Razorpay API returned status ${resp.status}.` };
  } catch (err: any) {
    return { ok: false, error: err?.message || "Unable to reach Razorpay API." };
  }
}

export function createPaymentsRouter(db: DatabaseSync): Router {
  const router = Router();

  router.get("/config", (_req, res) => {
    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    const razorpayEnabled = Boolean(keyId && keySecret);
    res.json({
      razorpayEnabled,
      keyId: razorpayEnabled ? keyId : "",
    });
  });

  router.post("/create-order", async (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required." });
      return;
    }

    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    if (!keyId || !keySecret) {
      res.status(503).json({ error: "Razorpay credentials are not configured on the server yet." });
      return;
    }

    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId) as any;
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }

    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;
    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode) as any;
      if (coupon && Number(coupon.used_count) < Number(coupon.max_uses)) {
        discountAmount =
          coupon.discount_type === "percent"
            ? Math.round((baseAmount * Number(coupon.discount_value)) / 100)
            : Math.min(baseAmount, Number(coupon.discount_value));
      }
    }
    const finalAmount = Math.max(1, baseAmount - discountAmount);

    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
      const resp = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: finalAmount * 100,
          currency: "INR",
          receipt: `ytr_${ctx.user.id}_${courseId}_${Date.now()}`.slice(0, 40),
          notes: {
            studentId: String(ctx.user.id),
            courseId: String(courseId),
            plan,
          },
        }),
      });
      const order = (await resp.json()) as any;
      if (!resp.ok || !order?.id) {
        res.status(502).json({ error: order?.error?.description || "Unable to create Razorpay order." });
        return;
      }
      res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId });
    } catch (err: any) {
      res.status(502).json({ error: err?.message || "Razorpay order creation failed." });
    }
  });

  router.post("/webhook", (req, res) => {
    const webhookSecret = (process.env.RAZORPAY_WEBHOOK_SECRET || "").trim();
    const signature = String(req.headers["x-razorpay-signature"] || "");
    if (!webhookSecret) {
      res.status(503).json({ error: "RAZORPAY_WEBHOOK_SECRET is not configured." });
      return;
    }
    const rawBody = typeof (req as any).rawBody === "string" ? (req as any).rawBody : JSON.stringify(req.body || {});
    if (!verifyRazorpayWebhookSignature(rawBody, signature, webhookSecret)) {
      res.status(400).json({ error: "Invalid Razorpay webhook signature." });
      return;
    }

    const event = String(req.body?.event || "");
    const paymentEntity = req.body?.payload?.payment?.entity;
    const orderId = cleanText(paymentEntity?.order_id || "", 100);
    const paymentId = cleanText(paymentEntity?.id || "", 100);
    if ((event === "payment.captured" || event === "order.paid") && orderId) {
      const now = nowIso();
      const row = db
        .prepare("SELECT id, student_id, course_id, enrollment_id, amount, verification_status FROM payments WHERE gateway_order_id = ? ORDER BY id DESC LIMIT 1")
        .get(orderId) as any;
      if (row && row.verification_status !== "verified") {
        const receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
        db.prepare(
          "UPDATE payments SET verification_status = 'verified', gateway_payment_id = COALESCE(NULLIF(?, ''), gateway_payment_id), receipt_number = ?, paid_at = ? WHERE id = ?"
        ).run(paymentId, receiptNumber, now, row.id);
        if (row.enrollment_id) {
          db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(row.enrollment_id);
        }
        db.prepare("UPDATE fee_records SET status = 'paid', paid_amount = ? WHERE student_id = ? AND course_id = ? AND status = 'pending'").run(
          row.amount,
          row.student_id,
          row.course_id
        );
      }
    }
    res.json({ ok: true });
  });

  router.post("/enroll", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required to enroll." });
      return;
    }

    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = cleanText(req.body?.utrReference, 80);
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();

    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId) as any;
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }

    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;

    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode) as any;
      if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses)) {
        res.status(400).json({ error: "Invalid or expired coupon code." });
        return;
      }
      discountAmount =
        coupon.discount_type === "percent"
          ? Math.round((baseAmount * Number(coupon.discount_value)) / 100)
          : Math.min(baseAmount, Number(coupon.discount_value));
      db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(coupon.id);
    }

    const finalAmount = Math.max(0, baseAmount - discountAmount);
    const now = nowIso();
    const months = plan === "yearly" ? 12 : 1;
    const expiresDate = new Date();
    expiresDate.setMonth(expiresDate.getMonth() + months);
    const expiresAt = expiresDate.toISOString().slice(0, 10);

    let verificationStatus: "pending_verification" | "verified" | "failed" = "pending_verification";
    let receiptNumber = "";
    let paidAt: string | null = null;
    let enrollmentStatus: "pending" | "active" = "pending";
    let message = "";
    const gOrder = cleanText(req.body?.gatewayOrderId, 100);
    const gPay = cleanText(req.body?.gatewayPaymentId, 100);
    const gSig = cleanText(req.body?.gatewaySignature, 200);

    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();

      if (rzpSecret && gOrder && gPay && gSig) {
        if (verifyRazorpaySignature(gOrder, gPay, gSig, rzpSecret)) {
          verificationStatus = "verified";
          enrollmentStatus = "active";
          paidAt = now;
          receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
          message = "Gateway signature verified! Your enrollment and fee receipt are now active.";
        } else {
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
      } else {
        // Never mark gateway payment successful without provider verification
        message =
          "Online payment gateway credentials (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) are not configured on this server. Enrollment saved as Pending Verification — submit UTR or pay at the Muradnagar desk.";
      }
    } else {
      message =
        "Enrollment submitted! Your payment is marked Pending Verification until confirmed by the Yuitor Team.";
    }

    db.prepare(
      `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
       VALUES (?, ?, ?, ?, 0, 0, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET plan = excluded.plan, status = excluded.status, expires_at = excluded.expires_at`
    ).run(ctx.user.id, courseId, plan, enrollmentStatus, expiresAt, now);

    const enrollment = db
      .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?")
      .get(ctx.user.id, courseId) as { id: number };

    const invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
    db.prepare(
      `INSERT INTO payments
       (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
        utr_reference, gateway_order_id, gateway_payment_id, gateway_signature, verification_status, invoice_number, receipt_number, paid_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      enrollment.id,
      plan,
      baseAmount,
      discountAmount,
      finalAmount,
      couponCode,
      paymentMethod,
      utrReference,
      gOrder,
      gPay,
      gSig,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      paidAt,
      now
    );

    db.prepare(
      `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      `${course.title} (${plan})`,
      baseAmount,
      discountAmount,
      verificationStatus === "verified" ? finalAmount : 0,
      now.slice(0, 10),
      verificationStatus === "verified" ? "paid" : "pending",
      now
    );

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New Enrollment Payment (${paymentMethod.toUpperCase()})`,
      `${ctx.user.full_name} enrolled in ${course.title} (₹${finalAmount}, ${verificationStatus}).`,
      now
    );

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: courseId,
      targetName: course.title,
      action: "enrollment_submitted",
      details: `${plan} ₹${finalAmount} (${verificationStatus})`,
      ipAddress: clientIp(req),
    });

    res.status(201).json({
      enrolled: true,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      amount: finalAmount,
      message,
    });
  });

  router.post("/refund-request", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const paymentId = Number(req.body?.paymentId);
    const reason = cleanText(req.body?.reason, 500);
    if (reason.length < 5) {
      res.status(400).json({ error: "Provide a refund reason (min 5 characters)." });
      return;
    }

    const pay = db.prepare("SELECT * FROM payments WHERE id = ? AND student_id = ?").get(paymentId, ctx.user.id) as any;
    if (!pay || pay.verification_status !== "verified") {
      res.status(404).json({ error: "Verified payment record not found." });
      return;
    }

    db.prepare("UPDATE payments SET refund_status = 'requested', refund_reason = ? WHERE id = ?").run(reason, paymentId);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run("Refund Request", `${ctx.user.full_name} requested refund for payment #${paymentId}: ${reason}`, nowIso());

    res.json({ requested: true });
  });

  return router;
}
