import { Router } from "express";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import multer from "multer";
import type { DatabaseSync } from "node:sqlite";
import { APP_ROOT, UPLOADS_DIR } from "../db.js";
import {
  checkRateLimit,
  cleanText,
  clientIp,
  getSessionContext,
  isValidEmail,
  isValidPhone,
  nowIso,
  recordRateLimitHit,
  verifyReleaseDownload,
} from "../security.js";
import { getAdminNotifyEmail, isSmtpConfigured, sendEmailDirect } from "../mailer.js";
import { generateShreyaReply, saveChatTurn, SHREYA_INTRO } from "../chatbot.js";

const ALLOWED_EXTENSIONS = new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp"]);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      const safeExt = ALLOWED_EXTENSIONS.has(ext) ? ext : ".bin";
      cb(null, `yu-${Date.now()}-${crypto.randomBytes(6).toString("hex")}${safeExt}`);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      cb(new Error("Only PDF, PNG, JPG, and WebP files up to 5 MB are allowed."));
      return;
    }
    cb(null, true);
  },
});

export function createPublicRouter(db: DatabaseSync): Router {
  const router = Router();

  router.get("/public/bootstrap", (_req, res) => {
    const courses = db.prepare("SELECT * FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const subjects = db.prepare("SELECT * FROM subjects WHERE is_active = 1 ORDER BY id ASC").all();
    const teachers = db
      .prepare(
        `SELECT u.id, u.full_name, u.avatar_url, tp.qualification, tp.experience_years, tp.bio
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.verification_status = 'approved' AND u.is_active = 1
         ORDER BY u.id ASC`
      )
      .all();
    const faqs = db.prepare("SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC, id ASC").all();
    const testimonials = db.prepare("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY id DESC").all();
    const banners = db.prepare("SELECT * FROM banners WHERE is_active = 1 ORDER BY id DESC").all();
    const announcements = db
      .prepare("SELECT * FROM announcements WHERE audience IN ('all', 'public') ORDER BY id DESC LIMIT 10")
      .all();

    res.json({ courses, subjects, teachers, faqs, testimonials, banners, announcements });
  });

  const handleInquirySubmit = (req: any, res: any) => {
    // Quiet honeypot trap
    if (String(req.body?.website || "").trim() !== "" || String(req.body?.website_url || "").trim() !== "") {
      res.status(201).json({ accepted: true, success: true, message: "Thank you. Your enquiry has been received." });
      return;
    }

    const ip = clientIp(req);
    const rl = checkRateLimit(db, `inq:${ip}`, 6, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: "Please wait a few seconds before sending another enquiry." });
      return;
    }

    const name = cleanText(req.body?.name, 120);
    const phone = cleanText(req.body?.phone, 24);
    const email = cleanText(req.body?.email, 254);
    const classOrCourse = cleanText(req.body?.class_or_course || req.body?.course || "General Inquiry", 120);
    const message = cleanText(req.body?.message, 2000);
    const source = cleanText(req.body?.source || "website", 40);

    if (name.length < 2) {
      res.status(400).json({ error: "Please enter your name." });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: "Please enter a valid mobile or phone number." });
      return;
    }
    if (email && !isValidEmail(email)) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }

    recordRateLimitHit(db, `inq:${ip}`, 300);
    const now = nowIso();
    db.prepare(
      `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'new', ?)`
    ).run(name, phone, email, classOrCourse, message, source, now);

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`New Inquiry: ${classOrCourse}`, `${name} (${phone}) submitted an inquiry.`, now);

    const notifyEmail = getAdminNotifyEmail();
    if (isSmtpConfigured() && notifyEmail) {
      void sendEmailDirect({
        to: notifyEmail,
        subject: `New Yuitor Inquiry (${classOrCourse}) — ${name}`,
        html: `<p><strong>Name:</strong> ${name}<br><strong>Phone:</strong> ${phone}<br><strong>Email:</strong> ${email || "N/A"}<br><strong>Course:</strong> ${classOrCourse}<br><strong>Message:</strong> ${message || "N/A"}</p>`,
      });
    }

    res.status(201).json({
      accepted: true,
      success: true,
      message: "Thank you! Your enquiry has been saved. Our Muradnagar team will contact you shortly.",
    });
  };

  router.post("/public/inquiries", handleInquirySubmit);
  router.post("/inquiries", handleInquirySubmit);

  router.get("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const user = db.prepare("SELECT email, marketing_opt_in FROM users WHERE unsubscribe_token = ?").get(token) as
      | { email: string; marketing_opt_in: number }
      | undefined;
    if (!user) {
      res.status(404).json({ error: "Invalid or expired unsubscribe token." });
      return;
    }
    res.json({
      email: user.email,
      reason: user.marketing_opt_in ? "Subscribed to Yuitor updates" : "Unsubscribed from marketing emails",
    });
  });

  router.post("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const optIn = Boolean(req.body?.marketingOptIn);
    const user = db.prepare("SELECT id, email FROM users WHERE unsubscribe_token = ?").get(token) as
      | { id: number; email: string }
      | undefined;
    if (!user) {
      res.status(404).json({ error: "Invalid unsubscribe token." });
      return;
    }
    db.prepare("UPDATE users SET marketing_opt_in = ?, updated_at = ? WHERE id = ?").run(optIn ? 1 : 0, nowIso(), user.id);
    if (optIn) {
      db.prepare("DELETE FROM email_suppressions WHERE email = ?").run(user.email);
    } else {
      db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, 'unsubscribed', ?)").run(
        user.email,
        nowIso()
      );
    }
    res.json({ updated: true, marketingOptIn: optIn });
  });

  // Shreya Chatbot Endpoints
  router.post("/public/chatbot/session", (req, res) => {
    try {
      const existingId = cleanText(req.body?.conversationId, 80);
      const visitorId = cleanText(req.body?.visitorId || `v-${crypto.randomBytes(4).toString("hex")}`, 80);

      if (existingId) {
        const conv = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(existingId);
        if (conv) {
          const messages = db
            .prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC")
            .all(existingId);
          res.json({ conversation: conv, messages });
          return;
        }
      }

      const newId = `chat-${crypto.randomUUID()}`;
      const now = nowIso();
      db.prepare(
        `INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at)
         VALUES (?, ?, 'active', ?, ?, ?)`
      ).run(newId, visitorId, SHREYA_INTRO, now, now);

      db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
        newId,
        SHREYA_INTRO,
        now
      );

      const conv = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(newId);
      const messages = db
        .prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC")
        .all(newId);
      res.json({ conversation: conv, messages });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to initialize chat session." });
    }
  });

  router.post("/public/chatbot/message", async (req, res) => {
    try {
      const ip = clientIp(req);
      const rl = checkRateLimit(db, `chat:${ip}`, 30, 300, 120);
      if (!rl.allowed) {
        res.status(429).json({ error: "Too many messages. Please wait a moment." });
        return;
      }
      recordRateLimitHit(db, `chat:${ip}`, 300);

      let conversationId = cleanText(req.body?.conversationId, 80);
      const message = cleanText(req.body?.message, 500);
      if (!message) {
        res.status(400).json({ error: "Message is required." });
        return;
      }

      const now = nowIso();
      if (!conversationId || !db.prepare("SELECT id FROM chatbot_conversations WHERE id = ?").get(conversationId)) {
        conversationId = `chat-${crypto.randomUUID()}`;
        db.prepare(
          "INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at) VALUES (?, 'visitor', 'active', ?, ?, ?)"
        ).run(conversationId, SHREYA_INTRO, now, now);
        db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
          conversationId,
          SHREYA_INTRO,
          now
        );
      }

      const vName = cleanText(req.body?.visitorName, 120);
      const vPhone = cleanText(req.body?.visitorPhone, 24);
      const vEmail = cleanText(req.body?.visitorEmail, 254);
      if (vName || vPhone || vEmail) {
        db.prepare(
          `UPDATE chatbot_conversations
           SET visitor_name = COALESCE(NULLIF(?, ''), visitor_name),
               visitor_phone = COALESCE(NULLIF(?, ''), visitor_phone),
               visitor_email = COALESCE(NULLIF(?, ''), visitor_email),
               updated_at = ?
           WHERE id = ?`
        ).run(vName, vPhone, vEmail, now, conversationId);
      }

      const { reply, escalate } = await generateShreyaReply(db, conversationId, message);
      saveChatTurn(db, conversationId, message, reply, escalate);

      if (escalate) {
        db.prepare(
          "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
        ).run("Shreya Escalation", `Visitor query requires Yuitor Team follow-up: "${message.slice(0, 120)}"`, now);
      }

      const messages = db
        .prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC")
        .all(conversationId);
      res.json({ conversationId, reply, escalated: escalate, messages });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Chatbot request failed." });
    }
  });

  router.post("/public/chatbot/feedback", (req, res) => {
    const conversationId = cleanText(req.body?.conversationId, 80);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const feedback = cleanText(req.body?.feedback, 500);
    const resolved = Boolean(req.body?.resolved);
    if (!conversationId) {
      res.status(400).json({ error: "Conversation ID required." });
      return;
    }

    const status = resolved ? "resolved" : "unresolved";
    db.prepare(
      "UPDATE chatbot_conversations SET rating = ?, feedback = ?, status = ?, updated_at = ? WHERE id = ?"
    ).run(rating, feedback, status, nowIso(), conversationId);
    res.json({ saved: true });
  });

  // Festival Engine compatibility endpoint
  const formatFestivalConfig = (row: any) => {
    let overrides: Record<string, any> = {};
    try {
      overrides = row?.overrides_json ? JSON.parse(row.overrides_json) : {};
    } catch {
      overrides = {};
    }
    const mode = row?.mode || "automatic";
    const manualFestivalId = row?.manual_festival_id || null;
    const simulatedDateIST = row?.simulated_date_ist || null;
    return {
      mode,
      manualFestivalId,
      simulatedDateIST,
      overrides,
      manual_festival_id: manualFestivalId,
      simulated_date_ist: simulatedDateIST,
      overrides_json: JSON.stringify(overrides),
    };
  };

  router.get("/festival", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get() as any;
    res.json({ config: formatFestivalConfig(row) });
  });
  router.get("/festival.php", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get() as any;
    res.json({ config: formatFestivalConfig(row) });
  });

  // Secure File Upload
  router.post("/uploads", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required to upload files." });
      return;
    }
    upload.single("file")(req, res, (err: any) => {
      if (err) {
        res.status(400).json({ error: err.message || "Upload failed." });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "No file uploaded." });
        return;
      }
      res.status(201).json({ url: `/uploads/${req.file.filename}`, filename: req.file.filename });
    });
  });

  // Time-limited HMAC-signed release ZIP download
  router.get("/download-release", (req, res) => {
    if (!verifyReleaseDownload(req.query.expires, req.query.sig)) {
      res.status(403).json({ error: "Invalid or expired download signature." });
      return;
    }
    const zipPath = path.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    if (!fs.existsSync(zipPath)) {
      res.status(404).json({ error: "Release ZIP archive not found." });
      return;
    }
    res.download(zipPath, "yuitor-smart-classes-final.zip");
  });

  return router;
}
