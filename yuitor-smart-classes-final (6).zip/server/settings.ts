import type { DatabaseSync } from "node:sqlite";
import { cleanText, nowIso } from "./security.js";

export type SettingCategory = "general" | "ai" | "email" | "sms" | "payments";

export interface SettingDefinition {
  key: string;
  category: SettingCategory;
  label: string;
  description: string;
  isSecret: boolean;
  defaultValue: string;
  placeholder: string;
  inputType: "text" | "url" | "email" | "number" | "password" | "boolean";
}

export const SETTING_DEFINITIONS: SettingDefinition[] = [
  {
    key: "APP_URL",
    category: "general",
    label: "Public App URL (APP_URL)",
    description: "Primary live domain URL used in emails, unsubscribe links, and origin checks.",
    isSecret: false,
    defaultValue: "https://yuitor.com",
    placeholder: "https://yuitor.com",
    inputType: "url",
  },
  {
    key: "SESSION_SECRET",
    category: "general",
    label: "Session Signing Secret (SESSION_SECRET)",
    description: "Strong random secret (min 16 chars, recommended 64-char hex) for signing cookies, OTPs, and download links.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter or generate a strong 64-char hex secret",
    inputType: "password",
  },
  {
    key: "YU_ADMIN_SETUP_KEY",
    category: "general",
    label: "First-Admin Setup Key (YU_ADMIN_SETUP_KEY)",
    description: "Optional security key required when creating the first Super Admin on /admin/setup.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Optional secret key for /admin/setup",
    inputType: "password",
  },
  {
    key: "GEMINI_API_KEY",
    category: "ai",
    label: "Google Gemini API Key (GEMINI_API_KEY)",
    description: "Enables live Gemini LLM responses for Shreya Smart AI (deterministic bilingual fallback runs when unset).",
    isSecret: true,
    defaultValue: "",
    placeholder: "AIza...",
    inputType: "password",
  },
  {
    key: "SMTP_HOST",
    category: "email",
    label: "SMTP Host (SMTP_HOST)",
    description: "Outgoing mail server hostname (e.g. smtp.hostinger.com or smtp.gmail.com).",
    isSecret: false,
    defaultValue: "",
    placeholder: "smtp.hostinger.com",
    inputType: "text",
  },
  {
    key: "SMTP_PORT",
    category: "email",
    label: "SMTP Port (SMTP_PORT)",
    description: "SMTP port number (587 for STARTTLS, 465 for SSL/TLS).",
    isSecret: false,
    defaultValue: "587",
    placeholder: "587",
    inputType: "number",
  },
  {
    key: "SMTP_SECURE",
    category: "email",
    label: "Use SSL/TLS (SMTP_SECURE)",
    description: "Enable direct TLS (true for port 465, false for port 587 STARTTLS).",
    isSecret: false,
    defaultValue: "false",
    placeholder: "false",
    inputType: "boolean",
  },
  {
    key: "SMTP_USER",
    category: "email",
    label: "SMTP Username (SMTP_USER)",
    description: "Authenticated email login username.",
    isSecret: false,
    defaultValue: "",
    placeholder: "info@yuitor.com",
    inputType: "text",
  },
  {
    key: "SMTP_PASS",
    category: "email",
    label: "SMTP Password (SMTP_PASS)",
    description: "SMTP mailbox password or app password (stored securely on server).",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter SMTP password or app password",
    inputType: "password",
  },
  {
    key: "MAIL_FROM_NAME",
    category: "email",
    label: "Sender Display Name (MAIL_FROM_NAME)",
    description: "Display name shown in outgoing emails.",
    isSecret: false,
    defaultValue: "Yuitor Smart Classes",
    placeholder: "Yuitor Smart Classes",
    inputType: "text",
  },
  {
    key: "MAIL_FROM_EMAIL",
    category: "email",
    label: "Sender Email (MAIL_FROM_EMAIL)",
    description: "From address for marketing campaigns and system emails.",
    isSecret: false,
    defaultValue: "info@yuitor.com",
    placeholder: "info@yuitor.com",
    inputType: "email",
  },
  {
    key: "REPLY_TO_EMAIL",
    category: "email",
    label: "Reply-To Email (REPLY_TO_EMAIL)",
    description: "Address where replies from students/parents are delivered.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email",
  },
  {
    key: "ADMIN_NOTIFY_EMAIL",
    category: "email",
    label: "Admin Alert Email (ADMIN_NOTIFY_EMAIL)",
    description: "Recipient email for new admission enquiries and registration approvals.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email",
  },
  {
    key: "FAST2SMS_API_KEY",
    category: "sms",
    label: "Fast2SMS API Key (FAST2SMS_API_KEY)",
    description: "Sends live 6-digit SMS OTPs to mobile numbers during registration and password reset.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Fast2SMS authorization key",
    inputType: "password",
  },
  {
    key: "FAST2SMS_SENDER_ID",
    category: "sms",
    label: "Fast2SMS Sender ID (Optional)",
    description: "Optional DLT/route sender ID if applicable to your Fast2SMS plan.",
    isSecret: false,
    defaultValue: "",
    placeholder: "YUITOR",
    inputType: "text",
  },
  {
    key: "RAZORPAY_KEY_ID",
    category: "payments",
    label: "Razorpay Key ID (RAZORPAY_KEY_ID)",
    description: "Public Razorpay Merchant Key ID (starts with rzp_live_ or rzp_test_).",
    isSecret: false,
    defaultValue: "",
    placeholder: "rzp_live_...",
    inputType: "text",
  },
  {
    key: "RAZORPAY_KEY_SECRET",
    category: "payments",
    label: "Razorpay Key Secret (RAZORPAY_KEY_SECRET)",
    description: "Secret key used to verify HMAC-SHA256 gateway payment signatures on the server.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter Razorpay key secret",
    inputType: "password",
  },
  {
    key: "RAZORPAY_WEBHOOK_SECRET",
    category: "payments",
    label: "Razorpay Webhook Secret (Optional)",
    description: "Optional webhook signature secret for Razorpay webhook events.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter webhook secret",
    inputType: "password",
  },
];

const SETTING_MAP = new Map(SETTING_DEFINITIONS.map((d) => [d.key, d]));
const ENV_BASELINE = new Map<string, string | undefined>();
let baselineCaptured = false;

function captureEnvBaseline(): void {
  if (baselineCaptured) return;
  for (const def of SETTING_DEFINITIONS) {
    ENV_BASELINE.set(def.key, process.env[def.key]);
  }
  baselineCaptured = true;
}

function isEffectiveValue(key: string, val: string): boolean {
  const v = val.trim();
  if (!v) return false;
  if (key === "APP_URL" && v === "MY_APP_URL") return false;
  if (key === "GEMINI_API_KEY" && v === "MY_GEMINI_API_KEY") return false;
  if (key === "SESSION_SECRET" && v === "replace-with-64-char-random-hex-secret") return false;
  if (key === "SMTP_HOST" && v === "smtp.example.com") return false;
  if (key === "SMTP_PASS" && v.startsWith("replace-with")) return false;
  return true;
}

function maskSecret(val: string): string {
  const trimmed = val.trim();
  if (!trimmed) return "";
  if (trimmed.length <= 6) return "••••••";
  return `${trimmed.slice(0, 2)}${"•".repeat(Math.min(12, trimmed.length - 6))}${trimmed.slice(-4)}`;
}

export function hydrateRuntimeSettings(db: DatabaseSync): void {
  captureEnvBaseline();
  const rows = db.prepare("SELECT key, value FROM system_settings").all() as Array<{ key: string; value: string }>;
  const dbMap = new Map(rows.map((r) => [r.key, String(r.value ?? "")]));

  for (const def of SETTING_DEFINITIONS) {
    const saved = dbMap.get(def.key);
    if (saved !== undefined && saved.trim() !== "") {
      process.env[def.key] = saved;
    } else {
      const orig = ENV_BASELINE.get(def.key);
      if (orig !== undefined) {
        process.env[def.key] = orig;
      } else {
        delete process.env[def.key];
      }
    }
  }
}

export function getAdminSettingsView(db: DatabaseSync) {
  hydrateRuntimeSettings(db);
  const rows = db.prepare("SELECT key, value, updated_at FROM system_settings").all() as Array<{
    key: string;
    value: string;
    updated_at: string;
  }>;
  const dbMap = new Map(rows.map((r) => [r.key, r]));

  const items = SETTING_DEFINITIONS.map((def) => {
    const dbRow = dbMap.get(def.key);
    const dbVal = dbRow?.value ?? "";
    const envVal = String(ENV_BASELINE.get(def.key) ?? "");
    const activeRaw = String(process.env[def.key] ?? "");

    const hasDbOverride = dbVal.trim() !== "";
    const configured = isEffectiveValue(def.key, activeRaw);
    const source: "admin" | "env" | "default" | "unset" = hasDbOverride
      ? "admin"
      : isEffectiveValue(def.key, envVal)
        ? "env"
        : def.defaultValue
          ? "default"
          : "unset";

    return {
      key: def.key,
      category: def.category,
      label: def.label,
      description: def.description,
      isSecret: def.isSecret,
      inputType: def.inputType,
      defaultValue: def.defaultValue,
      placeholder: def.placeholder,
      value: def.isSecret ? "" : activeRaw || def.defaultValue,
      maskedValue: def.isSecret && configured ? maskSecret(activeRaw) : "",
      isConfigured: configured,
      hasDbOverride,
      source,
      updatedAt: dbRow?.updated_at || null,
    };
  });

  const active = (k: string) => isEffectiveValue(k, String(process.env[k] ?? ""));
  const readiness = {
    appUrl: active("APP_URL"),
    sessionSecret: active("SESSION_SECRET"),
    setupKeyProtected: active("YU_ADMIN_SETUP_KEY"),
    geminiAi: active("GEMINI_API_KEY"),
    smtpMail: active("SMTP_HOST") && active("SMTP_USER") && active("SMTP_PASS"),
    fast2sms: active("FAST2SMS_API_KEY"),
    razorpay: active("RAZORPAY_KEY_ID") && active("RAZORPAY_KEY_SECRET"),
  };

  return { settings: items, readiness };
}

export function updateAdminSettings(
  db: DatabaseSync,
  valuesInput: Record<string, unknown>,
  clearKeysInput: string[],
  actorUserId: number
): { updatedKeys: string[]; clearedKeys: string[]; sessionSecretRotated: boolean } {
  const now = nowIso();
  const updatedKeys: string[] = [];
  const clearedKeys: string[] = [];
  let sessionSecretRotated = false;

  const upsert = db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET
       value = excluded.value,
       is_secret = excluded.is_secret,
       updated_at = excluded.updated_at,
       updated_by = excluded.updated_by`
  );
  const del = db.prepare("DELETE FROM system_settings WHERE key = ?");

  for (const rawKey of clearKeysInput) {
    const key = cleanText(rawKey, 80);
    if (!SETTING_MAP.has(key)) continue;
    del.run(key);
    clearedKeys.push(key);
    if (key === "SESSION_SECRET") sessionSecretRotated = true;
  }

  for (const [rawKey, rawVal] of Object.entries(valuesInput || {})) {
    const key = cleanText(rawKey, 80);
    const def = SETTING_MAP.get(key);
    if (!def) continue;
    if (clearedKeys.includes(key)) continue;

    const strVal = cleanText(rawVal, 1000);
    if (def.isSecret && strVal === "") {
      // Blank secret input preserves existing saved secret unless explicitly cleared
      continue;
    }

    if (key === "APP_URL" && strVal) {
      let parsed: URL;
      try {
        parsed = new URL(strVal);
      } catch {
        throw new Error("APP_URL must be a valid full URL (e.g. https://yuitor.com).");
      }
      if (!["http:", "https:"].includes(parsed.protocol)) {
        throw new Error("APP_URL must start with http:// or https://.");
      }
    }

    if (key === "SMTP_PORT" && strVal) {
      const port = Number(strVal);
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error("SMTP_PORT must be a valid port number between 1 and 65535.");
      }
    }

    if (key === "SESSION_SECRET" && strVal.length < 16) {
      throw new Error("SESSION_SECRET must be at least 16 characters (64-char hex recommended).");
    }

    if (def.inputType === "email" && strVal && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(strVal)) {
      throw new Error(`${def.label} must be a valid email address.`);
    }

    if (strVal === "" && !def.isSecret) {
      del.run(key);
      clearedKeys.push(key);
    } else {
      const normalized =
        key === "APP_URL"
          ? strVal.replace(/\/+$/, "")
          : key === "SMTP_SECURE"
            ? (String(strVal).toLowerCase() === "true" ? "true" : "false")
            : strVal;
      upsert.run(key, normalized, def.isSecret ? 1 : 0, now, actorUserId);
      updatedKeys.push(key);
      if (key === "SESSION_SECRET") sessionSecretRotated = true;
    }
  }

  hydrateRuntimeSettings(db);
  return { updatedKeys, clearedKeys, sessionSecretRotated };
}
