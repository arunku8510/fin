import { Router } from "express";
import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, clientIp, getSessionContext, nowIso, writeAuditLog } from "../security.js";

export function createPaymentsRouter(db: DatabaseSync): Router {
  const router = Router();

  router.post("/enroll", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required to enroll." });
      return;
    }

    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = cleanText(req.body?.utrReference, 80);
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();

    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId) as any;
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }

    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;

    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode) as any;
      if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses)) {
        res.status(400).json({ error: "Invalid or expired coupon code." });
        return;
      }
      discountAmount =
        coupon.discount_type === "percent"
          ? Math.round((baseAmount * Number(coupon.discount_value)) / 100)
          : Math.min(baseAmount, Number(coupon.discount_value));
      db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(coupon.id);
    }

    const finalAmount = Math.max(0, baseAmount - discountAmount);
    const now = nowIso();
    const months = plan === "yearly" ? 12 : 1;
    const expiresDate = new Date();
    expiresDate.setMonth(expiresDate.getMonth() + months);
    const expiresAt = expiresDate.toISOString().slice(0, 10);

    let verificationStatus: "pending_verification" | "verified" | "failed" = "pending_verification";
    let receiptNumber = "";
    let paidAt: string | null = null;
    let enrollmentStatus: "pending" | "active" = "pending";
    let message = "";

    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
      const gOrder = cleanText(req.body?.gatewayOrderId, 100);
      const gPay = cleanText(req.body?.gatewayPaymentId, 100);
      const gSig = cleanText(req.body?.gatewaySignature, 200);

      if (rzpSecret && gOrder && gPay && gSig) {
        const expectedSig = crypto.createHmac("sha256", rzpSecret).update(`${gOrder}|${gPay}`).digest("hex");
        const a = Buffer.from(gSig);
        const b = Buffer.from(expectedSig);
        if (a.length === b.length && crypto.timingSafeEqual(a, b)) {
          verificationStatus = "verified";
          enrollmentStatus = "active";
          paidAt = now;
          receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
          message = "Gateway signature verified! Your enrollment and fee receipt are now active.";
        } else {
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
      } else {
        // Never mark gateway payment successful without provider verification
        message =
          "Online payment gateway credentials (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) are not configured on this server. Enrollment saved as Pending Verification — submit UTR or pay at the Muradnagar desk.";
      }
    } else {
      message =
        "Enrollment submitted! Your payment is marked Pending Verification until confirmed by the Yuitor Team.";
    }

    db.prepare(
      `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
       VALUES (?, ?, ?, ?, 0, 0, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET plan = excluded.plan, status = excluded.status, expires_at = excluded.expires_at`
    ).run(ctx.user.id, courseId, plan, enrollmentStatus, expiresAt, now);

    const enrollment = db
      .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?")
      .get(ctx.user.id, courseId) as { id: number };

    const invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
    db.prepare(
      `INSERT INTO payments
       (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
        utr_reference, verification_status, invoice_number, receipt_number, paid_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      enrollment.id,
      plan,
      baseAmount,
      discountAmount,
      finalAmount,
      couponCode,
      paymentMethod,
      utrReference,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      paidAt,
      now
    );

    db.prepare(
      `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      `${course.title} (${plan})`,
      baseAmount,
      discountAmount,
      verificationStatus === "verified" ? finalAmount : 0,
      now.slice(0, 10),
      verificationStatus === "verified" ? "paid" : "pending",
      now
    );

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New Enrollment Payment (${paymentMethod.toUpperCase()})`,
      `${ctx.user.full_name} enrolled in ${course.title} (₹${finalAmount}, ${verificationStatus}).`,
      now
    );

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: courseId,
      targetName: course.title,
      action: "enrollment_submitted",
      details: `${plan} ₹${finalAmount} (${verificationStatus})`,
      ipAddress: clientIp(req),
    });

    res.status(201).json({
      enrolled: true,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      amount: finalAmount,
      message,
    });
  });

  router.post("/refund-request", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const paymentId = Number(req.body?.paymentId);
    const reason = cleanText(req.body?.reason, 500);
    if (reason.length < 5) {
      res.status(400).json({ error: "Provide a refund reason (min 5 characters)." });
      return;
    }

    const pay = db.prepare("SELECT * FROM payments WHERE id = ? AND student_id = ?").get(paymentId, ctx.user.id) as any;
    if (!pay || pay.verification_status !== "verified") {
      res.status(404).json({ error: "Verified payment record not found." });
      return;
    }

    db.prepare("UPDATE payments SET refund_status = 'requested', refund_reason = ? WHERE id = ?").run(reason, paymentId);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run("Refund Request", `${ctx.user.full_name} requested refund for payment #${paymentId}: ${reason}`, nowIso());

    res.json({ requested: true });
  });

  return router;
}
