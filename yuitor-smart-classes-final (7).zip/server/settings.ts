import type { DatabaseSync } from "node:sqlite";
import { cleanText, nowIso } from "./security.js";

export type SettingCategory = "general" | "ai" | "email" | "sms" | "payments";

export interface SettingDefinition {
  key: string;
  category: SettingCategory;
  label: string;
  description: string;
  isSecret: boolean;
  defaultValue: string;
  placeholder: string;
  inputType: "text" | "url" | "email" | "number" | "password" | "boolean";
}

export const SETTING_DEFINITIONS: SettingDefinition[] = [
  {
    key: "APP_URL",
    category: "general",
    label: "Public App URL (APP_URL)",
    description: "Primary live domain URL used in emails, unsubscribe links, and origin checks.",
    isSecret: false,
    defaultValue: "https://yuitor.com",
    placeholder: "https://yuitor.com",
    inputType: "url",
  },
  {
    key: "SESSION_SECRET",
    category: "general",
    label: "Session Signing Secret (SESSION_SECRET)",
    description: "Strong random secret (min 16 chars, recommended 64-char hex) for signing cookies, OTPs, and download links.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter or generate a strong 64-char hex secret",
    inputType: "password",
  },
  {
    key: "YU_ADMIN_SETUP_KEY",
    category: "general",
    label: "First-Admin Setup Key (YU_ADMIN_SETUP_KEY)",
    description: "Optional security key required when creating the first Super Admin on /admin/setup.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Optional secret key for /admin/setup",
    inputType: "password",
  },
  {
    key: "GEMINI_API_KEY",
    category: "ai",
    label: "Google Gemini API Key (GEMINI_API_KEY)",
    description: "Enables live Gemini LLM responses for Shreya Smart AI (deterministic bilingual fallback runs when unset).",
    isSecret: true,
    defaultValue: "",
    placeholder: "AIza...",
    inputType: "password",
  },
  {
    key: "GEMINI_MODEL",
    category: "ai",
    label: "Gemini Model Name (GEMINI_MODEL)",
    description: "Gemini model ID used for live Shreya AI replies (recommended: gemini-2.5-flash).",
    isSecret: false,
    defaultValue: "gemini-2.5-flash",
    placeholder: "gemini-2.5-flash",
    inputType: "text",
  },
  {
    key: "SMTP_HOST",
    category: "email",
    label: "SMTP Host (SMTP_HOST)",
    description: "Outgoing mail server hostname (e.g. smtp.hostinger.com or smtp.gmail.com).",
    isSecret: false,
    defaultValue: "",
    placeholder: "smtp.hostinger.com",
    inputType: "text",
  },
  {
    key: "SMTP_PORT",
    category: "email",
    label: "SMTP Port (SMTP_PORT)",
    description: "SMTP port number (587 for STARTTLS, 465 for SSL/TLS).",
    isSecret: false,
    defaultValue: "587",
    placeholder: "587",
    inputType: "number",
  },
  {
    key: "SMTP_SECURE",
    category: "email",
    label: "Use SSL/TLS (SMTP_SECURE)",
    description: "Enable direct TLS (true for port 465, false for port 587 STARTTLS).",
    isSecret: false,
    defaultValue: "false",
    placeholder: "false",
    inputType: "boolean",
  },
  {
    key: "SMTP_USER",
    category: "email",
    label: "SMTP Username (SMTP_USER)",
    description: "Authenticated email login username.",
    isSecret: false,
    defaultValue: "",
    placeholder: "info@yuitor.com",
    inputType: "text",
  },
  {
    key: "SMTP_PASS",
    category: "email",
    label: "SMTP Password (SMTP_PASS)",
    description: "SMTP mailbox password or app password (stored securely on server).",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter SMTP password or app password",
    inputType: "password",
  },
  {
    key: "MAIL_FROM_NAME",
    category: "email",
    label: "Sender Display Name (MAIL_FROM_NAME)",
    description: "Display name shown in outgoing emails.",
    isSecret: false,
    defaultValue: "Yuitor Smart Classes",
    placeholder: "Yuitor Smart Classes",
    inputType: "text",
  },
  {
    key: "MAIL_FROM_EMAIL",
    category: "email",
    label: "Sender Email (MAIL_FROM_EMAIL)",
    description: "From address for marketing campaigns and system emails.",
    isSecret: false,
    defaultValue: "info@yuitor.com",
    placeholder: "info@yuitor.com",
    inputType: "email",
  },
  {
    key: "REPLY_TO_EMAIL",
    category: "email",
    label: "Reply-To Email (REPLY_TO_EMAIL)",
    description: "Address where replies from students/parents are delivered.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email",
  },
  {
    key: "ADMIN_NOTIFY_EMAIL",
    category: "email",
    label: "Admin Alert Email (ADMIN_NOTIFY_EMAIL)",
    description: "Recipient email for new admission enquiries and registration approvals.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email",
  },
  {
    key: "FAST2SMS_API_KEY",
    category: "sms",
    label: "Fast2SMS API Key (FAST2SMS_API_KEY)",
    description: "Sends live 6-digit SMS OTPs to mobile numbers during registration and password reset.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Fast2SMS authorization key",
    inputType: "password",
  },
  {
    key: "FAST2SMS_ROUTE",
    category: "sms",
    label: "Fast2SMS Route (FAST2SMS_ROUTE)",
    description: "Choose 'q' for Quick SMS, 'otp' for OTP route, or 'dlt' for TRAI DLT approved templates.",
    isSecret: false,
    defaultValue: "q",
    placeholder: "q",
    inputType: "text",
  },
  {
    key: "FAST2SMS_SENDER_ID",
    category: "sms",
    label: "Fast2SMS Sender ID (Optional)",
    description: "Approved 6-character DLT sender ID (e.g. YUITOR) when using DLT route.",
    isSecret: false,
    defaultValue: "",
    placeholder: "YUITOR",
    inputType: "text",
  },
  {
    key: "FAST2SMS_DLT_TEMPLATE_ID",
    category: "sms",
    label: "Fast2SMS DLT Template ID (Optional)",
    description: "Registered TRAI DLT Template/Message ID when FAST2SMS_ROUTE is set to dlt.",
    isSecret: false,
    defaultValue: "",
    placeholder: "17071...",
    inputType: "text",
  },
  {
    key: "RAZORPAY_KEY_ID",
    category: "payments",
    label: "Razorpay Key ID (RAZORPAY_KEY_ID)",
    description: "Public Razorpay Merchant Key ID (starts with rzp_live_ or rzp_test_).",
    isSecret: false,
    defaultValue: "",
    placeholder: "rzp_live_...",
    inputType: "text",
  },
  {
    key: "RAZORPAY_KEY_SECRET",
    category: "payments",
    label: "Razorpay Key Secret (RAZORPAY_KEY_SECRET)",
    description: "Secret key used to create Razorpay orders and verify HMAC-SHA256 payment signatures.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter Razorpay key secret",
    inputType: "password",
  },
  {
    key: "RAZORPAY_WEBHOOK_SECRET",
    category: "payments",
    label: "Razorpay Webhook Secret (Optional)",
    description: "Webhook signing secret used to verify incoming Razorpay webhook events.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter webhook secret",
    inputType: "password",
  },
];

const SETTING_MAP = new Map(SETTING_DEFINITIONS.map((d) => [d.key, d]));
const ENV_BASELINE = new Map<string, string | undefined>();
let baselineCaptured = false;

function captureEnvBaseline(): void {
  if (baselineCaptured) return;
  for (const def of SETTING_DEFINITIONS) {
    ENV_BASELINE.set(def.key, process.env[def.key]);
  }
  baselineCaptured = true;
}

function isEffectiveValue(key: string, val: string): boolean {
  const v = val.trim();
  if (!v) return false;
  if (key === "APP_URL" && v === "MY_APP_URL") return false;
  if (key === "GEMINI_API_KEY" && v === "MY_GEMINI_API_KEY") return false;
  if (key === "SESSION_SECRET" && v === "replace-with-64-char-random-hex-secret") return false;
  if (key === "SMTP_HOST" && v === "smtp.example.com") return false;
  if (key === "SMTP_PASS" && v.startsWith("replace-with")) return false;
  return true;
}

function maskSecret(val: string): string {
  const trimmed = val.trim();
  if (!trimmed) return "";
  if (trimmed.length <= 6) return "••••••";
  return `${trimmed.slice(0, 2)}${"•".repeat(Math.min(12, trimmed.length - 6))}${trimmed.slice(-4)}`;
}

export function hydrateRuntimeSettings(db: DatabaseSync): void {
  captureEnvBaseline();
  const rows = db.prepare("SELECT key, value FROM system_settings").all() as Array<{ key: string; value: string }>;
  const dbMap = new Map(rows.map((r) => [r.key, String(r.value ?? "")]));

  for (const def of SETTING_DEFINITIONS) {
    const saved = dbMap.get(def.key);
    if (saved !== undefined && saved.trim() !== "") {
      process.env[def.key] = saved;
    } else {
      const orig = ENV_BASELINE.get(def.key);
      if (orig !== undefined) {
        process.env[def.key] = orig;
      } else {
        delete process.env[def.key];
      }
    }
  }
}

export type IntegrationKey = "razorpay" | "fast2sms" | "smtp" | "gemini";

export interface IntegrationTestStatus {
  tested: boolean;
  connected: boolean;
  message: string;
  testedAt: string | null;
}

const INTEGRATION_STATUS_META_KEY = "integration_test_statuses";

export function getIntegrationTestStatuses(db: DatabaseSync): Record<IntegrationKey, IntegrationTestStatus> {
  const empty = (): IntegrationTestStatus => ({ tested: false, connected: false, message: "", testedAt: null });
  const base: Record<IntegrationKey, IntegrationTestStatus> = {
    razorpay: empty(),
    fast2sms: empty(),
    smtp: empty(),
    gemini: empty(),
  };
  try {
    const row = db.prepare("SELECT value FROM schema_meta WHERE key = ?").get(INTEGRATION_STATUS_META_KEY) as
      | { value: string }
      | undefined;
    if (!row?.value) return base;
    const parsed = JSON.parse(row.value);
    for (const k of ["razorpay", "fast2sms", "smtp", "gemini"] as IntegrationKey[]) {
      if (parsed?.[k] && typeof parsed[k] === "object") {
        base[k] = {
          tested: Boolean(parsed[k].tested),
          connected: Boolean(parsed[k].connected),
          message: String(parsed[k].message || ""),
          testedAt: parsed[k].testedAt ? String(parsed[k].testedAt) : null,
        };
      }
    }
  } catch {
    // Return clean empty defaults if malformed
  }
  return base;
}

export function recordIntegrationTestStatus(
  db: DatabaseSync,
  key: IntegrationKey,
  connected: boolean,
  message: string
): Record<IntegrationKey, IntegrationTestStatus> {
  const current = getIntegrationTestStatuses(db);
  current[key] = {
    tested: true,
    connected,
    message: cleanText(message, 280),
    testedAt: nowIso(),
  };
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES (?, ?)").run(
    INTEGRATION_STATUS_META_KEY,
    JSON.stringify(current)
  );
  return current;
}

function clearIntegrationTestStatusesForKeys(db: DatabaseSync, touchedKeys: string[]): void {
  if (touchedKeys.length === 0) return;
  const current = getIntegrationTestStatuses(db);
  let dirty = false;
  const reset = (): IntegrationTestStatus => ({ tested: false, connected: false, message: "Credentials updated — re-test connection.", testedAt: null });
  if (touchedKeys.some((k) => k.startsWith("RAZORPAY_"))) {
    current.razorpay = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("FAST2SMS_"))) {
    current.fast2sms = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("SMTP_") || k.endsWith("_EMAIL") || k === "MAIL_FROM_NAME")) {
    current.smtp = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("GEMINI_"))) {
    current.gemini = reset();
    dirty = true;
  }
  if (dirty) {
    try {
      db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES (?, ?)").run(
        INTEGRATION_STATUS_META_KEY,
        JSON.stringify(current)
      );
    } catch {
      // Ignore if schema_meta table is absent in minimal test fixtures
    }
  }
}

export function getAdminSettingsView(db: DatabaseSync) {
  hydrateRuntimeSettings(db);
  const rows = db.prepare("SELECT key, value, updated_at FROM system_settings").all() as Array<{
    key: string;
    value: string;
    updated_at: string;
  }>;
  const dbMap = new Map(rows.map((r) => [r.key, r]));

  const items = SETTING_DEFINITIONS.map((def) => {
    const dbRow = dbMap.get(def.key);
    const dbVal = dbRow?.value ?? "";
    const envVal = String(ENV_BASELINE.get(def.key) ?? "");
    const activeRaw = String(process.env[def.key] ?? "");

    const hasDbOverride = dbVal.trim() !== "";
    const configured = isEffectiveValue(def.key, activeRaw);
    const source: "admin" | "env" | "default" | "unset" = hasDbOverride
      ? "admin"
      : isEffectiveValue(def.key, envVal)
        ? "env"
        : def.defaultValue
          ? "default"
          : "unset";

    return {
      key: def.key,
      category: def.category,
      label: def.label,
      description: def.description,
      isSecret: def.isSecret,
      inputType: def.inputType,
      defaultValue: def.defaultValue,
      placeholder: def.placeholder,
      value: def.isSecret ? "" : activeRaw || def.defaultValue,
      maskedValue: def.isSecret && configured ? maskSecret(activeRaw) : "",
      isConfigured: configured,
      hasDbOverride,
      source,
      updatedAt: dbRow?.updated_at || null,
    };
  });

  const active = (k: string) => isEffectiveValue(k, String(process.env[k] ?? ""));
  const readiness = {
    appUrl: active("APP_URL"),
    sessionSecret: active("SESSION_SECRET"),
    setupKeyProtected: active("YU_ADMIN_SETUP_KEY"),
    geminiAi: active("GEMINI_API_KEY"),
    geminiModel: (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash",
    smtpMail: active("SMTP_HOST") && active("SMTP_USER") && active("SMTP_PASS"),
    fast2sms: active("FAST2SMS_API_KEY"),
    razorpay: active("RAZORPAY_KEY_ID") && active("RAZORPAY_KEY_SECRET"),
    razorpayMode: (process.env.RAZORPAY_KEY_ID || "").trim().startsWith("rzp_live_")
      ? "live"
      : (process.env.RAZORPAY_KEY_ID || "").trim().startsWith("rzp_test_")
        ? "sandbox"
        : "unconfigured",
    razorpayWebhook: active("RAZORPAY_WEBHOOK_SECRET"),
  };

  return { settings: items, readiness, integrationStatuses: getIntegrationTestStatuses(db) };
}

export function updateAdminSettings(
  db: DatabaseSync,
  valuesInput: Record<string, unknown>,
  clearKeysInput: string[],
  actorUserId: number
): { updatedKeys: string[]; clearedKeys: string[]; sessionSecretRotated: boolean } {
  const now = nowIso();
  const updatedKeys: string[] = [];
  const clearedKeys: string[] = [];
  let sessionSecretRotated = false;

  const upsert = db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET
       value = excluded.value,
       is_secret = excluded.is_secret,
       updated_at = excluded.updated_at,
       updated_by = excluded.updated_by`
  );
  const del = db.prepare("DELETE FROM system_settings WHERE key = ?");

  for (const rawKey of clearKeysInput) {
    const key = cleanText(rawKey, 80);
    if (!SETTING_MAP.has(key)) continue;
    del.run(key);
    clearedKeys.push(key);
    if (key === "SESSION_SECRET") sessionSecretRotated = true;
  }

  for (const [rawKey, rawVal] of Object.entries(valuesInput || {})) {
    const key = cleanText(rawKey, 80);
    const def = SETTING_MAP.get(key);
    if (!def) continue;
    if (clearedKeys.includes(key)) continue;

    const strVal = cleanText(rawVal, 1000);
    if (def.isSecret && strVal === "") {
      // Blank secret input preserves existing saved secret unless explicitly cleared
      continue;
    }

    if (key === "APP_URL" && strVal) {
      let parsed: URL;
      try {
        parsed = new URL(strVal);
      } catch {
        throw new Error("APP_URL must be a valid full URL (e.g. https://yuitor.com).");
      }
      if (!["http:", "https:"].includes(parsed.protocol)) {
        throw new Error("APP_URL must start with http:// or https://.");
      }
    }

    if (key === "SMTP_PORT" && strVal) {
      const port = Number(strVal);
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error("SMTP_PORT must be a valid port number between 1 and 65535.");
      }
    }

    if (key === "SESSION_SECRET" && strVal.length < 16) {
      throw new Error("SESSION_SECRET must be at least 16 characters (64-char hex recommended).");
    }

    if (key === "FAST2SMS_ROUTE" && strVal && !["q", "otp", "dlt"].includes(strVal.toLowerCase())) {
      throw new Error("FAST2SMS_ROUTE must be one of: q, otp, or dlt.");
    }

    if (key === "RAZORPAY_KEY_ID" && strVal && !/^rzp_(test|live)_[A-Za-z0-9]{4,}$/.test(strVal)) {
      throw new Error("RAZORPAY_KEY_ID must start with rzp_test_ or rzp_live_ followed by the Razorpay key ID.");
    }

    if (key === "SMTP_HOST" && strVal && (!/^[a-z0-9.-]+$/i.test(strVal) || !strVal.includes("."))) {
      throw new Error("SMTP_HOST must be a valid mail server hostname (e.g. smtp.hostinger.com).");
    }

    if (key === "GEMINI_MODEL" && strVal && !/^gemini-[A-Za-z0-9._-]+$/i.test(strVal)) {
      throw new Error("GEMINI_MODEL must be a valid Gemini model ID (e.g. gemini-2.5-flash).");
    }

    if (def.inputType === "email" && strVal && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(strVal)) {
      throw new Error(`${def.label} must be a valid email address.`);
    }

    if (strVal === "" && !def.isSecret) {
      del.run(key);
      clearedKeys.push(key);
    } else {
      const normalized =
        key === "APP_URL"
          ? strVal.replace(/\/+$/, "")
          : key === "SMTP_SECURE"
            ? (String(strVal).toLowerCase() === "true" ? "true" : "false")
            : key === "FAST2SMS_ROUTE"
              ? strVal.toLowerCase()
              : strVal;
      upsert.run(key, normalized, def.isSecret ? 1 : 0, now, actorUserId);
      updatedKeys.push(key);
      if (key === "SESSION_SECRET") sessionSecretRotated = true;
    }
  }

  hydrateRuntimeSettings(db);
  clearIntegrationTestStatusesForKeys(db, [...updatedKeys, ...clearedKeys]);
  return { updatedKeys, clearedKeys, sessionSecretRotated };
}
