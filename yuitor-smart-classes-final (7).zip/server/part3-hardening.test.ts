import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { DatabaseSync } from "node:sqlite";
import { extractTextFromPdfBuffer, retrieveRelevantDocumentSnippets } from "./pdf.js";
import { generateShreyaReply } from "./chatbot.js";
import { seedDefaultContent } from "./db.js";
import {
  createSession,
  getSessionContext,
  issueOtp,
  sanitizeHttpOrUploadUrl,
  signSessionToken,
  validateUploadMagicBytes,
  verifyOtpToken,
} from "./security.js";
import { dispatchSmsOtp } from "./mailer.js";
import { getAdminSettingsView, recordIntegrationTestStatus, updateAdminSettings } from "./settings.js";

function createFullSchemaDb(): DatabaseSync {
  const db = new DatabaseSync(":memory:");
  const sql = fs.readFileSync(path.join(process.cwd(), "database", "migrations", "001_unified_portal.sql"), "utf8");
  db.exec(sql);
  seedDefaultContent(db);
  return db;
}

test("PDF extractor decodes uncompressed and FlateDecode PDF streams cleanly", () => {
  const plainPdf = Buffer.from(
    "%PDF-1.4\n1 0 obj << /Length 44 >> stream\nBT /F1 12 Tf (Yuitor Scholarship Test 2026) Tj ET\nendstream\nendobj\n%%EOF",
    "latin1"
  );
  assert.match(extractTextFromPdfBuffer(plainPdf), /Yuitor Scholarship Test 2026/);

  const compressedStream = zlib.deflateSync(Buffer.from("BT (NEET Physics Formula Sheet Mechanics) Tj ET", "latin1"));
  const compressedPdf = Buffer.concat([
    Buffer.from(`%PDF-1.4\n1 0 obj << /Filter /FlateDecode /Length ${compressedStream.length} >>\nstream\n`, "latin1"),
    compressedStream,
    Buffer.from("\nendstream\nendobj\n%%EOF", "latin1"),
  ]);
  assert.match(extractTextFromPdfBuffer(compressedPdf), /NEET Physics Formula Sheet Mechanics/);
});

test("Shreya retrieves uploaded PDF knowledge document snippets even without Gemini key", async () => {
  const db = createFullSchemaDb();
  const prevKey = process.env.GEMINI_API_KEY;
  process.env.GEMINI_API_KEY = "";
  try {
    db.prepare(
      `INSERT INTO knowledge_documents (title, filename, mime_type, size_bytes, file_path, extracted_text, is_active, created_at)
       VALUES (?, ?, 'application/pdf', 2048, 'knowledge/brochure.pdf', ?, 1, '2026-01-01T00:00:00Z')`
    ).run(
      "Muradnagar Hostel & Library Guide",
      "hostel-guide.pdf",
      "Yuitor Smart Classes Muradnagar provides a silent AC reading room library open daily from 7 AM to 9 PM for Class 11, 12 and NEET students."
    );

    const snippets = retrieveRelevantDocumentSnippets(db, "reading room library timings");
    assert.ok(snippets.length >= 1);
    assert.equal(snippets[0].sourceTitle, "Muradnagar Hostel & Library Guide");

    const reply = await generateShreyaReply(db, "conv-doc-1", "What are reading room library timings?");
    assert.match(reply.reply, /7 AM to 9 PM/i);
  } finally {
    if (prevKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = prevKey;
    db.close();
  }
});

test("Security helpers reject unsafe URLs, spoofed upload magic bytes, inactive sessions, and OTP reuse", () => {
  assert.equal(sanitizeHttpOrUploadUrl("https://meet.google.com/abc-def"), "https://meet.google.com/abc-def");
  assert.equal(sanitizeHttpOrUploadUrl("/uploads/notes.pdf"), "/uploads/notes.pdf");
  assert.equal(sanitizeHttpOrUploadUrl("javascript:alert(1)"), "");
  assert.equal(sanitizeHttpOrUploadUrl("data:text/html,<script>alert(1)</script>"), "");
  assert.equal(sanitizeHttpOrUploadUrl("//evil.example.com/x"), "");

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "yuitor-magic-"));
  try {
    const goodPdf = path.join(tmpDir, "valid.pdf");
    fs.writeFileSync(goodPdf, "%PDF-1.4\n1 0 obj\n%%EOF");
    assert.equal(validateUploadMagicBytes(goodPdf, ".pdf"), true);

    const spoofPdf = path.join(tmpDir, "spoof.pdf");
    fs.writeFileSync(spoofPdf, "<script>alert(1)</script>");
    assert.equal(validateUploadMagicBytes(spoofPdf, ".pdf"), false);

    const goodPng = path.join(tmpDir, "ok.png");
    fs.writeFileSync(goodPng, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00]));
    assert.equal(validateUploadMagicBytes(goodPng, ".png"), true);
    assert.equal(validateUploadMagicBytes(goodPng, ".jpg"), false);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  const db = createFullSchemaDb();
  try {
    db.prepare(
      `INSERT INTO users (id, role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at)
       VALUES (501, 'student', 'Test User', 'test501@example.com', '9876543501', 'hash', 1, 'approved', 1, 'unsub-501', '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z')`
    ).run();

    const sid = createSession(db, 501);
    const cookie = signSessionToken(sid);
    const activeCtx = getSessionContext(db, { cookies: { yu_session: cookie } } as any);
    assert.ok(activeCtx);
    assert.equal(activeCtx.user.id, 501);

    // Suspending user invalidates existing session immediately
    db.prepare("UPDATE users SET is_active = 0 WHERE id = 501").run();
    const inactiveCtx = getSessionContext(db, { cookies: { yu_session: cookie } } as any);
    assert.equal(inactiveCtx, null);

    // OTP timing-safe verification + single-use enforcement
    const issued = issueOtp(db, { userId: 501, phone: "9876543501", purpose: "registration" });
    const badAttempt = verifyOtpToken(db, { target: "9876543501", purpose: "registration", otp: "000000" });
    assert.equal(badAttempt.ok, false);
    const okAttempt = verifyOtpToken(db, { target: "9876543501", purpose: "registration", otp: issued.otp });
    assert.equal(okAttempt.ok, true);
    const replayAttempt = verifyOtpToken(db, { target: "9876543501", purpose: "registration", otp: issued.otp });
    assert.equal(replayAttempt.ok, false);
  } finally {
    db.close();
  }
});

test("dispatchSmsOtp never exposes OTP codes when Fast2SMS is unconfigured", async () => {
  const prevKey = process.env.FAST2SMS_API_KEY;
  process.env.FAST2SMS_API_KEY = "";
  try {
    const out = await dispatchSmsOtp("9876543210", "739284", "Registration");
    assert.equal(out.sent, false);
    assert.ok(!out.note.includes("739284"), "OTP code must never be exposed in note or response");
  } finally {
    if (prevKey === undefined) delete process.env.FAST2SMS_API_KEY;
    else process.env.FAST2SMS_API_KEY = prevKey;
  }
});

test("Settings validates Razorpay/SMTP/Gemini fields and resets integration test status on key update", () => {
  const db = createFullSchemaDb();
  const prevId = process.env.RAZORPAY_KEY_ID;
  const prevSec = process.env.RAZORPAY_KEY_SECRET;
  try {
    db.prepare(
      `INSERT INTO users (id, role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, unsubscribe_token, created_at, updated_at)
       VALUES (1, 'super_admin', 'Admin', 'admin@yuitor.com', '9876543001', 'hash', 1, 'approved', 1, 'unsub-1', '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z')`
    ).run();
    assert.throws(() => updateAdminSettings(db, { RAZORPAY_KEY_ID: "bad_key" }, [], 1), /RAZORPAY_KEY_ID/);
    assert.throws(() => updateAdminSettings(db, { SMTP_HOST: "localhost" }, [], 1), /SMTP_HOST/);
    assert.throws(() => updateAdminSettings(db, { GEMINI_MODEL: "gpt-4o" }, [], 1), /GEMINI_MODEL/);

    updateAdminSettings(
      db,
      { RAZORPAY_KEY_ID: "rzp_test_12345678", RAZORPAY_KEY_SECRET: "secret_12345678" },
      [],
      1
    );
    recordIntegrationTestStatus(db, "razorpay", true, "Razorpay SANDBOX verified");
    let view = getAdminSettingsView(db);
    assert.equal(view.readiness.razorpayMode, "sandbox");
    assert.equal(view.integrationStatuses.razorpay.connected, true);

    // Updating RAZORPAY_KEY_ID resets previous tested=true flag
    updateAdminSettings(db, { RAZORPAY_KEY_ID: "rzp_live_12345678" }, [], 1);
    view = getAdminSettingsView(db);
    assert.equal(view.readiness.razorpayMode, "live");
    assert.equal(view.integrationStatuses.razorpay.tested, false);
  } finally {
    if (prevId === undefined) delete process.env.RAZORPAY_KEY_ID;
    else process.env.RAZORPAY_KEY_ID = prevId;
    if (prevSec === undefined) delete process.env.RAZORPAY_KEY_SECRET;
    else process.env.RAZORPAY_KEY_SECRET = prevSec;
    db.close();
  }
});
