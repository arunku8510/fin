import { Router, type Request, type Response } from "express";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import multer from "multer";
import type { DatabaseSync } from "node:sqlite";
import { RESUMES_DIR } from "../db.js";
import {
  BRAND_PENDING_MSG,
  TEACHER_MISSING_RESUME_MSG,
  checkRateLimit,
  cleanText,
  clearRateLimit,
  clearSessionCookie,
  clientIp,
  createSession,
  escapeHtml,
  getSessionContext,
  hashPassword,
  isValidEmail,
  isValidIndianMobile,
  issueOtp,
  normalizeEmail,
  normalizePhone,
  nowIso,
  recordRateLimitHit,
  sanitizeHttpOrUploadUrl,
  setSessionCookie,
  verifyOtpToken,
  verifyPassword,
  verifySetupKey,
  writeAuditLog,
} from "../security.js";
import { dispatchSmsOtp, getAdminNotifyEmail, isSmtpConfigured, sendTransactionalEmail } from "../mailer.js";

const RESUME_ALLOWED_EXT = new Set([".pdf", ".doc", ".docx"]);
const RESUME_ALLOWED_MIME = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/octet-stream",
]);
const RESUME_MAX_BYTES = 5 * 1024 * 1024;

function createResumeUploader() {
  fs.mkdirSync(RESUMES_DIR, { recursive: true });
  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, RESUMES_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      const safeExt = RESUME_ALLOWED_EXT.has(ext) ? ext : ".pdf";
      cb(null, `resume-${Date.now()}-${crypto.randomBytes(8).toString("hex")}${safeExt}`);
    },
  });
  return multer({
    storage,
    limits: { fileSize: RESUME_MAX_BYTES },
    fileFilter: (_req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      if (!RESUME_ALLOWED_EXT.has(ext)) {
        cb(new Error("Please upload your resume in PDF, DOC, or DOCX format (max 5 MB)."));
        return;
      }
      const mime = String(file.mimetype || "").toLowerCase();
      if (mime && !RESUME_ALLOWED_MIME.has(mime)) {
        cb(new Error("Unsupported resume file type. Please upload a valid PDF, DOC, or DOCX file."));
        return;
      }
      cb(null, true);
    },
  }).single("resume");
}

const resumeUploadMiddleware = createResumeUploader();

function runResumeUpload(req: Request, res: Response): Promise<void> {
  return new Promise((resolve, reject) => {
    resumeUploadMiddleware(req, res, (err: any) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

function removeUploadedFile(file?: Express.Multer.File): void {
  if (file?.path && fs.existsSync(file.path)) {
    try {
      fs.unlinkSync(file.path);
    } catch {
      // Ignore cleanup errors
    }
  }
}

function hasValidResumeSignature(file: Express.Multer.File): boolean {
  try {
    if (!file.size || file.size <= 0) return false;
    const ext = path.extname(file.originalname || "").toLowerCase();
    const fd = fs.openSync(file.path, "r");
    const buf = Buffer.alloc(8);
    const bytesRead = fs.readSync(fd, buf, 0, 8, 0);
    fs.closeSync(fd);
    if (bytesRead < 2) return false;
    if (ext === ".pdf") {
      return buf.subarray(0, 4).toString("ascii") === "%PDF";
    }
    if (ext === ".docx") {
      return buf[0] === 0x50 && buf[1] === 0x4b; // PK zip header
    }
    if (ext === ".doc") {
      // OLE Compound File header OR RTF/DOC header
      const isOle = buf[0] === 0xd0 && buf[1] === 0xcf && buf[2] === 0x11 && buf[3] === 0xe0;
      const isRtf = buf.subarray(0, 5).toString("ascii") === "{\\rtf";
      return isOle || isRtf;
    }
    return false;
  } catch {
    return false;
  }
}

function parseListField(raw: unknown): string[] {
  if (Array.isArray(raw)) {
    return raw.map((x) => cleanText(x, 60)).filter(Boolean);
  }
  const str = String(raw || "").trim();
  if (!str) return [];
  if (str.startsWith("[")) {
    try {
      const parsed = JSON.parse(str);
      if (Array.isArray(parsed)) return parsed.map((x) => cleanText(x, 60)).filter(Boolean);
    } catch {
      // Fall through to CSV parsing
    }
  }
  return str
    .split(",")
    .map((x) => cleanText(x, 60))
    .filter(Boolean);
}

function getTeacherResumeSummary(db: DatabaseSync, userId: number) {
  const tp = db
    .prepare("SELECT resume_url, resume_filename, resume_status, resume_uploaded_at, resume_notes FROM teacher_profiles WHERE user_id = ?")
    .get(userId) as any;
  const hasFile = Boolean(tp?.resume_url);
  const status = tp?.resume_status || "missing";
  const valid = hasFile && ["submitted", "verified"].includes(status);
  return {
    hasResume: valid,
    resumeStatus: status,
    resumeFilename: tp?.resume_filename || "",
    resumeUploadedAt: tp?.resume_uploaded_at || null,
    resumeNotes: tp?.resume_notes || "",
    missingResumeMessage: valid ? "" : TEACHER_MISSING_RESUME_MSG,
  };
}

export function createAuthRouter(db: DatabaseSync): Router {
  const router = Router();

  router.get("/setup-status", (_req, res) => {
    const adminCount = (
      db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get() as { c: number }
    ).c;
    const requiresSetupKey = Boolean((process.env.YU_ADMIN_SETUP_KEY || "").trim());
    res.json({
      needsFirstAdminSetup: adminCount === 0,
      requiresSetupKey,
    });
  });

  router.post("/setup-admin", (req, res) => {
    const adminCount = (
      db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get() as { c: number }
    ).c;
    if (adminCount > 0) {
      res.status(409).json({ error: "Admin setup is already complete. Sign in via /admin/login.php." });
      return;
    }

    const ip = clientIp(req);
    const rl = checkRateLimit(db, `setup:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many setup attempts. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }

    const setupKey = cleanText(req.body?.setupKey, 200);
    if (!verifySetupKey(setupKey)) {
      recordRateLimitHit(db, `setup:${ip}`, 900);
      res.status(403).json({ error: "Invalid YU_ADMIN_SETUP_KEY. Configure the matching key in hosting environment variables." });
      return;
    }

    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");

    if (fullName.length < 2) {
      res.status(400).json({ error: "Enter full name (min 2 characters)." });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Enter a valid email address." });
      return;
    }
    if (!isValidIndianMobile(phone)) {
      res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number starting with 6–9." });
      return;
    }
    if (password.length < 8 || password.length > 200) {
      res.status(400).json({ error: "Password must be between 8 and 200 characters." });
      return;
    }

    const now = nowIso();
    const unsubToken = crypto.randomBytes(18).toString("hex");
    const result = db
      .prepare(
        `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', 1, 0, ?, ?, ?)`
      )
      .run(fullName, email, phone, hashPassword(password), unsubToken, now, now);

    const uid = Number(result.lastInsertRowid);
    clearRateLimit(db, `setup:${ip}`);
    writeAuditLog(db, {
      actorId: uid,
      actorName: fullName,
      targetId: uid,
      targetName: fullName,
      action: "first_admin_created",
      details: `Super Admin initialized (${email})`,
      ipAddress: ip,
    });

    const sid = createSession(db, uid);
    setSessionCookie(res, req, sid);
    res.status(201).json({ created: true, role: "super_admin" });
  });

  router.post("/register", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `reg:${ip}`, 10, 900, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many registration requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `reg:${ip}`, 900);

    if (req.is("multipart/form-data")) {
      try {
        await runResumeUpload(req, res);
      } catch (err: any) {
        removeUploadedFile(req.file);
        res.status(400).json({ error: err?.message || "Invalid resume file. Please upload a PDF, DOC, or DOCX up to 5 MB." });
        return;
      }
    }

    const role = String(req.body?.role || "student").toLowerCase() === "teacher" ? "teacher" : "student";
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");

    const fail = (status: number, error: string, extra?: Record<string, unknown>) => {
      removeUploadedFile(req.file);
      res.status(status).json({ error, ...(extra || {}) });
    };

    if (fullName.length < 2) {
      fail(400, "Please enter your full name.");
      return;
    }
    if (!isValidEmail(email)) {
      fail(400, "Please enter a valid email address.");
      return;
    }
    if (!isValidIndianMobile(phone)) {
      fail(400, "Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.");
      return;
    }
    if (password.length < 8 || password.length > 200) {
      fail(400, "Password must be at least 8 characters.");
      return;
    }

    if (role === "teacher") {
      if (!req.file || req.file.size === 0) {
        fail(400, TEACHER_MISSING_RESUME_MSG, { code: "RESUME_REQUIRED" });
        return;
      }
      if (!hasValidResumeSignature(req.file)) {
        fail(400, "The selected file could not be verified as a valid PDF, DOC, or DOCX resume. Please attach a valid resume file.", { code: "INVALID_RESUME_FORMAT" });
        return;
      }
    } else if (req.file) {
      removeUploadedFile(req.file);
    }

    const existing = db.prepare("SELECT id, verification_status FROM users WHERE email = ? OR phone = ?").get(email, phone) as
      | { id: number; verification_status: string }
      | undefined;

    if (existing) {
      fail(409, "An account already exists with this email or mobile number. Try signing in instead.");
      return;
    }

    const qualification = role === "teacher" ? cleanText(req.body?.qualification || "", 120) : "";
    if (role === "teacher" && qualification.length < 2) {
      fail(400, "Qualification is required for teacher registration.");
      return;
    }

    const now = nowIso();
    const unsubToken = crypto.randomBytes(18).toString("hex");
    const insertUser = db
      .prepare(
        `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 0, 'pending_otp', 1, 1, ?, ?, ?)`
      )
      .run(role, fullName, email, phone, hashPassword(password), unsubToken, now, now);

    const uid = Number(insertUser.lastInsertRowid);
    const subjects = parseListField(req.body?.subjects);

    if (role === "student") {
      const classLevel = cleanText(req.body?.classLevel || "Class 10", 60);
      const board = cleanText(req.body?.board || "CBSE", 40);
      const duration = Math.min(60, Math.max(1, Number(req.body?.courseDurationMonths || 12)));
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, enrollment_status)
         VALUES (?, ?, ?, ?, ?, 'pending')`
      ).run(uid, classLevel, board, JSON.stringify(subjects), duration);
    } else {
      const experienceYears = Math.min(50, Math.max(0, Number(req.body?.experienceYears || 0)));
      const assignedClasses = parseListField(req.body?.assignedClasses);
      const resumeFile = req.file!;
      db.prepare(
        `INSERT INTO teacher_profiles (
           user_id, qualification, experience_years, subjects_json, assigned_classes_json, availability_status,
           resume_url, resume_filename, resume_mime, resume_size, resume_status, resume_uploaded_at, resume_notes
         ) VALUES (?, ?, ?, ?, ?, 'available', ?, ?, ?, ?, 'submitted', ?, '')`
      ).run(
        uid,
        qualification,
        experienceYears,
        JSON.stringify(subjects),
        JSON.stringify(assignedClasses),
        `resumes/${resumeFile.filename}`,
        cleanText(resumeFile.originalname || resumeFile.filename, 180),
        cleanText(resumeFile.mimetype || "application/pdf", 120),
        Number(resumeFile.size || 0),
        now
      );
    }

    const { otp } = issueOtp(db, { userId: uid, phone, email, purpose: "registration" });
    const sms = await dispatchSmsOtp(phone, otp, "registration");

    writeAuditLog(db, {
      actorId: uid,
      actorName: fullName,
      targetId: uid,
      targetName: fullName,
      action: `${role}_registered`,
      details: role === "teacher"
        ? `Teacher registered with resume (${req.file?.originalname || "uploaded"}); OTP issued to ${phone}`
        : `OTP issued to ${phone} (SMS sent: ${sms.sent})`,
      ipAddress: ip,
    });

    res.status(201).json({
      registered: true,
      role,
      phone,
      smsSent: sms.sent,
      limitationNote: sms.sent ? "" : sms.note,
      resumeSubmitted: role === "teacher",
    });
  });

  router.post("/teacher-resume", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `resume:${ip}`, 10, 900, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many resume upload attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `resume:${ip}`, 900);

    try {
      await runResumeUpload(req, res);
    } catch (err: any) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: err?.message || "Invalid resume file. Upload PDF, DOC, or DOCX up to 5 MB." });
      return;
    }

    if (!req.file || req.file.size === 0) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: TEACHER_MISSING_RESUME_MSG, code: "RESUME_REQUIRED" });
      return;
    }
    if (!hasValidResumeSignature(req.file)) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: "Please attach a valid PDF, DOC, or DOCX resume file.", code: "INVALID_RESUME_FORMAT" });
      return;
    }

    let teacherUser: any = null;
    const ctx = getSessionContext(db, req);
    if (ctx && ctx.user.role === "teacher") {
      teacherUser = ctx.user;
    } else {
      const identifier = cleanText(req.body?.identifier, 254);
      const password = String(req.body?.password || "");
      const candidate = db
        .prepare("SELECT * FROM users WHERE role = 'teacher' AND (email = ? OR (phone != '' AND phone = ?)) LIMIT 1")
        .get(normalizeEmail(identifier), normalizePhone(identifier)) as any;
      if (!candidate || !verifyPassword(password, candidate.password_hash)) {
        removeUploadedFile(req.file);
        res.status(401).json({ error: "Please sign in as a registered teacher to upload your resume." });
        return;
      }
      teacherUser = candidate;
    }

    const existingTp = db.prepare("SELECT resume_url FROM teacher_profiles WHERE user_id = ?").get(teacherUser.id) as any;
    const oldResumeRel = existingTp?.resume_url ? String(existingTp.resume_url) : "";
    const now = nowIso();
    const resumeFile = req.file;
    const newRel = `resumes/${resumeFile.filename}`;

    db.prepare(
      `INSERT INTO teacher_profiles (
         user_id, resume_url, resume_filename, resume_mime, resume_size, resume_status, resume_uploaded_at, resume_notes
       ) VALUES (?, ?, ?, ?, ?, 'submitted', ?, '')
       ON CONFLICT(user_id) DO UPDATE SET
         resume_url = excluded.resume_url,
         resume_filename = excluded.resume_filename,
         resume_mime = excluded.resume_mime,
         resume_size = excluded.resume_size,
         resume_status = 'submitted',
         resume_uploaded_at = excluded.resume_uploaded_at,
         resume_notes = ''`
    ).run(
      teacherUser.id,
      newRel,
      cleanText(resumeFile.originalname || resumeFile.filename, 180),
      cleanText(resumeFile.mimetype || "application/pdf", 120),
      Number(resumeFile.size || 0),
      now
    );

    if (oldResumeRel && oldResumeRel !== newRel) {
      const oldFull = path.join(RESUMES_DIR, path.basename(oldResumeRel));
      if (oldFull.startsWith(RESUMES_DIR) && fs.existsSync(oldFull)) {
        try {
          fs.unlinkSync(oldFull);
        } catch {
          // Ignore old file removal error
        }
      }
    }

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `Teacher resume uploaded`,
      `${teacherUser.full_name} uploaded resume (${resumeFile.originalname || resumeFile.filename}) for verification.`,
      now
    );

    writeAuditLog(db, {
      actorId: teacherUser.id,
      actorName: teacherUser.full_name,
      targetId: teacherUser.id,
      targetName: teacherUser.full_name,
      action: "teacher_resume_uploaded",
      details: `Uploaded ${resumeFile.originalname || resumeFile.filename} (${resumeFile.size} bytes)`,
      ipAddress: clientIp(req),
    });

    res.json({
      uploaded: true,
      resumeFilename: cleanText(resumeFile.originalname || resumeFile.filename, 180),
      resumeStatus: "submitted",
      resumeUploadedAt: now,
    });
  });

  router.post("/verify-otp", async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    const otp = cleanText(req.body?.otp, 10);
    const ip = clientIp(req);

    const rl = checkRateLimit(db, `otpverify:${ip}:${phone}`, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP verification attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }

    if (!isValidIndianMobile(phone) || !/^\d{6}$/.test(otp)) {
      recordRateLimitHit(db, `otpverify:${ip}:${phone}`, 600);
      res.status(400).json({ error: "Enter a valid mobile number and 6-digit OTP." });
      return;
    }

    const check = verifyOtpToken(db, { target: phone, purpose: "registration", otp });
    if (!check.ok) {
      recordRateLimitHit(db, `otpverify:${ip}:${phone}`, 600);
      res.status(400).json({ error: check.error });
      return;
    }

    const user = db.prepare("SELECT * FROM users WHERE phone = ? OR id = ?").get(phone, check.tokenRow.user_id) as any;
    if (!user) {
      res.status(404).json({ error: "Account not found." });
      return;
    }

    const nextStatus = user.verification_status === "approved" ? "approved" : "pending_approval";
    db.prepare("UPDATE users SET mobile_verified = 1, verification_status = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      nowIso(),
      user.id
    );
    clearRateLimit(db, `otpverify:${ip}:${phone}`);

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New ${user.role} approval pending`,
      `${user.full_name} (${user.phone}) verified mobile OTP and is awaiting Yuitor Team approval.`,
      nowIso()
    );

    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "mobile_otp_verified",
      details: `Account moved to ${nextStatus}`,
      ipAddress: ip,
    });

    const notifyEmail = getAdminNotifyEmail();
    if (isSmtpConfigured() && notifyEmail) {
      void sendTransactionalEmail({
        to: notifyEmail,
        recipientName: "Yuitor Admissions Team",
        subject: `Pending ${user.role} approval: ${user.full_name}`,
        previewText: `${user.full_name} completed OTP verification and is awaiting review.`,
        htmlBody: `<p><strong>${escapeHtml(user.full_name)}</strong> (${escapeHtml(user.role)}, ${escapeHtml(user.phone)}, ${escapeHtml(user.email)}) completed mobile OTP verification and is awaiting admin approval.</p>`,
      });
    }
    if (isSmtpConfigured() && user.email) {
      const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
      void sendTransactionalEmail({
        to: user.email,
        recipientName: user.full_name || "Applicant",
        subject: "Registration & Mobile Verification Received — Yuitor Smart Classes",
        previewText: "Your mobile number is verified and your Yuitor account is pending team approval.",
        htmlBody: `<p>Dear {{name}},</p><p>${escapeHtml(BRAND_PENDING_MSG)}</p><p>Once approved by our team, you can sign in with your registered email or mobile number.</p>`,
        ctaLabel: "Open Portal Login",
        ctaUrl: `${siteUrl}/login`,
      });
    }

    res.json({
      verified: true,
      verificationStatus: nextStatus,
      pendingMessage: BRAND_PENDING_MSG,
    });
  });

  router.post("/resend-otp", async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    const ip = clientIp(req);
    if (!isValidIndianMobile(phone)) {
      res.status(400).json({ error: "Valid 10-digit mobile number is required." });
      return;
    }

    const rl = checkRateLimit(db, `otpresend:${ip}:${phone}`, 4, 3600, 900);
    if (!rl.allowed) {
      res.status(429).json({ error: `OTP resend limit reached. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }

    const user = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone) as any;
    if (!user) {
      res.status(404).json({ error: "No registration found for this mobile number." });
      return;
    }

    const latest = db
      .prepare("SELECT created_at FROM otp_tokens WHERE phone = ? AND purpose = 'registration' ORDER BY id DESC LIMIT 1")
      .get(phone) as { created_at: number } | undefined;
    const nowSec = Math.floor(Date.now() / 1000);
    if (latest && nowSec - latest.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latest.created_at)}s before requesting another OTP.` });
      return;
    }

    recordRateLimitHit(db, `otpresend:${ip}:${phone}`, 3600);
    const { otp } = issueOtp(db, { userId: user.id, phone, email: user.email, purpose: "registration" });
    const sms = await dispatchSmsOtp(phone, otp, "verification");

    res.json({
      resent: true,
      smsSent: sms.sent,
      limitationNote: sms.sent ? "" : sms.note,
    });
  });

  router.post("/login", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const password = String(req.body?.password || "");
    const ip = clientIp(req);
    const rateKey = `login:${ip}:${identifier.toLowerCase()}`;

    const rl = checkRateLimit(db, rateKey, 6, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many failed sign-in attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }

    if (!identifier || !password) {
      res.status(400).json({ error: "Enter both email/mobile and password." });
      return;
    }

    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db
      .prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1")
      .get(normalizedEmail, normalizedPhone) as any;

    const dummyHash = "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";
    const ok = verifyPassword(password, user ? user.password_hash : dummyHash);
    if (!user || !ok) {
      recordRateLimitHit(db, rateKey, 900);
      res.status(401).json({ error: "Incorrect email/mobile or password." });
      return;
    }

    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }

    const teacherResume = user.role === "teacher" ? getTeacherResumeSummary(db, Number(user.id)) : null;

    if (user.verification_status === "pending_otp") {
      res.json({
        authenticated: false,
        role: user.role,
        verificationStatus: "pending_otp",
        phone: user.phone,
        teacherResume,
      });
      return;
    }

    if (user.verification_status === "pending_approval" || user.verification_status === "otp_verified") {
      res.json({
        authenticated: false,
        role: user.role,
        verificationStatus: user.verification_status,
        pendingMessage: BRAND_PENDING_MSG,
        teacherResume,
      });
      return;
    }

    clearRateLimit(db, rateKey);
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    const sid = createSession(db, Number(user.id));
    setSessionCookie(res, req, sid);

    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "login_success",
      details: `${user.role} signed in`,
      ipAddress: ip,
    });

    res.json({
      authenticated: true,
      role: user.role,
      verificationStatus: user.verification_status,
      resumeRequired: Boolean(user.role === "teacher" && !teacherResume?.hasResume),
      teacherResume,
    });
  });

  router.post("/logout", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (ctx) {
      db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    }
    clearSessionCookie(res);
    res.json({ loggedOut: true });
  });

  router.get("/me", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.json({ authenticated: false, user: null });
      return;
    }
    const isPending = ctx.user.verification_status !== "approved";
    const teacherResume = ctx.user.role === "teacher" ? getTeacherResumeSummary(db, ctx.user.id) : null;
    res.json({
      authenticated: true,
      user: ctx.user,
      impersonation: ctx.impersonation,
      pendingMessage: isPending ? BRAND_PENDING_MSG : undefined,
      teacherResume,
    });
  });

  router.post("/forgot-password", async (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `forgot:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many reset requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `forgot:${ip}`, 900);

    const user = db
      .prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1")
      .get(normalizeEmail(identifier), normalizePhone(identifier)) as any;

    if (!user) {
      res.json({
        message: "If an account matches that email or mobile number, a 6-digit reset OTP has been generated.",
        limitationNote: "If no SMS/SMTP provider is configured, contact Yuitor Team at +91 78-2728-9292.",
      });
      return;
    }

    const latestReset = db
      .prepare("SELECT created_at FROM otp_tokens WHERE user_id = ? AND purpose = 'password_reset' ORDER BY id DESC LIMIT 1")
      .get(user.id) as { created_at: number } | undefined;
    const nowSec = Math.floor(Date.now() / 1000);
    if (latestReset && nowSec - latestReset.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latestReset.created_at)}s before requesting another reset OTP.` });
      return;
    }

    const { otp } = issueOtp(db, {
      userId: user.id,
      phone: user.phone,
      email: user.email,
      purpose: "password_reset",
    });

    let note = "";
    if (user.phone && isValidIndianMobile(user.phone)) {
      const sms = await dispatchSmsOtp(user.phone, otp, "password reset");
      if (!sms.sent) note = sms.note;
    }
    if (isSmtpConfigured() && user.email) {
      void sendTransactionalEmail({
        to: user.email,
        recipientName: user.full_name || "Member",
        subject: "Yuitor Smart Classes — Password Reset OTP",
        previewText: "Use this 6-digit OTP within 10 minutes to reset your password.",
        htmlBody: `<p>Hello {{name}},</p><p>Your 6-digit password reset OTP is <strong style="font-size:18px;letter-spacing:2px;">${escapeHtml(otp)}</strong>.</p><p>This code expires in 10 minutes. If you did not request a password reset, please ignore this email.</p>`,
      });
    }

    res.json({
      message: "6-digit password reset OTP dispatched.",
      limitationNote: note,
    });
  });

  router.post("/reset-password", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const otp = cleanText(req.body?.otp, 10);
    const newPassword = String(req.body?.newPassword || "");
    const ip = clientIp(req);
    const resetRlKey = `resetpw:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, resetRlKey, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many password reset attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }

    if (newPassword.length < 8 || newPassword.length > 200) {
      res.status(400).json({ error: "New password must be at least 8 characters." });
      return;
    }

    const user = db
      .prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1")
      .get(normalizeEmail(identifier), normalizePhone(identifier)) as any;
    if (!user) {
      recordRateLimitHit(db, resetRlKey, 600);
      res.status(400).json({ error: "Invalid OTP or account." });
      return;
    }

    const target = user.phone || user.email;
    const check = verifyOtpToken(db, { target, purpose: "password_reset", otp });
    if (!check.ok) {
      recordRateLimitHit(db, resetRlKey, 600);
      res.status(400).json({ error: check.error });
      return;
    }

    clearRateLimit(db, resetRlKey);
    db.prepare("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?").run(
      hashPassword(newPassword),
      nowIso(),
      user.id
    );
    // Invalidate existing sessions after password change
    db.prepare("DELETE FROM sessions WHERE user_id = ?").run(user.id);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "password_reset",
      details: "Password reset via OTP",
      ipAddress: ip,
    });

    res.json({ message: "Password updated successfully. You can now sign in." });
  });

  router.patch("/avatar", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required." });
      return;
    }
    const avatarUrl = sanitizeHttpOrUploadUrl(req.body?.avatarUrl, 300);
    if (!avatarUrl.startsWith("/uploads/")) {
      res.status(400).json({ error: "Invalid uploaded avatar path." });
      return;
    }
    db.prepare("UPDATE users SET avatar_url = ?, updated_at = ? WHERE id = ?").run(avatarUrl, nowIso(), ctx.user.id);
    res.json({ updated: true, avatarUrl });
  });

  router.post("/exit-impersonation", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || !ctx.impersonation.active || !ctx.impersonation.adminId) {
      res.status(400).json({ error: "No active impersonation session." });
      return;
    }

    const adminId = ctx.impersonation.adminId;
    db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    db.prepare(
      `UPDATE impersonation_logs SET ended_at = ?
       WHERE id = (SELECT id FROM impersonation_logs WHERE admin_id = ? AND target_user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1)`
    ).run(nowIso(), adminId, ctx.user.id);

    const newSid = createSession(db, adminId);
    setSessionCookie(res, req, newSid);

    writeAuditLog(db, {
      actorId: adminId,
      actorName: "Admin",
      targetId: ctx.user.id,
      targetName: ctx.user.full_name,
      action: "impersonation_ended",
      details: "Exited troubleshooting view",
      ipAddress: clientIp(req),
    });

    res.json({ redirectTo: "/admin/" });
  });

  return router;
}
