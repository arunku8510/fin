import { Router } from "express";
import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import {
  checkRateLimit,
  cleanText,
  clientIp,
  escapeHtml,
  getSessionContext,
  nowIso,
  recordRateLimitHit,
  writeAuditLog,
} from "../security.js";
import { sendTransactionalEmail } from "../mailer.js";

export function verifyRazorpaySignature(
  orderId: string,
  paymentId: string,
  signature: string,
  secret: string
): boolean {
  if (!orderId || !paymentId || !paymentId.trim() || !signature || !secret) return false;
  const expectedSig = crypto.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function verifyRazorpayWebhookSignature(
  payloadBody: string,
  signature: string,
  webhookSecret: string
): boolean {
  if (!payloadBody || !signature || !webhookSecret) return false;
  const expectedSig = crypto.createHmac("sha256", webhookSecret).update(payloadBody).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export async function testRazorpayConnection(): Promise<{ ok: true; message: string } | { ok: false; error: string }> {
  const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
  const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keyId || !keySecret) {
    return { ok: false, error: "Save both RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET first before testing." };
  }
  try {
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const resp = await fetch("https://api.razorpay.com/v1/orders?count=1", {
      method: "GET",
      headers: { Authorization: `Basic ${auth}` },
      signal: AbortSignal.timeout(12000),
    });
    const data = (await resp.json()) as any;
    if (resp.ok) {
      const mode = keyId.startsWith("rzp_live_") ? "LIVE" : "SANDBOX / TEST";
      return { ok: true, message: `Razorpay ${mode} credentials verified successfully.` };
    }
    return { ok: false, error: data?.error?.description || `Razorpay API returned status ${resp.status}.` };
  } catch (err: any) {
    return { ok: false, error: err?.message || "Unable to reach Razorpay API." };
  }
}

function runInTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec("BEGIN IMMEDIATE;");
  try {
    const result = fn();
    db.exec("COMMIT;");
    return result;
  } catch (err) {
    try {
      db.exec("ROLLBACK;");
    } catch {
      // Ignore rollback error
    }
    throw err;
  }
}

function sendVerifiedPaymentReceiptEmail(db: DatabaseSync, studentId: number, courseTitle: string, amount: number, receiptNumber: string): void {
  const student = db.prepare("SELECT full_name, email FROM users WHERE id = ?").get(studentId) as
    | { full_name: string; email: string }
    | undefined;
  if (!student?.email) return;
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  void sendTransactionalEmail({
    to: student.email,
    recipientName: student.full_name || "Student",
    subject: `Fee Receipt ${receiptNumber} — Yuitor Smart Classes`,
    previewText: `Payment of ₹${amount} verified for ${courseTitle}.`,
    htmlBody: `<p>Dear {{name}},</p><p>Your payment of <strong>₹${escapeHtml(amount)}</strong> for <strong>${escapeHtml(courseTitle)}</strong> has been verified successfully.</p><p><strong>Official Receipt No.:</strong> ${escapeHtml(receiptNumber)}<br>Your course lessons and materials are now active in your Student Portal.</p>`,
    ctaLabel: "Open Student Portal",
    ctaUrl: `${siteUrl}/student/`,
  });
}

export function createPaymentsRouter(db: DatabaseSync): Router {
  const router = Router();

  router.get("/config", (_req, res) => {
    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    const razorpayEnabled = Boolean(keyId && keySecret);
    res.json({
      razorpayEnabled,
      mode: keyId.startsWith("rzp_live_") ? "live" : razorpayEnabled ? "sandbox" : "unconfigured",
      keyId: razorpayEnabled ? keyId : "",
    });
  });

  router.post("/create-order", async (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required." });
      return;
    }

    const ip = clientIp(req);
    const rl = checkRateLimit(db, `payorder:${ip}:${ctx.user.id}`, 10, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many payment order requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `payorder:${ip}:${ctx.user.id}`, 300);

    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    if (!keyId || !keySecret) {
      res.status(503).json({ error: "Razorpay credentials are not configured on the server yet." });
      return;
    }

    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId) as any;
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }

    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;
    const today = nowIso().slice(0, 10);
    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode) as any;
      if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses) || (coupon.expires_at && coupon.expires_at < today)) {
        res.status(400).json({ error: "Invalid or expired coupon code." });
        return;
      }
      discountAmount =
        coupon.discount_type === "percent"
          ? Math.round((baseAmount * Number(coupon.discount_value)) / 100)
          : Math.min(baseAmount, Number(coupon.discount_value));
    }
    const finalAmount = Math.max(1, baseAmount - discountAmount);

    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
      const resp = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: finalAmount * 100,
          currency: "INR",
          receipt: `ytr_${ctx.user.id}_${courseId}_${Date.now()}`.slice(0, 40),
          notes: {
            studentId: String(ctx.user.id),
            courseId: String(courseId),
            plan,
          },
        }),
        signal: AbortSignal.timeout(12000),
      });
      const order = (await resp.json()) as any;
      if (!resp.ok || !order?.id) {
        res.status(502).json({ error: order?.error?.description || "Unable to create Razorpay order." });
        return;
      }

      const now = nowIso();
      const months = plan === "yearly" ? 12 : 1;
      const expiresDate = new Date();
      expiresDate.setMonth(expiresDate.getMonth() + months);
      const expiresAt = expiresDate.toISOString().slice(0, 10);
      const invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;

      runInTransaction(db, () => {
        const existingEnrollment = db
          .prepare("SELECT id, status FROM enrollments WHERE student_id = ? AND course_id = ?")
          .get(ctx.user.id, courseId) as { id: number; status: string } | undefined;
        let enrollmentId: number;
        if (existingEnrollment) {
          enrollmentId = Number(existingEnrollment.id);
        } else {
          const ins = db
            .prepare(
              `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
               VALUES (?, ?, ?, 'pending', 0, 0, ?, ?)`
            )
            .run(ctx.user.id, courseId, plan, expiresAt, now);
          enrollmentId = Number(ins.lastInsertRowid);
        }

        db.prepare(
          `INSERT INTO payments
           (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
            gateway_order_id, verification_status, invoice_number, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'gateway', ?, 'pending_verification', ?, ?)`
        ).run(ctx.user.id, courseId, enrollmentId, plan, baseAmount, discountAmount, finalAmount, couponCode, order.id, invoiceNumber, now);

        db.prepare(
          `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
           VALUES (?, ?, ?, ?, ?, 0, ?, 'pending', ?)`
        ).run(ctx.user.id, courseId, `${course.title} (${plan})`, baseAmount, discountAmount, now.slice(0, 10), now);
      });

      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: courseId,
        targetName: course.title,
        action: "razorpay_order_created",
        details: `Order ${order.id} for ₹${finalAmount} (${plan})`,
        ipAddress: ip,
      });

      res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId, invoiceNumber });
    } catch (err: any) {
      res.status(502).json({ error: err?.message || "Razorpay order creation failed." });
    }
  });

  router.post("/order-failed", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const orderId = cleanText(req.body?.orderId, 100);
    const reason = cleanText(req.body?.reason || "Cancelled or failed in Razorpay Checkout", 300);
    if (!orderId) {
      res.status(400).json({ error: "Order ID required." });
      return;
    }

    const row = db
      .prepare("SELECT id, verification_status FROM payments WHERE gateway_order_id = ? AND student_id = ? ORDER BY id DESC LIMIT 1")
      .get(orderId, ctx.user.id) as { id: number; verification_status: string } | undefined;
    if (!row) {
      res.status(404).json({ error: "Pending payment order not found." });
      return;
    }
    if (row.verification_status === "pending_verification") {
      db.prepare("UPDATE payments SET verification_status = 'failed' WHERE id = ?").run(row.id);
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: row.id,
        targetName: orderId,
        action: "razorpay_payment_failed_or_cancelled",
        details: reason,
        ipAddress: clientIp(req),
      });
    }
    res.json({ updated: true });
  });

  router.post("/webhook", (req, res) => {
    const webhookSecret = (process.env.RAZORPAY_WEBHOOK_SECRET || "").trim();
    const signature = String(req.headers["x-razorpay-signature"] || "");
    if (!webhookSecret) {
      res.status(503).json({ error: "RAZORPAY_WEBHOOK_SECRET is not configured." });
      return;
    }
    const rawBody = typeof (req as any).rawBody === "string" ? (req as any).rawBody : JSON.stringify(req.body || {});
    if (!verifyRazorpayWebhookSignature(rawBody, signature, webhookSecret)) {
      res.status(400).json({ error: "Invalid Razorpay webhook signature." });
      return;
    }

    const event = String(req.body?.event || "");
    const paymentEntity = req.body?.payload?.payment?.entity;
    const orderId = cleanText(paymentEntity?.order_id || req.body?.payload?.order?.entity?.id || "", 100);
    const paymentId = cleanText(paymentEntity?.id || "", 100);

    if ((event === "payment.captured" || event === "order.paid") && (orderId || paymentId)) {
      const outcome = runInTransaction(db, () => {
        if (paymentId) {
          const alreadyByPay = db
            .prepare("SELECT id FROM payments WHERE gateway_payment_id = ? AND verification_status = 'verified' LIMIT 1")
            .get(paymentId);
          if (alreadyByPay) {
            return { updated: false, duplicate: true as const };
          }
        }
        const row = orderId
          ? (db
              .prepare(
                `SELECT p.*, c.title as course_title
                 FROM payments p
                 LEFT JOIN courses c ON c.id = p.course_id
                 WHERE p.gateway_order_id = ? ORDER BY p.id DESC LIMIT 1`
              )
              .get(orderId) as any)
          : null;
        if (!row) {
          return { updated: false, duplicate: false as const };
        }
        if (row.verification_status === "verified") {
          return { updated: false, duplicate: true as const };
        }
        const now = nowIso();
        const receiptNumber = row.receipt_number || `YTR-RCP-${Date.now().toString().slice(-6)}`;
        db.prepare(
          "UPDATE payments SET verification_status = 'verified', gateway_payment_id = COALESCE(NULLIF(?, ''), gateway_payment_id), receipt_number = ?, paid_at = ? WHERE id = ?"
        ).run(paymentId, receiptNumber, now, row.id);
        if (row.enrollment_id) {
          db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(row.enrollment_id);
        }
        db.prepare(
          `UPDATE fee_records SET status = 'paid', paid_amount = ?
           WHERE id = (SELECT id FROM fee_records WHERE student_id = ? AND course_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1)`
        ).run(row.amount, row.student_id, row.course_id);
        if (row.coupon_code) {
          db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE code = ? AND used_count < max_uses").run(row.coupon_code);
        }
        writeAuditLog(db, {
          actorId: row.student_id,
          actorName: "Razorpay Webhook",
          targetId: row.id,
          targetName: orderId,
          action: "razorpay_webhook_verified",
          details: `Event ${event} verified payment ${paymentId || orderId} (₹${row.amount})`,
          ipAddress: clientIp(req),
        });
        return {
          updated: true,
          duplicate: false as const,
          studentId: Number(row.student_id),
          courseTitle: row.course_title || "Course",
          amount: Number(row.amount),
          receiptNumber,
        };
      });

      if (outcome.updated && outcome.studentId) {
        sendVerifiedPaymentReceiptEmail(db, outcome.studentId, outcome.courseTitle, outcome.amount, outcome.receiptNumber);
      }
      res.json({ ok: true, duplicate: outcome.duplicate });
      return;
    }

    if (event === "payment.failed" && orderId) {
      runInTransaction(db, () => {
        const row = db
          .prepare("SELECT id, student_id, verification_status FROM payments WHERE gateway_order_id = ? ORDER BY id DESC LIMIT 1")
          .get(orderId) as any;
        if (row && row.verification_status === "pending_verification") {
          db.prepare(
            "UPDATE payments SET verification_status = 'failed', gateway_payment_id = COALESCE(NULLIF(?, ''), gateway_payment_id) WHERE id = ?"
          ).run(paymentId, row.id);
          writeAuditLog(db, {
            actorId: row.student_id,
            actorName: "Razorpay Webhook",
            targetId: row.id,
            targetName: orderId,
            action: "razorpay_webhook_failed",
            details: cleanText(paymentEntity?.error_description || "Payment failed", 250),
            ipAddress: clientIp(req),
          });
        }
      });
    }

    res.json({ ok: true });
  });

  router.post("/enroll", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required to enroll." });
      return;
    }

    const ip = clientIp(req);
    const rl = checkRateLimit(db, `enroll:${ip}:${ctx.user.id}`, 10, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many enrollment attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `enroll:${ip}:${ctx.user.id}`, 300);

    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = cleanText(req.body?.utrReference, 80);
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const gOrder = cleanText(req.body?.gatewayOrderId, 100);
    const gPay = cleanText(req.body?.gatewayPaymentId, 100);
    const gSig = cleanText(req.body?.gatewaySignature, 200);

    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId) as any;
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }

    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
      if (rzpSecret && (gOrder || gPay || gSig)) {
        if (!verifyRazorpaySignature(gOrder, gPay, gSig, rzpSecret)) {
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
      }
    }

    const txOutcome = runInTransaction(db, () => {
      // Idempotency / duplicate payment guard
      if (paymentMethod === "gateway" && gPay) {
        const dupByPay = db
          .prepare("SELECT id, verification_status, invoice_number, receipt_number, amount FROM payments WHERE gateway_payment_id = ? LIMIT 1")
          .get(gPay) as any;
        if (dupByPay && dupByPay.verification_status === "verified") {
          return {
            statusCode: 200 as const,
            body: {
              enrolled: true,
              duplicatePrevented: true,
              verificationStatus: dupByPay.verification_status,
              invoiceNumber: dupByPay.invoice_number,
              receiptNumber: dupByPay.receipt_number,
              amount: Number(dupByPay.amount),
              message: "Payment already verified! Your enrollment and fee receipt are active.",
            },
          };
        }
      }

      const existingOrderRow =
        paymentMethod === "gateway" && gOrder
          ? (db
              .prepare("SELECT * FROM payments WHERE gateway_order_id = ? AND student_id = ? ORDER BY id DESC LIMIT 1")
              .get(gOrder, ctx.user.id) as any)
          : null;

      if (existingOrderRow && existingOrderRow.verification_status === "verified") {
        return {
          statusCode: 200 as const,
          body: {
            enrolled: true,
            duplicatePrevented: true,
            verificationStatus: existingOrderRow.verification_status,
            invoiceNumber: existingOrderRow.invoice_number,
            receiptNumber: existingOrderRow.receipt_number,
            amount: Number(existingOrderRow.amount),
            message: "Payment already verified! Your enrollment and fee receipt are active.",
          },
        };
      }

      const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
      let discountAmount = 0;
      const today = nowIso().slice(0, 10);

      if (couponCode) {
        const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode) as any;
        if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses) || (coupon.expires_at && coupon.expires_at < today)) {
          return { statusCode: 400 as const, body: { error: "Invalid or expired coupon code." } };
        }
        discountAmount =
          coupon.discount_type === "percent"
            ? Math.round((baseAmount * Number(coupon.discount_value)) / 100)
            : Math.min(baseAmount, Number(coupon.discount_value));
        db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(coupon.id);
      }

      const finalAmount = existingOrderRow ? Number(existingOrderRow.amount) : Math.max(0, baseAmount - discountAmount);
      const now = nowIso();
      const months = plan === "yearly" ? 12 : 1;
      const expiresDate = new Date();
      expiresDate.setMonth(expiresDate.getMonth() + months);
      const expiresAt = expiresDate.toISOString().slice(0, 10);

      let verificationStatus: "pending_verification" | "verified" | "failed" = "pending_verification";
      let receiptNumber = "";
      let paidAt: string | null = null;
      let enrollmentStatus: "pending" | "active" = "pending";
      let message = "";

      if (paymentMethod === "gateway") {
        const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
        if (rzpSecret && gOrder && gPay && gSig) {
          verificationStatus = "verified";
          enrollmentStatus = "active";
          paidAt = now;
          receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
          message = "Gateway signature verified! Your enrollment and fee receipt are now active.";
        } else {
          message =
            "Online payment gateway credentials (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) are not configured on this server. Enrollment saved as Pending Verification — submit UTR or pay at the Muradnagar desk.";
        }
      } else {
        message = "Enrollment submitted! Your payment is marked Pending Verification until confirmed by the Yuitor Team.";
      }

      db.prepare(
        `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
         VALUES (?, ?, ?, ?, 0, 0, ?, ?)
         ON CONFLICT(student_id, course_id) DO UPDATE SET
           plan = excluded.plan,
           status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
           expires_at = excluded.expires_at`
      ).run(ctx.user.id, courseId, plan, enrollmentStatus, expiresAt, now);

      const enrollment = db
        .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?")
        .get(ctx.user.id, courseId) as { id: number };

      let invoiceNumber = "";
      if (existingOrderRow) {
        invoiceNumber = existingOrderRow.invoice_number;
        db.prepare(
          `UPDATE payments
           SET enrollment_id = ?, gateway_payment_id = ?, gateway_signature = ?, verification_status = ?, receipt_number = ?, paid_at = ?
           WHERE id = ?`
        ).run(enrollment.id, gPay, gSig, verificationStatus, receiptNumber, paidAt, existingOrderRow.id);

        if (verificationStatus === "verified") {
          db.prepare(
            `UPDATE fee_records SET status = 'paid', paid_amount = ?
             WHERE id = (SELECT id FROM fee_records WHERE student_id = ? AND course_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1)`
          ).run(finalAmount, ctx.user.id, courseId);
        }
      } else {
        invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
        db.prepare(
          `INSERT INTO payments
           (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
            utr_reference, gateway_order_id, gateway_payment_id, gateway_signature, verification_status, invoice_number, receipt_number, paid_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          ctx.user.id,
          courseId,
          enrollment.id,
          plan,
          baseAmount,
          discountAmount,
          finalAmount,
          couponCode,
          paymentMethod,
          utrReference,
          gOrder,
          gPay,
          gSig,
          verificationStatus,
          invoiceNumber,
          receiptNumber,
          paidAt,
          now
        );

        db.prepare(
          `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          ctx.user.id,
          courseId,
          `${course.title} (${plan})`,
          baseAmount,
          discountAmount,
          verificationStatus === "verified" ? finalAmount : 0,
          now.slice(0, 10),
          verificationStatus === "verified" ? "paid" : "pending",
          now
        );
      }

      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
      ).run(
        `New Enrollment Payment (${paymentMethod.toUpperCase()})`,
        `${ctx.user.full_name} enrolled in ${course.title} (₹${finalAmount}, ${verificationStatus}).`,
        now
      );

      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: courseId,
        targetName: course.title,
        action: "enrollment_submitted",
        details: `${plan} ₹${finalAmount} (${verificationStatus})`,
        ipAddress: ip,
      });

      return {
        statusCode: 201 as const,
        body: {
          enrolled: true,
          verificationStatus,
          invoiceNumber,
          receiptNumber,
          amount: finalAmount,
          message,
        },
        sendReceipt: verificationStatus === "verified",
      };
    });

    if (txOutcome.statusCode === 201 && (txOutcome as any).sendReceipt) {
      sendVerifiedPaymentReceiptEmail(
        db,
        ctx.user.id,
        course.title,
        Number(txOutcome.body.amount),
        String(txOutcome.body.receiptNumber || "")
      );
    }

    res.status(txOutcome.statusCode).json(txOutcome.body);
  });

  router.post("/refund-request", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const paymentId = Number(req.body?.paymentId);
    const reason = cleanText(req.body?.reason, 500);
    if (reason.length < 5) {
      res.status(400).json({ error: "Provide a refund reason (min 5 characters)." });
      return;
    }

    const pay = db.prepare("SELECT * FROM payments WHERE id = ? AND student_id = ?").get(paymentId, ctx.user.id) as any;
    if (!pay || pay.verification_status !== "verified") {
      res.status(404).json({ error: "Verified payment record not found." });
      return;
    }

    db.prepare("UPDATE payments SET refund_status = 'requested', refund_reason = ? WHERE id = ?").run(reason, paymentId);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run("Refund Request", `${ctx.user.full_name} requested refund for payment #${paymentId}: ${reason}`, nowIso());

    res.json({ requested: true });
  });

  return router;
}

