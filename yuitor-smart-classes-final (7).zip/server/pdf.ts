import zlib from "node:zlib";
import fs from "node:fs";
import type { DatabaseSync } from "node:sqlite";

function decodePdfLiteralString(raw: string): string {
  let out = "";
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch === "\\" && i + 1 < raw.length) {
      const nxt = raw[++i];
      if (nxt === "n") out += "\n";
      else if (nxt === "r") out += "\r";
      else if (nxt === "t") out += "\t";
      else if (nxt === "b") out += "\b";
      else if (nxt === "f") out += "\f";
      else if (nxt === "(" || nxt === ")" || nxt === "\\") out += nxt;
      else if (/[0-7]/.test(nxt)) {
        let oct = nxt;
        if (i + 1 < raw.length && /[0-7]/.test(raw[i + 1])) oct += raw[++i];
        if (i + 1 < raw.length && /[0-7]/.test(raw[i + 1])) oct += raw[++i];
        out += String.fromCharCode(parseInt(oct, 8));
      } else {
        out += nxt;
      }
    } else {
      out += ch;
    }
  }
  return out;
}

function decodePdfHexString(hexRaw: string): string {
  const hex = hexRaw.replace(/[^0-9a-fA-F]/g, "");
  if (!hex || hex.length < 2) return "";
  const padded = hex.length % 2 === 1 ? hex + "0" : hex;
  const bytes = Buffer.from(padded, "hex");
  // Handle UTF-16BE BOM or null-interleaved ASCII
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    let s = "";
    for (let i = 2; i + 1 < bytes.length; i += 2) {
      s += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
    }
    return s;
  }
  return bytes
    .toString("latin1")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
}

function extractTextOperatorsFromStream(content: string): string[] {
  const chunks: string[] = [];
  // Extract BT ... ET text blocks or standalone Tj / TJ operators
  const litRe = /\(((?:\\.|[^\\()])*)\)\s*(?:Tj|'|")/g;
  let m: RegExpExecArray | null;
  while ((m = litRe.exec(content)) !== null) {
    const t = decodePdfLiteralString(m[1]).trim();
    if (t) chunks.push(t);
  }

  const tjArrayRe = /\[([\s\S]*?)\]\s*TJ/g;
  while ((m = tjArrayRe.exec(content)) !== null) {
    const inner = m[1];
    const parts: string[] = [];
    const tokenRe = /\(((?:\\.|[^\\()])*)\)|<([0-9a-fA-F\s]+)>/g;
    let tm: RegExpExecArray | null;
    while ((tm = tokenRe.exec(inner)) !== null) {
      if (tm[1] !== undefined) parts.push(decodePdfLiteralString(tm[1]));
      else if (tm[2] !== undefined) parts.push(decodePdfHexString(tm[2]));
    }
    const joined = parts.join("").trim();
    if (joined) chunks.push(joined);
  }

  const hexTjRe = /<([0-9a-fA-F\s]+)>\s*Tj/g;
  while ((m = hexTjRe.exec(content)) !== null) {
    const t = decodePdfHexString(m[1]).trim();
    if (t) chunks.push(t);
  }

  return chunks;
}

export function extractTextFromPdfBuffer(buf: Buffer): string {
  if (!buf || buf.length === 0) return "";
  const rawLatin = buf.toString("latin1");
  const pieces: string[] = [];

  // Process all PDF stream ... endstream blocks (compressed and uncompressed)
  const streamRe = /stream\r?\n([\s\S]*?)\r?\n?endstream/g;
  let match: RegExpExecArray | null;
  while ((match = streamRe.exec(rawLatin)) !== null) {
    const headerStart = Math.max(0, match.index - 320);
    const dictSlice = rawLatin.slice(headerStart, match.index);
    const rawStreamBytes = Buffer.from(match[1], "latin1");
    let decoded = "";

    if (/\/FlateDecode/i.test(dictSlice)) {
      try {
        decoded = zlib.inflateSync(rawStreamBytes).toString("latin1");
      } catch {
        try {
          decoded = zlib.inflateRawSync(rawStreamBytes).toString("latin1");
        } catch {
          decoded = "";
        }
      }
    } else {
      decoded = match[1];
    }

    if (decoded) {
      pieces.push(...extractTextOperatorsFromStream(decoded));
    }
  }

  // Fallback for uncompressed top-level text operators
  if (pieces.length === 0) {
    pieces.push(...extractTextOperatorsFromStream(rawLatin));
  }

  return pieces
    .join(" ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60000);
}

export function extractTextFromDocumentFile(filePath: string, mimeOrExt: string): string {
  const buf = fs.readFileSync(filePath);
  const hint = mimeOrExt.toLowerCase();
  if (hint.includes("pdf") || filePath.toLowerCase().endsWith(".pdf")) {
    return extractTextFromPdfBuffer(buf);
  }
  // Plain text / markdown / CSV fallback
  return buf
    .toString("utf8")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60000);
}

export interface DocumentSnippet {
  sourceTitle: string;
  excerpt: string;
  score: number;
}

export function retrieveRelevantDocumentSnippets(
  db: DatabaseSync,
  query: string,
  maxSnippets = 4
): DocumentSnippet[] {
  const qWords = Array.from(
    new Set(
      String(query || "")
        .toLowerCase()
        .split(/[^a-z0-9\u0900-\u097F]+/)
        .filter((w) => w.length >= 3)
    )
  );

  const candidates: Array<{ title: string; text: string }> = [];

  try {
    const docs = db
      .prepare("SELECT title, extracted_text FROM knowledge_documents WHERE is_active = 1 AND extracted_text != '' ORDER BY id DESC LIMIT 30")
      .all() as Array<{ title: string; extracted_text: string }>;
    for (const d of docs) {
      candidates.push({ title: d.title, text: d.extracted_text });
    }
  } catch {
    // Table may not exist in older unit-test fixtures
  }

  try {
    const lessons = db
      .prepare(
        `SELECT l.title, l.content, c.title as course_title
         FROM lessons l
         JOIN courses c ON c.id = l.course_id
         WHERE l.is_visible = 1 AND l.content != ''
         ORDER BY l.id DESC LIMIT 40`
      )
      .all() as Array<{ title: string; content: string; course_title: string }>;
    for (const l of lessons) {
      candidates.push({ title: `${l.course_title} — ${l.title}`, text: l.content });
    }
  } catch {
    // Ignore if lessons table absent in minimal test fixture
  }

  try {
    const posts = db
      .prepare("SELECT title, excerpt, content FROM blog_posts WHERE is_published = 1 ORDER BY id DESC LIMIT 20")
      .all() as Array<{ title: string; excerpt: string; content: string }>;
    for (const p of posts) {
      candidates.push({ title: `Blog: ${p.title}`, text: `${p.excerpt} ${p.content}`.trim() });
    }
  } catch {
    // Ignore if blog_posts absent
  }

  if (candidates.length === 0) return [];

  const scored: DocumentSnippet[] = [];
  for (const item of candidates) {
    const text = item.text.trim();
    if (!text) continue;
    const chunks: string[] = [];
    for (let i = 0; i < text.length; i += 450) {
      chunks.push(text.slice(i, i + 550));
    }
    for (const chunk of chunks) {
      const hay = `${item.title} ${chunk}`.toLowerCase();
      let score = 0;
      for (const w of qWords) {
        if (hay.includes(w)) score += w.length >= 5 ? 2 : 1;
      }
      if (score > 0 || qWords.length === 0) {
        scored.push({
          sourceTitle: item.title,
          excerpt: chunk.trim(),
          score,
        });
      }
    }
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, maxSnippets);
}
